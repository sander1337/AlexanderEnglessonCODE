#pragma once
#include <tge/math/Matrix.h>
#include "tge/math/color.h"

class Bound;
class GameObject;
// Type of Colliders
class SphereCollider;
class CapsuleCollider;
class BoxCollider;

struct NumberRange
{
	NumberRange();
	NumberRange(float aMin, float aMax);
	float min;
	float max;
	void InsertValue(float aValue);
	void MergeRanges(const NumberRange& anOtherRange);
	
	[[nodiscard]] bool IsOverlapping(const NumberRange& anOtherRange) const
	{
		return min <= anOtherRange.max && max >= anOtherRange.min;
	}
	[[nodiscard]] float GetOverlapLength(const NumberRange& anOtherRange) const;
};

class Collider
{
public:

	Collider(const std::shared_ptr<GameObject>& anOwner, const Tga::Vector3f& anOffset)
		: myOwner(anOwner), myOffset(anOffset)
	{
	}
	virtual ~Collider() = default;

	// Setters

	// Getters
	Tga::Matrix4x4f GetTransform() const;
	Tga::Vector3f GetOffset() const;
	Tga::Vector3f GetPosition() const;

	std::shared_ptr<GameObject> GetOwner() const { return myOwner.lock(); }
	Tga::Vector3f GetDirection(const Collider& aCollider) const;

	// Collision Functions
	virtual bool Collision(Collider&) = 0;
	virtual bool Collision(SphereCollider&) = 0;
	virtual bool Collision(BoxCollider&) = 0;
	virtual bool Collision(CapsuleCollider&) = 0;

	// Rigidbody Functions
	virtual Tga::Vector3f SeparateCollision(Collider&) = 0;
	virtual Tga::Vector3f SeparateCollision(SphereCollider&) = 0;
	virtual Tga::Vector3f SeparateCollision(BoxCollider&) = 0;
	virtual Tga::Vector3f SeparateCollision(CapsuleCollider&) = 0;

	virtual std::shared_ptr<Bound> GetBounds() = 0;

	virtual void DebugRender() = 0;
	//todo remove later
	Tga::Color color = { 0.f, 1.f, 0.f };
protected:
	static void DrawProjectionLines(const NumberRange& aRangeA, const NumberRange& aRangeB, const Tga::Vector3f& aPosition, const Tga::Vector3f& anAxis, bool aIsSeparated);
	static NumberRange ProjectLineToAxis(const Tga::Vector3f& aStartPos, const Tga::Vector3f& anEndPos, const Tga::Vector3f& anAxis);
	static NumberRange ProjectSphereToAxis(const Tga::Vector3f& aCenter, float aRadius, const Tga::Vector3f& anAxis);
	static NumberRange ProjectCapsuleToAxis(const Tga::Vector3f& aBottomPos, const Tga::Vector3f& aTopPos, float aRadius, const Tga::Vector3f& anAxis);
	template<size_t Size>
	static NumberRange ProjectPointsToAxis(const std::array<Tga::Vector3f, Size>& somePoints, const Tga::Vector3f& anAxis)
	{
		NumberRange range;
		for (int i = 0; i < Size; ++i)
		{
			range.InsertValue(anAxis.Dot(somePoints[i]));
		}
		return range;
	}
	/** Check if two polyhedrons are separated in an axis
	 * @param somePointsA The vertices of the first polyhedron
	 * @param somePointsB The vertices of the second polyhedron
	 * @param aPosition A position of the object to draw the debug lines on todo: move this somewhere else
	 * @param anAxis The axis or normal to project everything into
	 * @return
	 */
	template<size_t SizeA, size_t SizeB>
	static bool CheckSeparationInAxis(const std::array<Tga::Vector3f, SizeA>& somePointsA, const std::array<Tga::Vector3f, SizeB>& somePointsB, const Tga::Vector3f& aPosition, const Tga::Vector3f& anAxis);
	template<size_t SizeA, size_t SizeB>
	static float GetOverlapInAxis(const std::array<Tga::Vector3f, SizeA>& somePointsA, const std::array<Tga::Vector3f, SizeB>& somePointsB, const Tga::Vector3f& anAxis);
	/** Check if a polyhedron and a sphere are separated in an axis
	 * @param somePoints The vertices of the polyhedron (shape made up of flat faces)
	 * @param aCenter The center position of the sphere
	 * @param aRadius The radius of the sphere
	 * @param anAxis The axis or normal to project everything into
	 * @return
	 */
	template<size_t Size>
	static bool CheckSeparationInAxis(const std::array<Tga::Vector3f, Size>& somePoints, const Tga::Vector3f& aCenter, float aRadius, const Tga::Vector3f& anAxis);
	template<size_t Size>
	static float GetOverlapInAxis(const std::array<Tga::Vector3f, Size>& somePoints, const Tga::Vector3f& aCenter, float aRadius, const Tga::Vector3f& anAxis);
	Tga::Vector3f myOffset;
	std::weak_ptr<GameObject> myOwner;
};

template <size_t SizeA, size_t SizeB>
bool Collider::CheckSeparationInAxis(const std::array<Tga::Vector3f, SizeA>& somePointsA, const std::array<Tga::Vector3f, SizeB>& somePointsB,
	const Tga::Vector3f& aPosition, const Tga::Vector3f& anAxis)
{
	//Project all vertices into normal 
	const NumberRange rangeA = Collider::ProjectPointsToAxis(somePointsA, anAxis);
	const NumberRange rangeB = Collider::ProjectPointsToAxis(somePointsB, anAxis);

	//Check if seperated
	const bool isSeparated = !rangeA.IsOverlapping(rangeB);
	DrawProjectionLines(rangeA, rangeB, aPosition, anAxis, isSeparated);
	return isSeparated;
}

template <size_t SizeA, size_t SizeB>
float Collider::GetOverlapInAxis(const std::array<Tga::Vector3f, SizeA>& somePointsA, const std::array<Tga::Vector3f, SizeB>& somePointsB, const Tga::Vector3f& anAxis)
{
	//Project all vertices into normal 
	const NumberRange rangeA = Collider::ProjectPointsToAxis(somePointsA, anAxis);
	const NumberRange rangeB = Collider::ProjectPointsToAxis(somePointsB, anAxis);

	return rangeA.GetOverlapLength(rangeB);
}

template <size_t Size>
bool Collider::CheckSeparationInAxis(const std::array<Tga::Vector3f, Size>& somePoints,
	const Tga::Vector3f& aCenter, const float aRadius, const Tga::Vector3f& anAxis)
{
	//Project everything into normal 
	NumberRange polyRange;// = Collider::ProjectPointsToAxis(somePoints, anAxis);
	for (int i = 0; i < Size; ++i)
	{
		polyRange.InsertValue(anAxis.Dot(somePoints[i] - aCenter));
	}
	const NumberRange sphereRange{ -aRadius, aRadius };// = ProjectSphereToAxis(aCenter, aRadius, anAxis);

	//Check if seperated
	const bool isSeparated = !polyRange.IsOverlapping(sphereRange);
	DrawProjectionLines(polyRange, sphereRange, aCenter, anAxis, isSeparated);

	return isSeparated;
}

template <size_t Size>
float Collider::GetOverlapInAxis(const std::array<Tga::Vector3f, Size>& somePoints, const Tga::Vector3f& aCenter, float aRadius, const Tga::Vector3f& anAxis)
{
	//Project everything into normal 
	NumberRange polyRange;
	for (int i = 0; i < Size; ++i)
	{
		polyRange.InsertValue(anAxis.Dot(somePoints[i] - aCenter));
	}
	const NumberRange sphereRange{ -aRadius, aRadius };

	return polyRange.GetOverlapLength(sphereRange);
}