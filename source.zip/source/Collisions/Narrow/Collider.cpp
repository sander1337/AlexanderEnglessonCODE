﻿#include <stdafx.h>
#include "Collider.h"
#include "../../Objects/GameObject.h"
#include "tge/drawers/DebugDrawer.h"

NumberRange::NumberRange() : min(std::numeric_limits<float>::max()), max(std::numeric_limits<float>::lowest()) //lowest() is the negative equivalent to max()
{
}

NumberRange::NumberRange(const float aMin, const float aMax) : min(aMin), max(aMax)
{
}

void NumberRange::InsertValue(const float aValue)
{
    min = std::min(min, aValue);
    max = std::max(max, aValue);
}

void NumberRange::MergeRanges(const NumberRange& anOtherRange)
{
    InsertValue(anOtherRange.min);
    InsertValue(anOtherRange.max);
}

float NumberRange::GetOverlapLength(const NumberRange& anOtherRange) const
{
    if (IsOverlapping(anOtherRange))
    {
        return std::min(max, anOtherRange.max) - std::max(min, anOtherRange.min);
    }
    return 0.f;
}

Tga::Matrix4x4f Collider::GetTransform() const
{
    Tga::Matrix4x4f transform = myOwner.lock()->GetTransform();
    return transform.Translate(myOffset * Tga::Matrix3x3f(transform));
}

Tga::Vector3f Collider::GetOffset() const
{
    return myOffset;
}

Tga::Vector3f Collider::GetPosition() const
{
    auto gameObject = myOwner.lock();
    return gameObject->GetPosition() + (myOffset * Tga::Matrix3x3f(gameObject->GetTransform()));
}

Tga::Vector3f Collider::GetDirection(const Collider& aCollider) const
{
    return Tga::Vector3f(aCollider.GetPosition() - GetPosition()).GetNormalized();
}

void Collider::DrawProjectionLines(const NumberRange& aRangeA, const NumberRange& aRangeB, const Tga::Vector3f& aPosition, const Tga::Vector3f& anAxis, const bool aIsSeparated)
{
    auto& dbg = Tga::Engine::GetInstance()->GetDebugDrawer();
    dbg.DrawLine(anAxis * aRangeA.min + aPosition, anAxis * aRangeA.max + aPosition, { 0.f, 0.f, 1.f });
    dbg.DrawLine(anAxis * aRangeB.min + aPosition, anAxis * aRangeB.max + aPosition, { 1.f, 0.f, aIsSeparated ? 0.f : 1.f });
}

NumberRange Collider::ProjectSphereToAxis(const Tga::Vector3f& aCenter, const float aRadius, const Tga::Vector3f& anAxis)
{
    const float projectedCenter = anAxis.Dot(aCenter);
    //Since a sphere should be of equal radius on all sides, we can assume that no distortion happens when we project it. So we can just add and subtract the radius from the range.
    return { projectedCenter - aRadius, projectedCenter + aRadius };
}

NumberRange Collider::ProjectCapsuleToAxis(const Tga::Vector3f& aBottomPos, const Tga::Vector3f& aTopPos, float aRadius, const Tga::Vector3f& anAxis)
{
    NumberRange range = ProjectLineToAxis(aBottomPos, aTopPos, anAxis);
    range.min -= aRadius;
    range.max += aRadius;
    return range;
}

NumberRange Collider::ProjectLineToAxis(const Tga::Vector3f& aStartPos, const Tga::Vector3f& anEndPos, const Tga::Vector3f& anAxis)
{
    NumberRange range;
    range.InsertValue(anAxis.Dot(aStartPos));
    range.InsertValue(anAxis.Dot(anEndPos));
    return range;
}