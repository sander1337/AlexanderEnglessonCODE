﻿#pragma once

#include "tge/Math/Vector3.h"
struct Ray;
class SphereCollider;
class CapsuleCollider;
class BoxCollider;

class Raycast
{
public:
	static bool IsRayOverlapping(const Ray& aRay, const SphereCollider& aCollider);
	static bool IsRayOverlapping(const Ray& aRay, const BoxCollider& aCollider);
	static bool IsRayOverlapping(const Ray& aRay, const CapsuleCollider& aCollider);
	static bool RaySphereIntersect(const Ray& aRay, const Tga::Vector3f& aSphereCenter, float aSphereRadius);
};
