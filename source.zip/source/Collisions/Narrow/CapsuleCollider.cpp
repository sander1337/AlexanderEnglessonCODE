#include "stdafx.h"
#include "CapsuleCollider.h"

#include <algorithm>

#include "BoxCollider.h"
#include "SphereCollider.h"
#include "tge/Engine.h"
#include "tge/drawers/DebugDrawer.h"
#include "../Broad/BoundingBox.h"

using Tga::Vector3f;
using Tga::Matrix4x4f;

bool CapsuleCollider::Collision(Collider& anOther)
{
	return anOther.Collision(*this);
}

bool CapsuleCollider::Collision(SphereCollider& anOther)
{
	return anOther.Collision(*this);
}

bool CapsuleCollider::Collision(BoxCollider& anOther)
{
	const std::array<Vector3f, 8>& otherCorners = anOther.GetCorners();
	const Vector3f position = GetPosition();
	float halfHeight = (myHeight / 2.f);
	Vector3f topSphereCenter = position + (myDirection * halfHeight);
	Vector3f bottomSphereCenter = position + (-myDirection * halfHeight);
	const Matrix4x4f otherTransform = anOther.GetTransform();
	
	const Vector3f otherRightNorm = otherTransform.GetRight().GetNormalized();
	const Vector3f otherUpNorm = otherTransform.GetUp().GetNormalized();
	const Vector3f otherForwardNorm = otherTransform.GetForward().GetNormalized();

	const std::array allAxis =
	{
	//Main normals:
		otherRightNorm,
		otherUpNorm,
		otherForwardNorm,
	//Cross product of objects normals against other objects normals: 
		myDirection.Cross(otherRightNorm).GetNormalized(),
		myDirection.Cross(otherUpNorm).GetNormalized(),
		myDirection.Cross(otherForwardNorm).GetNormalized()
	};
	for (const Vector3f& axis : allAxis)
	{
		//Project all vertices into normal 
		NumberRange capsuleRange = ProjectLineToAxis(bottomSphereCenter, topSphereCenter, axis);
		capsuleRange.min -= myRadius;
		capsuleRange.max += myRadius;
		const NumberRange cubeRange = ProjectPointsToAxis(otherCorners, axis);
		
		//Check if seperated
		if (!capsuleRange.IsOverlapping(cubeRange))
		{
			return false;
		}
	}
	return true;
}

bool CapsuleCollider::Collision(CapsuleCollider& anOther)
{
	const Vector3f position = GetPosition();
	const float halfHeight = myHeight / 2.f;
	const Vector3f bottomPosition = position + (-myDirection * halfHeight);
	const Vector3f topPosition = position + (myDirection * halfHeight);
	const Vector3f otherPosition = anOther.GetPosition();
	const float otherHalfHeight = anOther.myHeight / 2.f;
	const Vector3f otherBottomPosition = otherPosition + (-anOther.myDirection * otherHalfHeight);
	const Vector3f otherTopPosition = otherPosition + (anOther.myDirection * otherHalfHeight);
	
	const Vector3f direction = myDirection.GetNormalized();
	const Vector3f otherDirection = anOther.myDirection.GetNormalized();
	
	const std::array allAxis =
	{
		direction,
		otherDirection,
		(otherBottomPosition - bottomPosition).GetNormalized(),
		(otherTopPosition - topPosition).GetNormalized()	
	};

	for (const Vector3f& axis : allAxis)
	{
		const NumberRange capsuleRange = ProjectCapsuleToAxis(bottomPosition, topPosition, myRadius, axis);
		const NumberRange otherCapsuleRange = ProjectCapsuleToAxis(otherBottomPosition, otherTopPosition, anOther.myRadius, axis);
		//Check if seperated
		if (!capsuleRange.IsOverlapping(otherCapsuleRange))
		{
			return false;
		}
	}
	return true;
}

Tga::Vector3f CapsuleCollider::SeparateCollision(Collider& anOther)
{
	return anOther.SeparateCollision(*this);
}

Tga::Vector3f CapsuleCollider::SeparateCollision(SphereCollider& anOther)
{
	return -anOther.SeparateCollision(*this);
}

Tga::Vector3f CapsuleCollider::SeparateCollision(BoxCollider& anOther)
{
	const std::array<Vector3f, 8>& otherCorners = anOther.GetCorners();
	const Vector3f position = GetPosition();
	float halfHeight = myHeight / 2.f;
	Vector3f topSphereCenter = position + (myDirection * halfHeight);
	Vector3f bottomSphereCenter = position + (-myDirection * halfHeight);
	const Matrix4x4f otherTransform = anOther.GetTransform();
	const Vector3f otherPosition = otherTransform.GetPosition();
	
	const Vector3f otherRightNorm = otherTransform.GetRight().GetNormalized();
	const Vector3f otherUpNorm = otherTransform.GetUp().GetNormalized();
	const Vector3f otherForwardNorm = otherTransform.GetForward().GetNormalized();

	const std::array allAxis =
	{
	//Main normals:
		otherRightNorm,
		otherUpNorm,
		otherForwardNorm,
	//Cross product of objects normals against other objects normals: 
		myDirection.Cross(otherRightNorm).GetNormalized(),
		myDirection.Cross(otherUpNorm).GetNormalized(),
		myDirection.Cross(otherForwardNorm).GetNormalized()
	};
	
	float separationLength = std::numeric_limits<float>::max();
	Vector3f separationAxis;
	for (const Vector3f& axis : allAxis)
	{
		const NumberRange capsuleRange = ProjectCapsuleToAxis(bottomSphereCenter, topSphereCenter, myRadius, axis);
		const NumberRange cubeRange = ProjectPointsToAxis(otherCorners, axis);
		const float overlap = capsuleRange.GetOverlapLength(cubeRange);
		if (overlap <= 0.f)
		{
			if (axis.LengthSqr() == 0.f)
			{
				continue;
			}
			return { 0.f };
		}
		if (overlap < separationLength)
		{
			separationLength = overlap;
			separationAxis = axis;
		}
	}

	//Calculate if other object should be pulled in axis instead of pushed:  
	if (separationAxis.Dot(otherPosition) <= separationAxis.Dot(position))
	{
		separationLength = -separationLength;
	}
	return separationAxis * separationLength;
}

Tga::Vector3f CapsuleCollider::SeparateCollision(CapsuleCollider& anOther)
{
	const Vector3f position = GetPosition();
	const float halfHeight = myHeight / 2.f;
	const Vector3f bottomPosition = position + (-myDirection * halfHeight);
	const Vector3f topPosition = position + (myDirection * halfHeight);
	const Vector3f otherPosition = anOther.GetPosition();
	const float otherHalfHeight = anOther.myHeight / 2.f;
	const Vector3f otherBottomPosition = otherPosition + (-anOther.myDirection * otherHalfHeight);
	const Vector3f otherTopPosition = otherPosition + (anOther.myDirection * otherHalfHeight);
	
	const Vector3f direction = myDirection.GetNormalized();
	const Vector3f otherDirection = anOther.myDirection.GetNormalized();
	const std::array allAxis =
	{
		direction,
		otherDirection,
		(otherBottomPosition - bottomPosition).GetNormalized(),
		(otherTopPosition - topPosition).GetNormalized()	
	};
	
	float separationLength = std::numeric_limits<float>::max();
	Vector3f separationAxis;
	for (const Vector3f& axis : allAxis)
	{
		if (axis.LengthSqr() == 0.f)
		{
			continue;
		}
		const NumberRange capsuleRange = ProjectCapsuleToAxis(bottomPosition, topPosition, myRadius, axis);
		const NumberRange otherCapsuleRange = ProjectCapsuleToAxis(otherBottomPosition, otherTopPosition, anOther.myRadius, axis);
		const float overlap = capsuleRange.GetOverlapLength(otherCapsuleRange);
		DrawProjectionLines(capsuleRange, otherCapsuleRange, position, axis, overlap > 0.f);
		if (overlap <= 0.f)
		{
			return { 0.f };
		}
		if (overlap < separationLength)
		{
			separationLength = overlap;
			separationAxis = axis;
		}
	}
	//Calculate if other object should be pulled in axis instead of pushed:  
	if (separationAxis.Dot(otherPosition) <= separationAxis.Dot(position))
	{
		separationLength = -separationLength;
	}
	return separationAxis * separationLength;
}

std::shared_ptr<Bound> CapsuleCollider::GetBounds()
{
	float halfHeight = (myHeight / 2.f);
	Vector3f position = GetPosition();
	Vector3f topCenter = position + (myDirection * halfHeight);
	Vector3f bottomCenter = position + (-myDirection * halfHeight);
	Vector3f min = topCenter;
	Vector3f max = topCenter;
	
	min.x = std::min(min.x, bottomCenter.x);
	min.y = std::min(min.y, bottomCenter.y);
	min.z = std::min(min.z, bottomCenter.z);
	max.x = std::max(max.x, bottomCenter.x);
	max.y = std::max(max.y, bottomCenter.y);
	max.z = std::max(max.z, bottomCenter.z);

	min += Vector3f{-myRadius};
	max += Vector3f{myRadius};
	return std::make_shared<BoundingBox>(min, max);
}

void CapsuleCollider::DebugRender()
{
	Tga::Engine::GetInstance()->GetDebugDrawer().DrawCapsule(GetPosition(), myRadius, myHeight, myDirection, {0.f, 1.f, 0.f});
}

Tga::Vector3f CapsuleCollider::ClosestPointOnLineSegment(const Tga::Vector3f& aLineStart, const Tga::Vector3f& aLineEnd, const Tga::Vector3f& aPoint)
{
	Vector3f AB = aLineEnd - aLineStart;
	float t = AB.Dot(aPoint - aLineStart) / AB.LengthSqr();
	return std::clamp(t, 0.f, 1.f) * AB + aLineStart;
}