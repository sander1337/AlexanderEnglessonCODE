#pragma once
#include "Collider.h"

class BoxCollider : public Collider
{
public:
	
	BoxCollider(const std::shared_ptr<GameObject>& anOwner, const Tga::Vector3f& anOffset, const Tga::Vector3f& aSize)
		: Collider(anOwner, anOffset), myHalfSize(aSize / 2.f)
	{
	}

	bool Collision(Collider&) override;
	bool Collision(SphereCollider&) override;
	bool Collision(BoxCollider&) override;
	bool Collision(CapsuleCollider&) override;
	
	Tga::Vector3f SeparateCollision(Collider&) override;
	Tga::Vector3f SeparateCollision(SphereCollider&) override;
	Tga::Vector3f SeparateCollision(BoxCollider&) override;
	Tga::Vector3f SeparateCollision(CapsuleCollider&) override;
	
	void DebugRender() override;
	std::shared_ptr<Bound> GetBounds() override;
	
	const std::array<Tga::Vector3f, 8>& GetCorners();
	Tga::Vector3f GetHalfSize() const {return myHalfSize;}
	Tga::Vector3f GetSize() const {return myHalfSize * 2.f;}
	
private:
	void UpdateBuffer();
	Tga::Vector3f myHalfSize;
	Tga::Matrix4x4f myBufferedTransform;
	std::array<Tga::Vector3f, 8> myBufferedCorners;
};