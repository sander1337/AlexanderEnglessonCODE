#pragma once
#include "Collider.h"

class CapsuleCollider : public Collider
{
	friend class Raycast;
public:
	CapsuleCollider(const std::shared_ptr<GameObject>& anOwner, const Tga::Vector3f& anOffset, float aRadius, float aHeight, const Tga::Vector3f& aDirection)
		: Collider(anOwner, anOffset), myRadius(aRadius), myHeight(aHeight), myDirection(aDirection) {}

	bool Collision(Collider&) override;
	bool Collision(SphereCollider&) override;
	bool Collision(BoxCollider&) override;
	bool Collision(CapsuleCollider&) override;
	Tga::Vector3f SeparateCollision(Collider&) override;
	Tga::Vector3f SeparateCollision(SphereCollider&) override;
	Tga::Vector3f SeparateCollision(BoxCollider&) override;
	Tga::Vector3f SeparateCollision(CapsuleCollider&) override;
	std::shared_ptr<Bound> GetBounds() override;
	void DebugRender() override;

private:
	static Tga::Vector3f ClosestPointOnLineSegment(const Tga::Vector3f& aLineStart, const Tga::Vector3f& aLineEnd, const Tga::Vector3f& aPoint);
	float myRadius;
	float myHeight;
	Tga::Vector3f myDirection;
};