﻿#include "stdafx.h"
#include "Raycast.h"

#include <algorithm>

#include "CapsuleCollider.h"
#include "SphereCollider.h"
#include "tge/graphics/Camera.h"

using Tga::Vector3f;
using Tga::Matrix4x4f;

bool Raycast::IsRayOverlapping(const Ray& aRay, const SphereCollider& aCollider)
{
	const Vector3f colPosition = aCollider.GetPosition();
	const Vector3f posDifference = colPosition - aRay.origin;
	//"Base" as in base of triangle
	const float baseLength = posDifference.Dot(aRay.direction);
	Vector3f closestPointInRay = aRay.origin + aRay.direction * baseLength;
	return Vector3f::Distance(closestPointInRay, colPosition) <= aCollider.GetRadius();
}


bool Raycast::IsRayOverlapping(const Ray& aRay, const CapsuleCollider& aCollider)
{
	//Translated code to C++ from https://github.com/sketchpunk/FunWithWebGL2/blob/master/lesson_049/test.html#L100
	//
	//Get Capsule's line segment and move it to world space
	const Vector3f capPos = aCollider.GetPosition();
	float halfHeight = aCollider.myHeight / 2.f;
	const Vector3f topPos = capPos + (aCollider.myDirection * halfHeight),
				   bottomPos = capPos + (aCollider.myDirection * -halfHeight);

	//Start calculating lengths and cross products
	Vector3f AB		= bottomPos - topPos,		//From top to bottom
			 AO		= aRay.origin - topPos,		//From top to ray origin
			 AOxAB	= AO.Cross(AB),				//Normal of top to ray origin & capsule line
			 RxAB 	= aRay.direction.Cross(AB);	//Normal of ray direction & capsule line
	float	 ab2	= AB.LengthSqr(),
			 a		= RxAB.LengthSqr(),
			 b		= 2 * RxAB.Dot(AOxAB),
			 c		= AOxAB.Dot(AOxAB) - (aCollider.myRadius * aCollider.myRadius * ab2),
			 d		= b * b - 4 * a * c;

	//Checking D seems to be related to distance from capsule. If not within radius, D will be under 0
	if (d < 0)
	{
		return false;
	}

	//T is less then 0 then ray goes through both end caps cylinder cap.
	auto t = (-b - sqrtf(d)) / (2 * a);
	if(t < 0) 
	{
		return RaySphereIntersect(aRay, (topPos - aRay.origin).LengthSqr() < (bottomPos - aRay.origin).LengthSqr() ? topPos : bottomPos, aCollider.myRadius);
	}

	//Limit intersection between the bounds of the cylinder's end caps.
	Vector3f iPos	 = aRay.direction * t + aRay.origin;
	Vector3f iPosLen = iPos - topPos;
	float tLimit	= iPosLen.Dot(AB) / ab2;
	//Projection of iPos onto Cap Line

	if(tLimit >= 0 && tLimit <= 1)
	{
		return true;//iPos;
	}
	else if(tLimit < 0)
	{
		return RaySphereIntersect(aRay, topPos, aCollider.myRadius);
	} 
	else if(tLimit > 1)
	{
		return RaySphereIntersect(aRay, bottomPos, aCollider.myRadius);
	} 

	return false;
}

bool Raycast::RaySphereIntersect(const Ray& aRay, const Tga::Vector3f& aSphereCenter, const float aSphereRadius)
{
	const Vector3f posDifference = aSphereCenter - aRay.origin;
	const float baseLength = posDifference.Dot(aRay.direction);
	Vector3f closestPointInRay = aRay.origin + aRay.direction * baseLength;
	return Vector3f::Distance(closestPointInRay, aSphereCenter) <= aSphereRadius;
}

bool Raycast::IsRayOverlapping([[maybe_unused]]const Ray& aRay, [[maybe_unused]]const BoxCollider& aCollider)
{
	return true;
}

