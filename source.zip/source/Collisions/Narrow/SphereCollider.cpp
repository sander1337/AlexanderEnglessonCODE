#include "stdafx.h"
#include "SphereCollider.h"
#include "CapsuleCollider.h"
#include "BoxCollider.h"
#include <tge/graphics/GraphicsStateStack.h>

#include "../Broad/BoundingSphere.h"
#include "tge/drawers/DebugDrawer.h"

using Tga::Vector3f;
using Tga::Matrix4x4f;

bool SphereCollider::Collision(Collider& anOther)
{
	return anOther.Collision(*this);
}

bool SphereCollider::Collision(SphereCollider& anOther)
{
	const float radiusSum = myRadius + anOther.myRadius;
	return Vector3f::Distance(GetPosition(), anOther.GetPosition()) <= radiusSum;
}

bool SphereCollider::Collision(BoxCollider& anOther)
{
	const std::array<Vector3f, 8>& corners = anOther.GetCorners();

	Vector3f center = GetPosition();
	if (CheckSeparationInAxis(corners, center, myRadius, (anOther.GetPosition() - center).GetNormalized()))
	{
		return false;
	}
	return true;
}

bool SphereCollider::Collision(CapsuleCollider& anOther)
{
	return anOther.Collision(*this);
}

Tga::Vector3f SphereCollider::SeparateCollision(Collider& anOther)
{
	return anOther.SeparateCollision(*this);
}

Tga::Vector3f SphereCollider::SeparateCollision([[maybe_unused]] SphereCollider& anOther)
{
	return Vector3f();
}

Tga::Vector3f SphereCollider::SeparateCollision([[maybe_unused]] BoxCollider& anOther)
{
	const std::array<Vector3f, 8>& corners = anOther.GetCorners();
	const Vector3f position = GetPosition();
	const Vector3f otherPosition = anOther.GetPosition();
	const Vector3f separationAxis = (otherPosition - position).GetNormalized();
	float separationLength = GetOverlapInAxis(corners, position, myRadius, separationAxis);
	if (separationLength <= 0.f)
	{
		return { 0.f };
	}
	//Calculate if other object should be pulled in axis instead of pushed:  
	if (separationAxis.Dot(otherPosition) <= separationAxis.Dot(position))
	{
		separationLength = -separationLength;
	}
	return separationAxis * separationLength;
}

Tga::Vector3f SphereCollider::SeparateCollision(CapsuleCollider& anOther)
{
	return -anOther.SeparateCollision(*this);
}

void SphereCollider::DebugRender()
{
	Tga::Engine::GetInstance()->GetDebugDrawer().DrawSphere(GetPosition(), myRadius, { 0.f, 1.f, 0.f });
}

std::shared_ptr<Bound> SphereCollider::GetBounds()
{
	return std::make_shared<BoundingSphere>(GetPosition(), myRadius);
}