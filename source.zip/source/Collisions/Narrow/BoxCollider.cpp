#include <stdafx.h>
#include "BoxCollider.h"
#include "SphereCollider.h"
#include "CapsuleCollider.h"
#include "../Broad/BoundingBox.h"
#include "tge/drawers/DebugDrawer.h"

using Tga::Vector3f;
using Tga::Matrix4x4f;

bool BoxCollider::Collision(Collider& anOther)
{
	return anOther.Collision(*this);
}

bool BoxCollider::Collision(SphereCollider& anOther)
{
	return anOther.Collision(*this);
}

//todo Separate function into an optimized check and a debug check

bool BoxCollider::Collision(BoxCollider& anOther)
{
	const std::array<Vector3f, 8>& corners = GetCorners();
	const std::array<Vector3f, 8>& otherCorners = anOther.GetCorners();

	Vector3f position = myBufferedTransform.GetPosition();
	Vector3f otherPosition = anOther.myBufferedTransform.GetPosition();

	const Vector3f rightNorm = myBufferedTransform.GetRight();
	const Vector3f upNorm = myBufferedTransform.GetUp();
	const Vector3f forwardNorm = myBufferedTransform.GetForward();
	const Vector3f otherRightNorm = anOther.myBufferedTransform.GetRight();
	const Vector3f otherUpNorm = anOther.myBufferedTransform.GetUp();
	const Vector3f otherForwardNorm = anOther.myBufferedTransform.GetForward();

	if (
		//Check separation in all main normals
		CheckSeparationInAxis(corners, otherCorners, position, rightNorm) ||
		CheckSeparationInAxis(corners, otherCorners, position, upNorm) ||
		CheckSeparationInAxis(corners, otherCorners, position, forwardNorm) ||
		CheckSeparationInAxis(corners, otherCorners, otherPosition, otherRightNorm) ||
		CheckSeparationInAxis(corners, otherCorners, otherPosition, otherUpNorm) ||
		CheckSeparationInAxis(corners, otherCorners, otherPosition, otherForwardNorm) ||
		//For each normal, check separation in cross product of other objects normals 
		CheckSeparationInAxis(corners, otherCorners, position, rightNorm.Cross(otherRightNorm)) ||
		CheckSeparationInAxis(corners, otherCorners, position, rightNorm.Cross(otherUpNorm)) ||
		CheckSeparationInAxis(corners, otherCorners, position, rightNorm.Cross(otherForwardNorm)) ||
		CheckSeparationInAxis(corners, otherCorners, position, upNorm.Cross(otherRightNorm)) ||
		CheckSeparationInAxis(corners, otherCorners, position, upNorm.Cross(otherUpNorm)) ||
		CheckSeparationInAxis(corners, otherCorners, position, upNorm.Cross(otherForwardNorm)) ||
		CheckSeparationInAxis(corners, otherCorners, position, forwardNorm.Cross(otherRightNorm)) ||
		CheckSeparationInAxis(corners, otherCorners, position, forwardNorm.Cross(otherUpNorm)) ||
		CheckSeparationInAxis(corners, otherCorners, position, forwardNorm.Cross(otherForwardNorm))
		)
	{
		return false;
	}
	return true;
}

bool BoxCollider::Collision(CapsuleCollider& aCapsuleCollider)
{
	return aCapsuleCollider.Collision(*this);
}

Vector3f BoxCollider::SeparateCollision(Collider& anOther)
{
	return anOther.SeparateCollision(*this);
}

Vector3f BoxCollider::SeparateCollision([[maybe_unused]] SphereCollider& anOther)
{
	return -anOther.SeparateCollision(*this);
}

Vector3f BoxCollider::SeparateCollision([[maybe_unused]] BoxCollider& anOther)
{
	const std::array<Vector3f, 8>& corners = GetCorners();
	const std::array<Vector3f, 8>& otherCorners = anOther.GetCorners();
	const Vector3f position = myBufferedTransform.GetPosition();
	const Vector3f otherPosition = anOther.myBufferedTransform.GetPosition();

	const Vector3f rightNorm = myBufferedTransform.GetRight().GetNormalized();
	const Vector3f upNorm = myBufferedTransform.GetUp().GetNormalized();
	const Vector3f forwardNorm = myBufferedTransform.GetForward().GetNormalized();
	const Vector3f otherRightNorm = anOther.myBufferedTransform.GetRight().GetNormalized();
	const Vector3f otherUpNorm = anOther.myBufferedTransform.GetUp().GetNormalized();
	const Vector3f otherForwardNorm = anOther.myBufferedTransform.GetForward().GetNormalized();

	const std::array<Vector3f, 15> allAxis =
	{
		//Main normals:
			rightNorm,
			upNorm,
			forwardNorm,
			otherRightNorm,
			otherUpNorm,
			otherForwardNorm,
		//Cross product of objects normals against other objects normals: 
			rightNorm.Cross(otherRightNorm),
			rightNorm.Cross(otherUpNorm),
			rightNorm.Cross(otherForwardNorm),
			upNorm.Cross(otherRightNorm),
			upNorm.Cross(otherUpNorm),
			upNorm.Cross(otherForwardNorm),
			forwardNorm.Cross(otherRightNorm),
			forwardNorm.Cross(otherUpNorm),
			forwardNorm.Cross(otherForwardNorm)
	};

	float separationLength = std::numeric_limits<float>::max();
	Vector3f separationAxis;

	for (const Vector3f& axis : allAxis)
	{
		float overlap = GetOverlapInAxis(corners, otherCorners, axis);
		if (overlap <= 0.f)
		{
			if (axis.LengthSqr() == 0.f)
			{
				continue;
			}
			else
			{
				return { 0.f };
			}
		}
		if (overlap < separationLength)
		{
			separationLength = overlap;
			separationAxis = axis;
		}
	}
	//Calculate if other object should be pulled in axis instead of pushed:  
	if (separationAxis.Dot(otherPosition) <= separationAxis.Dot(position))
	{
		separationLength = -separationLength;
	}
	return separationAxis * separationLength;
}

Tga::Vector3f BoxCollider::SeparateCollision(CapsuleCollider& anOther)
{
	return -anOther.SeparateCollision(*this);
}

void BoxCollider::DebugRender()
{
	Tga::Engine::GetInstance()->GetDebugDrawer().DrawCube(GetTransform(), GetSize(), color);
}

std::shared_ptr<Bound> BoxCollider::GetBounds()
{
	Vector3f min{ std::numeric_limits<float>::max() };
	Vector3f max{ std::numeric_limits<float>::lowest() };

	UpdateBuffer();
	for (auto& corner : myBufferedCorners)
	{
		min.x = std::min(min.x, corner.x);
		min.y = std::min(min.y, corner.y);
		min.z = std::min(min.z, corner.z);
		max.x = std::max(max.x, corner.x);
		max.y = std::max(max.y, corner.y);
		max.z = std::max(max.z, corner.z);
	}
	return std::make_shared<BoundingBox>(min, max);
}

void BoxCollider::UpdateBuffer()
{
	const Matrix4x4f transform = GetTransform();
	if (myBufferedTransform != transform) //Check if buffer is not up to date/valid
	{
		myBufferedTransform = transform;
		myBufferedCorners[0] = Vector3f{ -myHalfSize.x, -myHalfSize.y, -myHalfSize.z } *myBufferedTransform;
		myBufferedCorners[1] = Vector3f{ -myHalfSize.x, -myHalfSize.y, myHalfSize.z } *myBufferedTransform;
		myBufferedCorners[2] = Vector3f{ -myHalfSize.x, myHalfSize.y, -myHalfSize.z } *myBufferedTransform;
		myBufferedCorners[3] = Vector3f{ -myHalfSize.x, myHalfSize.y, myHalfSize.z } *myBufferedTransform;
		myBufferedCorners[4] = Vector3f{ myHalfSize.x, -myHalfSize.y, myHalfSize.z } *myBufferedTransform;
		myBufferedCorners[5] = Vector3f{ myHalfSize.x, -myHalfSize.y, -myHalfSize.z } *myBufferedTransform;
		myBufferedCorners[6] = Vector3f{ myHalfSize.x, myHalfSize.y, myHalfSize.z } *myBufferedTransform;
		myBufferedCorners[7] = Vector3f{ myHalfSize.x, myHalfSize.y, -myHalfSize.z } *myBufferedTransform;
	}
}

const std::array<Vector3f, 8>& BoxCollider::GetCorners()
{
	UpdateBuffer();
	return myBufferedCorners;
}