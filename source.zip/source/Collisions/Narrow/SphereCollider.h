#pragma once
#include "Collider.h"

class SphereCollider : public Collider
{
public:
	SphereCollider(const std::shared_ptr<GameObject>& anOwner,  const Tga::Vector3f& anOffset, float aRadius)
		: Collider(anOwner, anOffset), myRadius(aRadius)
	{
	}

	bool Collision(Collider&) override;
	bool Collision(SphereCollider&) override;
	bool Collision(BoxCollider&) override;
	bool Collision(CapsuleCollider&) override;
	Tga::Vector3f SeparateCollision(Collider&) override;
	Tga::Vector3f SeparateCollision(SphereCollider&) override;
	Tga::Vector3f SeparateCollision(BoxCollider&) override;
	Tga::Vector3f SeparateCollision(CapsuleCollider&) override;
	
	void DebugRender() override;
	std::shared_ptr<Bound> GetBounds() override;
	
	float GetRadius() const { return myRadius; }

private:
	float myRadius;
};