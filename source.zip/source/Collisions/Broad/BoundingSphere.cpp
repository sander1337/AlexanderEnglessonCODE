﻿#include "stdafx.h"
#include "BoundingSphere.h"
#include "BoundingBox.h"
#include <algorithm>

bool BoundingSphere::CheckOverlap(const Bound& anOther) const
{
    return anOther.CheckOverlap(*this);
}

bool BoundingSphere::CheckOverlap(const BoundingBox& anOther) const
{
    //Sphere on AABB collision detection
    Tga::Vector3f positionInBox =
    {
        std::clamp(myPosition.x, anOther.myMin.x, anOther.myMax.x),
        std::clamp(myPosition.y, anOther.myMin.y, anOther.myMax.y),
        std::clamp(myPosition.z, anOther.myMin.z, anOther.myMax.z),
    };
    return Tga::Vector3f::Distance(myPosition, positionInBox) < myRadius;
}

bool BoundingSphere::CheckOverlap(const BoundingSphere& anOther) const
{
    //Sphere on sphere collision detection
    return Tga::Vector3f::Distance(myPosition, anOther.myPosition) < (myRadius + anOther.myRadius);
}
