﻿#include "stdafx.h"
#include "BoundingBox.h"
#include "BoundingSphere.h"

bool BoundingBox::CheckOverlap(const Bound& anOther) const
{
    return anOther.CheckOverlap(*this);
}

bool BoundingBox::CheckOverlap(const BoundingBox& anOther) const
{
    //AABB on AABB collision detection
    return	myMin.X <= anOther.myMax.X &&
            myMax.X >= anOther.myMin.X &&
            myMin.Y <= anOther.myMax.Y &&
            myMax.Y >= anOther.myMin.Y &&
            myMin.Z <= anOther.myMax.Z &&
            myMax.Z >= anOther.myMin.Z;
}

bool BoundingBox::CheckOverlap(const BoundingSphere& anOther) const
{
    return anOther.CheckOverlap(*this);
}