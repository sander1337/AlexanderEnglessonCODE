#pragma once
#include "Bound.h"
#include "tge/math/Vector3.h"

class BoundingSphere : public Bound
{
public:
    BoundingSphere(const Tga::Vector3f& aPosition, float aRadius)
        : myPosition(aPosition),
          myRadius(aRadius) {}

    bool CheckOverlap(const Bound&) const override;
    bool CheckOverlap(const BoundingBox&) const override;
    bool CheckOverlap(const BoundingSphere&) const override;
    
private:
    friend class BoundingBox;
    Tga::Vector3f myPosition;
    float myRadius;
};