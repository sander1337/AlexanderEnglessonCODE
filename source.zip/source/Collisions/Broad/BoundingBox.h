#pragma once
#include "Bound.h"
#include "tge/math/Vector3.h"

class BoundingBox : public Bound
{
public:
	BoundingBox(const Tga::Vector3f& aMin, const Tga::Vector3f& aMax)
		: myMin(aMin),
		  myMax(aMax) {}

	bool CheckOverlap(const Bound&) const override;
	bool CheckOverlap(const BoundingBox&) const override;
	bool CheckOverlap(const BoundingSphere&) const override;

private:
	friend class BoundingSphere;
	Tga::Vector3f myMin;
	Tga::Vector3f myMax;
};
