﻿#pragma once

class BoundingSphere;
class BoundingBox;

class Bound
{
public:
    virtual bool CheckOverlap(const Bound&) const = 0;
    virtual bool CheckOverlap(const BoundingBox&) const = 0;
    virtual bool CheckOverlap(const BoundingSphere&) const = 0;
protected:
    friend class BoundingBox;
    friend class BoundingSphere;
};
