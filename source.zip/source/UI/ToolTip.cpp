#include "ToolTip.h"
#include <tge/engine.h>
#include <tge/drawers/SpriteDrawer.h>
#include <tge/graphics/GraphicsEngine.h>
#include <tge/texture/TextureManager.h>
//#include <tge/scene/SceneObjectDefinitionManager.h>
#include <tge/scene/SceneObjectDefinition.h>
#include <tge/scene/SceneObject.h>

using namespace Tga;

void ToolTip::Init(const Tga::SceneObject& aSceneObject, const std::vector<Tga::ScenePropertyDefinition>& someProperties)
{
	for (auto& property : someProperties)
	{
		if (property.type == GetPropertyType<CopyOnWriteWrapper<Tga::SceneText>>())
		{
			Tga::SceneText values = property.value.Get<CopyOnWriteWrapper<Tga::SceneText>>()->Get();
			Tga::Text text(values.fontPath.GetString(), values.fontSize);
			text.SetText(values.text.GetString());
			Tga::Vector2f textPos = values.localPosition;
			textPos.x -= text.GetWidth() * 0.5f;
			text.SetPosition(textPos);
			text.SetColor(values.color);
			myText = text;
		}
		else if (property.type == GetPropertyType<CopyOnWriteWrapper<SceneSprite>>())
		{
			Tga::SceneSprite sprite = property.value.Get<CopyOnWriteWrapper<SceneSprite>>()->Get();
			mySpriteSharedData.myTexture = Tga::Engine::GetInstance()->GetTextureManager().GetTexture(sprite.textures[0].GetString());

			Tga::Vector3f scale = aSceneObject.GetScale();
			mySpriteInstance.myIsHidden = false;
			mySpriteInstance.mySize = { sprite.size.x * scale.x, sprite.size.y * scale.y };
			mySpriteInstance.myTransform = Tga::SpriteTransformFromSceneObject(aSceneObject, sprite.size, sprite.pivot);
		}
		if (property.type == GetPropertyType<CopyOnWriteWrapper<HUDData>>())
		{
			myHUDType = property.value.Get<CopyOnWriteWrapper<HUDData>>()->Get().hudType;
		}
	}
}

void ToolTip::Render()
{
	if (myIsHovered)
	{
		Tga::Engine::GetInstance()->GetGraphicsEngine().GetSpriteDrawer().Draw(mySpriteSharedData, mySpriteInstance);
		myText.Render();
	}
}

void ToolTip::ReceiveEvent(const Message& aMessage)
{
	if (std::get<HUDType>(aMessage.data) != myHUDType)
		return;

	switch (aMessage.eventType)
	{
		case Event::ShowToolTip:
		{
			myIsHovered = true;
			break;
		}
		case Event::HideToolTip:
		{
			myIsHovered = false;
			break;
		}
	}
}

void ToolTip::RegisterEvent()
{
	EventManager::GetInstance()->Subscribe(Event::ShowToolTip, this);
	EventManager::GetInstance()->Subscribe(Event::HideToolTip, this);
}

void ToolTip::UnregisterEvent()
{
	EventManager::GetInstance()->UnSubscribe(Event::ShowToolTip, this);
	EventManager::GetInstance()->UnSubscribe(Event::HideToolTip, this);
}