﻿#include "stdafx.h"
#include "Button.h"

#include "tge/engine.h"
#include <tge/texture/TextureManager.h>
#include <tge/script/BaseProperties.h>
#include <tge/scene/ScenePropertyTypes.h>
#include <tge/graphics/GraphicsEngine.h>
#include <tge/graphics/GraphicsStateStack.h>
#include <tge/scene/SceneObjectDefinition.h>
#include <tge/drawers/SpriteDrawer.h>
#include <tge/scene/SceneObject.h>

#include "../Events/EventManager.h"
#include "../States/StateStack.h"
#include "../States/State.h"
#include "../source/SceneManagement/SceneID.h"
#include "../source/Utilities/BlackBoard.h"
#include "../Render/RenderManager.h"
#include "../GameWorld.h"
#include "../Audio/AudioManager.h"
#include "../source/Utilities/ConstantIdentifiers.h"
#include <tge/drawers/DebugDrawer.h>

using namespace Tga;

Button::Button() {}
Button::~Button() {}

void Button::Init(const Tga::SceneObject& aSceneObject, const std::vector<ScenePropertyDefinition>& someProperties)
{
	myCanBeClicked = true;

	Tga::Vector2ui resolution = Tga::Engine::GetInstance()->GetRenderSize();
	myPosition = Tga::Vector2f{ 0.5f * (float)resolution.x, 0.5f * (float)resolution.y };
	myPosition = { aSceneObject.GetPosition().x, aSceneObject.GetPosition().y };
	myTransform = aSceneObject.GetTransform();
	Tga::Vector3f scale = aSceneObject.GetScale();
	Tga::Vector2f colliderSize = Tga::Vector2f{ 0.f,0.f };

	Tga::Color color(1.f, 1.f, 1.f, 1.f);
	for (int i = 0; i < static_cast<int>(ButtonColor::Count); i++)
	{
		switch (static_cast<ButtonColor>(i))
		{
		case ButtonColor::DefaultColor:
		{
			color = { 0.7f,0.7f,0.7f,1.f };
			break;
		}
		case ButtonColor::HoverColor:
		{
			color = { 1.f,1.f,1.f,1.f };
			break;
		}
		case ButtonColor::ClickedColor:
		{
			color = { 0.3f,0.3f,0.3f,1.f };
			break;
		}
		}
		myColors.emplace_back(color);
	}

	for (auto& property : someProperties)
	{
		if (property.name == "Unlocked"_tgaid)
		{
			myCanBeClicked = *property.value.Get<bool>();
		}
		else if (property.type == GetPropertyType<CopyOnWriteWrapper<GameSpriteData>>())
		{
			mySprite.Init(property.value.Get<CopyOnWriteWrapper<GameSpriteData>>()->Get(), aSceneObject);
			mySprite.SetColor(myColors[static_cast<int>(ButtonColor::DefaultColor)]);
			myHalfSize = mySprite.GetSize() * 0.5f;
		}
		else if (property.type == GetPropertyType<CopyOnWriteWrapper<SceneText>>())
		{
			Tga::SceneText values = property.value.Get<CopyOnWriteWrapper<SceneText>>()->Get();
			Tga::Text text(values.fontPath.GetString(), values.fontSize);
			text.SetText(values.text.GetString());
			Tga::Vector2f textPos = values.localPosition;
			textPos.x -= text.GetWidth() * 0.5f;
			text.SetPosition(textPos);
			text.SetColor(values.color);
			myTexts.push_back(text);
		}
		else if (property.type == GetPropertyType<CopyOnWriteWrapper<ColliderData>>())
		{
			Tga::ColliderData values = property.value.Get<CopyOnWriteWrapper<ColliderData>>()->Get();
			colliderSize = Tga::Vector2f{ values.boxSize.x, values.boxSize.y } *0.5f * Tga::Vector2f{ scale.x, scale.y };
		}
	}

	if (myCanBeClicked)
	{
		mySprite.PlayAnimation("Default"_tgaid);
	}
	else
	{
		mySprite.PlayAnimation("Locked"_tgaid);
	}
	myIsBeingClicked = false;

	if (colliderSize.Length() >= 0.1f)
		myHalfSize = colliderSize;
}

void Button::Render()
{
	Tga::GraphicsStateStack& graphicsStateStack = Tga::Engine::GetInstance()->GetGraphicsEngine().GetGraphicsStateStack();

	graphicsStateStack.Push();
	mySprite.UpdateAndRender();
	graphicsStateStack.SetTransform(myTransform);
	graphicsStateStack.Translate({ 0.f,0.f,-1.1f });
	for (auto& text : myTexts)
	{
		text.Render();
	}
	graphicsStateStack.Pop();

#ifdef _DEBUG
	if (ShouldRenderDebugBounds())
	{
		auto& debugDrawer = Tga::Engine::GetInstance()->GetDebugDrawer();
		Color color = (myIsHovered) ? Tga::Color{ 0.f, 1.f, 0.f, 1.f } : Tga::Color{ 1.f, 0.f, 0.f, 1.f };

		Tga::Vector2f halfLength = myHalfSize;
		Tga::Vector2f pos = myPosition;

		debugDrawer.DrawLine(Vector2f{ pos.x - halfLength.x, pos.y - halfLength.y }, { pos.x - halfLength.x, pos.y + halfLength.y }, color);
		debugDrawer.DrawLine(Vector2f{ pos.x - halfLength.x, pos.y - halfLength.y }, { pos.x + halfLength.x, pos.y - halfLength.y }, color);
		debugDrawer.DrawLine(Vector2f{ pos.x - halfLength.x, pos.y + halfLength.y }, { pos.x + halfLength.x, pos.y + halfLength.y }, color);
		debugDrawer.DrawLine(Vector2f{ pos.x + halfLength.x, pos.y - halfLength.y }, { pos.x + halfLength.x, pos.y + halfLength.y }, color);
	}
#endif
}

void Button::Update(float aDeltaTime)
{
	aDeltaTime;
}

void Button::Unlock()
{
	myCanBeClicked = true;
	mySprite.PlayAnimation("Default"_tgaid);
}

void Button::ReceiveInput(InputEvent aGameEvent, const std::any& someData)
{

	if (!myCanBeClicked) return;

	switch (aGameEvent)
	{
	case InputEvent::Hover:
	{
		Tga::Vector2f mouseScreenPos = std::any_cast<Tga::Vector2f>(someData);
		Tga::Vector2f mousePos = myCamera->GetScreenToWorldCoordinatesVec2(mouseScreenPos);

		// If dragging -> move
		if (myIsDragging)
		{
			SetPosition2D(mousePos - myDragOffset);
			break;
		}

		// Normal hover check
		const bool inside =
			mousePos.x >= myPosition.x - myHalfSize.x && mousePos.x <= myPosition.x + myHalfSize.x &&
			mousePos.y >= myPosition.y - myHalfSize.y && mousePos.y <= myPosition.y + myHalfSize.y;

		if (inside)
		{
			if (!myIsHovered) OnHoverEnter();
		}
		else if (myIsHovered)
		{
			OnHoverExit();
		}
		break;
	}

	case InputEvent::MenuLClick:
	{
		if (!myIsHovered) break;

		Tga::Vector2f mouseScreenPos = std::any_cast<Tga::Vector2f>(someData);
		Tga::Vector2f mousePos = myCamera->GetScreenToWorldCoordinatesVec2(mouseScreenPos);

		if (myIsDraggable)
		{
			myIsDragging = true;
			myDragOffset = mousePos - myPosition;
		}
		else
		{
			OnLeftClick();
		}
		break;
	}

	case InputEvent::MenuLRelease:
	{
		myIsDragging = false;
		myIsBeingClicked = false;
		break;
	}
	}
}

void Button::RegisterInput()
{
	RegisterToMapper(
		{
			InputEvent::MenuLClick,
			InputEvent::MenuLRelease,
			InputEvent::Hover
		});
}

void Button::UnregisterInput()
{
	UnRegisterToMapper(
		{
			InputEvent::MenuLClick,
			InputEvent::MenuLRelease,
			InputEvent::Hover
		});
}

void Button::AddChild(Button* child)
{
	if (!child || child == this) return;

	// detach from previous parent
	if (child->myParent)
		child->myParent->RemoveChild(child);

	child->myParent = this;
	myChildren.push_back(child);
}

void Button::RemoveChild(Button* child)
{
	if (!child) return;

	auto it = std::find(myChildren.begin(), myChildren.end(), child);
	if (it != myChildren.end())
	{
		(*it)->myParent = nullptr;
		myChildren.erase(it);
	}
}

void Button::SetPosition2D_NoText(const Tga::Vector2f& aNewPos)
{
	const Tga::Vector2f delta = aNewPos - myPosition;
	myPosition = aNewPos;

	const float z = myTransform.GetPosition().z; // <- stable

	// Flytta sprite + transform
	const Tga::Vector3f trPos = myTransform.GetPosition();
	mySprite.SetPosition(Tga::Vector3f{
		myPosition.x, myPosition.y,
		z
		});

	myTransform.SetPosition({ myPosition.x, myPosition.y, trPos.z });

	PropagateMoveToChildren(delta);
}

void Button::PropagateMoveToChildren(const Tga::Vector2f& delta)
{
	for (Button* c : myChildren)
	{
		if (!c) continue;

		c->SetPosition2D_NoText(c->GetPosition() + delta);
	}
}

bool Button::OnHoverEnter()
{
	if (!myCanBeClicked || myIsBeingClicked)
		return false;

	Tga::Engine::GetInstance()->SetCursorState("Hover"_tgaid);

	myIsHovered = true;

	const auto currentAnim = mySprite.GetCurrentAnimation();

	if (currentAnim == "Clicked"_tgaid || currentAnim == "Clicked_Hover"_tgaid)
	{
		mySprite.PlayAnimation("Clicked_Hover"_tgaid);
	}
	else
	{
		mySprite.PlayAnimation("Hover"_tgaid);
	}

	mySprite.SetColor(myColors[static_cast<int>(ButtonColor::HoverColor)]);
	return true;
}

void Button::OnHoverExit()
{
	if (!myCanBeClicked)
	{
		return;
	}

	Tga::Engine::GetInstance()->SetCursorState("Default"_tgaid);

	myIsHovered = false;
	if (mySprite.GetCurrentAnimation() == "Clicked_Hover"_tgaid || mySprite.GetCurrentAnimation() == "Clicked"_tgaid)
	{
		mySprite.PlayAnimation("Clicked"_tgaid);
	}
	else if (mySprite.GetCurrentAnimation() != "Clicked"_tgaid)
	{
		mySprite.PlayAnimation("Default"_tgaid);
	}


	mySprite.SetColor(myColors[static_cast<int>(ButtonColor::DefaultColor)]);
}

void Button::SetColor(ButtonColor aType, Tga::Color aColor)
{
	myColors[static_cast<int>(aType)] = aColor;
}

Tga::Color Button::GetColor(ButtonColor aType) const
{
	return myColors[static_cast<int>(aType)];
}

void Button::DebugDrawBounds(const Tga::Color& aColor) const
{
	if (!myIsVisible)
	{
		return;
	}

	if (!ShouldRenderDebugBounds())
	{
		return;
	}

	auto& dd = Tga::Engine::GetInstance()->GetDebugDrawer();

	const Tga::Vector2f p = myPosition;  // center
	const Tga::Vector2f h = myHalfSize;  // half extents

	const Tga::Vector2f LB{ p.x - h.x, p.y - h.y };
	const Tga::Vector2f LT{ p.x - h.x, p.y + h.y };
	const Tga::Vector2f RB{ p.x + h.x, p.y - h.y };
	const Tga::Vector2f RT{ p.x + h.x, p.y + h.y };

	dd.DrawLine(LB, LT, aColor);
	dd.DrawLine(LT, RT, aColor);
	dd.DrawLine(RT, RB, aColor);
	dd.DrawLine(RB, LB, aColor);
}

void Button::InitRuntime(const Tga::Vector2f& pos, const Tga::Vector2f& size)
{
	myCanBeClicked = true;
	myPosition = pos;
	myHalfSize = size * 0.5f;

	myColors.clear();
	myColors.resize(static_cast<int>(ButtonColor::Count));

	myColors[(int)ButtonColor::DefaultColor] = { 0.7f, 0.7f, 0.7f, 1.f };
	myColors[(int)ButtonColor::HoverColor] = { 1.f, 1.f, 1.f, 1.f };
	myColors[(int)ButtonColor::ClickedColor] = { 0.3f, 0.3f, 0.3f, 1.f };

	myTransform = Tga::Matrix4x4f::CreateIdentityMatrix();
	myTransform.SetPosition({ pos.x, pos.y, 0.f });

	mySprite.SetPosition({ pos.x, pos.y, 0.f });
	mySprite.SetColor(myColors[(int)ButtonColor::DefaultColor]); // ✅ safe now
}

void Button::OnLeftClick()
{
	const AudioManager& aManager = *AudioManager::GetInstance();
	//aManager.PlayNonSpatialisedAudio(AudioConstExpr::SFX_UI_CONFIRM);
	aManager.RunUpdateCycle();

	if (mySprite.GetCurrentAnimation() == "Hover"_tgaid)
	{
		mySprite.PlayAnimation("Clicked_Hover"_tgaid);
	}
	else
	{
		mySprite.PlayAnimation("Hover"_tgaid);
	}
}

void Button::OnRightClick()
{
	//AudioManager::GetInstance()->PlaySpatialisedAudio(AudioConstExpr::SFX_UI_BACK);
}

Tga::Vector2f Button::GetMouseToWorldCoordinatesVec2(Tga::Vector2f aMousePos) const
{
	State* state = myStateStack->GetCurrentState();
	const std::shared_ptr<Tga::Camera>& camera = state->GetActiveCamera();

	Tga::Vector2f renderSize = { (float)Tga::Engine::GetInstance()->GetRenderSize().x, (float)Tga::Engine::GetInstance()->GetRenderSize().y };
	//Tga::Vector2f windowSize = { (float)Tga::Engine::GetInstance()->GetWindowSize().x, (float)Tga::Engine::GetInstance()->GetWindowSize().y };
	//Tga::Vector2f renderWindowOffset = windowSize - renderSize;

	// Edit later so we can resize window as well
	Tga::Vector2f ogSize = Tga::Vector2f{ renderSize.x, renderSize.y };
	//Tga::Vector2f ogSize = Tga::Vector2f{ static_cast<float>(MainSingleton::GetInstance().GetOriginalRenderSize().x), static_cast<float>(MainSingleton::GetInstance().GetOriginalRenderSize().y) };
	Tga::Vector2f scale = ogSize / renderSize;


	float screenWidth = ogSize.x;
	float screenHeight = ogSize.y;

	Tga::Vector3f mouseNDC = { 0.f,0.f,1.f };
	mouseNDC.x = ((aMousePos.x * scale.x * 2.f) / screenWidth) - 1.f;
	mouseNDC.y = 1.f - ((aMousePos.y * scale.y * 2.f) / screenHeight);

	Tga::Vector4f mouseView = { 0.f,0.f,1.f,1.f };
	mouseView.x = (mouseNDC.x / camera->GetProjection()(1, 1));
	mouseView.y = (mouseNDC.y / camera->GetProjection()(2, 2));

	Tga::Vector3f mouseWorld = { 0.f, 0.f, 1.f };
	mouseWorld = mouseView * camera->GetTransform();
	return { mouseWorld.x , -mouseWorld.y }; // something weird with the calculations. up and down is reversed for y, thats why it's -y for now
}

// BUTTON WILL GO IN ENGINE, WHEN CREATING A GAME YOU CAN THEN JUST INHERIT FROM IT AND CREATE YOUR OWN BUTTONS
// DON'T FORGET TO MOVE AnimatedSprite TO ENGINE TOO
// 
/////////////// DIFFERENT BUTTONS -------- KEEP THESE IN GAME, IN AN "OTHER BUTTONS" FILE.

#pragma region OTHER BUTTONS

void FullScreenButton::Init(const Tga::SceneObject& aSceneObject, const std::vector<Tga::ScenePropertyDefinition>& someProperties)
{
	Button::Init(aSceneObject, someProperties);

	if (myIsFullScreen)
	{
		mySprite.PlayAnimation("Clicked"_tgaid);
	}
	else
	{
		mySprite.PlayAnimation("Default"_tgaid);
	}
}

void FullScreenButton::OnLeftClick()
{
	myIsFullScreen = !myIsFullScreen;

	//AudioManager::GetInstance()->PlayNonSpatialisedAudio(AudioConstExpr::SFX_UI_CONFIRM);

	Tga::Engine::GetInstance()->SetFullScreen(myIsFullScreen);

	if (myIsFullScreen)
	{
		mySprite.PlayAnimation("Clicked"_tgaid);
	}
	else
	{
		mySprite.PlayAnimation("Hover"_tgaid);
	}
}

void NewGameButton::OnLeftClick()
{
	const AudioManager& aManager = *AudioManager::GetInstance();
	//aManager.PlayNonSpatialisedAudio(AudioConstExpr::SFX_UI_START_GAME);
	aManager.RunUpdateCycle();
	Message msg;
	msg.eventType = Event::ResetLevel;
	EventManager::GetInstance()->SendEventMessage(msg);
	if (mySprite.GetCurrentAnimation() == "Hover"_tgaid)
	{
		mySprite.PlayAnimation("Clicked_Hover"_tgaid);
	}
	else
	{
		mySprite.PlayAnimation("Hover"_tgaid);
	}
	myStateStack->Push(StateID::InGame, SceneID::Level1);
}

void Level2Button::OnLeftClick()
{
	Message msg;
	msg.eventType = Event::ResetLevel;
	EventManager::GetInstance()->SendEventMessage(msg);
	Button::OnLeftClick();
	myStateStack->Push(StateID::InGame, SceneID::Level2);
}

void LevelSelectButton::OnLeftClick()
{
	Button::OnLeftClick();
	myStateStack->Push(StateID::LevelSelect, SceneID::LevelSelect);
}

void OptionsButton::OnLeftClick()
{
	Button::OnLeftClick();
	myStateStack->Push(StateID::Options, SceneID::Options);
}

void EditHUDButton::OnLeftClick()
{
	Button::OnLeftClick();
	myStateStack->Pop();
	myStateStack->Push(StateID::HUD, SceneID::HUD);
}

void Save::OnLeftClick()
{
	Button::OnLeftClick();
	Message msg;
	msg.eventType = Event::HudLayoutSavePressed;
	EventManager::GetInstance()->SendEventMessage(msg);
	myStateStack->Pop();
	myStateStack->Pop();
}

void MoveAllButtonsInMySize::OnLeftClick()
{
	Button::OnLeftClick();
}

void CreditsButton::OnLeftClick()
{
	Button::OnLeftClick();
	myStateStack->Push(StateID::Credits, SceneID::Credits);
}

void BackButton::OnLeftClick()
{
	const AudioManager& aManager = *AudioManager::GetInstance();
	//aManager.PlayNonSpatialisedAudio(AudioConstExpr::SFX_UI_BACK);
	aManager.RunUpdateCycle();
	if (mySprite.GetCurrentAnimation() == "Hover"_tgaid)
	{
		mySprite.PlayAnimation("Clicked_Hover"_tgaid);
	}
	else
	{
		mySprite.PlayAnimation("Hover"_tgaid);
	}
	myStateStack->Pop();
}

void BackButton::RegisterInput()
{
	Button::RegisterInput();
	RegisterToMapper(InputEvent::Back);
}

void BackButton::UnregisterInput()
{
	Button::UnregisterInput();
	UnRegisterToMapper(InputEvent::Back);
}

void BackButton::ReceiveInput(InputEvent aGameEvent, const std::any& someData)
{
	Button::ReceiveInput(aGameEvent, someData);
	switch (aGameEvent)
	{
	case InputEvent::Back:
	{
		OnLeftClick();
		myIsBeingClicked = false;
		break;
	}
	}
}

void BackButton2x::OnLeftClick()
{
	Button::OnLeftClick();
	myStateStack->Pop();
	myStateStack->Pop();
}

void MainMenuButton::OnLeftClick()
{
	mySprite.PlayAnimation("Default"_tgaid);

	while (myStateStack->GetCurrentState()->GetID() != StateID::MainMenu)
	{
		myStateStack->Pop();
		if (myStateStack->GetCurrentState() == nullptr)
		{
			return;
		}
	}
}

void QuitButton::OnLeftClick()
{
	const AudioManager& aManager = *AudioManager::GetInstance();
	//aManager.PlayNonSpatialisedAudio(AudioConstExpr::SFX_UI_BACK);
	aManager.RunUpdateCycle();
	mySprite.PlayAnimation("Default"_tgaid);
	myStateStack->Clear();
}
#pragma endregion

// MAKE SLIDER BUTTON IN ENGINE, WHICH VOLUME BUTTON CAN INHERIT FROM IN GAME (OTHER BUTTONS)
#pragma region SLIDER BUTTON
void SliderButton::Init(const Tga::SceneObject& aSceneObject, const std::vector<Tga::ScenePropertyDefinition>& someProperties)
{
	Button::Init(aSceneObject, someProperties);

	Tga::Vector3f pos = Tga::Vector3f{ myPosition.x, myPosition.y, 1.f };
	mySprite.SetPosition(pos);
	Tga::Vector2f scale = Tga::Vector2f{ aSceneObject.GetScale().x, aSceneObject.GetScale().y };

	for (auto& property : someProperties)
	{
		if (property.type == GetPropertyType<CopyOnWriteWrapper<SceneSprite>>())
		{
			Tga::SceneSprite sprite = property.value.Get<CopyOnWriteWrapper<SceneSprite>>()->Get();

			RenderManager& renderManager = *GameWorld::GetInstance().GetRenderManager().lock();
			NCE::RenderResources& renderResources = renderManager.GetRenderResources();

			// Optional custom pixel shader 
			if (!sprite.shader.pixel.IsEmpty())
			{
				const char* pixelPath = sprite.shader.pixel.GetString();
				Tga::StringId shaderID = Tga::StringRegistry::RegisterOrGetString(pixelPath);

				auto shaderIt = renderResources.mySpriteShaders.find(shaderID);
				if (shaderIt == renderResources.mySpriteShaders.end())
				{
					auto shader = std::make_unique<Tga::SpriteShader>();
					shader->Init("Shaders/instanced_sprite_shader_VS", pixelPath);
					mySliderData.myCustomShader = shader.get();
					renderResources.mySpriteShaders.emplace(shaderID, std::move(shader));
				}
				else
				{
					mySliderData.myCustomShader = shaderIt->second.get();
				}
			}
			TextureManager& textureManager = Tga::Engine::GetInstance()->GetTextureManager();
			mySliderData.myTexture = textureManager.GetTexture(sprite.textures[0].GetString());
			mySliderData.myMaps[0] = textureManager.GetTexture(sprite.textures[1].GetString(), TextureSrgbMode::ForceNoSrgbFormat);
			mySliderData.myMaps[1] = textureManager.GetTexture(sprite.textures[2].GetString(), TextureSrgbMode::ForceNoSrgbFormat);
			mySliderData.myMaps[2] = textureManager.GetTexture(sprite.textures[3].GetString(), TextureSrgbMode::ForceNoSrgbFormat);
			mySliderInstance.mySize = sprite.size * scale;

			mySliderInstance.myTransform = Tga::SpriteTransformFromSceneObject(aSceneObject, sprite.size, sprite.pivot);

			myLimitX = mySliderInstance.mySize.x * 0.5f;
			myMidPosX = mySliderInstance.myTransform.GetPosition().x + myLimitX;
		}
	}

	SetPositionToValue(0.5f);
}

void SliderButton::OnLeftClick()
{
	if (myMidPosX == 0.f)
	{
		myMidPosX = myPosition.x;
	}

	if (mySprite.GetCurrentAnimation() == "Hover"_tgaid)
	{
		mySprite.PlayAnimation("Clicked_Hover"_tgaid);
	}
	else
	{
		mySprite.PlayAnimation("Hover"_tgaid);
	}
	//Button::OnLeftClick();
}

void SliderButton::Render()
{
	Tga::GraphicsStateStack& graphicsStateStack = Tga::Engine::GetInstance()->GetGraphicsEngine().GetGraphicsStateStack();
	graphicsStateStack.Push();
	graphicsStateStack.SetBlendState(Tga::BlendState::AlphaBlend);

	Tga::SpriteDrawer& spriteDrawer = Tga::Engine::GetInstance()->GetGraphicsEngine().GetSpriteDrawer();
	spriteDrawer.Draw(mySliderData, mySliderInstance);
	graphicsStateStack.Pop();

	Button::Render();
}

void SliderButton::RegisterInput()
{
	Button::RegisterInput();
	RegisterToMapper(InputEvent::MenuLRelease);

}

void SliderButton::UnregisterInput()
{
	Button::UnregisterInput();
	UnRegisterToMapper(InputEvent::MenuLRelease);
}

void SliderButton::OnSlide(Tga::Vector2f aMousePos)
{
	if (aMousePos.x < myMidPosX + myLimitX && aMousePos.x > myMidPosX - myLimitX)
	{
		myPosition.x = aMousePos.x;
	}
	else if (aMousePos.x > myMidPosX + myLimitX)
	{
		myPosition.x = myMidPosX + myLimitX;
	}
	else if (aMousePos.x < myMidPosX - myLimitX)
	{
		myPosition.x = myMidPosX - myLimitX;
	}

	Tga::Vector3f pos = Tga::Vector3f{ myPosition.x, myPosition.y, 1.f };

	mySprite.SetPosition(pos);

	float posOnSlider = myPosition.x - myMidPosX + myLimitX;
	float totalSliderLength = myLimitX * 2.f;
	float percentage = posOnSlider / totalSliderLength;
	if (percentage <= 0.015f)
	{
		percentage = 0.f;
	}

	OnChangedPosition(percentage);
}

void SliderButton::OnSlide(Tga::Vector3f aDirection)
{
	myPosition.x += aDirection.x * 5.f;
	if (myPosition.x > myMidPosX + myLimitX)
	{
		myPosition.x = myMidPosX + myLimitX;
	}
	else if (myPosition.x < myMidPosX - myLimitX)
	{
		myPosition.x = myMidPosX - myLimitX;
	}
	Tga::Vector3f pos = Tga::Vector3f{ myPosition.x, myPosition.y, 1.f };
	mySprite.SetPosition(pos);

	float posOnSlider = myPosition.x - myMidPosX + myLimitX;
	float totalSliderLength = myLimitX * 2.f;
	float percentage = posOnSlider / totalSliderLength;
	if (percentage <= 0.015f)
	{
		percentage = 0.f;
	}
}

void SliderButton::ReceiveInput(InputEvent aGameEvent, const std::any& someData)
{
	Button::ReceiveInput(aGameEvent, someData);

	if (!myCanBeClicked)
	{
		return;
	}

	switch (aGameEvent)
	{
	case InputEvent::MenuLClick:
	{
		if (myIsHovered && !myIsBeingClicked)
		{
			myIsBeingClicked = true;
			OnLeftClick();
		}
		break;
	}
	case InputEvent::Hover:
	{
		if (myIsBeingClicked)
		{
			Tga::Vector2f mouseScreenPos = std::any_cast<Tga::Vector2f>(someData);
			Tga::Vector2f mousePos = myCamera->GetScreenToWorldCoordinatesVec2(mouseScreenPos);
			OnSlide(mousePos);
		}
		break;
	}
	case InputEvent::MenuLRelease:
	{
		if (myIsBeingClicked)
		{
			//AudioManager::GetInstance()->PlayNonSpatialisedAudio(AudioConstExpr::SFX_UI_SLIDER);
			myIsBeingClicked = false;
		}
		break;
	}
	}
}

void SliderButton::OnChangedPosition(float aValue)
{
	aValue;
	// Do something with the value, e.g. use it to set a volume
}

void Button::SetPosition2D(const Tga::Vector2f& aNewPos)
{
	const Tga::Vector2f delta = aNewPos - myPosition;
	myPosition = aNewPos;

	const float z = myTransform.GetPosition().z; // <- stable

	mySprite.SetPosition(Tga::Vector3f{ myPosition.x, myPosition.y, z });
	myTransform.SetPosition({ myPosition.x, myPosition.y, z });

	for (auto& t : myTexts)
		t.SetPosition(t.GetPosition() + delta);

	myToolTip.SetPosition(myToolTip.GetPosition() + delta);

	PropagateMoveToChildren(delta);
}

void SliderButton::SetPositionToValue(float aValue)
{
	float posOnSlider = myMidPosX - myLimitX + (myLimitX * 2.f * aValue);
	myPosition.x = posOnSlider;
	Tga::Vector3f pos = Tga::Vector3f{ myPosition.x, myPosition.y, 1.f };
	mySprite.SetPosition(pos);
}
#pragma endregion

// VOLUME BUTTON
#pragma region VOLUME BUTTON
void VolumeButton::Init(const Tga::SceneObject& aSceneObject, const std::vector<Tga::ScenePropertyDefinition>& someProperties)
{
	SliderButton::Init(aSceneObject, someProperties);

	for (auto& property : someProperties)
	{
		if (property.type == GetPropertyType<CopyOnWriteWrapper<ButtonData>>())
		{
			ButtonType buttonType = property.value.Get<CopyOnWriteWrapper<ButtonData>>()->Get().buttonType;
			switch (buttonType)
			{
			case ButtonType::VolumeMaster:
			{
				myAudioType = AudioBusType::Master;
				break;
			}
			case ButtonType::VolumeSFX:
			{
				myAudioType = AudioBusType::SFX;
				break;
			}
			case ButtonType::VolumeAmbience:
			{
				myAudioType = AudioBusType::Ambience;
				break;
			}
			case ButtonType::VolumeMusic:
			{
				myAudioType = AudioBusType::Music;
				break;
			}
			}
			break;
		}
	}

	float currentVolume = AudioManager::GetInstance()->GetVolume(myAudioType);

	SetPositionToValue(currentVolume);
}
void VolumeButton::OnChangedPosition(float aValue)
{
	aValue;
	/*switch (myAudioType)
	{
		case AudioBusType::Master:
		{
			AudioManager::GetInstance()->SetMasterVolume(aValue);
			break;
		}
		case AudioBusType::SFX:
		{
			AudioManager::GetInstance()->SetSFXVolume(aValue);
			break;
	}
		case AudioBusType::Ambience:
		{
			AudioManager::GetInstance()->SetAmbienceVolume(aValue);
			break;
}
		case AudioBusType::Music:
		{
			AudioManager::GetInstance()->SetMusicVolume(aValue);
			break;
		}
	}*/
}
#pragma endregion

#pragma region HUD BUTTON
void HUDButton::Init(const Tga::SceneObject& aSceneObject, const std::vector<Tga::ScenePropertyDefinition>& someProperties)
{
	myToolTipEnabled = true;
	Button::Init(aSceneObject, someProperties);

	// ToolTip
	myToolTip = Tga::Text("Text/BarlowSemiCondensed-Regular.ttf", Tga::FontSize_24);
	Tga::Vector2f tooltipPos = myPosition;
	tooltipPos.y += 130.f;
	myToolTip.SetPosition(tooltipPos);

	for (auto& property : someProperties)
	{
		if (property.type == GetPropertyType<CopyOnWriteWrapper<HUDData>>())
		{
			myHUDType = property.value.Get<CopyOnWriteWrapper<HUDData>>()->Get().hudType;
			//switch (myHUDType)
			{
				//case HUDType::AbilitySlash:
				//{
				//	myEvent = Event::PlayerUsedSlash;
				//	myToolTip.SetText("Slash - Slash nearby enemies!");
				//	myCanBeClicked = true;
				//	break;
				//}
				//case HUDType::AbilityArrow:
				//{
				//	myEvent = Event::PlayerUsedArrow;
				//	myToolTip.SetText("Arrow - Shoot an arrow!");
				//	myCanBeClicked = true;
				//	break;
				//}
				//case HUDType::AbilityHeal:
				//{
				//	myEvent = Event::PlayerUsedHeal;
				//	myToolTip.SetText("Heal - Get healthy!");
				//	myCanBeClicked = false;
				//	break;
				//}
				//case HUDType::AbilityDash:
				//{
				//	myEvent = Event::PlayerUsedDash;
				//	myToolTip.SetText("Dash - Go VROOM!");
				//	myCanBeClicked = false;
				//	break;
				//}
				//case HUDType::AbilityRangedAOE:
				//{
				//	myEvent = Event::PlayerUsedRangedAOE;
				//	myToolTip.SetText("AttackAOE - Use an AOE attack!");
				//	myCanBeClicked = false;
				//	break;
				//}
				//case HUDType::AbilityAura:
				//{
				//	myEvent = Event::PlayerUsedAura;
				//	myToolTip.SetText("Aura - Do a bunch of damage with your great aura!");
				//	myCanBeClicked = false;
				//	break;
				//}
				//case HUDType::HealthOrb:
				//{
				//	myEvent = Event::PlayerHealthChange;
				//	myToolTip.SetText("Your Health");
				//	myCanBeClicked = true;
				//	break;
				//}
				//case HUDType::ManaOrb:
				//{
				//	myEvent = Event::PlayerManaChange;
				//	myToolTip.SetText("Your Mana");
				//	myCanBeClicked = true;
				//	break;
				//}
				//case HUDType::XpBar:
				//{
				//	myEvent = Event::PlayerXPChange;
				//	myToolTip.SetText("Your XP");
				//	myCanBeClicked = true;
				//	break;
				//}
			}
		}
		else if (property.type == GetPropertyType <CopyOnWriteWrapper<SceneSprite>>() && property.name == "ToolTip_BG"_tgaid)
		{
			Tga::SceneSprite sprite = property.value.Get<CopyOnWriteWrapper<SceneSprite>>()->Get();
			myToolTipSharedData.myTexture = Tga::Engine::GetInstance()->GetTextureManager().GetTexture(sprite.textures[0].GetString());
			myToolTipSpriteInstance.mySize = sprite.size * 0.25f;
			myToolTipSpriteInstance.myPivot = Tga::Vector2f{ sprite.pivot.x, sprite.pivot.y };
			myToolTipSpriteInstance.myPosition = mySprite.GetPosVec2();
			break;
		}

		Tga::Vector2f textPos = myPosition;
		textPos.x -= myToolTip.GetWidth() * 0.5f;
		textPos.y += myToolTipSpriteInstance.mySize.y * 0.75f;
	}
}

void HUDButton::RegisterInput()
{
	Button::RegisterInput();
	RegisterEvent();
}

void HUDButton::UnregisterInput()
{
	Button::UnregisterInput();
	UnregisterEvent();
}

bool HUDButton::OnHoverEnter()
{
	if (!Button::OnHoverEnter())
		return false;

	Message message{ Event::ShowToolTip, myHUDType };
	EventManager::GetInstance()->SendEventMessage(message);
	return true;
}

void HUDButton::OnHoverExit()
{
	Button::OnHoverExit();
	Message message{ Event::HideToolTip, myHUDType };
	EventManager::GetInstance()->SendEventMessage(message);
}
#pragma endregion

////// ABILITY HUD BUTTON FILE
#pragma region ABILITY HUD BUTTON
void AbilityHUDButton::Init(const Tga::SceneObject& aSceneObject, const std::vector<Tga::ScenePropertyDefinition>& someProperties)
{
	HUDButton::Init(aSceneObject, someProperties);

	for (auto& property : someProperties)
	{
		if (property.type == GetPropertyType<CopyOnWriteWrapper<SceneSprite>>() && property.name == "Input"_tgaid)
		{
			Tga::SceneSprite sprite = property.value.Get<CopyOnWriteWrapper<SceneSprite>>()->Get();
			myInputSharedData.myTexture = Tga::Engine::GetInstance()->GetTextureManager().GetTexture(sprite.textures[0].GetString());
			Tga::Vector3f spriteScale = mySprite.GetScale();
			myInputSpriteInstance.mySize = sprite.size * Tga::Vector2f{ spriteScale.x, spriteScale.y };
			myInputSpriteInstance.myPivot = Tga::Vector2f{ sprite.pivot.x, sprite.pivot.y };
			// Lol hard-coded for now
			myInputSpriteInstance.myPivot = { -0.8f,-2.5f };
			myInputSpriteInstance.myPosition = mySprite.GetPosVec2();
			break;
		}
	}

	RenderManager& renderManager = *GameWorld::GetInstance().GetRenderManager().lock();
	NCE::RenderResources& renderResources = renderManager.GetRenderResources();

	// Cooldown Shader - OBS: This shader does not exist at the moment
	const char* pixelPath = "Shaders/RadialFade_PS";
	Tga::StringId shaderID = Tga::StringRegistry::RegisterOrGetString(pixelPath);

	auto shaderIt = renderResources.mySpriteShaders.find(shaderID);
	if (shaderIt == renderResources.mySpriteShaders.end())
	{
		auto shader = std::make_unique<Tga::SpriteShader>();
		shader->Init("Shaders/instanced_sprite_shader_VS", pixelPath);
		mySprite.SetShader(shader.get());
		renderResources.mySpriteShaders.emplace(shaderID, std::move(shader));
	}
	else
	{
		mySprite.SetShader(shaderIt->second.get());
	}
}

void AbilityHUDButton::Render()
{
	Tga::GraphicsStateStack& graphicsStateStack = Tga::Engine::GetInstance()->GetGraphicsEngine().GetGraphicsStateStack();
	graphicsStateStack.Push();
	graphicsStateStack.SetBlendState(Tga::BlendState::AlphaBlend);
	graphicsStateStack.SetOrbValue(myCooldownNormalized);

	Tga::SpriteDrawer& spriteDrawer = Tga::Engine::GetInstance()->GetGraphicsEngine().GetSpriteDrawer();
	if (myCanBeClicked)
	{
		Button::Render();
	}
	spriteDrawer.Draw(myInputSharedData, myInputSpriteInstance);
	graphicsStateStack.Pop();

}

void AbilityHUDButton::RegisterEvent()
{
	EventManager::GetInstance()->Subscribe(myEvent, this);
}

void AbilityHUDButton::UnregisterEvent()
{
	EventManager::GetInstance()->UnSubscribe(myEvent, this);
}

void AbilityHUDButton::ReceiveEvent(const Message& aMessage)
{
	if (aMessage.eventType == myEvent)
	{
		float cooldown = std::get<float>(aMessage.data);

		if (cooldown == 10.f)
		{
			mySprite.PlayAnimation("Clicked"_tgaid);
		}
		else if (cooldown == -10.f)
		{
			if (!myIsHovered)
			{
				mySprite.PlayAnimation("Default"_tgaid);
			}
			else
			{
				mySprite.PlayAnimation("Hover"_tgaid);
			}
		}
		else if (cooldown == 1000.f)
		{
			myCanBeClicked = true;
			return;
		}
		else if (cooldown == -1000.f)
		{
			myCanBeClicked = false;
			return;
		}
		else
		{
			myCooldownNormalized = cooldown;
		}
	}
}
#pragma endregion


//sander la till dessa jag vet att det är skit ful fix atm but if u know better idea please help
static const char* WeaponToString(WeaponType t)
{
	switch (t)
	{
	case WeaponType::Revolver:       return "Revolver";
	case WeaponType::MachineGun:     return "MachineGun";
	case WeaponType::Shotgun:        return "Shotgun";
	case WeaponType::RocketLauncher: return "RocketLauncher";
	default:                         return "Unknown";
	}
}

static std::string FormatPoints8(int value)
{
	if (value < 0) value = 0;
	if (value > 99999999) value = 99999999; // clamp så den alltid är 8 siffror

	std::ostringstream ss;
	ss << std::setw(8) << std::setfill('0') << value; // "00000010"

	std::string s = ss.str();
	// gör "0000 0010"
	s.insert(4, " ");
	return s;
}


#pragma region VALUE HUD BUTTON
void ValueHUDButton::Init(const Tga::SceneObject& aSceneObject, const std::vector<Tga::ScenePropertyDefinition>& someProperties)
{
	HUDButton::Init(aSceneObject, someProperties);

	for (auto& property : someProperties)
	{
		if (property.type == GetPropertyType<CopyOnWriteWrapper<HUDData>>())
		{
			HUDType hudType = property.value.Get<CopyOnWriteWrapper<HUDData>>()->Get().hudType;
			switch (hudType)
			{
			case HUDType::Health:
			{
				myEvent = Event::PlayerHealthChange;
				//myTexts.back().SetText("100/100");
				if (!myTexts.empty())
				{
					myTexts.back().SetText("Health: 100/100");
				}
				myCanBeClicked = true;
				break;
			}
			case HUDType::Ammo:
			{
				myEvent = Event::AmmoChange;

				if (!myTexts.empty())
				{
					myTexts.back().SetText("Ammo: --/-- (--)");
				}

				myCanBeClicked = true;
				break;
			}
			case HUDType::Reload:
			{
				myEvent = Event::ReloadChange;

				if (!myTexts.empty())
				{
					myTexts.back().SetText("Reload: --");
				}

				myCanBeClicked = true;
				break;
			}
			case HUDType::Points:
			{
				myEvent = Event::PointsChange;

				if (!myTexts.empty())
				{
					myTexts.back().SetText(FormatPoints8(0));

					myOldValue = 0.f;
					myNewValue = 0.f;
					myCurrentValue = 0.f;

					// Om du vill att texten INTE ska hoppa:
					// sätt position EN gång här och ändra inte x efter det.
					// (du har redan myTexts.back().SetPosition(...) i init-logiken)
				}

				myCanBeClicked = true;
				break;
			}
			case HUDType::Combo:
			{
				myEvent = Event::ComboChange;

				if (!myTexts.empty())
				{
					myTexts.back().SetText("1x");  // startvärde (combo multiplier)

					myOldValue = 0.f;
					myNewValue = 0.f;
					myCurrentValue = 0.f;
				}

				myCanBeClicked = true;
				break;
			}
			case HUDType::Info:
			{
				myEvent = Event::TopTextChange;

				if (!myTexts.empty())
				{
					myTexts.back().SetText(""); // start empty
					myOldValue = myNewValue = myCurrentValue = 0.f; // optional, since no bar needed
				}

				myCanBeClicked = false; // or true if you want hover etc
				break;
			}
			}
		}
		else if (property.type == GetPropertyType <CopyOnWriteWrapper<SceneSprite>>() && property.name != "ToolTip_BG"_tgaid)
		{
			Tga::SceneSprite sprite = property.value.Get<CopyOnWriteWrapper<SceneSprite>>()->Get();

			RenderManager& renderManager = *GameWorld::GetInstance().GetRenderManager().lock();
			NCE::RenderResources& renderResources = renderManager.GetRenderResources();

			// Optional custom pixel shader 
			if (!sprite.shader.pixel.IsEmpty())
			{
				const char* pixelPath = sprite.shader.pixel.GetString();
				Tga::StringId shaderID = Tga::StringRegistry::RegisterOrGetString(pixelPath);

				auto shaderIt = renderResources.mySpriteShaders.find(shaderID);
				if (shaderIt == renderResources.mySpriteShaders.end())
				{
					auto shader = std::make_unique<Tga::SpriteShader>();
					shader->Init("Shaders/instanced_sprite_shader_VS", pixelPath);
					myOrbSharedData.myCustomShader = shader.get();
					renderResources.mySpriteShaders.emplace(shaderID, std::move(shader));
				}
				else
				{
					myOrbSharedData.myCustomShader = shaderIt->second.get();
				}

				TextureManager& textureManager = Tga::Engine::GetInstance()->GetTextureManager();
				myOrbSharedData.myTexture = textureManager.GetTexture(sprite.textures[0].GetString());
				myOrbSharedData.myMaps[0] = textureManager.GetTexture(sprite.textures[1].GetString(), TextureSrgbMode::ForceNoSrgbFormat);
				myOrbSharedData.myMaps[1] = textureManager.GetTexture(sprite.textures[2].GetString(), TextureSrgbMode::ForceNoSrgbFormat);
				myOrbSharedData.myMaps[2] = textureManager.GetTexture(sprite.textures[3].GetString(), TextureSrgbMode::ForceNoSrgbFormat);

				myOrbSpriteInstance.mySize = sprite.size;
				myOrbSpriteInstance.myPivot = sprite.pivot - Tga::Vector2f{ 0.5f,0.5f };
				myOrbSpriteInstance.myPosition = Tga::SpritePositionVec2FromSceneObject(aSceneObject, sprite.size, sprite.pivot);
			}
		}

		Tga::Vector2f textPos = myPosition;
		if (!myTexts.empty())
		{
			textPos.x -= myTexts.back().GetWidth() * 0.5f;
			textPos.y += myOrbSpriteInstance.mySize.y * 0.75f;
			myOrbSpriteInstance.myIsHidden = true;
			myTexts.back().SetPosition((textPos));
		}
	}
}



void ValueHUDButton::Render()
{
	if (myCurrentValue != myNewValue)
	{
		if (myOldValue < myNewValue && myCurrentValue < myNewValue)
		{
			myCurrentValue += Tga::Engine::GetInstance()->GetDeltaTime();
			myCurrentValue = (myCurrentValue > myNewValue) ? myNewValue : myCurrentValue;
		}
		else if (myOldValue > myNewValue && myCurrentValue > myNewValue)
		{
			myCurrentValue -= Tga::Engine::GetInstance()->GetDeltaTime();
			myCurrentValue = (myCurrentValue < myNewValue) ? myNewValue : myCurrentValue;
		}
	}
	Tga::GraphicsStateStack& graphicsStateStack = Tga::Engine::GetInstance()->GetGraphicsEngine().GetGraphicsStateStack();
	graphicsStateStack.Push();
	graphicsStateStack.SetBlendState(Tga::BlendState::AlphaBlend);
	graphicsStateStack.SetOrbValue(myCurrentValue);

	//Tga::SpriteDrawer& spriteDrawer = Tga::Engine::GetInstance()->GetGraphicsEngine().GetSpriteDrawer();
	//spriteDrawer.Draw(myOrbSharedData, myOrbSpriteInstance);
	graphicsStateStack.Pop();

	//if (myIsHovered)
	//{
	//	myToolTip.Render();
	//}
	//myText.Render();
	for (auto& text : myTexts)
	{
		text.Render();
	}
}

void ValueHUDButton::ReceiveEvent(const Message& aMessage)
{
	if (myTexts.empty()) return;
	if (aMessage.eventType == myEvent)
	{
		switch (myEvent)
		{
		case Event::PlayerHealthChange:
		{
			IntBarValues values = std::get<IntBarValues>(aMessage.data);
			myTexts.back().SetText("Health: " + std::to_string(values.currentValue) + "/" + std::to_string(values.maxValue));
			myNewValue = static_cast<float>(values.currentValue) / static_cast<float>(values.maxValue);
			break;
		}
		case Event::AmmoChange:
		{
			AmmoHUDValues a = std::get<AmmoHUDValues>(aMessage.data);

			myTexts.back().SetText(
				std::string(WeaponToString(a.weapon)) + "  " +
				std::to_string(a.mag) + "/" + std::to_string(a.magSize) +
				"  (" + std::to_string(a.reserve) + ")"
			);

			myNewValue = (a.magSize > 0) ? (float)a.mag / (float)a.magSize : 0.f;
			break;
		}
		case Event::ReloadChange:
		{
			ReloadHUDValues r = std::get<ReloadHUDValues>(aMessage.data);

			if (!r.isReloading)
			{
				myTexts.back().SetText("");
				myNewValue = 0.f;
				break;
			}

			// Ex: “Revolver Reload 0.8s”
			myTexts.back().SetText(
				std::string(WeaponToString(r.weapon)) +
				" Reload: " + std::to_string(r.remaining).substr(0, 4) + "s"
			);

			// bar: 1 -> 0 under reload (eller tvärtom)
			myNewValue = (r.duration > 0.f) ? (1.f - (r.remaining / r.duration)) : 0.f;

			break;
		}
		case Event::PointsChange:
		{
			IntBarValues values = std::get<IntBarValues>(aMessage.data);

			myTexts.back().SetText(FormatPoints8(values.currentValue));

			myNewValue = (values.maxValue > 0)
				? (float)values.currentValue / (float)values.maxValue
				: 0.f;

			break;
		}
		case Event::ComboChange:
		{
			IntBarValues values = std::get<IntBarValues>(aMessage.data);

			const int mult = values.currentValue;

			if (mult <= 1)
			{
				myTexts.back().SetText("");
				myNewValue = 0.f;
			}
			else
			{
				myTexts.back().SetText(std::to_string(mult) + "x");
				myNewValue = (values.maxValue > 0)
					? (float)mult / (float)values.maxValue
					: 0.f;
			}

			break;
		}
		case Event::TopTextChange:
		{
			const std::string& s = std::get<std::string>(aMessage.data);
			myTexts.back().SetText(s);

			// If this “info text” has no orb/bar, keep it 0:
			myNewValue = 0.f;
			break;
		}
		}
		Tga::Vector2f textPos = myOrbSpriteInstance.myPosition;
		textPos.x -= myToolTip.GetWidth() * 0.5f;
		myToolTip.SetPosition(textPos);
		myOldValue = myCurrentValue;
	}
}