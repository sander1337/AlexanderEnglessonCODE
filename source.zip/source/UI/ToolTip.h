#pragma once
//#pragma message(__FILE__" was compiled")
#include "../Events/EventManager.h"
#include <vector>
//#include "../Graphics/GameSprite.h"
#include <tge/text/text.h>
#include <tge/sprite/sprite.h>
#include <tge/scene/ScenePropertyTypes.h>

class ToolTip : public Observer
{
public:
	ToolTip() {};
	~ToolTip() {};
	void Init(const Tga::SceneObject& aSceneObject, const std::vector<Tga::ScenePropertyDefinition>& someProperties);
	void Render();

	void ReceiveEvent(const Message& aMessage);
	void RegisterEvent();
	void UnregisterEvent();

private:
	bool myIsHovered = false;
	Tga::HUDType myHUDType = Tga::HUDType::Count;
	Tga::Text myText;
	Tga::SpriteSharedData mySpriteSharedData;
	Tga::Sprite3DInstanceData  mySpriteInstance;
};