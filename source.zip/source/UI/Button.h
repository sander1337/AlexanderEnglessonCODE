#pragma once
//#pragma message(__FILE__" was compiled")
#include "../Events/EventManager.h"
#include <vector>
#include "../Graphics/GameSprite.h"
#include "../Input/InputMapper.h"
#include <tge/text/text.h>

enum class AudioBusType : uint8_t;

namespace Tga
{
	class Camera;
}

class StateStack;

class Button : public InputObserver
{
public:
	enum class ButtonColor
	{
		DefaultColor,
		HoverColor,
		ClickingColor,
		ClickedColor,
		Count
	};

	Button();
	~Button();
	virtual void Init(const Tga::SceneObject& aSceneObject, const std::vector<Tga::ScenePropertyDefinition>& someProperties);
	virtual void SetStateStack(StateStack* aStateStack) { myStateStack = aStateStack; };
	virtual void SetCamera(std::shared_ptr<Tga::Camera> aCamera) { myCamera = aCamera; };
	virtual void Render();
	virtual void Update(float aDeltaTime);
	virtual void Unlock();
	virtual bool OnHoverEnter();
	virtual void OnHoverExit();
	virtual void Unclick() { myIsBeingClicked = false; };
	virtual void Unhover() { myIsHovered = false; };
	virtual bool ShouldRenderDebugBounds() const { return true; }

	void SetColor(ButtonColor aType, Tga::Color aColor);
	Tga::Color GetColor(ButtonColor aType) const;
	Tga::Vector2f GetPosition() { return myPosition; };

	void ReceiveInput(InputEvent aGameEvent, const std::any& someData) override;
	virtual void RegisterInput() override;
	virtual void UnregisterInput() override;

	//AJDUSTABLE HUD
	void SetDraggable(bool aValue) { myIsDraggable = aValue; if (!aValue)myIsDragging = false; }
	bool IsDraggable() const { return myIsDraggable; }
	void CancelDrag() { myIsDragging = false; }
	void SetPosition(const Tga::Vector2f& p) { SetPosition2D(p); }
	void MoveBy(const Tga::Vector2f& delta) { SetPosition2D(myPosition + delta); }
	bool IsDragging() const { return myIsDragging; }
	bool IsHovered() const { return myIsHovered; }
	void AddChild(Button* child);
	void RemoveChild(Button* child);
	void SetVisible(bool v) { myIsVisible = v; }
	bool IsVisible() const { return myIsVisible; }

	Button* GetParent() const { return myParent; }

	const Tga::Vector2f& GetPosition() const { return myPosition; }
	const Tga::Vector2f& GetHalfSize() const { return myHalfSize; }

	void DebugDrawBounds(const Tga::Color& aColor) const;
	void InitRuntime(const Tga::Vector2f& pos, const Tga::Vector2f& size);

	void SetHalfSize(const Tga::Vector2f& half) { myHalfSize = half; /* + uppdatera sprite size om du har */ }
	void SetSize(const Tga::Vector2f& size) { SetHalfSize(size * 0.5f); }


protected:
	virtual void OnLeftClick();
	virtual void OnRightClick();

	Tga::Vector2f GetMouseToWorldCoordinatesVec2(Tga::Vector2f aMousePos) const;

	std::shared_ptr<Tga::Camera> myCamera;
	bool myCanBeClicked;
	bool myIsHovered;
	bool myIsBeingClicked = false;
	bool myIsClicked = false;
	bool myIsVisible = false;


	StateStack* myStateStack;

	GameSprite mySprite;
	Tga::Vector2f myHalfSize;
	Tga::Vector2f myPosition;

	std::vector<Tga::Color> myColors;

	Tga::Matrix4x4f myTransform;

	std::vector<Tga::Text> myTexts;

	Tga::Text myToolTip;
	bool myToolTipEnabled = false;

	//AJDUSTABLE HUD
	void SetPosition2D(const Tga::Vector2f& aNewPos); // moves sprite + text + transform
	void PropagateMoveToChildren(const Tga::Vector2f& delta);
	void SetPosition2D_NoText(const Tga::Vector2f& aNewPos);

	bool myIsDraggable = false;
	bool myIsDragging = false;
	Tga::Vector2f myDragOffset = { 0.f, 0.f };
	Button* myParent = nullptr;
	std::vector<Button*> myChildren;
};

// Slider
class SliderButton : public Button
{
public:
	virtual void Init(const Tga::SceneObject& aSceneObject, const std::vector<Tga::ScenePropertyDefinition>& someProperties) override;
	virtual void OnLeftClick() override;
	virtual void Render() override;
	virtual void RegisterInput() override;
	virtual void UnregisterInput() override;
	virtual void OnSlide(Tga::Vector2f aMousePos);
	virtual void OnSlide(Tga::Vector3f aDirection);
	virtual void ReceiveInput(InputEvent aGameEvent, const std::any& someData) override;

protected:
	virtual void SetPositionToValue(float aValue);
	virtual void OnChangedPosition(float aValue);
	Tga::SpriteSharedData mySliderData;
	Tga::Sprite3DInstanceData mySliderInstance;
	float myMousePosX;

	// Change from hardcoded
	float myMidPosX = 255.f;
	float myLimitX = 180.f;
	float mySoundTimer = 0.f;
	float mySoundInterval = 0.5f;
};

// Different buttons

class NewGameButton : public Button
{
	void OnLeftClick() override;
};

class Level2Button : public Button
{
	void OnLeftClick() override;
};

class LevelSelectButton : public Button
{
	void OnLeftClick() override;
};

class OptionsButton : public Button
{
	void OnLeftClick() override;
};

class EditHUDButton : public Button
{
	void OnLeftClick() override;
};

class Save : public Button
{
	void OnLeftClick() override;
};

class MoveAllButtonsInMySize : public Button
{
	void OnLeftClick() override;
};

class FullScreenButton : public Button
{
public:
	void Init(const Tga::SceneObject& aSceneObject, const std::vector<Tga::ScenePropertyDefinition>& someProperties) override;

private:
	void OnLeftClick() override;
	bool myIsFullScreen = true;
};

class CreditsButton : public Button
{
	void OnLeftClick() override;
};

class BackButton : public Button
{
	void OnLeftClick() override;

	void RegisterInput() override;
	void UnregisterInput() override;
	void ReceiveInput(InputEvent aGameEvent, const std::any& someData) override;
};

class BackButton2x : public Button
{
	void OnLeftClick() override;
};

class MainMenuButton : public Button
{
	void OnLeftClick() override;
};

class QuitButton : public Button
{
	void OnLeftClick() override;
};

class NextLineButton : public Button
{
	void OnLeftClick() override {};
};

class VolumeButton : public SliderButton
{
public:
	void Init(const Tga::SceneObject& aSceneObject, const std::vector<Tga::ScenePropertyDefinition>& someProperties) override;

private:
	void OnChangedPosition(float aValue) override;
	AudioBusType myAudioType;
};

// HUD Buttons
class HUDButton : public Button, public Observer
{
public:
	virtual void Init(const Tga::SceneObject& aSceneObject, const std::vector<Tga::ScenePropertyDefinition>& someProperties) override;

	virtual void RegisterInput() override;
	virtual void UnregisterInput() override;
	virtual void ReceiveEvent(const Message& aMessage) = 0;
protected:
	virtual void RegisterEvent() = 0;
	virtual void UnregisterEvent() = 0;
	bool OnHoverEnter() override;
	void OnHoverExit() override;

	Tga::HUDType myHUDType = Tga::HUDType::Count;
	Event myEvent = Event::Count;
	Tga::Text myToolTip;
	Tga::SpriteSharedData myToolTipSharedData;
	Tga::Sprite2DInstanceData  myToolTipSpriteInstance;
};

// Ability Button
class AbilityHUDButton : public HUDButton
{
public:
	void Init(const Tga::SceneObject& aSceneObject, const std::vector<Tga::ScenePropertyDefinition>& someProperties) override;
	void Render() override;
	void RegisterEvent() override;
	void UnregisterEvent() override;

	void ReceiveEvent(const Message& aMessage) override;
private:
	Tga::SpriteSharedData myInputSharedData;
	Tga::Sprite2DInstanceData myInputSpriteInstance;
	float myCooldownNormalized = 0.f;
};

// Rename BarButton ? Or ValueButton, PercentageButton?
class ValueHUDButton : public AbilityHUDButton
{
public:
	void Init(const Tga::SceneObject& aSceneObject, const std::vector<Tga::ScenePropertyDefinition>& someProperties) override;
	void Render() override;
	void ReceiveEvent(const Message& aMessage) override;
protected:
	Tga::Text myText;
	float myOldValue;
	float myNewValue;
	float myCurrentValue = 1.f;
	Tga::SpriteSharedData myOrbSharedData;
	Tga::Sprite2DInstanceData myOrbSpriteInstance;
};