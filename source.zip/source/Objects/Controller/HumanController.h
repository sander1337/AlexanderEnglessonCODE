#pragma once
#include "Controller.h"
#include "../Behaviors/Seek.h"
#include "../Behaviors/Separation.h"
#include "../Behaviors/StateMachine.h"
#include "../Behaviors/Wander.h"
#include "../Behaviors/HumanBrainTree.h"

enum class EnemyStateID : uint8_t;


class HumanController : public AI::Controller
{
public:
	HumanController() = default;
	~HumanController() = default;

	void Init(Enemy* anEnemy) override;
	ControllerOutput Update(Enemy* anEnemy, float aDeltaTime) override;

	void SetStateIdle();

private:
	HumanBrainTree myHumanBrainTree;

	Wander myWanderBehavior;
	Seek mySeekBehavior;
	SeparationBehavior mySeparationBehavior;
	
	Tga::Vector3f mySmoothedVelocity = Tga::Vector3f();
};