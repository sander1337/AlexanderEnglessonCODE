#include "Controller.h"

#include "stdafx.h"
#include "../Actors/Enemy/Enemy.h"

namespace AI
{
	void Controller::SetTargetPosition(Tga::Vector3f aTargetPosition)
	{
		myTargetPosition = aTargetPosition;
	}
}