#pragma once

#include "../Behaviors/SteeringBehaviorDataStructs.h"
#include "../Behaviors/StateMachine.h"

#include <tge/math/vector.h>

class Enemy;
class Actor;


namespace AI
{
	class Controller
	{
	public:
		virtual void Init(Enemy* anEnemy) = 0;
		virtual ControllerOutput Update(Enemy* anEnemy, float aDeltaTime) = 0;
		void SetTargetPosition(Tga::Vector3f aTargetPosition);
		const Tga::Vector3f& GetTargetPosition() const { return myTargetPosition; }
		//virtual EnemyStateID GetCurrentStateID() const { return EnemyStateID::Count; }

	protected:
		Tga::Vector3f myTargetPosition;

	};
}