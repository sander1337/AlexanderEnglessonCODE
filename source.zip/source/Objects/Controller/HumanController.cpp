#include "stdafx.h"
#include "HumanController.h"

#include <memory>

#include "../Behaviors/AttackState.h"
#include "../Behaviors/EngageState.h"
#include "../Behaviors/IdleState.h"
#include "../Behaviors/WanderState.h"
#include "../Actors/Enemy/EnemyData.h"
#include "../Actors/Enemy/Enemy.h"


void HumanController::Init(Enemy* anEnemy)
{
    myHumanBrainTree.Init(anEnemy);
}

ControllerOutput HumanController::Update(Enemy* anEnemy, float aDeltaTime)
{
    myHumanBrainTree.Update(aDeltaTime);

    ControllerOutput output;
    SteeringOutput seek = mySeekBehavior.Calculate(anEnemy, myTargetPosition, aDeltaTime);
    SteeringOutput separation = mySeparationBehavior.Calculate(anEnemy, myTargetPosition, aDeltaTime);

    // Blend forces with tunable weights
    const float seekWeight = 2.0f;
    const float separationWeight = 0.5f;

    Tga::Vector3f blended = (seek.velocity * seekWeight) + (separation.velocity * separationWeight);

    // Apply smoothing to prevent jitter
    const float smoothing = 0.15f;
    mySmoothedVelocity = Tga::Vector3f::Lerp(mySmoothedVelocity, blended, smoothing);

    output.steeringOutput.velocity = mySmoothedVelocity * anEnemy->GetData().speed * 0.25f * aDeltaTime;
    output.steeringOutput.rotation = 0.0f;

    return output;
}

void HumanController::SetStateIdle()
{
    myHumanBrainTree.SetStateIdle();
}