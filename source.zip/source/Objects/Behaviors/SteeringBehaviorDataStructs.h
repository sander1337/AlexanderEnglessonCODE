#pragma once

#include <tge/Math/Vector3.h>


struct SteeringOutput
{
	Tga::Vector3f velocity = {0.f, 0.f, 0.f};
	float rotation = 0.f;
};

struct ControllerOutput
{
	SteeringOutput steeringOutput;
};
