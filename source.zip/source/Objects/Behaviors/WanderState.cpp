#include "stdafx.h"
#include "WanderState.h"

//#include "StateMachine.h"
//#include <GameWorld.h>
//#include <tge/navmesh/navmesh.h>
//#include <Utilities/BlackBoard.h>
//#include <SceneManagement/GameScene.h>
//#include "../Actors/Enemy/Enemy.h"
//#include "../Actors/Enemy/EnemyData.h"
//#include "../Controller/Controller.h"

//
//void WanderState::OnEnter(Enemy* anEnemy)
//{
//	myHasWanderPosition = false;
//	EnemyState::OnEnter(anEnemy);
//}
//
//void WanderState::Update(Enemy* anEnemy, [[ maybe_unused ]] float aDeltaTime)
//{
//	Tga::Vector3f playerPosition = Blackboard::GetInstance()->GetVector3("playerPosition");
//	Tga::Vector3f currentPosition = anEnemy->GetPosition();
//	float aggroRange = anEnemy->GetData().aggroRange;
//
//	float distance = (playerPosition - currentPosition).Length();
//
//	if (distance < aggroRange)
//	{
//		myStateMachine->ChangeState(anEnemy, EnemyStateID::Engage);
//		return;
//	}
//
//	if (!myHasWanderPosition)
//	{
//		std::weak_ptr<GameScene> gameScene = GameWorld::GetInstance().GetCurrentGameScene();
//		Navmesh& navmesh = *gameScene.lock().get()->GetNavmesh();
//		float wanderRadius = 300.f;
//		Tga::Vector3f randomPosition = navmesh.GetRandomNearbyPosition(currentPosition, wanderRadius);
//		anEnemy->GetActorData().myController->SetTargetPosition(randomPosition);
//		myHasWanderPosition = true;
//		// IF WE NEED THE PATH BECAUSE OF OBSTACLES:
//		/*std::vector<Tga::Vector3f> path = navmesh.FindShortestPath(anEnemy->GetPosition(), randomPosition);*/
//	}
//
//	Tga::Vector3f targetPosition = anEnemy->GetActorData().myController->GetTargetPosition();
//
//	distance = (targetPosition - currentPosition).Length();
//
//	if (distance < 5.f)
//	{
//		myStateMachine->ChangeState(anEnemy, EnemyStateID::Idle);
//	}
//}
//
//void WanderState::OnExit(Enemy* anEnemy)
//{
//	myHasWanderPosition = false;
//	EnemyState::OnExit(anEnemy);
//}