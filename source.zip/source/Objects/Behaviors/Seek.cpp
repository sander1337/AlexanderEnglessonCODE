#include "stdafx.h"
#include "Seek.h"

#include "tge/math/FMath.h"
#include "../Actors/Enemy/EnemyData.h"
#include "../Actors/Enemy/Enemy.h"

Seek::Seek()
{
}

SteeringOutput Seek::Calculate(Enemy* anEnemy, Tga::Vector3f aTargetPosition, [[maybe_unused]] float aDeltaTime)
{
    SteeringOutput output{};

    if (!myData.isEnabled)
    {
        return output;
    }

    [[maybe_unused]] float speed = anEnemy->GetData().speed;

    output.velocity = aTargetPosition - anEnemy->GetPosition();

    if (output.velocity.LengthSqr() < 1.f) // too small of a number makes the enemy never reach its destination = shaky behaviour
    {
        return output;
    }

    output.velocity.Normalize();
    //output.velocity *= (speed * 50.f * aDeltaTime);
    output.velocity *= 50.f;

    output.rotation = 0.f;

    return output;
}