#include "stdafx.h"
#include "IdleState.h"

//#include <tge/Math/Vector3.h>
//#include "../Actors/Enemy/EnemyData.h"
//#include "StateMachine.h"
//#include "../Actors/Enemy/Enemy.h"
//#include <Utilities/BlackBoard.h>
//#include "../Controller/Controller.h"
//
//
//void IdleState::OnEnter(Enemy* anEnemy)
//{
//	myIdleTimer = 0.f;
//	EnemyState::OnEnter(anEnemy);
//}
//
//void IdleState::Update(Enemy* anEnemy, float aDeltaTime)
//{
//	Tga::Vector3f currentPosition = anEnemy->GetPosition();
//	anEnemy->GetActorData().myController->SetTargetPosition(currentPosition);
//
//	Tga::Vector3f playerPosition = Blackboard::GetInstance()->GetVector3("playerPosition");
//	float aggroRange = anEnemy->GetData().aggroRange;
//
//	float distance = (playerPosition - currentPosition).Length();
//
//	if (distance < aggroRange)
//	{
//		myStateMachine->ChangeState(anEnemy, EnemyStateID::Engage);
//		return;
//	}
//
//	myIdleTimer += aDeltaTime;
//
//	if (myIdleTimer >= myIdleTime)
//	{
//		myStateMachine->ChangeState(anEnemy, EnemyStateID::Wander);
//	}
//}
//
//void IdleState::OnExit(Enemy* anEnemy)
//{
//	myIdleTimer = 0.f;
//	EnemyState::OnExit(anEnemy);
//}