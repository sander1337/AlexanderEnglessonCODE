#pragma once
//#pragma message(__FILE__" was compiled")
#include "SteeringBehavior.h"
#include "SteeringBehaviorDataStructs.h"

class Enemy;

struct CohesionBehaviorData : public BehaviorData
{
    bool isEnabled = true;
    float cohesionRadius = 300.f;
    float cohesionWeight = 1.0f;
};

class Cohesion : public SteeringBehavior
{
public:
    Cohesion();
    ~Cohesion() override = default;

    SteeringOutput Calculate(Enemy* anEnemy, Tga::Vector3f aTargetPosition, float aDeltaTime) override;
    BehaviorData& GetBehaviorData() override;

private:
    CohesionBehaviorData myData;
};