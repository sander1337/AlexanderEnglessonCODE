#include "stdafx.h"
#include "StateMachine.h"

//#include "EnemyState.h"
//#include <Objects/Actors/Enemy/Enemy.h>

//
//void StateMachine::Update(Enemy* anEnemy, float aDeltaTime)
//{
//	myCurrentState->Update(anEnemy, aDeltaTime);
//}
//
//void StateMachine::RegisterState(EnemyStateID aStateID, std::unique_ptr<EnemyState> anEnemyState)
//{
//	anEnemyState->SetOwner(this);
//	myCachedStates.try_emplace(aStateID, std::move(anEnemyState));
//}
//
//void StateMachine::ChangeState(Enemy* anEnemy, EnemyStateID anEnemyStateID)
//{
//	if (myCachedStates.contains(anEnemyStateID))
//	{
//		myCurrentStateID = anEnemyStateID;
//		myCurrentState->OnExit(anEnemy);
//		myCurrentState = myCachedStates.at(anEnemyStateID).get();
//		anEnemy->SetAnimation(anEnemyStateID);
//		myCurrentState->OnEnter(anEnemy);
//	}
//	else
//	{
//		//std::cout << "Tried to change to a EnemyState with ID: " << static_cast<int>(anEnemyStateID) << " that does not exist in the current Enemy State Machine" << "\n";
//	}
//}
//
//void StateMachine::SetInitialState(EnemyStateID anEnemyStateID)
//{
//	if (myCachedStates.contains(anEnemyStateID))
//	{
//		myCurrentStateID = anEnemyStateID;
//		myCurrentState = myCachedStates.at(anEnemyStateID).get();
//	}
//}
//
//EnemyStateID StateMachine::GetCurrentStateID() const
//{
//	return myCurrentStateID;
//}