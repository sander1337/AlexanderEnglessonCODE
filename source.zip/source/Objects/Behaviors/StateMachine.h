#pragma once

//#include "EnemyState.h"
//
//#include <cstdint>
//#include <memory>
//#include <unordered_map>


//class Enemy;
//
//enum class EnemyStateID : uint8_t
//{
//	Idle,
//	Wander,
//	Engage,
//	Buff,
//	Attack,
//	Death,
//	Count
//};
//
//class StateMachine
//{
//public:
//	StateMachine() = default;
//	~StateMachine() = default;
//
//	void Update(Enemy* anEnemy, float aDeltaTime);
//	void RegisterState(EnemyStateID aStateID, std::unique_ptr<EnemyState> anEnemyState);
//	void ChangeState(Enemy* anEnemy, EnemyStateID anEnemyStateID);
//
//	void SetInitialState(EnemyStateID anEnemyStateID);
//
//	EnemyStateID GetCurrentStateID() const;
//
//private:
//	std::unordered_map<EnemyStateID, std::unique_ptr<EnemyState>> myCachedStates;
//	EnemyState* myCurrentState;
//	EnemyStateID myCurrentStateID;
//};