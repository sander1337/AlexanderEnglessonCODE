#pragma once

//#include "EnemyState.h"
//#include <Utilities/PollingStation.h>

//
//class EngageState : public EnemyState
//{
//public:
//	EngageState() = default;
//	~EngageState() override = default;
//
//	void OnEnter(Enemy* anEnemy) override;
//	void Update(Enemy* anEnemy, float aDeltaTime) override;
//	void OnExit(Enemy* anEnemy) override;
//private:
//	AI::PollingStation3D* myPollingStation;
//	std::vector<Actor*> myActors;
//	float myBuffRadius = 500.f;
//};