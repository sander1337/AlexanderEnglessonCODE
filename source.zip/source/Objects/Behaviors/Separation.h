#pragma once
//#pragma message(__FILE__" was compiled")
#include "SteeringBehavior.h"

class Enemy;

struct SeparationBehaviorData : public BehaviorData
{
    float separationRadius = 100.f;
    float separationWeight = 2.0f;
};

class SeparationBehavior : public SteeringBehavior
{
public:
    SeparationBehavior();
    SteeringOutput Calculate(Enemy* anEnemy, Tga::Vector3f aTargetPosition, float aDeltaTime) override;
    BehaviorData& GetBehaviorData() override { return myData; }

private:
    SeparationBehaviorData myData;

    Tga::Vector3f myCurrentVelocity = Tga::Vector3f();
    Tga::Vector3f myPreviousVelocity = Tga::Vector3f();

    bool AreFloat3Equal(Tga::Vector3f aVecA, Tga::Vector3f aVecB, float anEqualLength)
    {
        if (abs((aVecA - aVecB).Length()) < anEqualLength)
        {
            return true;
        }

        return false;
    }
};
