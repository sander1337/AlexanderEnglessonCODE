#pragma once

//#include "EnemyState.h"

//
//class AttackState : public EnemyState
//{
//public:
//	AttackState() = default;
//	~AttackState() override = default;
//
//	void OnEnter(Enemy* anEnemy) override;
//	void Update(Enemy* anEnemy, float aDeltaTime) override;
//	void OnExit(Enemy* anEnemy) override;
//
//private:
//	float myTimeUntilAttack = 0.f;
//};