#pragma once

class StateMachine;
class Enemy;


class EnemyState
{
public:
	EnemyState() = default;
	virtual ~EnemyState() = default;

	virtual void OnEnter(Enemy* anEnemy);
	virtual void Update(Enemy* anEnemy, float aDeltaTime) = 0;
	virtual void OnExit(Enemy* anEnemy);

	void SetOwner(StateMachine* aStateMachine);

protected:
	StateMachine* myStateMachine;
};