#include "EngageState.h"

//#include "stdafx.h"
//
//#include "StateMachine.h"
//#include <GameWorld.h>
//#include <Utilities/BlackBoard.h>
//#include <tge/navmesh/navmesh.h>
//#include <SceneManagement/GameScene.h>
//#include "../Actors/Enemy/Enemy.h"
//#include "../Actors/Enemy/EnemyData.h"

//
//void EngageState::OnEnter(Enemy* anEnemy)
//{
//	anEnemy->ClearPath();
//	anEnemy->GetData().pathRecalculateTimer = anEnemy->GetData().pathRecalculateInterval;
//
//	EnemyState::OnEnter(anEnemy);
//}
//
//void EngageState::Update(Enemy* anEnemy, float aDeltaTime)
//{
//	Tga::Vector3f playerPosition = Blackboard::GetInstance()->GetVector3("playerPosition");
//	float distance = (playerPosition - anEnemy->GetPosition()).Length();
//	float attackRange = anEnemy->GetData().attackRange;
//
//	if (distance <= attackRange)
//	{
//		myStateMachine->ChangeState(anEnemy, EnemyStateID::Attack);
//		return;
//	}
//
//	anEnemy->GetData().pathRecalculateTimer += aDeltaTime;
//
//	if (anEnemy->GetData().pathRecalculateTimer >= anEnemy->GetData().pathRecalculateInterval)
//	{
//		anEnemy->ClearPath();
//		std::weak_ptr<GameScene> gameScene = GameWorld::GetInstance().GetCurrentGameScene();
//		std::shared_ptr<Navmesh> navmesh = gameScene.lock()->GetNavmesh();
//		std::vector<Tga::Vector3f> path;
//		if (navmesh)
//		{
//			constexpr int maxPathSize = 10;
//			Tga::Vector3f safeStart = navmesh->FindNearestInNavmesh(anEnemy->GetPosition());
//			Tga::Vector3f safeTarget = navmesh->FindNearestInNavmesh(playerPosition);
//			path = navmesh->FindShortestPath(safeStart, safeTarget);
//
//			if (path.size() > maxPathSize)
//			{
//				path.clear();
//				myStateMachine->ChangeState(anEnemy, EnemyStateID::Idle);
//				return;
//			}
//		}
//		anEnemy->SetPath(path);
//		anEnemy->GetData().pathRecalculateTimer = 0.f;
//	}
//}
//
//void EngageState::OnExit(Enemy* anEnemy)
//{
//	anEnemy->ClearPath();
//	anEnemy->GetData().pathRecalculateTimer = anEnemy->GetData().pathRecalculateInterval;
//	EnemyState::OnExit(anEnemy);
//}