#include "EnemyState.h"

void EnemyState::OnEnter(Enemy* anEnemy)
{
	anEnemy;
}

void EnemyState::OnExit(Enemy* anEnemy)
{
	anEnemy;
}

void EnemyState::SetOwner(StateMachine* aStateMachine)
{
	myStateMachine = aStateMachine;
}