#pragma once

//#include "EnemyState.h"
//
//
//class IdleState : public EnemyState
//{
//public:
//	IdleState() = default;
//	~IdleState() override = default;
//
//	void OnEnter(Enemy* anEnemy) override;
//	void Update(Enemy* anEnemy, float aDeltaTime) override;
//	void OnExit(Enemy* anEnemy) override;
//
//private:
//	float myIdleTime = 4.f;
//	float myIdleTimer = 0.f;
//};