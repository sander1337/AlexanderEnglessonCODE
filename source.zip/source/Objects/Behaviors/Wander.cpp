#include "stdafx.h"
#include "Wander.h"

#include <Utilities/RandomGenerator.h>
#include "../Actors/Enemy/EnemyData.h"
#include "../Actors/Enemy/Enemy.h"

#include <tge/Math/FMath.h>

Wander::Wander()
{
    myData.weight = 1.0f;
}

//SteeringOutput Wander::Calculate(ActorData& aActor, float aDeltaTime)
//{
//    aDeltaTime;
//    SteeringOutput output{};
//
//    if (!myData.isEnabled)
//    {
//        return output;
//    }
//
//    // --- Adjust wander angle randomly ---
//    float randomFloat = RandomGenerator::GetInstance()->GetRandomFloat(-myData.wanderRate, myData.wanderRate);
//    myData.currentAngle += randomFloat;
//
//    // --- Calculate circle center in front of actor ---
//    const Tga::Vector2f forwardDir(aActor.direction.x, aActor.direction.z);
//    Tga::Vector2f circleCenter = forwardDir.GetNormalized() * myData.wanderOffset;
//
//    // --- Calculate offset on circle ---
//    Tga::Vector2f offset(
//        cosf(myData.currentAngle) * myData.wanderRadius,
//        sinf(myData.currentAngle) * myData.wanderRadius
//    );
//
//    // --- Target direction ---
//    Tga::Vector2f desiredDir = (circleCenter + offset).GetNormalized();
//
//    // --- Blend smoothly (slerp) ---
//    Tga::Vector2f blendedDir = FMath::SLerp2(
//        Tga::Vector2f{ aActor.direction.x, aActor.direction.z },
//        desiredDir,
//        0.1f
//    );
//
//    Tga::Vector3f finalDir(blendedDir.x, 0.f, blendedDir.y);
//    finalDir.Normalize();
//
//    output.velocity = finalDir * aActor.speed * myData.weight;
//
//    return output;
//}

SteeringOutput Wander::Calculate(Enemy* anEnemy, Tga::Vector3f aTargetPosition, float aDeltaTime)
{
    aTargetPosition;
    aDeltaTime;
    SteeringOutput output{};

    if (!myData.isEnabled)
    {
        return output;
    }

    // --- Adjust wander angle randomly ---
    float randomFloat = RandomGenerator::GetInstance()->GetFloat(-myData.wanderRate, myData.wanderRate);
    myData.currentAngle += randomFloat;

    // --- Calculate circle center in front of actor ---
    const Tga::Vector2f forwardDir(anEnemy->GetTransform().GetForward().x, anEnemy->GetTransform().GetForward().z);
    Tga::Vector2f circleCenter = forwardDir.GetNormalized() * myData.wanderOffset;

    // --- Calculate offset on circle ---
    Tga::Vector2f offset(
        cosf(myData.currentAngle) * myData.wanderRadius,
        sinf(myData.currentAngle) * myData.wanderRadius
    );

    // --- Target direction ---
    Tga::Vector2f desiredDir = (circleCenter + offset).GetNormalized();

    // --- Blend smoothly (slerp) ---
    Tga::Vector2f blendedDir = FMath::SLerp2(
        Tga::Vector2f{ anEnemy->GetTransform().GetForward().x, anEnemy->GetTransform().GetForward().z },
        desiredDir,
        0.1f
    );

    Tga::Vector3f finalDir(blendedDir.x, 0.f, blendedDir.y);
    finalDir.Normalize();

    output.velocity = finalDir * anEnemy->GetData().speed * myData.weight;

    return output;
}
