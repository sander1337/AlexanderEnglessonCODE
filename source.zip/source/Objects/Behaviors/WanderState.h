#pragma once

//#include <tge/math/Vector3.h>
//#include "EnemyState.h"

//
//class WanderState : public EnemyState
//{
//public:
//
//	WanderState() = default;
//	~WanderState() override = default;
//
//	void OnEnter(Enemy* anEnemy) override;
//	void Update(Enemy* anEnemy, float aDeltaTime) override;
//	void OnExit(Enemy* anEnemy) override;
//
//	Tga::Vector3f GetRandomWanderPosition(const Tga::Vector3f aPosition, const float aRadius);
//
//private:
//	bool myHasWanderPosition;
//};