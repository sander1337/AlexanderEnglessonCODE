#pragma once
//#pragma message(__FILE__" was compiled")
#include "SteeringBehaviorDataStructs.h"

class Enemy;
struct ActorData;

enum class SteeringBehaviorID : uint8_t
{
	Seek,
    Wander,
    Separate,
    Cohesion,
    Count
};

struct BehaviorData
{
    float weight = 1.0f;
    bool isEnabled = true;
};


class SteeringBehavior
{
public:
    virtual ~SteeringBehavior() = default;

    //virtual SteeringOutput Calculate(ActorData& aActor, float aDeltaTime) = 0;
    virtual SteeringOutput Calculate(Enemy* anEnemy, Tga::Vector3f aTargetPosition, float aDeltaTime) = 0;
    virtual BehaviorData& GetBehaviorData() = 0;
};