// BrainTree - A C++ behaviour tree single header library.
// Copyright 2015-2018 Par Arvidsson. All rights reserved.
// Licensed under the MIT license (https://github.com/arvidsson/BrainTree/blob/master/LICENSE).

#pragma once

#include <memory>
#include <vector>
#include <string>
#include <unordered_map>
#include <cassert>

//#include "PollingStation.h"

////////////////////////////////////////////////////////
struct M
{
	//PollingStation poll;
};
////////////////////////////////////////////////////////


namespace BrainTree
{
	enum class Status
	{
		Invalid,
		Success,
		Failure,
		Running,
	};

	class Node
	{
	public:

		virtual ~Node() {}

		virtual Status Update([[maybe_unused]] const float aDeltaTime) = 0;
		virtual void Init() {}
		virtual void Terminate([[maybe_unused]] Status aS) {}

		Status Tick([[maybe_unused]] const float aDeltaTime)
		{
			if (myStatus != Status::Running)
			{
				Init();
			}

			myStatus = Update(aDeltaTime);

			if (myStatus != Status::Running)
			{
				Terminate(myStatus);
			}

			return myStatus;
		}

		bool IsSuccess() const { return myStatus == Status::Success; }
		bool IsFailure() const { return myStatus == Status::Failure; }
		bool IsRunning() const { return myStatus == Status::Running; }
		bool IsTerminated() const { return IsSuccess() || IsFailure(); }

		void Reset() { myStatus = Status::Invalid; }

		using Ptr = std::shared_ptr<Node>;

		/////////////////////////////////////////////////////////////////////////////////////
		void SetMemory(M* memory) { myMemory = memory; }
		/////////////////////////////////////////////////////////////////////////////////////

	protected:
		Status myStatus = Status::Invalid;

		/////////////////////////////////////////////////////////////////////////////////////
		M* myMemory = nullptr;
		/////////////////////////////////////////////////////////////////////////////////////
	};

	class Composite : public Node
	{
	public:
		Composite() : myIt(myChildren.begin()) {}
		virtual ~Composite() {}

		void AddChild(Node::Ptr aChild) { myChildren.push_back(aChild); }
		bool HasChildren() const { return !myChildren.empty(); }

		/////////////////////////////////////////////////////////////////////////////////////
		std::vector<Node::Ptr> GetChildren() { return myChildren; }
		/////////////////////////////////////////////////////////////////////////////////////

	protected:
		std::vector<Node::Ptr> myChildren;
		std::vector<Node::Ptr>::iterator myIt;
	};

	class Decorator : public Node
	{
	public:
		virtual ~Decorator() {}

		void SetChild(Node::Ptr aNode) { myChild = aNode; }
		bool HasChild() const { return myChild != nullptr; }

		/////////////////////////////////////////////////////////////////////////////////////
		Node::Ptr GetChild() { return myChild; }
		/////////////////////////////////////////////////////////////////////////////////////

	protected:
		Node::Ptr myChild = nullptr;
	};

	class Blackboard
	{
	public:
		void SetBool(std::string aKey, bool aValue) { myBools[aKey] = aValue; }
		bool GetBool(std::string aKey)
		{
			if (myBools.find(aKey) == myBools.end())
			{
				myBools[aKey] = false;
			}
			return myBools[aKey];
		}
		bool HasBool(std::string aKey) const { return myBools.find(aKey) != myBools.end(); }

		void SetInt(std::string aKey, int aValue) { myInts[aKey] = aValue; }
		int GetInt(std::string aKey)
		{
			if (myInts.find(aKey) == myInts.end())
			{
				myInts[aKey] = 0;
			}
			return myInts[aKey];
		}
		bool HasInt(std::string aKey) const { return myInts.find(aKey) != myInts.end(); }

		void SetFloat(std::string aKey, float aValue) { myFloats[aKey] = aValue; }
		float GetFloat(std::string aKey)
		{
			if (myFloats.find(aKey) == myFloats.end())
			{
				myFloats[aKey] = 0.0f;
			}
			return myFloats[aKey];
		}
		bool HasFloat(std::string aKey) const { return myFloats.find(aKey) != myFloats.end(); }

		void SetDouble(std::string aKey, double aValue) { myDoubles[aKey] = aValue; }
		double GetDouble(std::string aKey)
		{
			if (myDoubles.find(aKey) == myDoubles.end())
			{
				myDoubles[aKey] = 0.0f;
			}
			return myDoubles[aKey];
		}
		bool HasDouble(std::string aKey) const { return myDoubles.find(aKey) != myDoubles.end(); }

		void SetString(std::string aKey, std::string aValue) { myStrings[aKey] = aValue; }
		std::string getString(std::string aKey)
		{
			if (myStrings.find(aKey) == myStrings.end())
			{
				myStrings[aKey] = "";
			}
			return myStrings[aKey];
		}
		bool HasString(std::string aKey) const { return myStrings.find(aKey) != myStrings.end(); }

		using Ptr = std::shared_ptr<Blackboard>;

	protected:
		std::unordered_map<std::string, bool> myBools;
		std::unordered_map<std::string, int> myInts;
		std::unordered_map<std::string, float> myFloats;
		std::unordered_map<std::string, double> myDoubles;
		std::unordered_map<std::string, std::string> myStrings;
	};

	class Leaf : public Node
	{
	public:
		Leaf() {}
		virtual ~Leaf() {}
		Leaf(Blackboard::Ptr aBlackboard) : myBlackboard(aBlackboard) {}

		virtual Status Update([[maybe_unused]] const float aDeltaTime) = 0;

	protected:
		Blackboard::Ptr myBlackboard;
	};

	class BehaviourTree : public Node
	{
	public:
		BehaviourTree() : myBlackboard(std::make_shared<Blackboard>()) {}
		BehaviourTree(const Node::Ptr& aRootNode) : BehaviourTree() { myRoot = aRootNode; }

		Status Update([[maybe_unused]] const float aDeltaTime) { return myRoot->Tick(aDeltaTime); }

		Blackboard::Ptr GetBlackboard() const { return myBlackboard; }

		/////////////////////////////////////////////////////////////////////////////////////
		std::unique_ptr<M> m = std::make_unique<M>();

		void SetRoot(const Node::Ptr& aNode)
		{
			myRoot = aNode;
			AssignMemory(myRoot.get(), m.get());
		}

		M* GetMemory()
		{
			return m.get();
		}
		/////////////////////////////////////////////////////////////////////////////////////

	private:
		Node::Ptr myRoot = nullptr;
		Blackboard::Ptr myBlackboard = nullptr;

		/////////////////////////////////////////////////////////////////////////////////////
		void AssignMemory(Node* node, M* memory)
		{
			node->SetMemory(memory);

			if (auto comp = dynamic_cast<Composite*>(node))
			{
				for (auto& c : comp->GetChildren())
				{
					AssignMemory(c.get(), memory);
				}
			}

			if (auto deco = dynamic_cast<Decorator*>(node))
			{
				if (deco->GetChild())
				{
					AssignMemory(deco->GetChild().get(), memory);
				}
			}
		}
		/////////////////////////////////////////////////////////////////////////////////////
	};

	template <class Parent>
	class DecoratorBuilder;

	template <class Parent>
	class CompositeBuilder
	{
	public:
		CompositeBuilder([[maybe_unused]] Parent* aParent, Composite* aNode) : myParent(aParent), myNode(aNode) {}

		template <class NodeType, typename... Args>
		CompositeBuilder<Parent> leaf(Args... anArgs)
		{
			auto child = std::make_shared<NodeType>((anArgs)...);
			myNode->AddChild(child);
			return *this;
		}

		template <class CompositeType, typename... Args>
		CompositeBuilder<CompositeBuilder<Parent>> composite(Args... anArgs)
		{
			auto child = std::make_shared<CompositeType>((anArgs)...);
			myNode->AddChild(child);
			return CompositeBuilder<CompositeBuilder<Parent>>(this, (CompositeType*)child.get());
		}

		template <class DecoratorType, typename... Args>
		DecoratorBuilder<CompositeBuilder<Parent>> decorator(Args... anArgs)
		{
			auto child = std::make_shared<DecoratorType>((anArgs)...);
			myNode->AddChild(child);
			return DecoratorBuilder<CompositeBuilder<Parent>>(this, (DecoratorType*)child.get());
		}

		Parent& end()
		{
			return *myParent;
		}

	private:
		Parent* myParent;
		Composite* myNode;
	};

	template <class Parent>
	class DecoratorBuilder
	{
	public:
		DecoratorBuilder(Parent* aParent, Decorator* aNode) : myParent(aParent), myNode(aNode) {}

		template <class NodeType, typename... Args>
		DecoratorBuilder<Parent> leaf(Args... anArgs)
		{
			auto child = std::make_shared<NodeType>((anArgs)...);
			myNode->SetChild(child);
			return *this;
		}

		template <class CompositeType, typename... Args>
		CompositeBuilder<DecoratorBuilder<Parent>> composite(Args... anArgs)
		{
			auto child = std::make_shared<CompositeType>((anArgs)...);
			myNode->SetChild(child);
			return CompositeBuilder<DecoratorBuilder<Parent>>(this, (CompositeType*)child.get());
		}

		template <class DecoratorType, typename... Args>
		DecoratorBuilder<DecoratorBuilder<Parent>> decorator(Args... anArgs)
		{
			auto child = std::make_shared<DecoratorType>((anArgs)...);
			myNode->SetChild(child);
			return DecoratorBuilder<DecoratorBuilder<Parent>>(this, (DecoratorType*)child.get());
		}

		Parent& end()
		{
			return *myParent;
		}

	private:
		Parent* myParent;
		Decorator* myNode;
	};

	class Builder
	{
	public:
		template <class NodeType, typename... Args>
		Builder leaf(Args... anArgs)
		{
			myRoot = std::make_shared<NodeType>((anArgs)...);
			return *this;
		}

		template <class CompositeType, typename... Args>
		CompositeBuilder<Builder> composite(Args... anArgs)
		{
			myRoot = std::make_shared<CompositeType>((anArgs)...);
			return CompositeBuilder<Builder>(this, (CompositeType*)myRoot.get());
		}

		template <class DecoratorType, typename... Args>
		DecoratorBuilder<Builder> decorator(Args... anArgs)
		{
			myRoot = std::make_shared<DecoratorType>((anArgs)...);
			return DecoratorBuilder<Builder>(this, (DecoratorType*)myRoot.get());
		}

		Node::Ptr Build()
		{
			assert(myRoot != nullptr && "The Behavior Tree is empty!");
			auto tree = std::make_shared<BehaviourTree>();
			tree->SetRoot(myRoot);
			return tree;
		}

	private:
		Node::Ptr myRoot;
	};

	// The Selector composite ticks each myChild aNode in order.
	// If a myChild succeeds or runs, the selector returns the same status.
	// In the next tick, it will try to run each myChild in order again.
	// If all children fails, only then does the selector fail.
	class Selector : public Composite
	{
	public:
		void Init() override
		{
			myIt = myChildren.begin();
		}

		Status Update([[maybe_unused]] const float aDeltaTime) override
		{
			assert(HasChildren() && "Composite has no children");

			while (myIt != myChildren.end())
			{
				auto status = (*myIt)->Tick(aDeltaTime);

				if (status != Status::Failure)
				{
					return status;
				}

				myIt++;
			}

			return Status::Failure;
		}
	};

	// The Sequence composite ticks each myChild aNode in order.
	// If a myChild fails or runs, the sequence returns the same status.
	// In the next tick, it will try to run each myChild in order again.
	// If all children succeeds, only then does the sequence succeed.
	class Sequence : public Composite
	{
	public:
		void Init() override
		{
			myIt = myChildren.begin();
		}

		Status Update([[maybe_unused]] const float aDeltaTime) override
		{
			assert(HasChildren() && "Composite has no children");

			while (myIt != myChildren.end())
			{
				auto status = (*myIt)->Tick(aDeltaTime);

				if (status != Status::Success)
				{
					return status;
				}

				myIt++;
			}

			return Status::Success;
		}
	};

	// The StatefulSelector composite ticks each myChild aNode in order, and remembers what myChild it prevously tried to tick.
	// If a myChild succeeds or runs, the stateful selector returns the same status.
	// In the next tick, it will try to run the next myChild or start from the beginning again.
	// If all children fails, only then does the stateful selector fail.
	class StatefulSelector : public Composite
	{
	public:
		Status Update([[maybe_unused]] const float aDeltaTime) override
		{
			assert(HasChildren() && "Composite has no children");


			//// Initialize iterator if it's invalid
			//if (myIt == myChildren.end())
			//{
			//	myIt = myChildren.begin();
			//}


			//myChildren.at(myIt);
			//if (myChildren[myIt] )


			//if (myIt._Ptr->get())
			{
				while (myIt != myChildren.end())
				{
					auto status = (*myIt)->Tick(aDeltaTime);

					if (status != Status::Failure)
					{
						return status;
					}

					myIt++;
				}
			}

			myIt = myChildren.begin();
			return Status::Failure;
		}
	};

	// The StatefulSequence composite ticks each myChild aNode in order, and remembers what myChild it prevously tried to tick.
	// If a myChild fails or runs, the stateful sequence returns the same status.
	// In the next tick, it will try to run the next myChild or start from the beginning again.
	// If all children succeeds, only then does the stateful sequence succeed.
	class MemSequence : public Composite
	{
	public:
		Status Update([[maybe_unused]] const float aDeltaTime) override
		{
			assert(HasChildren() && "Composite has no children");

			while (myIt != myChildren.end())
			{
				auto status = (*myIt)->Tick(aDeltaTime);

				if (status != Status::Success)
				{
					return status;
				}

				myIt++;
			}

			myIt = myChildren.begin();
			return Status::Success;
		}
	};

	class ParallelSequence : public Composite
	{
	public:
		ParallelSequence(bool aSuccessOnAll = true, bool aFailOnAll = true) : myUseSuccessFailPolicy(true), mySuccessOnAll(aSuccessOnAll), myFailOnAll(aFailOnAll) {}
		ParallelSequence(int aMinSuccess, int aMinFail) : myMinSuccess(aMinSuccess), myMinFail(aMinFail) {}

		Status Update([[maybe_unused]] const float aDeltaTime) override
		{
			assert(HasChildren() && "Composite has no children");

			int minimumSuccess = myMinSuccess;
			int minimumFail = myMinFail;

			if (myUseSuccessFailPolicy)
			{
				if (mySuccessOnAll)
				{
					minimumSuccess = static_cast<int>(myChildren.size());
				}
				else
				{
					minimumSuccess = 1;
				}

				if (myFailOnAll)
				{
					minimumFail = static_cast<int>(myChildren.size());
				}
				else {
					minimumFail = 1;
				}
			}

			int total_success = 0;
			int total_fail = 0;

			for (auto& myChild : myChildren) {
				auto status = myChild->Tick(aDeltaTime);
				if (status == Status::Success) {
					total_success++;
				}
				if (status == Status::Failure) {
					total_fail++;
				}
			}

			if (total_success >= minimumSuccess) {
				return Status::Success;
			}
			if (total_fail >= minimumFail) {
				return Status::Failure;
			}

			return Status::Running;
		}

	private:
		bool myUseSuccessFailPolicy = false;
		bool mySuccessOnAll = true;
		bool myFailOnAll = true;
		int myMinSuccess = 0;
		int myMinFail = 0;
	};

	// The Succeeder decorator returns success, regardless of what happens to the myChild.
	class Succeeder : public Decorator
	{
	public:
		Status Update([[maybe_unused]] const float aDeltaTime) override
		{
			myChild->Tick(aDeltaTime);
			return Status::Success;
		}
	};

	// The Failer decorator returns failure, regardless of what happens to the myChild.
	class Failer : public Decorator
	{
	public:
		Status Update([[maybe_unused]] const float aDeltaTime) override
		{
			myChild->Tick(aDeltaTime);
			return Status::Failure;
		}
	};

	// The Inverter decorator inverts the myChild aNode's status, i.e. failure becomes success and success becomes failure.
	// If the myChild runs, the Inverter returns the status that it is running too.
	class Inverter : public Decorator
	{
	public:
		Status Update([[maybe_unused]] const float aDeltaTime) override
		{
			auto s = myChild->Tick(aDeltaTime);

			if (s == Status::Success) {
				return Status::Failure;
			}
			else if (s == Status::Failure) {
				return Status::Success;
			}

			return s;
		}
	};

	// The Repeater decorator repeats infinitely or to a limit until the myChild returns success.
	class Repeater : public Decorator
	{
	public:
		Repeater(int limit = 0) : limit(limit) {}

		void Init() override
		{
			counter = 0;
		}

		Status Update([[maybe_unused]] const float aDeltaTime) override
		{
			auto status = myChild->Tick(aDeltaTime);

			if (status == Status::Success) {
				return Status::Success;
			}

			if (limit > 0 && ++counter == limit) {
				return Status::Success;
			}

			return Status::Running;
		}

	protected:
		int limit;
		int counter = 0;
	};

	// The UntilSuccess decorator repeats until the myChild returns success and then returns success.
	class UntilSuccess : public Decorator
	{
	public:
		Status Update([[maybe_unused]] const float aDeltaTime) override
		{
			while (1)
			{
				auto status = myChild->Tick(aDeltaTime);

				if (status == Status::Success)
				{
					return Status::Success;
				}
			}
		}
	};

	// The UntilFailure decorator repeats until the myChild returns fail and then returns success.
	class UntilFailure : public Decorator
	{
	public:
		Status Update([[maybe_unused]] const float aDeltaTime) override
		{
			while (1)
			{
				auto status = myChild->Tick(aDeltaTime);

				if (status == Status::Failure)
				{
					return Status::Success;
				}
			}
		}
	};

} // namespace BrainTree