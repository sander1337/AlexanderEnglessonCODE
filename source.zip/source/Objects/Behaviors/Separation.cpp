#include "stdafx.h"
#include "Separation.h"

#include <Objects/Actors/Enemy/EnemyData.h>
#include <Objects/Actors/Enemy/Enemy.h>
#include <Utilities/PollingStation.h>
#include <vector>


SeparationBehavior::SeparationBehavior()
{
	myData.weight = 1.0f;
}

SteeringOutput SeparationBehavior::Calculate(Enemy* anEnemy, [[maybe_unused]] Tga::Vector3f aTargetPosition, float aDeltaTime)
{
	SteeringOutput output{};
	output.rotation = 0.0f;
	output.velocity = Tga::Vector3f();

	if (!myData.isEnabled)
	{
		return output;
	}

	// --- Get neighbors from PollingStation ---
	auto& poll = AI::PollingStation3D::Get();
	std::vector<Tga::Vector3f> neighbors = poll.GetNeighbourPositions(anEnemy->GetPosition(), myData.separationRadius);

	if (neighbors.empty())
	{
		return output;
	}

	// --- Calculate steering away from neighbors ---
	Tga::Vector3f steer = { 0.f, 0.f, 0.f };
	const float radiusSquared = myData.separationRadius * myData.separationRadius;

	float distance = 0.f;
	for (const auto& neighborPos : neighbors)
	{
		Tga::Vector3f delta = anEnemy->GetPosition() - neighborPos;
		delta.y = 0.0f;

		float distanceSquared = delta.LengthSqr();

		if (distanceSquared > radiusSquared || distanceSquared < FMath::KindaSmallNumber)
			continue;

		distance = sqrtf(distanceSquared);
		Tga::Vector3f away = delta / distance;
		float strength = powf((myData.separationRadius - distance) / myData.separationRadius, 2.0f);
		steer += away * strength;
	}

	// keep it flat
	steer.y = 0.0f;
	if (steer.LengthSqr() > FMath::SmallNumber)
		steer.Normalize();

	steer *= myData.separationWeight * myData.weight;

	// If velocity is the same as previous, skip
	myCurrentVelocity = steer * anEnemy->GetData().speed * 50.f * aDeltaTime;
	if (!AreFloat3Equal(myCurrentVelocity, myPreviousVelocity, 1.f))
	{
		output.velocity = myCurrentVelocity;
	}
	myPreviousVelocity = myCurrentVelocity;

	return output;
}