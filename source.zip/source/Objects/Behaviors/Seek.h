#pragma once
//#pragma message(__FILE__" was compiled")
#include "SteeringBehavior.h"

class Enemy;

struct SeekBehaviorData : public BehaviorData
{
    float maxAcceleration = 500.f;
};

class Seek : public SteeringBehavior
{
public:
    Seek();
    ~Seek() override = default;

    SteeringOutput Calculate(Enemy* anEnemy, Tga::Vector3f aTargetPosition, float aDeltaTime) override;
    //SteeringOutput Calculate(ActorData& aActorData, float aDeltaTime) override;
    BehaviorData& GetBehaviorData() override { return myData; }

private:
    SeekBehaviorData myData;
};

