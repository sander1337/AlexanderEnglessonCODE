#include "stdafx.h"
#include "AttackState.h"

//#include <Utilities/BlackBoard.h>
//#include <Graphics/VFXmanager.h>
//#include "StateMachine.h"
//#include "../Actors/Enemy/EnemyData.h"
//#include "../Actors/Enemy/Enemy.h"
//#include "../Controller/Controller.h"
//
//
//void AttackState::OnEnter(Enemy* anEnemy)
//{
//	myTimeUntilAttack = anEnemy->GetData().attackInterval;
//	EnemyState::OnEnter(anEnemy);
//}
//
//void AttackState::Update(Enemy* anEnemy, [[maybe_unused]] float aDeltaTime)
//{
//	const float attackRange = anEnemy->GetData().attackRange;
//	const Tga::Vector3f playerPosition = Blackboard::GetInstance()->GetVector3("playerPosition");
//	const Tga::Vector3f currentPosition = anEnemy->GetPosition();
//	const Tga::Vector3f difference = playerPosition - currentPosition;
//
//	if (difference.Length() > attackRange)
//	{
//		myStateMachine->ChangeState(anEnemy, EnemyStateID::Engage);
//		return;
//	}
//	
//	anEnemy->GetActorData().myController->SetTargetPosition(currentPosition);
//	anEnemy->RotateTowardsVelocityOrDirection(difference, aDeltaTime);
//
//	if (anEnemy->TryAttack())
//	{
//		anEnemy->SetAnimation(EnemyStateID::Attack);
//	}
//}
//
//void AttackState::OnExit(Enemy* anEnemy)
//{
//	myTimeUntilAttack = 0.f;
//	EnemyState::OnExit(anEnemy);
//}