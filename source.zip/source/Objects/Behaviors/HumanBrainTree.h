#pragma once

#include <iostream>
#include "../Behaviors/BrainTree.h"

class Enemy;

enum class EnemyStateID : uint8_t
{
	Idle,
	Wander,
	Engage,
	Buff,
	Attack,
	Death,
	Count
};
class Player;


class HumanBrainTree
{
	BrainTree::BehaviourTree myTree;

	struct Context
	{
	public:
		Enemy* enemy = nullptr;
		EnemyStateID enemyState = EnemyStateID::Count;
		Player* player = nullptr;
	} myContext;

	bool myHasWanderPosition = false;
	bool myHasPlayer = false;

	float myTimeUntilAttack = 0.f;
	float myIdleTime = 4.f;
	float myIdleTimer = 0.f;

public:
	HumanBrainTree() {};
	~HumanBrainTree() {};

	void Init(Enemy* anEnemy);
	void Update([[maybe_unused]] const float aDeltaTime);

	void SetStateIdle() { myContext.enemyState = EnemyStateID::Idle; }

	//////

	BrainTree::BehaviourTree* GetTree() { return &myTree; }
	Context* GetContext() { return &myContext; }

	bool& GetHasWanderPosition() { return myHasWanderPosition; }
	void SetHasWanderPosition(bool aHasWanderPos) { myHasWanderPosition = aHasWanderPos; }

	float& GetTimeUntilAttack() { return myTimeUntilAttack; }
	float& GetIdleTime() { return myIdleTime; }
	float& GetIdleTimer() { return myIdleTimer; }

	void SetTimeUntilAttack(float aTimeUntilAttack) { myTimeUntilAttack = aTimeUntilAttack; }
	void SetIdleTime(float aIdleTime) { myIdleTime = aIdleTime; }
	void SetIdleTimer(float aIdleTimer) { myIdleTimer = aIdleTimer; }
};