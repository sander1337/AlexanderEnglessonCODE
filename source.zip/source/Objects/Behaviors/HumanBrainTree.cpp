#include "HumanBrainTree.h"

#include "../Actors/Enemy/Enemy.h"
#include "../Actors/Enemy/EnemyData.h"
#include "../Behaviors/EnemyState.h"
#include "../../Utilities/Blackboard.h"
#include "../../Engine/tge/navmesh/navmesh.h"
#include "../source/SceneManagement/GameScene.h"
#include "../source/GameWorld.h"
#include "Objects/Controller/Controller.h"
#include "Utilities/PollingStation.h"
#include "Objects/Actors/Player/Player.h"

#include "../../Audio/AudioManager.h"
#include "Utilities/ConstantIdentifiers.h"


namespace EnemyBT
{
	////////// ATTACK //////////

	class AttackOnEnter : public BrainTree::Leaf
	{
	public:
		HumanBrainTree* brain = nullptr;

		AttackOnEnter(HumanBrainTree* aBrain)
			: BrainTree::Leaf(nullptr), brain(aBrain)
		{
		}

		AttackOnEnter() : BrainTree::Leaf(nullptr) {}
		BrainTree::Status Update([[maybe_unused]] const float aDeltaTime) override
		{
			if (brain->GetContext()->enemyState == EnemyStateID::Attack)
			{
				brain->GetContext()->enemy->SetAnimation(EnemyStateID::Attack);

				brain->SetTimeUntilAttack(brain->GetContext()->enemy->GetData().attackInterval);
				return BrainTree::Status::Success;
			}
			else
			{
				return BrainTree::Status::Failure;
			}

		}
	};
	class AttackUpdate : public BrainTree::Leaf
	{
	public:
		HumanBrainTree* brain = nullptr;

		AttackUpdate(HumanBrainTree* aBrain)
			: BrainTree::Leaf(nullptr), brain(aBrain)
		{
		}

		AttackUpdate() : BrainTree::Leaf(nullptr) {}
		BrainTree::Status Update([[maybe_unused]] const float aDeltaTime) override
		{
			const float attackRange = brain->GetContext()->enemy->GetData().attackRange;
			const Tga::Vector3f playerPosition = Blackboard::GetInstance()->GetVector3("playerPosition");
			const Tga::Vector3f currentPosition = brain->GetContext()->enemy->GetPosition();
			const Tga::Vector3f difference = playerPosition - currentPosition;

			if (difference.Length() > attackRange)
			{
				brain->GetContext()->enemyState = EnemyStateID::Engage;
				return BrainTree::Status::Failure;
			}

			const Tga::Vector3f offsetFromPlayer = difference.GetNormalized() * 150.f;
			
			brain->GetContext()->enemy->GetActorData().myController->SetTargetPosition(playerPosition - offsetFromPlayer);
			brain->GetContext()->enemy->RotateTowardsVelocityOrDirection(difference, aDeltaTime);

			brain->GetContext()->enemy->SetAnimation(EnemyStateID::Attack);

			unsigned int frame = brain->GetContext()->enemy->GetCurrentAnimation()->GetFrame();
			//if (frame < 16 && frame > 14)
			if (frame == 15)
			{
				brain->GetContext()->enemy->TryAttack();
			}
			return BrainTree::Status::Running;
		}
	};
	class AttackOnExit : public BrainTree::Leaf
	{
	public:
		HumanBrainTree* brain = nullptr;

		AttackOnExit(HumanBrainTree* aBrain)
			: BrainTree::Leaf(nullptr), brain(aBrain)
		{
		}

		AttackOnExit() : BrainTree::Leaf(nullptr) {}
		BrainTree::Status Update([[maybe_unused]] const float aDeltaTime) override
		{
			brain->SetTimeUntilAttack(0.f);
			return BrainTree::Status::Success;
		}
	};



	////////// IDLE //////////

	class IdleOnEnter : public BrainTree::Leaf
	{
	public:
		HumanBrainTree* brain = nullptr;

		IdleOnEnter(HumanBrainTree* aBrain)
			: BrainTree::Leaf(nullptr), brain(aBrain)
		{
		}

		IdleOnEnter() : BrainTree::Leaf(nullptr) {}
		BrainTree::Status Update([[maybe_unused]] const float aDeltaTime) override
		{
			if (brain->GetContext()->enemyState == EnemyStateID::Idle)
			{
				brain->GetContext()->enemy->SetAnimation(EnemyStateID::Idle);
				brain->SetIdleTimer(0.f);
				return BrainTree::Status::Success;
			}
			else
			{
				return BrainTree::Status::Failure;
			}
		}
	};
	class IdleUpdate : public BrainTree::Leaf
	{
	public:
		HumanBrainTree* brain = nullptr;

		IdleUpdate(HumanBrainTree* aBrain)
			: BrainTree::Leaf(nullptr), brain(aBrain)
		{
		}

		IdleUpdate() : BrainTree::Leaf(nullptr) {}
		BrainTree::Status Update([[maybe_unused]] const float aDeltaTime) override
		{
			Tga::Vector3f currentPosition = brain->GetContext()->enemy->GetPosition();
			brain->GetContext()->enemy->GetActorData().myController->SetTargetPosition(currentPosition);

			Tga::Vector3f playerPosition = Blackboard::GetInstance()->GetVector3("playerPosition");
			float aggroRange = brain->GetContext()->enemy->GetData().aggroRange;

			float distance = (playerPosition - currentPosition).Length();

			if (distance < aggroRange)
			{
				brain->GetContext()->enemyState = EnemyStateID::Engage;
				return BrainTree::Status::Failure;
			}

			brain->SetIdleTimer(brain->GetIdleTimer() + aDeltaTime);

			if (brain->GetIdleTimer() >= brain->GetIdleTime())
			{
				brain->GetContext()->enemyState = EnemyStateID::Wander;
				return BrainTree::Status::Failure;
			}

			return BrainTree::Status::Running;
		}
	};
	class IdleOnExit : public BrainTree::Leaf
	{
	public:
		HumanBrainTree* brain = nullptr;

		IdleOnExit(HumanBrainTree* aBrain)
			: BrainTree::Leaf(nullptr), brain(aBrain)
		{
		}

		IdleOnExit() : BrainTree::Leaf(nullptr) {}
		BrainTree::Status Update([[maybe_unused]] const float aDeltaTime) override
		{
			brain->SetIdleTimer(0.f);
			return BrainTree::Status::Success;
		}
	};



	////////// ENGAGE //////////

	class EngageOnEnter : public BrainTree::Leaf
	{
	public:
		HumanBrainTree* brain = nullptr;

		EngageOnEnter(HumanBrainTree* aBrain)
			: BrainTree::Leaf(nullptr), brain(aBrain)
		{
		}

		EngageOnEnter() : BrainTree::Leaf(nullptr) {}
		BrainTree::Status Update([[maybe_unused]] const float aDeltaTime) override
		{
			if (brain->GetContext()->enemyState == EnemyStateID::Engage)
			{
				brain->GetContext()->enemy->SetAnimation(EnemyStateID::Engage);
				brain->GetContext()->enemy->ClearPath();
				brain->GetContext()->enemy->GetData().pathRecalculateTimer = brain->GetContext()->enemy->GetData().pathRecalculateInterval;

				return BrainTree::Status::Success;
			}
			else
			{
				return BrainTree::Status::Failure;
			}
		}
	};
	class EngageUpdate : public BrainTree::Leaf
	{
	public:
		HumanBrainTree* brain = nullptr;

		EngageUpdate(HumanBrainTree* aBrain)
			: BrainTree::Leaf(nullptr), brain(aBrain)
		{
		}

		EngageUpdate() : BrainTree::Leaf(nullptr) {}
		BrainTree::Status Update([[maybe_unused]] const float aDeltaTime) override
		{
			Tga::Vector3f playerPosition = Blackboard::GetInstance()->GetVector3("playerPosition");
			float distance = (playerPosition - brain->GetContext()->enemy->GetPosition()).Length();
			float attackRange = brain->GetContext()->enemy->GetData().attackRange;

			if (distance <= attackRange)
			{
				brain->GetContext()->enemyState = EnemyStateID::Attack;
				return BrainTree::Status::Failure;
			}

			brain->GetContext()->enemy->GetData().pathRecalculateTimer += aDeltaTime;

			if (brain->GetContext()->enemy->GetData().pathRecalculateTimer >= brain->GetContext()->enemy->GetData().pathRecalculateInterval)
			{
				brain->GetContext()->enemy->ClearPath();
				std::weak_ptr<GameScene> gameScene = GameWorld::GetInstance().GetCurrentGameScene();
				std::shared_ptr<Navmesh> navmesh = gameScene.lock()->GetNavmesh();
				std::vector<Tga::Vector3f> path;
				if (navmesh)
				{
					constexpr int maxPathSize = 10;
					Tga::Vector3f safeStart = navmesh->FindNearestInNavmesh(brain->GetContext()->enemy->GetPosition());
					Tga::Vector3f safeTarget = navmesh->FindNearestInNavmesh(playerPosition);
					path = navmesh->FindShortestPath(safeStart, safeTarget);

					if (path.size() > maxPathSize)
					{
						path.clear();

						brain->GetContext()->enemyState = EnemyStateID::Idle;
						return BrainTree::Status::Failure;
					}
				}
				brain->GetContext()->enemy->SetPath(path);
				brain->GetContext()->enemy->GetData().pathRecalculateTimer = 0.f;
			}

			return BrainTree::Status::Running;
		}
	};
	class EngageOnExit : public BrainTree::Leaf
	{
	public:
		HumanBrainTree* brain = nullptr;

		EngageOnExit(HumanBrainTree* aBrain)
			: BrainTree::Leaf(nullptr), brain(aBrain)
		{
		}

		EngageOnExit() : BrainTree::Leaf(nullptr) {}
		BrainTree::Status Update([[maybe_unused]] const float aDeltaTime) override
		{
			brain->GetContext()->enemy->ClearPath();
			brain->GetContext()->enemy->GetData().pathRecalculateTimer = brain->GetContext()->enemy->GetData().pathRecalculateInterval;
			return BrainTree::Status::Success;
		}
	};



	////////// WANDER //////////

	class WanderOnEnter : public BrainTree::Leaf
	{
	public:
		HumanBrainTree* brain = nullptr;

		WanderOnEnter(HumanBrainTree* aBrain)
			: BrainTree::Leaf(nullptr), brain(aBrain)
		{
		}

		WanderOnEnter() : BrainTree::Leaf(nullptr) {}
		BrainTree::Status Update([[maybe_unused]] const float aDeltaTime) override
		{
			if (brain->GetContext()->enemyState == EnemyStateID::Wander)
			{
				brain->GetContext()->enemy->SetAnimation(EnemyStateID::Wander);
				brain->SetHasWanderPosition(false);
				return BrainTree::Status::Success;
			}
			else
			{
				return BrainTree::Status::Failure;
			}
		}
	};
	class WanderUpdate : public BrainTree::Leaf
	{
	public:
		HumanBrainTree* brain = nullptr;

		WanderUpdate(HumanBrainTree* aBrain)
			: BrainTree::Leaf(nullptr), brain(aBrain)
		{
		}

		WanderUpdate() : BrainTree::Leaf(nullptr) {}
		BrainTree::Status Update([[maybe_unused]] const float aDeltaTime) override
		{
			Tga::Vector3f playerPosition = Blackboard::GetInstance()->GetVector3("playerPosition");
			Tga::Vector3f currentPosition = brain->GetContext()->enemy->GetPosition();
			float aggroRange = brain->GetContext()->enemy->GetData().aggroRange;

			float distance = (playerPosition - currentPosition).Length();

			if (distance < aggroRange)
			{
				brain->GetContext()->enemyState = EnemyStateID::Engage;
				return BrainTree::Status::Failure;
			}

			if (!brain->GetHasWanderPosition())
			{
				std::weak_ptr<GameScene> gameScene = GameWorld::GetInstance().GetCurrentGameScene();
				Navmesh& navmesh = *gameScene.lock().get()->GetNavmesh();
				float wanderRadius = 300.f;
				Tga::Vector3f randomPosition = navmesh.GetRandomNearbyPosition(currentPosition, wanderRadius);
				brain->GetContext()->enemy->GetActorData().myController->SetTargetPosition(randomPosition);
				brain->SetHasWanderPosition(true);

				// IF WE NEED THE PATH BECAUSE OF OBSTACLES:
				/*std::vector<Tga::Vector3f> path = navmesh.FindShortestPath(myContext.enemy->GetPosition(), randomPosition);*/
			}

			Tga::Vector3f targetPosition = brain->GetContext()->enemy->GetActorData().myController->GetTargetPosition();

			distance = (targetPosition - currentPosition).Length();

			if (distance < 5.f)
			{
				brain->GetContext()->enemyState = EnemyStateID::Idle;
			}

			return BrainTree::Status::Running;
		}
	};
	class WanderOnExit : public BrainTree::Leaf
	{
	public:
		HumanBrainTree* brain = nullptr;

		WanderOnExit(HumanBrainTree* aBrain)
			: BrainTree::Leaf(nullptr), brain(aBrain)
		{
		}

		WanderOnExit() : BrainTree::Leaf(nullptr) {}
		BrainTree::Status Update([[maybe_unused]] const float aDeltaTime) override
		{
			brain->SetHasWanderPosition(false);
			return BrainTree::Status::Success;
		}
	};
}

void HumanBrainTree::Init(Enemy* anEnemy)
{
	myContext.enemy = anEnemy;
	myContext.enemyState = EnemyStateID::Idle;

	myTree = BrainTree::Builder()
		.composite<BrainTree::Selector>()
		.composite<BrainTree::Sequence>()
		.leaf<EnemyBT::AttackOnEnter>(this)
		.leaf<EnemyBT::AttackUpdate>(this)
		.leaf<EnemyBT::AttackOnExit>(this)
		.end()

		.composite<BrainTree::Sequence>()
		.leaf<EnemyBT::EngageOnEnter>(this)
		.leaf<EnemyBT::EngageUpdate>(this)
		.leaf<EnemyBT::EngageOnExit>(this)
		.end()

		.composite<BrainTree::Sequence>()
		.leaf<EnemyBT::WanderOnEnter>(this)
		.leaf<EnemyBT::WanderUpdate>(this)
		.leaf<EnemyBT::WanderOnExit>(this)
		.end()

		.composite<BrainTree::Sequence>()
		.leaf<EnemyBT::IdleOnEnter>(this)
		.leaf<EnemyBT::IdleUpdate>(this)
		.leaf<EnemyBT::IdleOnExit>(this)
		.end()
		.end()
		.Build();
}

void HumanBrainTree::Update([[maybe_unused]] const float aDeltaTime)
{
	if (!myHasPlayer)
	{
		if (!myContext.player)
		{
			if (AI::PollingStation3D::Get().GetPlayer())
			{
				myContext.player = AI::PollingStation3D::Get().GetPlayer();
				myHasPlayer = true;
			}
		}
	}

	myTree.Update(aDeltaTime);

	// AUDIO
	switch (myContext.enemyState)
	{
	case EnemyStateID::Idle:
	{
		break;
	}
	case EnemyStateID::Wander:
	{
		if (myContext.enemy->GetCurrentAnimation()->GetFrame() == 0 || myContext.enemy->GetCurrentAnimation()->GetFrame() == 11)
		{
			AudioManager::GetInstance()->PlayOneShotAudio(AudioConstExpr::FOOTSTEP, myContext.enemy->GetTransform());
		}
		break;
	}
	case EnemyStateID::Engage:
	{
		if (myContext.enemy->GetCurrentAnimation()->GetFrame() == 0 || myContext.enemy->GetCurrentAnimation()->GetFrame() == 11)
		{
			AudioManager::GetInstance()->PlayOneShotAudio(AudioConstExpr::FOOTSTEP, myContext.enemy->GetTransform());
		}
		break;
	}
	case EnemyStateID::Buff:
	{
		break;
	}
	case EnemyStateID::Attack:
	{
		break;
	}
	case EnemyStateID::Death:
	{
		break;
	}
	}
}