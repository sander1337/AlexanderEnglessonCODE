#include "stdafx.h"
#include "Cohesion.h"

#include "../Actors/Enemy/EnemyData.h"
#include "../Actors/Enemy/Enemy.h"
#include "SteeringBehaviorDataStructs.h"
#include <Utilities/PollingStation.h>

Cohesion::Cohesion()
{
}

SteeringOutput Cohesion::Calculate(Enemy* anEnemy, Tga::Vector3f aTargetPosition, float aDeltaTime)
{
    aTargetPosition;
    aDeltaTime;
    SteeringOutput output{};

    if (!myData.isEnabled)
    {
        return output;
    }

    AI::PollingStation3D& poll = AI::PollingStation3D::Get();
    std::vector<Tga::Vector3f> neighbors = poll.GetNeighbourPositions(anEnemy, myData.cohesionRadius);

    if (neighbors.empty())
    {
        return output;
    }

    // Compute the average (centroid) of nearby neighbors
    Tga::Vector3f center{ 0.f, 0.f, 0.f };
    for (const auto& pos : neighbors)
    {
        center += pos;
    }

    center /= static_cast<float>(neighbors.size());

    // Direction toward the center
    Tga::Vector3f toCenter = center - anEnemy->GetPosition();

    if (toCenter.LengthSqr() < FMath::SmallNumber)
    {
        return output;
    }

    toCenter.Normalize();

    // Weighted velocity
    toCenter *= anEnemy->GetData().speed * myData.cohesionWeight;

    output.velocity = toCenter;
    output.rotation = 0.0f;

    return output;
}

BehaviorData& Cohesion::GetBehaviorData()
{
	return myData;
}
