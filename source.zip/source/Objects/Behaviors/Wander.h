#pragma once
//#pragma message(__FILE__" was compiled")
#include "SteeringBehavior.h"

struct WanderBehaviorData : public BehaviorData
{
    float wanderRadius = 50.f;
    float wanderRate = 0.5f;
    float wanderOffset = 2.f;
    float currentAngle = 0.f;
};

class Wander : public SteeringBehavior
{
public:
    Wander();
    //SteeringOutput Calculate(ActorData& aActor, float aDeltaTime) override;
    SteeringOutput Calculate(Enemy* anEnemy, Tga::Vector3f aTargetPosition, float aDeltaTime) override;
    BehaviorData& GetBehaviorData() override { return myData; }

private:
    WanderBehaviorData myData;
    
};

