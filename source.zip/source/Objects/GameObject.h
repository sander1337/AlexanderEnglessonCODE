#pragma once


#include <memory>
#include <tge/scene/ScenePropertyTypes.h>
#include "../Render/RenderData.h"
#include <tge/script/ScriptObject.h>
#include "tge/components/Component.h"
#include <map>
#include <typeindex>

class EffectMaterial;
class Collider;
class Human;
class BaseModelInstance;
struct AnimatedObject;

namespace Tga
{
    struct Sprite3DInstanceData;
    struct SpriteSharedData;
    class Model;
}

class GameObject : public ScriptObject
{
public:
    GameObject() = default;
    virtual ~GameObject() = default;

    virtual void Init();
    virtual void Update(float aDeltaTime);
    virtual void DebugRender();
    virtual void ResetMe();

    virtual void SetAnimatedObject(AnimatedObject& aAnimatedObject);
    virtual AnimatedObject GetAnimatedObject();
    
    virtual void OnCollision(const std::shared_ptr<Collider>& anOther);
    //virtual AnimatedObject GetAnimatedObject() {};

    // Setters
    void SetModelInstance(const std::shared_ptr<BaseModelInstance>& aModelInstance);
    void SetPosition(const Tga::Vector3f& aPosition) const;
    void SetRotation(const Tga::Vector3f& aRotation) const;
    void SetScale(const Tga::Vector3f& aScale);
    void SetTransform(const Tga::Matrix4x4f& aTransform) const;
    void SetShouldRender(bool aShouldRender);
    void SetTag(Tga::Tag aTag);
    void SetEffectMaterial(const std::shared_ptr<EffectMaterial>& aEffectMaterial);
    void Set3DSpriteInstance(const std::shared_ptr<Tga::Sprite3DInstanceData>& aSprite3DInstanceData);
    void SetSpriteSharedData(const std::shared_ptr<Tga::SpriteSharedData>& aSpriteSharedData);
    void SetRenderType(RenderType aRenderType);
    void CreateCollider(const std::shared_ptr<Collider>& aCollider);

    // Getters
    Tga::Vector3f GetPosition();
    Tga::Vector3f GetPosition() const;

    std::shared_ptr<BaseModelInstance> GetModelInstance();
    const std::shared_ptr<BaseModelInstance> GetModelInstance() const;

    Tga::SpriteSharedData* GetSpriteSharedData();
    const Tga::SpriteSharedData* GetSpriteSharedData() const;

    std::shared_ptr<Tga::Sprite3DInstanceData>& Get3DSpriteInstance();
    const std::shared_ptr<Tga::Sprite3DInstanceData>& Get3DSpriteInstance() const;

    void SetShouldFade(bool aShouldFade) { myShouldFade = aShouldFade; }
    bool GetShouldFade() const { return myShouldFade; }

    const Tga::Vector3f& GetScale() const { return myScale; }
    const Tga::Matrix4x4f& GetTransform() const;
    const std::shared_ptr<Collider>& GetCollider();
    bool GetShouldRender() const;
    Tga::Tag GetTag() const;
    const std::shared_ptr<EffectMaterial>& GetEffectMaterial();
    const std::shared_ptr<EffectMaterial>& GetEffectMaterial() const;
    void MarkForDelete() { myMarkedForDelete = true; }
    bool GetMarkedForDelete() const;
    RenderType GetRenderType() const;
    bool IsWithinUpdateRange();

    void SetTerrain(bool abool);
    bool GetIsTerrain();


    //Gets component of type T
    // Usage: GetComponent<Collider>(); to get the collider component
    template<typename T> T& GetComponent();
    template<typename T> const T& GetComponent() const;

    template<typename T> std::vector<std::shared_ptr<T>> GetComponents() const;
	//Adds component of type T with constructor arguments "someArguments"
    // 
    // Whatever you send in as arguments will be arguments for the constructor if you want, you can also skip
    //     Type of component vvv        vvv constructor arguments (empty if component has no constructor arguments )
    // Usage: AddComponent<Collider>(myRadius);
    // In case of error "'BoolManager::BoolManager': no overloaded function could convert all the argument types": Double-check the arguments for the Component
   template<typename T, typename... Args> const T& AddComponent(Args&&... someArguments);

protected:
    std::shared_ptr<BaseModelInstance> myModel = nullptr;
    std::shared_ptr<Collider> myCollider = nullptr;

    bool myMarkedForDelete = false;
    bool myOnlyRunBaseLogic = true;


    // SCRIPT
    std::shared_ptr<Tga::ScriptRuntimeInstance> myScript = nullptr;


private:
	std::map<std::type_index, std::vector<std::shared_ptr<Component>>> myComponents;
    bool isTerrain = false;
    std::shared_ptr<EffectMaterial> myEffectMaterial = nullptr;
    std::shared_ptr<Tga::Sprite3DInstanceData> mySprite3DInstanceData = nullptr;
    std::shared_ptr<Tga::SpriteSharedData> mySharedData = nullptr;

    RenderType myRenderType = RenderType::Count;
    Tga::Vector3f myScale;
    Tga::Tag myTag = Tga::Tag::Other;
    bool myShouldRender = true;
    bool myShouldFade = false;

};
template<typename T>
inline T& GameObject::GetComponent()
{
    return *std::dynamic_pointer_cast<T>(myComponents[typeid(T)].back());
}

template<typename T>
inline const T& GameObject::GetComponent() const
{
    return *std::dynamic_pointer_cast<T>(myComponents[typeid(T)].back());
}

template<typename T>
inline std::vector<std::shared_ptr<T>> GameObject::GetComponents() const
{
    std::vector<std::shared_ptr<T>> castedComponents;
    if (!myComponents.contains(typeid(T)))
    {
        return castedComponents;
    }

    for (auto& component : myComponents[typeid(T)])
    {
        castedComponents.emplace_back(std::dynamic_pointer_cast<T>(component));
    }
    return castedComponents;
}

template<typename T, typename... Args>
inline const T& GameObject::AddComponent(Args&&... someArguments)
{
    auto it = myComponents.find(typeid(T));
	if (it != myComponents.end())
    {
        it->second.emplace_back(std::make_shared<T>(std::forward<Args>(someArguments)...));
		it->second.back()->SetGameObject(this);
        it->second.back()->Init();
        return *std::dynamic_pointer_cast<T>(it->second.back());
    }
    
    myComponents.try_emplace(typeid(T), std::vector<std::shared_ptr<Component>>{});
    myComponents[typeid(T)].emplace_back(std::make_shared<T>(std::forward<Args>(someArguments)...));
    myComponents[typeid(T)].back()->SetGameObject(this);
    myComponents[typeid(T)].back()->Init();
    return *std::dynamic_pointer_cast<T>(myComponents[typeid(T)].back());
}
