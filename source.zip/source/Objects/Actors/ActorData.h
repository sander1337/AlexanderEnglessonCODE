#pragma once

namespace AI
{
	class Controller;
}

struct ActorData
{
	std::unique_ptr<AI::Controller> myController;
	float currentYawDeg = 0.0f; // Store yaw in DEGREES
};
