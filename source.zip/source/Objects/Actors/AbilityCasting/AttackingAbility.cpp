﻿#include "stdafx.h"
#include "AttackingAbility.h"
#include "../Attacks/Attack.h"
#include "../../../GameWorld.h"
#include "../../Actors/Actor.h"
#include "../source/Events/EventManager.h"
#include "Objects/Actors/Attacks/FollowingAttack.h"
#include <tge/drawers/DebugDrawer.h>


// Random direction inside a cone around baseDir.
// spreadDeg = full cone angle (e.g. 8 degrees)
static Tga::Vector3f RandomDirInCone(const Tga::Vector3f& baseDir, float spreadDeg)
{
	Tga::Vector3f dir = baseDir;
	dir.Normalize();

	// Build an orthonormal basis around dir
	Tga::Vector3f up = { 0.f, 1.f, 0.f };
	if (fabs(dir.Dot(up)) > 0.99f) up = { 1.f, 0.f, 0.f };

	Tga::Vector3f right = up.Cross(dir); right.Normalize();
	Tga::Vector3f realUp = dir.Cross(right); realUp.Normalize();

	// Random yaw/pitch within cone
	float halfAngle = Tga::DegToRad(spreadDeg * 0.5f);

	// uniform-ish small cone: random radius in [0, halfAngle]
	float u = static_cast<float>(rand()) / static_cast<float>(RAND_MAX);
	float v = static_cast<float>(rand()) / static_cast<float>(RAND_MAX);

	float yaw = (u * 2.f - 1.f) * halfAngle;
	float pitch = (v * 2.f - 1.f) * halfAngle;

	// dir' = dir + right*yaw + up*pitch (small-angle approximation)
	Tga::Vector3f out = dir + right * yaw + realUp * pitch;
	out.Normalize();
	return out;
}

AttackingAbility::AttackingAbility(const std::shared_ptr<Actor>& aCaster, TargetType aType, const std::string_view& anObjectString, float aCooldown, float aCastTime, int anAttackDmg) :
	myObjectID(Tga::StringRegistry::RegisterOrGetString(anObjectString)), Ability(aCaster, aType, aCooldown, aCastTime), myAttackDmg(anAttackDmg)
{
}

void AttackingAbility::OnActivate(const Tga::Vector3f& aTargetPosition)
{
	Message message{ EventManager::EventFromStringId(myObjectID), -10.f };
	EventManager::GetInstance()->SendEventMessage(message);

	auto caster = myCaster.lock();
	if (!caster || myObjectID.IsEmpty())
		return;

	const auto& casterTransform = caster->GetTransform();
	
	Tga::Matrix4x4f attackTransform;
	switch (myType)
	{
		case TargetType::Directional:
		{
			if (caster->GetActorType() == ActorType::Player)
			{
				auto cam = Picking::GetInstance()->GetCamera();
				const auto& camTransform = cam->GetTransform();

				// Projektera gun-pos längs kamerans pitch
				Tga::Vector3f camForward = camTransform.GetForward().GetNormalized();
				Tga::Vector3f camPos = camTransform.GetPosition();

				Tga::Matrix4x4f boneTrans = caster->GetBoneTransformInModelSpace("Bullet");

				Tga::Vector3f startPos = casterTransform.GetPosition() + boneTrans.GetPosition();
				Tga::Vector3f toGun = startPos - camPos;
				float depth = toGun.Dot(camForward);
				startPos = camPos + camForward * depth;

				Tga::Vector3f baseDir = (aTargetPosition - startPos);
				if (baseDir.LengthSqr() < 1e-6f)
				{
					return;
				}
				baseDir.Normalize();

				const int pellets = (myPellets > 0) ? myPellets : 1;

				for (int i = 0; i < pellets; ++i)
				{
					Tga::Vector3f dir = baseDir;
					if (pellets > 1 && mySpreadDeg > 0.f)
					{
						dir = RandomDirInCone(baseDir, mySpreadDeg); // implement here or utility
					}

					attackTransform = Tga::Matrix4x4f::CreateLookAt(startPos, dir, casterTransform.GetUp());

					auto attackObj = GameWorld::GetInstance().LoadAssetToScene(myObjectID, attackTransform, true).lock();
					if (!attackObj) continue;

					auto attack = std::dynamic_pointer_cast<Attack>(attackObj);
					if (!attack) continue;

					attack->SetCaster(caster);
					attack->SetDamage(myAttackDmg);
				}
				return;
			}
			else
			{
				Tga::Vector3f direction = (aTargetPosition - casterTransform.GetPosition()).GetNormalized();
				attackTransform = Tga::Matrix4x4f::CreateLookAt(casterTransform.GetPosition(), direction, casterTransform.GetUp());
			}

			break;
		}
		case TargetType::Locational: 
		{
			attackTransform.SetPosition(aTargetPosition);
			break;
		}
		case TargetType::Self:
		{
			attackTransform.SetPosition(casterTransform.GetPosition());
			break;
		}
		default:
		{
			break;
		}
	}

	const std::shared_ptr attackObj = GameWorld::GetInstance().LoadAssetToScene(myObjectID, attackTransform, true).lock();

	if (!attackObj)
		return;

	auto attack = std::reinterpret_pointer_cast<Attack>(attackObj);
	if (!attack)
		return;

	attack->SetCaster(caster);
	attack->SetDamage(myAttackDmg);
}

void AttackingAbility::OnActivate(const Tga::Matrix4x4f& spawnTransform)
{
	Message message{ EventManager::EventFromStringId(myObjectID), -10.f };
	EventManager::GetInstance()->SendEventMessage(message);

	auto caster = myCaster.lock();
	if (!caster || myObjectID.IsEmpty())
	{
		return;
	}

	auto attackObj = GameWorld::GetInstance().LoadAssetToScene(myObjectID, spawnTransform, true).lock();
	if (!attackObj)
	{
		return; // spawn fail
	}

	// Rätt: dynamic cast
	auto attack = std::dynamic_pointer_cast<Attack>(attackObj);
	if (!attack)
	{
		// Här betyder det: det du laddar ("Player_Melee"/"Player_Arrow") skapar INTE en Attack-instans.
		// Logga gärna vad det är för asset / property.
		return;
	}

	attack->SetCaster(caster);
	attack->SetDamage(myAttackDmg);

	// casta från attack (inte från attackObj)
	if (auto followingAttack = std::dynamic_pointer_cast<FollowingAttack>(attack))
	{
		followingAttack->SetPosFromCaster(spawnTransform.GetPosition() - caster->GetPosition());
	}
}

void AttackingAbility::OnStartCast()
{
	// Update HUD to show ability is cast
	Message message{ EventManager::EventFromStringId(myObjectID), 10.f };
	EventManager::GetInstance()->SendEventMessage(message);
}
