#include "stdafx.h"
#include "Ability.h"
#include "../source/Events/EventManager.h"

Ability::Ability(const std::shared_ptr<Actor>& aCaster, const TargetType aType, const float aCooldown, const float aCastTime)
	: myCaster(aCaster), myType(aType), myMaxCooldown(aCooldown), myCastTime(aCastTime)
{
}

bool Ability::TryActivate(const Tga::Vector3f& targetPos)
{
	if (!GetIsReady())
	{
		return false;
	}

	if (myCastTime == 0.f)
	{
		OnActivate(targetPos);
		myCooldownTimer = myMaxCooldown;
	}
	else
	{
		myBufferedActivationPos = targetPos;
		myHasBufferedMatrix = false;  

		OnStartCast();
		myActivationTimer = myCastTime;
	}

	return true;
}

bool Ability::TryActivate(const Tga::Matrix4x4f& anActivationMatrix)
{
	if (!GetIsReady())
		return false;

	if (myCastTime == 0.f)
	{
		OnActivate(anActivationMatrix);
		myCooldownTimer = myMaxCooldown;
	}
	else
	{
		myBufferedActivationMatrix = anActivationMatrix;
		myHasBufferedMatrix = true;

		OnStartCast();
		myActivationTimer = myCastTime;
	}

	return true;
}

void Ability::Update(const float aDeltaTime)
{
	if (myActivationTimer > 0.f)
	{
		OnCasting(aDeltaTime);
		myActivationTimer -= aDeltaTime;
	}
	if (myCooldownTimer > 0.f)
	{
		myCooldownTimer -= aDeltaTime;
	}
	else
	{
		OnCooldownEnd();
	}
	
	if (myActivationTimer <= 0.f && GetIsCasting())
	{
		if (myHasBufferedMatrix)
		{
			OnActivate(myBufferedActivationMatrix);
			myHasBufferedMatrix = false;
		}
		else
		{
			OnActivate(myBufferedActivationPos);
		}

		myCooldownTimer = myMaxCooldown;
		myActivationTimer = -1.f;
	}

}

bool Ability::GetIsCasting() const
{
	return myActivationTimer > -1.f;
}

bool Ability::GetIsReady() const
{
	return myCooldownTimer <= 0.f && myActivationTimer <= 0.f;
}

float Ability::GetCooldownNormalized() const
{
	return myCooldownTimer / myMaxCooldown;
}