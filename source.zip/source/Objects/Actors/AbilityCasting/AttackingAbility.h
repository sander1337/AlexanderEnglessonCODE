﻿#pragma once
//#pragma message(__FILE__" was compiled")
#include "Ability.h"

class AttackingAbility : public Ability
{
public:
	AttackingAbility(const std::shared_ptr<Actor>& aCaster, TargetType aType, const std::string_view& anObjectString, float aCooldown, float aCastTime = 0.f, int anAttackDmg = 25);
	void SetPelletParams(int pellets, float spreadDeg) { myPellets = pellets; mySpreadDeg = spreadDeg; }

protected:
	void OnActivate(const Tga::Matrix4x4f& spawnTransform) override;
	void OnActivate(const Tga::Vector3f& aTargetPosition) override;
private:
	void OnStartCast() override;
	const Tga::StringId myObjectID;
	int myPellets = 1;
	float mySpreadDeg = 0.f;
	int myAttackDmg = 25;
};
