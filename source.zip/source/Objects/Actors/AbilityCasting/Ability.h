#pragma once

#include <tge/Math/Vector3.h>
#include <tge/math/Matrix.h>

namespace Tga
{
	class GraphicsStateStack;
	class ModelDrawer;
}
class Actor;

enum class TargetType : std::uint8_t
{
	Directional,
	Locational,
	Self
};

class Ability
{
public:
	Ability() = default;
	Ability(const std::shared_ptr<Actor>& aCaster, TargetType aType, float aCooldown, float aCastTime);

	bool TryActivate(const Tga::Vector3f& targetPos);
	bool TryActivate(const Tga::Matrix4x4f& anActivationMatrix);
	void Update(float aDeltaTime);

	bool GetIsCasting() const;
	virtual bool GetIsReady() const;
	float GetCooldownNormalized() const;

protected:
	virtual void OnActivate(const Tga::Vector3f& aTargetPosition) = 0;
	virtual void OnActivate(const Tga::Matrix4x4f& spawnTransform) = 0;
	virtual void OnStartCast() {}
	virtual void OnCasting([[maybe_unused]] float aDeltaTime) {}
	virtual void OnCooldownEnd() {};
	
	const TargetType myType = TargetType::Directional;

	std::weak_ptr<Actor> myCaster;
	Tga::Vector3f myBufferedActivationPos;
	
	const float myMaxCooldown;
	float myCooldownTimer = 0.f;
	float myActivationTimer = -1.f;
	const float myCastTime;

	Tga::Matrix4x4f myBufferedActivationMatrix;
	bool myHasBufferedMatrix = false;
private:

	bool myFromEnemy = false;
};