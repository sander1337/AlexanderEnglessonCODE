#include "stdafx.h"
#include "Player.h"

#include "Weapon/PlayerWeapons.h"

#include <Utilities/ConstantIdentifiers.h>
#include <Utilities/CountDownTimer.h>
#include <Audio/AudioManager.h>

#include <Utilities/Picking.h>
#include <tge/drawers/DebugDrawer.h>
#include "../AbilityCasting/AttackingAbility.h"
#include "../AbilityCasting/Ability.h"
#include <GameWorld.h>
#include <Utilities/BlackBoard.h>
#include <Events/EventManager.h>
#include <Graphics/VFXManager.h>
#include <Utilities/RandomGenerator.h>
#include <Utilities/PollingStation.h>
#include <SceneManagement/SceneID.h>
#include <SceneManagement/GameScene.h>
#include <tge/model/AnimatedModelInstance.h>
#include "tge/math/FMath.h"

#include <tge/script/BaseProperties.h>
#include <tge/scene/ScenePropertyTypes.h>

#include <variant>
#include <Audio/DamagedByType.h>
#include "../Attacks/Attack.h"
#include <Graphics/SpawnedObject.h>

#include <Collisions/Narrow/Collider.h>
#include "../../StaticObjects/PickupObject.h"
#include "tge/components/HiManager.h"
using Tga::Vector2f;
using Tga::Vector3f;


void Player::ApplyProps([[maybe_unused]] const std::vector<Tga::ScenePropertyDefinition>& someProperties)
{
	myAbilities.try_emplace(PlayerAttackID::Stabby,
		std::make_unique<AttackingAbility>(Actor::shared_from_this(), TargetType::Directional, "Player_Melee", 0.3f, 0.25f, myAttackDmgMelee));

	myAbilities.try_emplace(PlayerAttackID::PewPew,	
		std::make_unique<AttackingAbility>(Actor::shared_from_this(),TargetType::Directional,"Player_Revolver_Bullet",0.6f, 0.5f, myAttackDmgRanged));
}

void Player::AddKillScore(int basePoints)
{
	if (myComboTimeLeft <= 0.f)
		myComboMultiplier = 1;

	const int gained = basePoints * myComboMultiplier;
	myPoints += gained;

	myComboMultiplier += 1;
	myComboTimeLeft = kComboDuration;

	SendPointsChangeToUI();
	SendComboChangeToUI();
}

void Player::ResetCombo()
{
	myComboMultiplier = 1;
	myComboTimeLeft = 0.f;
	SendComboChangeToUI();
}

void Player::ResetInfoText()
{
	myInfoTextTimeLeft = 0.f;

	Message msg{};
	msg.eventType = Event::TopTextChange;
	msg.data = std::string("");       
	EventManager::GetInstance()->SendEventMessage(msg);
}

void Player::EquipWeapon(WeaponType t)
{
	// Only allow equipping if the weapon is unlocked
	if (!myWeapons.EquipIfUnlocked(t))
		return; // locked -> do nothing (optionally play a UI sound)

	const auto& w = myWeapons.GetEquippedDef();

	auto aa = std::make_unique<AttackingAbility>(
		Actor::shared_from_this(),
		w.targetType,
		w.attackObject,
		w.cooldown,
		w.castTime,
		w.damage
	);

	aa->SetPelletParams(w.pellets, w.spreadDeg);
	myAbilities[PlayerAttackID::PewPew] = std::move(aa);

	SendAmmoEventForEquippedWeapon();
}

void Player::Init()
{
	GameObject::Init();
	AddComponent<HiManager>();


	EventManager::GetInstance()->Subscribe(Event::PlayerBlink, this);
	EventManager::GetInstance()->Subscribe(Event::PickUp, this);
	EventManager::GetInstance()->Subscribe(Event::EnemyDied, this);
	EventManager::GetInstance()->Subscribe(Event::ToggleHudEditMode, this);

	myWeapons.InitLocked();

	//Unlocked because pickups are not placed everywhere yet
	myWeapons.UnlockOrGiveWeapon(WeaponType::Revolver);

	SendAmmoEventForEquippedWeapon();
	SendReloadEvent(false, 0.f, myWeapons.GetEquippedDef().reloadTime);


	AI::PollingStation3D::Get().SetPlayerPtr(this);

	myStartPos = GetPosition();
	myMaxHealth = 100;
	myHealth = myMaxHealth;
	myRespawnPos = myStartPos;

	myDirection = { 0.f,0.f,0.f };
	myPitch = -0.35f;
	myYaw = 0.f;

	myAnimatedObject.animations["Idle_long"_tgaid].SetIsLooping(false);
	myAnimatedObject.animations["Shot_1"_tgaid].SetIsLooping(false);
	myAnimatedObject.animations["Shot_2"_tgaid].SetIsLooping(false);

	//AudioManager::GetInstance()->PlayNonSpazializedAudio(AudioConstExpr::KORV);

	IntBarValues values;
	values.currentValue = myHealth;
	values.maxValue = myMaxHealth;
	Message message;
	message.eventType = Event::PlayerHealthChange;
	message.data = values;
	EventManager::GetInstance()->SendEventMessage(message);
}

void Player::Update(float aDeltaTime)
{
	if (!armsInitialized)
	{
		InitializeArmBones();
		armsInitialized = true;
	}

	if (mySkipUpdate)
	{
		mySkipUpdate = false;
		return;
	}

	if (myIAmDead)
	{
		OnDeath();
	}

	if (myComboTimeLeft > 0.f)
	{
		myComboTimeLeft -= aDeltaTime;
		if (myComboTimeLeft <= 0.f)
		{
			ResetCombo();
		}
	}

	if (myInfoTextTimeLeft > 0.f)
	{
		myInfoTextTimeLeft -= aDeltaTime;
		if (myInfoTextTimeLeft <= 0.f)
		{
			ResetInfoText();
		}
	}

	myWeapons.UpdateSwapLock(aDeltaTime);

	const bool reloadFinished = myWeapons.UpdateReload(aDeltaTime);

	if (myWeapons.IsReloading())
	{
		SendReloadEvent(true, myWeapons.GetReloadRemaining(), myWeapons.GetReloadDuration());
	}
	else if (reloadFinished)
	{
		SendReloadEvent(false, 0.f, myWeapons.GetReloadDuration());
		SendAmmoEventForEquippedWeapon();
	}

	const auto& def = myWeapons.GetEquippedDef();

	if (myWantsToAutoFire && def.fireMode == FireMode::FullAuto)
	{
		myFireTimer -= aDeltaTime;

		if (myFireTimer <= 0.f)
		{
			FireEquippedWeaponOnce();
			myFireTimer = def.cooldown;
		}
	}
	else
	{
		myFireTimer = 0.f;
	}

	const Vector3f position = GetPosition();
	Vector3f newPosition = position;

	float dirLength = myDirection.Length();

	// This is shit but jUst temporary solution to the Player States / Animations state problem, we need
	// a clear state switch somewhere when the animation ends or when the ability "Stops". Below: State updates to Attacking while we are playing the animation

	if (myState == PlayerState::Attacking && myCurrentAnimationState != Tga::AnimationState::Finished)
	{
		myState = PlayerState::Attacking;
	}
	else if (myState != PlayerState::Attacking)
	{
		myState = (dirLength > 0.5f * 0.5f) ? PlayerState::Walking : PlayerState::Idle;
	}

	if (myState != PlayerState::Idle)
	{
		myIdleTime = 0.f;
	}

	if (dirLength)
	{
		newPosition += myDirection * aDeltaTime * mySpeed * mySpeedMultiplier;

		std::shared_ptr gameScene = GameWorld::GetInstance().GetCurrentGameScene().lock();
		newPosition += gameScene->CheckStaticCollisions(GetCollider());
		newPosition = Picking::GetInstance()->NearestInNavmesh(newPosition);
		SetPosition(newPosition);
	}

	Blackboard::GetInstance()->SetVector3("playerPosition", newPosition);

	UpdateAbilities(aDeltaTime);
	UpdateAnimation(aDeltaTime);
	ApplyYaw();
	PlayPlayerVFX();
	Actor::Update(aDeltaTime);

	// Pickups!
	std::weak_ptr<GameScene> gameScene = GameWorld::GetInstance().GetCurrentGameScene();
	auto pickupObjects = gameScene.lock()->GetPickupObjectsInBounds(GetCollider()->GetBounds());
	for (std::weak_ptr weakObj : pickupObjects)
	{
		if (std::shared_ptr targetDestObj = weakObj.lock())
		{
			// Pickups take damage and then die, just like Destructibles
			targetDestObj->TakeDamage(1);
		}
	}
}

void Player::UpdateAbilities(float aDeltaTime)
{
	if (myState != PlayerState::Attacking)
	{
		for (const std::unique_ptr<Ability>& ability : myAbilities | std::views::values)
		{
			if (ability)
			{
				ability->Update(aDeltaTime);
			}
		}
	}
	else
	{
		bool isAttacking = false;

		for (const std::unique_ptr<Ability>& ability : myAbilities | std::views::values)
		{
			if (ability)
			{
				ability->Update(aDeltaTime);
				isAttacking |= ability->GetIsCasting();
			}
		}
		if (!isAttacking)
		{
			myState = PlayerState::Idle;
		}
	}
}

void Player::ApplyYaw()
{
	Tga::Matrix4x4f t = GetTransform();
	constexpr float RadToDeg = 57.2957795f;
	t.SetRotation({ 0.f, myYaw * RadToDeg, 0.f });
	SetTransform(t);
}

void Player::SetInitialPos()
{
	myStartPos = Picking::GetInstance()->NearestInNavmesh(myStartPos);
	SetPosition(myStartPos);
	myRespawnPos = myStartPos;
}

void Player::ApplyPitchToHead(Tga::LocalSpacePose& pose)
{
	const Tga::Skeleton* skeleton = GetModelInstance()->GetModel()->GetSkeleton();
	std::string headBoneName = "Head";
	size_t headIndex = skeleton->JointNameToIndex.find(headBoneName)->second;

	Tga::ScaleRotationTranslationf& headTransform = pose.JointTransforms[headIndex];

	Tga::Matrix4x4f pitchMat = Tga::Matrix4x4f::CreateRotationAroundX(myPitch);
	Tga::Quaternionf pitchQuat = pitchMat.GetRotationAsQuaternion();

	Tga::Quaternionf newHeadRot = pitchQuat * headTransform.GetRotation();
	headTransform.SetRotation(newHeadRot);
}

void Player::RegisterInput()
{
	RegisterToMapper({
		InputEvent::MoveAxis,
		InputEvent::AttackLeft,
		InputEvent::AttackRightDown,
		InputEvent::AttackRightHold,
		InputEvent::AttackRightUp,
		InputEvent::LookAround,
		InputEvent::LookAroundAndTurnPlayer,
		InputEvent::CameraZoomIn,
		InputEvent::CameraZoomOut,
		InputEvent::SpeedUp,
		InputEvent::SlowDown,
		InputEvent::NextWeapon,
		InputEvent::PrevWeapon,
		InputEvent::Reload,
		InputEvent::PlayerWeaponInfo
		});
}

void Player::UnregisterInput()
{
	UnRegisterToMapper({
		InputEvent::MoveAxis,
		InputEvent::AttackLeft,
		InputEvent::AttackRightDown,
		InputEvent::AttackRightHold,
		InputEvent::AttackRightUp,
		InputEvent::LookAround,
		InputEvent::LookAroundAndTurnPlayer,
		InputEvent::CameraZoomIn,
		InputEvent::CameraZoomOut,
		InputEvent::SpeedUp,
		InputEvent::SlowDown,
		InputEvent::NextWeapon,
		InputEvent::PrevWeapon,
		InputEvent::Reload,
		InputEvent::PlayerWeaponInfo
		});
}

void Player::ReceiveInput(InputEvent aGameEvent, [[maybe_unused]] const std::any& someData)
{
	StopPreparingAbility();

	if (myIAmDead)
	{
		return;
	}

	switch (aGameEvent)
	{
		// P6 MOVEMENT
	case InputEvent::MoveAxis:
	{
		const Tga::Vector2f axis = std::any_cast<Tga::Vector2f>(someData);

		// flatten forward/right so you don’t move up/down
		Tga::Vector3f fwd = GetTransform().GetForward();
		fwd.y = 0.f; fwd.Normalize();

		Tga::Vector3f right = GetTransform().GetRight();
		right.y = 0.f; right.Normalize();

		myDirection = fwd * axis.myY + right * axis.myX;

		// normalize to prevent diagonal speed boost
		if (myDirection.LengthSqr() > 1e-6f)
		{
			myDirection.Normalize();
		}

		// AUDIO
		if (Timer(myLeftFootStepTimer, myLeftFootStepTimerMax, Tga::Engine::GetInstance()->GetDeltaTime()))
		{
			AudioManager::GetInstance()->PlayNonSpazializedAudio(AudioConstExpr::FOOTSTEP);
		}
		if (Timer(myRightFootStepTimer, myRightFootStepTimerMax, Tga::Engine::GetInstance()->GetDeltaTime()))
		{
			AudioManager::GetInstance()->PlayNonSpazializedAudio(AudioConstExpr::FOOTSTEP);
		}

		break;
	}
	case InputEvent::LookAround:
	{
		const Tga::Vector2f mouseDelta = std::any_cast<Tga::Vector2f>(someData);

		myYaw += mouseDelta.myX * myMouseSensitivity;
		myPitch -= mouseDelta.myY * myMouseSensitivity;

		const float maxPitchUp = Tga::DegToRad(20.f);
		const float maxPitchDown = Tga::DegToRad(-75.f);

		myPitch = std::clamp(myPitch, maxPitchDown, maxPitchUp);
		break;
	}
	case InputEvent::LookAroundAndTurnPlayer:
	{
		const Tga::Vector2f mouseDelta = std::any_cast<Tga::Vector2f>(someData);

		myYaw += mouseDelta.myX * myMouseSensitivity;
		myPitch -= mouseDelta.myY * myMouseSensitivity;

		constexpr float TwoPi = 6.28318530718f;
		if (myYaw > TwoPi)
			myYaw -= TwoPi;
		else if (myYaw < 0.f)
			myYaw += TwoPi;

		const float maxPitchUp = Tga::DegToRad(20.f);
		const float maxPitchDown = Tga::DegToRad(-75.f);
		myPitch = std::clamp(myPitch, maxPitchDown, maxPitchUp);

		ApplyYaw();
		break;
	}
	case InputEvent::CameraZoomIn:
	{
		ZoomCamera(-myCameraZoomStep); // closer
		break;
	}
	case InputEvent::CameraZoomOut:
	{
		ZoomCamera(+myCameraZoomStep); // farther
		break;
	}
	case InputEvent::SpeedUp:
	{
		mySpeedMultiplier = 3.f;
		break;
	}
	case InputEvent::SlowDown:
	{
		mySpeedMultiplier = 1.f;
		break;
	}
	case InputEvent::AttackLeft:
	{
		const auto& camTr = Picking::GetInstance()->GetCamera()->GetTransform();
		const Tga::Vector3f camPos = GetThirdPersonCameraPos();

		Tga::Matrix4x4f spawn = camTr;
		spawn.SetPosition(camPos);

		//const float forwardOffset = 200.f;
		//spawn.SetPosition(camPos + camTr.GetForward().GetNormalized() * forwardOffset);

		UseAbility(PlayerAttackID::Stabby, spawn);
		break;
	}
	case InputEvent::NextWeapon:
	{
		CycleWeapon(+1);
		break;
	}
	case InputEvent::PrevWeapon:
	{
		CycleWeapon(-1);
		break;
	}
	case InputEvent::Reload:
	{
		myWeapons.StartReload();
		const auto& def = myWeapons.GetEquippedDef();
		SendReloadEvent(true, def.reloadTime, def.reloadTime);
		break;
	}
	case InputEvent::PlayerWeaponInfo:
	{
		//DebugPrintAllWeapons();
		break;
	}
	default: {}
	}
}

Tga::Vector3f Player::GetThirdPersonCameraPos() const
{
	const float pivotHeight = 120.f;   // point camera orbits around
	const float distance = myCameraDistance;

	const Tga::Vector3f pivot = GetPosition() + Tga::Vector3f(0.f, pivotHeight, 0.f);

	const float cosPitch = std::cos(myPitch);
	const float sinPitch = std::sin(myPitch);
	const float sinYaw = std::sin(myYaw);
	const float cosYaw = std::cos(myYaw);

	Tga::Vector3f orbitDir;
	orbitDir.x = sinYaw * cosPitch;
	orbitDir.y = sinPitch;
	orbitDir.z = cosYaw * cosPitch;
	orbitDir.Normalize();

	return pivot - orbitDir * distance;
}

void Player::ReceiveEvent([[maybe_unused]] const Message& aMessage)
{
	switch (aMessage.eventType)
	{
		case Event::EnemyDied:
		{
			const int basePoints = std::get<int>(aMessage.data);
			AddKillScore(basePoints);
			break;
		}
		case Event::PlayerBlink:
		{
			BlinkForward(800.f);
			break;
		}
		case Event::PickUp:
		{
			const Tga::PickUpType type = std::get<Tga::PickUpType>(aMessage.data);

			// --- Apply pickup effect ---
			switch (type)
			{
			case Tga::PickUpType::Ammo:
				myWeapons.AddAmmoFromPickUpToAllWeapons(10);
				SendAmmoEventForEquippedWeapon();
				break;

			case Tga::PickUpType::Health:
				ReceiveHealing(10);
				SendHealthEvent();
				break;

			case Tga::PickUpType::Revolver:
				myWeapons.UnlockOrGiveWeapon(WeaponType::Revolver);
				myWeapons.EquipIfUnlocked(WeaponType::Revolver);
				EquipWeapon(WeaponType::Revolver);
				SendAmmoEventForEquippedWeapon();
				break;

			case Tga::PickUpType::Machinegun:
				myWeapons.UnlockOrGiveWeapon(WeaponType::MachineGun);
				myWeapons.EquipIfUnlocked(WeaponType::MachineGun);
				EquipWeapon(WeaponType::MachineGun);
				SendAmmoEventForEquippedWeapon();
				break;

			case Tga::PickUpType::Shotgun:
				myWeapons.UnlockOrGiveWeapon(WeaponType::Shotgun);
				myWeapons.EquipIfUnlocked(WeaponType::Shotgun);
				EquipWeapon(WeaponType::Shotgun);
				SendAmmoEventForEquippedWeapon();
				break;

			case Tga::PickUpType::RocketLauncher:
				myWeapons.UnlockOrGiveWeapon(WeaponType::RocketLauncher);
				myWeapons.EquipIfUnlocked(WeaponType::RocketLauncher);
				EquipWeapon(WeaponType::RocketLauncher);
				SendAmmoEventForEquippedWeapon();
				break;
			default:
				break;
			}

			// --- Send InfoTextTop ---
			std::string text;
			switch (type)
			{
			case Tga::PickUpType::Ammo:           text = "Picked up: Ammo +10"; break;
			case Tga::PickUpType::Health:         text = "Picked up: Health +10"; break;
			case Tga::PickUpType::Revolver:       text = "Picked up: Revolver"; break;
			case Tga::PickUpType::Machinegun:     text = "Picked up: MachineGun"; break;
			case Tga::PickUpType::Shotgun:        text = "Picked up: Shotgun"; break;
			case Tga::PickUpType::RocketLauncher: text = "Picked up: RocketLauncher"; break;
			default:                              text = "Picked up"; break;
			}

			Message msg{};
			msg.eventType = Event::TopTextChange;
			msg.data = text;
			EventManager::GetInstance()->SendEventMessage(msg);
			myInfoTextTimeLeft = kComboDuration;

			break;
		}
		default:
		{
			break;
		}
	}
}

void Player::DebugRender()
{
	GameObject::DebugRender();

	auto& debug = Tga::Engine::GetInstance()->GetDebugDrawer();

	const Tga::Vector3f pos = GetTransform().GetPosition();

	// Player forward (HORIZONTAL body forward)
	Tga::Vector3f forward = GetTransform().GetForward();
	forward.Normalize();

	const float arrowLength = 150.f;

	// Arrow body
	debug.DrawLine(
		pos,
		pos + forward * arrowLength,
		Tga::Color(0.f, 1.f, 0.f, 1.f) // green
	);

	// Arrow head (simple V shape)
	Tga::Vector3f right = GetTransform().GetRight().GetNormalized();
	debug.DrawLine(
		pos + forward * arrowLength,
		pos + forward * arrowLength - forward * 20.f + right * 10.f,
		Tga::Color(0.f, 1.f, 0.f, 1.f)
	);
	debug.DrawLine(
		pos + forward * arrowLength,
		pos + forward * arrowLength - forward * 20.f - right * 10.f,
		Tga::Color(0.f, 1.f, 0.f, 1.f)
	);

	// ---------------------------
	// Cursor (crosshair in world)
	// ---------------------------
	auto cam = Picking::GetInstance()->GetCamera();
	const auto& camTr = cam->GetTransform();

	const Tga::Vector3f camPos = camTr.GetPosition();
	Tga::Vector3f camFwd = camTr.GetForward().GetNormalized();

	// 1) Find cursor point: hit point if ray hits, otherwise fallback distance
	constexpr float fallbackDist = 2000.f;
	Tga::Vector3f cursorPos = camPos + camFwd * fallbackDist;

	// If you have a raycast/pick function, use it here (pseudo API)
	// Example patterns:
	// if (Picking::GetInstance()->Raycast(camPos, camFwd, hitPos)) cursorPos = hitPos;
	// or: auto hit = Picking::GetInstance()->Pick(camPos, camFwd); if (hit.didHit) cursorPos = hit.position;

	// 2) Draw crosshair at cursorPos (camera-aligned so it always faces you)
	const Tga::Vector3f cRight = camTr.GetRight().GetNormalized();
	const Tga::Vector3f cUp = camTr.GetUp().GetNormalized();

	constexpr float cursorSize = 20.f;

	debug.DrawLine(cursorPos - cRight * cursorSize, cursorPos + cRight * cursorSize,
		Tga::Color(1.f, 1.f, 0.f, 1.f)); // yellow
	debug.DrawLine(cursorPos - cUp * cursorSize, cursorPos + cUp * cursorSize,
		Tga::Color(1.f, 1.f, 0.f, 1.f)); // yellow

	// Optional: draw aim line from camera to cursor
	debug.DrawLine(camPos, cursorPos, Tga::Color(1.f, 1.f, 0.f, 0.35f));
}

void Player::SetSpeed(float aSpeed)
{
	mySpeed = aSpeed;
}

void Player::SetSpeedMultiplier(float aSpeedMultiplier)
{
	mySpeedMultiplier = aSpeedMultiplier;
}

void Player::PrepareAbility(PlayerAttackID anAbilityIdentifier, Actor* aTargetActor)
{
	myPreparingAbility = anAbilityIdentifier;
	myAbilityTarget = aTargetActor;
}

void Player::StopPreparingAbility()
{
	myPreparingAbility = PlayerAttackID::Count;
	myAbilityTarget = nullptr;
}

void Player::UseAbility(PlayerAttackID id, const Tga::Matrix4x4f& spawnTransform)
{
	if (!myAbilities.contains(id) || !myAbilities[id])
	{
		return;
	}

	myState = PlayerState::Attacking;

	if (myAbilities[id]->TryActivate(spawnTransform))
	{
		myPlayerAbilityState = id;
	}

	if (myCurrentAnimation->GetFrame() == 1)
	{
		AudioManager::GetInstance()->PlayNonSpazializedAudio(AudioConstExpr::KNIFESTAB);
	}
}

bool Player::UseAbility(PlayerAttackID anAbilityIdentifier, const Tga::Vector3f& aTargetPosition)
{
	if (!myAbilities.contains(anAbilityIdentifier))
		return false;

	if (myAbilities[anAbilityIdentifier])
	{
		RotateTowardsVelocityOrDirection(aTargetPosition - GetPosition(), 100.f);
		myState = PlayerState::Attacking;

		if (myAbilities[anAbilityIdentifier]->TryActivate(aTargetPosition))
		{
			myPlayerAbilityState = anAbilityIdentifier;
			return true; // shot actually happened
		}
	}
	return false;
}

void Player::OnDeath()
{
	if (myState != PlayerState::Death)
	{
		myIAmDead = true;
		myState = PlayerState::Death;
		myDeathTimer = DEATH_DURATION;

		Message message{ Event::GameOver };
		EventManager::GetInstance()->SendEventMessage(message);

		AudioManager::GetInstance()->PlayActorAudio(this->GetActorType(), AudioIdentifier::DEATH, this->GetTransform());
		return;
	}

	myDeathTimer -= Tga::Engine::GetInstance()->GetDeltaTime();

	if (myState == PlayerState::Death && myCurrentAnimationState == Tga::AnimationState::Finished && myDeathTimer)
	{
		myHealth = myMaxHealth;
		Blackboard::GetInstance()->SetInt("playerHealth", myHealth);

		myState = PlayerState::Idle;

		if (AI::PollingStation3D::Get().GetCurrentSceneID() == SceneID::Level1)
		{
			SetPosition(myRespawnPos);
			AI::PollingStation3D::Get().UpdateActorPos(this, myRespawnPos);
		}
		else if (AI::PollingStation3D::Get().GetCurrentSceneID() == SceneID::Level2)
		{
			SetPosition(myRespawnPos);
			AI::PollingStation3D::Get().UpdateActorPos(this, myRespawnPos);
		}

		myIAmDead = false;
	}
}

void Player::SetCheckpoint(const Tga::Vector3f& aPosition)
{
	myRespawnPos = aPosition;
}

const char* Player::WeaponTypeToString(WeaponType t)
{
	switch (t)
	{
		case WeaponType::Revolver:			return "Revolver";
		case WeaponType::MachineGun:		return "MachineGun";
		case WeaponType::Shotgun:			return "Shotgun";
		case WeaponType::RocketLauncher:	return "RocketLauncher";
		default:							return "Unknown";
	}
}

void Player::CycleWeapon(int dir)
{
	if (myWeapons.IsSwapLocked())
		return;

	// Try swap first. If it fails (0 or 1 unlocked weapon), do NOTHING.
	const bool swapped = myWeapons.CycleUnlocked(dir);
	if (!swapped)
		return;

	// Only when swap succeeded:
	EquipWeapon(myWeapons.GetEquippedType());

	myFireTimer = 0.f;
	myWeapons.StartSwapLock(kWeaponSwapLockDuration);
	SendReloadEvent(false, 0.f, myWeapons.GetEquippedDef().reloadTime);
}

void Player::SendAmmoEventForEquippedWeapon()
{
	const WeaponType wt = myWeapons.GetEquippedType();

	AmmoHUDValues v{};
	v.weapon = wt;

	if (!myWeapons.IsUnlocked(wt))
	{
		v.mag = 0;
		v.magSize = 0;
		v.reserve = 0;
		v.maxReserve = 0;
	}
	else
	{
		const auto& def = myWeapons.GetEquippedDef();
		const auto& ammo = myWeapons.GetAmmo(wt);
		v.mag = ammo.mag;
		v.magSize = def.magSize;
		v.reserve = ammo.reserve;
		v.maxReserve = def.maxReserve;
	}

	Message msg{};
	msg.eventType = Event::AmmoChange;
	msg.data = v;

	EventManager::GetInstance()->SendEventMessage(msg);
}

void Player::SendReloadEvent(bool isReloading, float remaining, float duration)
{
	ReloadHUDValues v{};
	v.weapon = myWeapons.GetEquippedType();
	v.remaining = remaining;
	v.duration = duration;
	v.isReloading = isReloading;

	Message msg{};
	msg.eventType = Event::ReloadChange;
	msg.data = v;

	EventManager::GetInstance()->SendEventMessage(msg);
}

void Player::SendHealthEvent()
{
	IntBarValues values;
	values.currentValue = myHealth;
	values.maxValue = myMaxHealth;
	Message message;
	message.eventType = Event::PlayerHealthChange;
	message.data = values;
	EventManager::GetInstance()->SendEventMessage(message);
}

void Player::ResetPlayer(SceneID aSceneId)
{
	if (aSceneId == SceneID::Level1)
	{
		myAbilities.clear();

		myAbilities.try_emplace(PlayerAttackID::Stabby,
			std::make_unique<AttackingAbility>(Actor::shared_from_this(), TargetType::Directional, "Player_Melee", 0.3f, 0.25f, myAttackDmgMelee));
		myAbilities.try_emplace(PlayerAttackID::PewPew,
			std::make_unique<AttackingAbility>(Actor::shared_from_this(), TargetType::Directional, "Player_Revolver_Bullet", 0.6f, 0.5f, myAttackDmgRanged));
	}

	myHealth = myMaxHealth;
	SendHealthEvent();
	myIAmDead = false;
	SetPosition(myStartPos);
	myState = PlayerState::Idle;

	myDirection = { 0.f,0.f,0.f };
}

void Player::UpdateAnimation(float aDeltaTime)
{
	// Arms
	// upperArm_L
	// upperArm_R

	if (!myAnimatedObject.model)
	{
		return;
	}

	myAnimatedObject.blendValue = FMath::Min(myAnimatedObject.blendValue + aDeltaTime * myAnimatedObject.blendSpeed, 1.f);

	if (myState == PlayerState::Death)
	{
		aDeltaTime *= 0.3f;
	}

	myCurrentAnimation->Update(aDeltaTime);

	static Tga::StringId nullAnim = {};
	if (myAnimatedObject.blendValue < 1.f && myAnimatedObject.previousState != nullAnim)
	{
		const Tga::LocalSpacePose& currentPose = myCurrentAnimation->GetLocalSpacePose();
		const Tga::LocalSpacePose& blendPose = myAnimatedObject.animations[myAnimatedObject.previousState].GetLocalSpacePose();
		Tga::LocalSpacePose lerpPose;
		lerpPose.Count = myCurrentAnimation->GetLocalSpacePose().Count;
		for (size_t i = 0; i < lerpPose.Count; i++)
		{
			const auto& previousJointXform = blendPose.JointTransforms[i];
			const auto& currentJointXform = currentPose.JointTransforms[i];
			lerpPose.JointTransforms[i] = Tga::ScaleRotationTranslationf::Lerp(previousJointXform, currentJointXform, myAnimatedObject.blendValue);
		}

		// Apply pitch to head bone before setting pose
		ApplyPitchToHead(lerpPose);
		myAnimatedObject.model->SetPose(lerpPose);
	}
	else
	{
		// Get a copy and apply pitch
		Tga::LocalSpacePose pose = myCurrentAnimation->GetLocalSpacePose();
		ApplyPitchToHead(pose);
		myAnimatedObject.model->SetPose(pose);
	}

	myCurrentAnimationState = myAnimatedObject.animations[myAnimatedObject.currentAnimation].GetState();
	bool ready = myCurrentAnimationState == Tga::AnimationState::Finished || myAnimatedObject.animations[myAnimatedObject.currentAnimation].GetIsLooping();

	if (!ready)
	{
		return;
	}

	constexpr float blendSpeed = 5.f;
	if (myState == PlayerState::Idle)
	{
		if (myIdleTime >= 3.f)
		{
			if (myAnimatedObject.currentAnimation != "Idle_long"_tgaid)
			{
				myAnimatedObject.SetAnimationWithBlending("Idle_long"_tgaid, 0.2f, blendSpeed);
			}

			if (myCurrentAnimationState == Tga::AnimationState::Finished)
			{
				myAnimatedObject.SetAnimationWithBlending("Idle"_tgaid, 0.2f, blendSpeed);
				myIdleTime = 0.f;
			}
		}
		else
		{
			myAnimatedObject.SetAnimationWithBlending("Idle"_tgaid, 0.2f, blendSpeed);
			myIdleTime += aDeltaTime;
		}
	}
	else if (myState == PlayerState::Walking)
	{
		myAnimatedObject.SetAnimationWithBlending("Walk"_tgaid, 0.2f, blendSpeed);
	}
	else if (myState == PlayerState::Attacking)
	{
		if (myAbilities[PlayerAttackID::Stabby]->GetIsCasting())
		{
			myAnimatedObject.SetAnimationWithBlending("Stab_1"_tgaid, 0.9f, blendSpeed);
		}
		else if (myAbilities[PlayerAttackID::PewPew]->GetIsCasting())
		{
			int first = RandomGenerator::GetInstance()->GetBool();
			if (first)
			{
				myAnimatedObject.SetAnimationWithBlending("Shot_1"_tgaid, 0.2f, blendSpeed);
			}
			else
			{
				myAnimatedObject.SetAnimationWithBlending("Shot_2"_tgaid, 0.2f, blendSpeed);
			}
		}
	}
	else if (myState == PlayerState::Death)
	{
		myAnimatedObject.SetAnimationWithBlending("Death"_tgaid, 0.0f, blendSpeed);
	}

	if (myCurrentAnimation != &myAnimatedObject.animations[myAnimatedObject.currentAnimation])
	{
		if (myCurrentAnimation != nullptr)
		{
			myCurrentAnimation->Stop();
		}
		myCurrentAnimation = &myAnimatedObject.animations[myAnimatedObject.currentAnimation];
		myCurrentAnimation->Play();
	}

	//if (!myAnimatedObject.model)
	//{
	//	return;
	//}

	//// Initialize arm bones once
	//if (!myArmBonesInitialized)
	//{
	//	InitializeArmBones();
	//}

	//myAnimatedObject.blendValue = FMath::Min(myAnimatedObject.blendValue + aDeltaTime * myAnimatedObject.blendSpeed, 1.f);

	//if (myState == PlayerState::Death)
	//{
	//	aDeltaTime *= 0.3f;
	//}

	//// Update base animation
	//myCurrentAnimation->Update(aDeltaTime);

	//// Update arm animations
	//if (myLeftArmState.isPlaying && myLeftArmState.animationPlayer)
	//{
	//	myLeftArmState.animationPlayer->Update(aDeltaTime);
	//	if (myLeftArmState.animationPlayer->GetState() == Tga::AnimationState::Finished)
	//	{
	//		myLeftArmState.isPlaying = false;
	//	}
	//}

	//if (myRightArmState.isPlaying && myRightArmState.animationPlayer)
	//{
	//	myRightArmState.animationPlayer->Update(aDeltaTime);
	//	if (myRightArmState.animationPlayer->GetState() == Tga::AnimationState::Finished)
	//	{
	//		myRightArmState.isPlaying = false;
	//	}
	//}

	//// Build final pose
	//Tga::LocalSpacePose finalPose;

	//static Tga::StringId nullAnim = {};
	//if (myAnimatedObject.blendValue < 1.f && myAnimatedObject.previousState != nullAnim)
	//{
	//	const Tga::LocalSpacePose& currentPose = myCurrentAnimation->GetLocalSpacePose();
	//	const Tga::LocalSpacePose& blendPose = myAnimatedObject.animations[myAnimatedObject.previousState].GetLocalSpacePose();
	//	finalPose.Count = myCurrentAnimation->GetLocalSpacePose().Count;
	//	for (size_t i = 0; i < finalPose.Count; i++)
	//	{
	//		const auto& previousJointXform = blendPose.JointTransforms[i];
	//		const auto& currentJointXform = currentPose.JointTransforms[i];
	//		finalPose.JointTransforms[i] = Tga::ScaleRotationTranslationf::Lerp(previousJointXform, currentJointXform, myAnimatedObject.blendValue);
	//	}
	//}
	//else
	//{
	//	finalPose = myCurrentAnimation->GetLocalSpacePose();
	//}

	//// Apply independent arm animations
	//if (myLeftArmState.isPlaying && myLeftArmState.animationPlayer)
	//{
	//	const Tga::LocalSpacePose& leftArmPose = myLeftArmState.animationPlayer->GetLocalSpacePose();
	//	ApplyArmAnimation(finalPose, leftArmPose, myLeftArmBones);
	//}

	//if (myRightArmState.isPlaying && myRightArmState.animationPlayer)
	//{
	//	const Tga::LocalSpacePose& rightArmPose = myRightArmState.animationPlayer->GetLocalSpacePose();
	//	ApplyArmAnimation(finalPose, rightArmPose, myRightArmBones);
	//}

	//// Apply pitch to head
	//ApplyPitchToHead(finalPose);

	//// Set final pose
	//myAnimatedObject.model->SetPose(finalPose);

	//// Animation state logic
	//myCurrentAnimationState = myAnimatedObject.animations[myAnimatedObject.currentAnimation].GetState();
	//bool ready = myCurrentAnimationState == Tga::AnimationState::Finished || myAnimatedObject.animations[myAnimatedObject.currentAnimation].GetIsLooping();

	//if (!ready)
	//{
	//	return;
	//}

	//constexpr float blendSpeed = 5.f;
	//if (myState == PlayerState::Idle)
	//{
	//	if (myIdleTime >= 3.f)
	//	{
	//		if (myAnimatedObject.currentAnimation != "Idle_long"_tgaid)
	//		{
	//			myAnimatedObject.SetAnimationWithBlending("Idle_long"_tgaid, 0.2f, blendSpeed);
	//		}

	//		if (myCurrentAnimationState == Tga::AnimationState::Finished)
	//		{
	//			myAnimatedObject.SetAnimationWithBlending("Idle"_tgaid, 0.2f, blendSpeed);
	//			myIdleTime = 0.f;
	//		}
	//	}
	//	else
	//	{
	//		myAnimatedObject.SetAnimationWithBlending("Idle"_tgaid, 0.2f, blendSpeed);
	//		myIdleTime += aDeltaTime;
	//	}
	//}
	//else if (myState == PlayerState::Walking)
	//{
	//	myAnimatedObject.SetAnimationWithBlending("Walk"_tgaid, 0.2f, blendSpeed);
	//}
	//else if (myState == PlayerState::Attacking)
	//{
	//	if (myAbilities[PlayerAttackID::Stabby]->GetIsCasting())
	//	{
	//		//myAnimatedObject.SetAnimationWithBlending("Stab_1"_tgaid, 0.9f, blendSpeed);
	//		PlayLeftArmAnimation("Stab_1"_tgaid);
	//	}
	//	else if (myAbilities[PlayerAttackID::PewPew]->GetIsCasting())
	//	{
	//		int first = RandomGenerator::GetInstance()->GetBool();
	//		if (first)
	//		{
	//			//myAnimatedObject.SetAnimationWithBlending("Shot_1"_tgaid, 0.2f, blendSpeed);
	//			PlayRightArmAnimation("Shot_1"_tgaid);
	//		}
	//		else
	//		{
	//			//myAnimatedObject.SetAnimationWithBlending("Shot_2"_tgaid, 0.2f, blendSpeed);
	//			PlayRightArmAnimation("Shot_2"_tgaid);
	//		}
	//	}
	//}
	//else if (myState == PlayerState::Death)
	//{
	//	myAnimatedObject.SetAnimationWithBlending("Death"_tgaid, 0.0f, blendSpeed);
	//}

	//if (myCurrentAnimation != &myAnimatedObject.animations[myAnimatedObject.currentAnimation])
	//{
	//	if (myCurrentAnimation != nullptr)
	//	{
	//		myCurrentAnimation->Stop();
	//	}
	//	myCurrentAnimation = &myAnimatedObject.animations[myAnimatedObject.currentAnimation];
	//	myCurrentAnimation->Play();
	//}
}

Tga::Matrix4x4f Player::GetHeadTransform()
{
	// Get head position from animation skeleton
	Tga::LocalSpacePose localPose = myCurrentAnimation->GetLocalSpacePose();
	const Tga::Skeleton* skeleton = GetModelInstance()->GetModel()->GetSkeleton();
	Tga::ModelSpacePose modelSpacePose;
	skeleton->ConvertPoseToModelSpace(localPose, modelSpacePose);

	std::string socketPositionName = "Head";
	size_t boneIndex = skeleton->JointNameToIndex.find(socketPositionName)->second;

	// Get head world transform
	Tga::Matrix4x4f headWorld = modelSpacePose.JointTransforms[boneIndex] * GetTransform();
	Tga::Vector3f headPosition = headWorld.GetPosition();

	// Create rotation around the head position
	Tga::Matrix4x4f yawRot = Tga::Matrix4x4f::CreateRotationAroundY(myYaw);
	Tga::Matrix4x4f pitchRot = Tga::Matrix4x4f::CreateRotationAroundX(myPitch);

	// Combine rotations and set position to head
	Tga::Matrix4x4f result = pitchRot * yawRot;
	result.SetPosition(headPosition);

	return result;
}

void Player::PlayPlayerVFX()
{
	switch (myPlayerAbilityState)
	{
	case PlayerAttackID::Stabby:
	{
		/*if (myCurrentAnimation->GetFrame() == 2)*/
		{
			VFXManager::GetInstance()->PlayVFX("Player_Slash_1_VFX"_tgaid, GetTransform());
			myPlayerAbilityState = PlayerAttackID::Count;
		}
		break;
	}
	default:
	{
		break;
	}
	}
}

void Player::FireEquippedWeaponOnce()
{
	if (myWeapons.IsSwapLocked())
		return;

	if (!myWeapons.CanShoot())
	{
		if (myWeapons.CanReload())
			myWeapons.StartReload();
		return;
	}

	auto cam = Picking::GetInstance()->GetCamera();
	const auto& camTr = cam->GetTransform();

	Tga::Vector3f aimDir = camTr.GetForward().GetNormalized();

	constexpr float farPlane = 10000.f; // Camera farplane, can get from here=> GetFrustumPlanes(nearPlane, farPlane);

	Tga::Vector3f targetPos = camTr.GetPosition() + aimDir * farPlane;
	
	const bool fired = UseAbility(PlayerAttackID::PewPew, targetPos);
	if (!fired)
		return;

	myWeapons.TryConsumeAmmoForShot();
	SendAmmoEventForEquippedWeapon();

	const auto& def = myWeapons.GetEquippedDef();
	const auto& ammo = myWeapons.GetAmmo(myWeapons.GetEquippedType());
	if (!def.infiniteAmmo && ammo.mag == 0 && myWeapons.CanReload())
		myWeapons.StartReload();
}

void Player::SendPointsChangeToUI()
{
	IntBarValues v{};
	v.currentValue = myPoints;
	v.maxValue = kPointsMax; // 50

	Message msg{};
	msg.eventType = Event::PointsChange;
	msg.data = v;

	EventManager::GetInstance()->SendEventMessage(msg);
}

void Player::SendComboChangeToUI()
{
	IntBarValues v{};
	v.currentValue = myComboMultiplier; // 1,2,3...
	v.maxValue = 50;                    // eller nåt rimligt max för bar (t.ex 10)

	Message msg{};
	msg.eventType = Event::ComboChange;
	msg.data = v;

	EventManager::GetInstance()->SendEventMessage(msg);
}

void Player::InitializeArmBones()
{
	if (myArmBonesInitialized) return;

	const Tga::Skeleton* skeleton = myAnimatedObject.model->GetModel()->GetSkeleton();;

	// Get left arm hierarchy
	auto leftIt = skeleton->JointNameToIndex.find("upperArm_L");
	if (leftIt != skeleton->JointNameToIndex.end())
	{
		GetBoneHierarchy(skeleton, leftIt->second, myLeftArmBones);
	}

	// Get right arm hierarchy
	auto rightIt = skeleton->JointNameToIndex.find("upperArm_R");
	if (rightIt != skeleton->JointNameToIndex.end())
	{
		GetBoneHierarchy(skeleton, rightIt->second, myRightArmBones);
	}

	myArmBonesInitialized = true;
}

void Player::GetBoneHierarchy(const Tga::Skeleton* skeleton, size_t boneIndex, std::vector<size_t>& outBoneIndices)
{
	outBoneIndices.push_back(boneIndex);

	const auto& joint = skeleton->Joints[boneIndex];
	for (size_t childIndex : joint.Children)
	{
		GetBoneHierarchy(skeleton, childIndex, outBoneIndices);
	}
}

void Player::ApplyArmAnimation(Tga::LocalSpacePose& basePose, const Tga::LocalSpacePose& armPose, const std::vector<size_t>& armBoneIndices)
{
	for (size_t boneIndex : armBoneIndices)
	{
		basePose.JointTransforms[boneIndex] = armPose.JointTransforms[boneIndex];
	}
}

void Player::PlayLeftArmAnimation(const Tga::StringId& animationId)
{
	auto it = myAnimatedObject.animations.find(animationId);
	if (it != myAnimatedObject.animations.end())
	{
		myLeftArmState.animationPlayer = &it->second;
		myLeftArmState.animationPlayer->Play();
		myLeftArmState.isPlaying = true;
	}
}

void Player::PlayRightArmAnimation(const Tga::StringId& animationId)
{
	auto it = myAnimatedObject.animations.find(animationId);
	if (it != myAnimatedObject.animations.end())
	{
		myRightArmState.animationPlayer = &it->second;
		myRightArmState.animationPlayer->Play();
		myRightArmState.isPlaying = true;
	}
}

void Player::TakeDamage(int someDamage)
{
	if (GODMODE)
	{
		return;
	}

	if (myHealth > 0)
	{
		myHealth -= someDamage;
		SendHealthEvent();
	}

	if (myHealth <= 0)
	{
		OnDeath();
	}

}

void Player::ZoomCamera(float delta)
{
	myCameraDistance += delta;
	myCameraDistance = std::clamp(myCameraDistance, myMinCameraDistance, myMaxCameraDistance);
}

void Player::BlinkForward(float aDistance)
{
	Tga::Vector3f forward = GetTransform().GetForward();
	forward.y = 0.f;

	if (forward.LengthSqr() <= 0.0001f)
		return;

	forward.Normalize();

	Tga::Vector3f targetPos = GetPosition() + forward * aDistance;

	// Clamp to navmesh so we don't blink outside walkable area
	targetPos = Picking::GetInstance()->NearestInNavmesh(targetPos);

	SetPosition(targetPos);
	AI::PollingStation3D::Get().UpdateActorPos(this, targetPos);
}
