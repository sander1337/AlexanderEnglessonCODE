#pragma once

enum class PlayerAttackID : uint8_t
{
	Stabby,
	PewPew,
	Count,
};