#pragma once
#include <array>
#include <algorithm>

#include "WeaponDef.h"
#include "WeaponPresets.h"

struct WeaponAmmoState
{
    int mag = 0;
    int reserve = 0;
    bool reloading = false;
    float reloadTimer = 0.f;
};

class PlayerWeapons
{
public:
    static const char* ToString(WeaponType t);

    // NEW: init with only defs, no weapons unlocked
    void InitLocked();

    // NEW: unlock / query
    void UnlockOrGiveWeapon(WeaponType t);
    bool IsUnlocked(WeaponType t) const;

    // Equip / cycle but ONLY if unlocked
    bool EquipIfUnlocked(WeaponType t);
    bool CycleUnlocked(int dir);

    WeaponType GetEquippedType() const { return myEquippedType; }
    const WeaponDef& GetEquippedDef() const { return myEquippedDef; }

    // swap lock
    void StartSwapLock(float seconds);
    void UpdateSwapLock(float dt);
    bool IsSwapLocked() const { return mySwapLock > 0.0f; }

    // ammo
    const WeaponAmmoState& GetAmmo(WeaponType t) const;
    const WeaponDef& GetDef(WeaponType t) const;

    bool CanShoot() const;
    bool TryConsumeAmmoForShot();

    bool CanReload() const;
    void StartReload();
    bool UpdateReload(float dt);

    void AddAmmoFromPickUp(WeaponType aWeaponType, int aAddToReserve);
    void AddAmmoFromPickUpToAllWeapons(int aAmmoToAdd);

    // debug
    void DebugAddAmmo(WeaponType t, int addToMag, int addToReserve);
    void DebugSetAmmo(WeaponType t, int newMag, int newReserve);

    bool IsReloading() const;
    float GetReloadRemaining() const;
    float GetReloadDuration() const;

private:
    WeaponAmmoState& AmmoFor(WeaponType t);
    const WeaponAmmoState& AmmoFor(WeaponType t) const;

    // INTERNAL: keep your old equip but don�t call it from Player anymore
    void Equip(WeaponType t);

private:
    WeaponType myEquippedType = WeaponType::Revolver;
    WeaponDef  myEquippedDef{};

    std::array<WeaponDef, static_cast<size_t>(WeaponType::Count)> myDefs{};
    std::array<WeaponAmmoState, static_cast<size_t>(WeaponType::Count)> myAmmo{};

    // NEW: unlocked flags
    std::array<bool, static_cast<size_t>(WeaponType::Count)> myUnlocked{};

    float mySwapLock = 0.0f;
};
