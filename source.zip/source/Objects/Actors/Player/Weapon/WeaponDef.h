#pragma once

#include "../../AbilityCasting/Ability.h"
#include <string_view>
#include <cstdint>

enum class WeaponType : uint8_t
{
    Revolver,
    MachineGun,
    Shotgun,
    RocketLauncher,
    Count
};

enum class FireMode : uint8_t
{
    SemiAuto,   // click
    FullAuto    // hold
};

struct WeaponDef
{
    WeaponType type = WeaponType::Revolver;

    // This is the important link to your current system:
    // "Player_Arrow", "Player_Rocket", "Player_Shotgun" etc.
    std::string_view attackObject = "Player_Revolver_Bullet";

    TargetType targetType = TargetType::Directional; // matches AttackingAbility

    FireMode fireMode = FireMode::SemiAuto;

    float cooldown = 0.2f;  // used by Ability base
    float castTime = 0.0f;  // used by Ability base

    int damage = 10;

    // Optional extras (use later)
    int pellets = 1;        // shotgun
    float spreadDeg = 0.f;  // shotgun/mg

    // --- Ammo ---
    int magSize = 12;           // bullets per magazine
    int ammoPerShot = 1;        // shotgun/rocket kan vara 1, ev specials senare
    int maxReserve = 120;       // max ammo in reserve
    int startReserve = 60;      // start reserve
    float reloadTime = 1.2f;    // seconds
    bool infiniteAmmo = false;  // debug/cheat
};
