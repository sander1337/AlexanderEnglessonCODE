#include "stdafx.h"
#include "PlayerWeapons.h"
#include <algorithm>

const char* PlayerWeapons::ToString(WeaponType t)
{
    switch (t)
    {
    case WeaponType::Revolver:       return "Revolver";
    case WeaponType::MachineGun:     return "MachineGun";
    case WeaponType::Shotgun:        return "Shotgun";
    case WeaponType::RocketLauncher: return "RocketLauncher";
    default:                         return "Unknown";
    }
}

void PlayerWeapons::InitLocked()
{
    for (int i = 0; i < static_cast<int>(WeaponType::Count); ++i)
    {
        WeaponType wt = static_cast<WeaponType>(i);
        myDefs[static_cast<size_t>(wt)] = MakeWeapon(wt);

        myUnlocked[static_cast<size_t>(wt)] = false;

        // Start with 0 ammo because it's locked
        auto& a = AmmoFor(wt);
        a.mag = 0;
        a.reserve = 0;
        a.reloading = false;
        a.reloadTimer = 0.f;
    }

    // Keep a default equippedType, but it is "not usable" until unlocked.
    myEquippedType = WeaponType::Revolver;
    myEquippedDef = myDefs[static_cast<size_t>(myEquippedType)];
}

bool PlayerWeapons::IsUnlocked(WeaponType t) const
{
    return myUnlocked[static_cast<size_t>(t)];
}

void PlayerWeapons::UnlockOrGiveWeapon(WeaponType t)
{
    const size_t idx = static_cast<size_t>(t);
    if (myUnlocked[idx])
        return;

    myUnlocked[idx] = true;

    // Give starting ammo when unlocked
    const WeaponDef& def = myDefs[idx];
    auto& a = AmmoFor(t);
    a.mag = def.magSize;
    a.reserve = def.startReserve;
    a.reloading = false;
    a.reloadTimer = 0.f;
}

bool PlayerWeapons::EquipIfUnlocked(WeaponType t)
{
    if (!IsUnlocked(t))
        return false;

    Equip(t);
    return true;
}

bool PlayerWeapons::CycleUnlocked(int dir)
{
    const int count = static_cast<int>(WeaponType::Count);
    int start = static_cast<int>(myEquippedType);

    for (int step = 1; step <= count; ++step)
    {
        int w = (start + step * dir) % count;
        if (w < 0) w += count;

        WeaponType wt = static_cast<WeaponType>(w);
        if (IsUnlocked(wt))
        {
            Equip(wt);
            return true;
        }
    }

    return false;
}

void PlayerWeapons::Equip(WeaponType t)
{
    myEquippedType = t;
    myEquippedDef = myDefs[static_cast<size_t>(t)];
}

void PlayerWeapons::StartSwapLock(float seconds)
{
    mySwapLock = std::max(0.0f, seconds);
}

void PlayerWeapons::UpdateSwapLock(float dt)
{
    if (mySwapLock <= 0.0f) return;
    mySwapLock -= dt;
    if (mySwapLock < 0.0f) mySwapLock = 0.0f;
}

WeaponAmmoState& PlayerWeapons::AmmoFor(WeaponType t)
{
    return myAmmo[static_cast<size_t>(t)];
}

const WeaponAmmoState& PlayerWeapons::AmmoFor(WeaponType t) const
{
    return myAmmo[static_cast<size_t>(t)];
}

const WeaponAmmoState& PlayerWeapons::GetAmmo(WeaponType t) const
{
    return AmmoFor(t);
}

const WeaponDef& PlayerWeapons::GetDef(WeaponType t) const
{
    return myDefs[static_cast<size_t>(t)];
}

bool PlayerWeapons::CanShoot() const
{
    if (!IsUnlocked(myEquippedType))
        return false;

    const auto& def = myEquippedDef;
    const auto& ammo = AmmoFor(myEquippedType);

    if (def.infiniteAmmo) return true;
    if (ammo.reloading) return false;
    return ammo.mag >= def.ammoPerShot;
}

bool PlayerWeapons::TryConsumeAmmoForShot()
{
    auto& def = myEquippedDef;
    auto& ammo = AmmoFor(myEquippedType);

    if (def.infiniteAmmo) return true;
    if (ammo.reloading) return false;
    if (ammo.mag < def.ammoPerShot) return false;

    ammo.mag -= def.ammoPerShot;
    return true;
}

bool PlayerWeapons::CanReload() const
{
    if (!IsUnlocked(myEquippedType))
        return false;

    const auto& def = myEquippedDef;
    const auto& ammo = AmmoFor(myEquippedType);

    if (def.infiniteAmmo) return false;
    if (ammo.reloading) return false;
    if (ammo.mag >= def.magSize) return false;
    if (ammo.reserve <= 0) return false;
    return true;
}

void PlayerWeapons::StartReload()
{
    if (!CanReload()) return;

    auto& def = myEquippedDef;
    auto& ammo = AmmoFor(myEquippedType);

    ammo.reloading = true;
    ammo.reloadTimer = def.reloadTime;
}

bool PlayerWeapons::UpdateReload(float dt)
{
    auto& def = myEquippedDef;
    auto& ammo = AmmoFor(myEquippedType);

    if (!ammo.reloading) return false;

    ammo.reloadTimer -= dt;
    if (ammo.reloadTimer > 0.f) return false;

    ammo.reloading = false;
    ammo.reloadTimer = 0.f;

    const int need = def.magSize - ammo.mag;
    const int take = (ammo.reserve < need) ? ammo.reserve : need;

    ammo.mag += take;
    ammo.reserve -= take;

    return true; 
}

void PlayerWeapons::AddAmmoFromPickUp(WeaponType aWeaponType, int aAmmoToAdd)
{
    if (!IsUnlocked(aWeaponType))
        return;

    // your existing logic below unchanged...
    if (aAmmoToAdd != 0)
    {
        auto& ammoState = AmmoFor(aWeaponType);
        auto& def = myDefs[static_cast<size_t>(aWeaponType)];

        if (aAmmoToAdd + ammoState.reserve <= def.maxReserve)
        {
            ammoState.reserve += aAmmoToAdd;
        }
        else
        {
            int addToReserv = def.maxReserve - ammoState.reserve;
            int addToMag = aAmmoToAdd - addToReserv;

            ammoState.reserve += addToReserv;

            if (addToMag + ammoState.mag <= def.magSize)
                ammoState.mag += addToMag;
            else
                ammoState.mag = def.magSize;
        }
    }
}

void PlayerWeapons::AddAmmoFromPickUpToAllWeapons(int aAmmoToAdd)
{
    for (int i = 0; i < static_cast<int>(WeaponType::Count); ++i)
    {
        WeaponType wt = static_cast<WeaponType>(i);
        if (!IsUnlocked(wt))
            continue;

        AddAmmoFromPickUp(wt, aAmmoToAdd);
    }
}

void PlayerWeapons::DebugAddAmmo(WeaponType t, int addToMag, int addToReserve)
{
    auto& a = AmmoFor(t);
    const WeaponDef def = myDefs[static_cast<size_t>(t)];

    if (addToMag != 0)
    {
        a.mag = std::clamp(a.mag + addToMag, 0, def.magSize);
    }

    if (addToReserve != 0)
    {
        a.reserve = std::clamp(a.reserve + addToReserve, 0, def.maxReserve);
    }
}

void PlayerWeapons::DebugSetAmmo(WeaponType t, int newMag, int newReserve)
{
    auto& a = AmmoFor(t);
    const WeaponDef def = myDefs[static_cast<size_t>(t)];

    a.mag = std::clamp(newMag, 0, def.magSize);
    a.reserve = std::clamp(newReserve, 0, def.maxReserve);
}

bool PlayerWeapons::IsReloading() const
{
    return AmmoFor(myEquippedType).reloading;
}

float PlayerWeapons::GetReloadRemaining() const
{
    return AmmoFor(myEquippedType).reloadTimer; // �sek kvar� om du anv�nder den s�
}

float PlayerWeapons::GetReloadDuration() const
{
    return myEquippedDef.reloadTime;
}

