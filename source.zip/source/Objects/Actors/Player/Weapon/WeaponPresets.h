// WeaponPresets.h
#pragma once
#include "WeaponDef.h"

inline WeaponDef MakeWeapon(WeaponType t)
{
    switch (t)
    {
    case WeaponType::Revolver:
        return WeaponDef{
            .type = t,
            .attackObject = "Player_Revolver_Bullet",
            .targetType = TargetType::Directional,
            .fireMode = FireMode::SemiAuto,
            .cooldown = 1.5f,
            .castTime = 0.02f,
            .damage = 40,
            .pellets = 1,
            .spreadDeg = 0.5f,
            .magSize = 6,
            .ammoPerShot = 1,
            .maxReserve = 60,
            .startReserve = 30,
            .reloadTime = 0.0f
        };

    case WeaponType::MachineGun:
        return WeaponDef{
            .type = t,
            .attackObject = "Player_MachineGun_Bullet",
            .targetType = TargetType::Directional,
            .fireMode = FireMode::FullAuto,
            .cooldown = 0.08f,
            .castTime = 0.02f,
            .damage = 12,
            .pellets = 1,
            .spreadDeg = 2.0f,
            .magSize = 30,
            .ammoPerShot = 1,
            .maxReserve = 240,
            .startReserve = 120,
            .reloadTime = 1.8f
        };

    case WeaponType::Shotgun:
        return WeaponDef{
            .type = t,
            .attackObject = "Player_Shotgun_pellets",
            .targetType = TargetType::Directional,
            .fireMode = FireMode::SemiAuto,
            .cooldown = 0.9f,
            .castTime = 0.10f,
            .damage = 8,
            .pellets = 10,
            .spreadDeg = 8.0f,
            .magSize = 8,          // shells
            .ammoPerShot = 1,
            .maxReserve = 40,
            .startReserve = 16,
            .reloadTime = 2.2f
        };

    case WeaponType::RocketLauncher:
        return WeaponDef{
            .type = t,
            .attackObject = "Player_RocketLauncher_rocket",
            .targetType = TargetType::Directional,
            .fireMode = FireMode::SemiAuto,
            .cooldown = 1.2f,
            .castTime = 0.15f,
            .damage = 120,
            .pellets = 1,
            .spreadDeg = 0.f,
            .magSize = 1,
            .ammoPerShot = 1,
            .maxReserve = 10,
            .startReserve = 4,
            .reloadTime = 2.5f
        };

    default:
        return WeaponDef{};
    }
}