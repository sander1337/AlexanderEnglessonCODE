#pragma once

#include "../Game/source/Input/InputMapper.h"
#include "../Game/source/Events/EventManager.h"
#include "../AbilityCasting/Ability.h"
#include "../Actor.h"
#include <vector>
#include "PlayerAbility.h"
#include "Weapon/PlayerWeapons.h"


struct Tga::ScenePropertyDefinition;

enum class DamageType : std::uint8_t;
class SpawnedObject;

class Player : public Actor, public InputObserver, public Observer
{
public:
	Player() = default;
	~Player() override = default;

	void Init(/*AnimatedObject& aAnimatedObject*/) override;
	void Update(float aDeltaTime) override;
	void DebugRender() override;

	void ResetPlayer(SceneID aSceneId);

	void ApplyProps(const std::vector<Tga::ScenePropertyDefinition>& someProperties) override;
	void UpdateAbilities(float aDeltaTime);
	void ApplyYaw();
	void SetInitialPos();
	void ApplyPitchToHead(Tga::LocalSpacePose& pose);
	float GetPitch() const { return myPitch; }
	float GetYaw() const { return myYaw; }

	void RegisterInput() override;
	void UnregisterInput() override;
	void ReceiveInput(InputEvent aGameEvent, const std::any& someData) override;
	Tga::Vector3f GetThirdPersonCameraPos() const;
	void ReceiveEvent(const Message& aMessage) override;

	void UpdateAnimation(float aDeltaTime);

	void SetSpeed(float aSpeed);
	void SetSpeedMultiplier(float aSpeedMultiplier);

	ActorType GetActorType() const override { return ActorType::Player; }

	void OnCollision(const std::shared_ptr<Collider>& anOther) override { anOther; }

	void OnDeath() override;

	void SetCheckpoint(const Tga::Vector3f& aPosition);

	void SetIsRestarting(bool aStatus) { mySkipUpdate = aStatus; }
	Tga::Matrix4x4f GetHeadTransform();

	const PlayerWeapons& GetWeapons() const { return myWeapons; }
	PlayerWeapons& GetWeapons() { return myWeapons; }

	///weapon
	static const char* WeaponTypeToString(WeaponType t);
	void CycleWeapon(int dir);
	void SendAmmoEventForEquippedWeapon();
	void SendReloadEvent(bool isReloading, float remaining, float duration);

	void SendHealthEvent();
	void TakeDamage(int someDamage) override;

	void ZoomCamera(float delta);
	float GetCameraDistance() const { return myCameraDistance; }

	void BlinkForward(float aDistance);
private:
	static constexpr float DEATH_DURATION = 3.f;

	void PlayPlayerVFX();

	enum class PlayerState : uint8_t
	{
		Idle,
		Walking,
		Attacking,
		Death,
		Count
	};

	struct ArmAnimationState
	{
		Tga::AnimationPlayer* animationPlayer = nullptr;
		bool isPlaying = false;
		float blendValue = 1.f;
	};

	ArmAnimationState myLeftArmState;
	ArmAnimationState myRightArmState;

	std::vector<size_t> myLeftArmBones;
	std::vector<size_t> myRightArmBones;
	bool myArmBonesInitialized = false;

	//Abilities
	void UseAbility(PlayerAttackID id, const Tga::Matrix4x4f& spawnTransform);
	bool UseAbility(PlayerAttackID anAbilityIdentifier, const Tga::Vector3f& aDirection = Tga::Vector3f{});
	void PrepareAbility(PlayerAttackID anAbilityIdentifier, Actor* aTargetActor);
	void StopPreparingAbility();
	std::map<PlayerAttackID, std::unique_ptr<Ability>> myAbilities;
	Actor* myAbilityTarget;
	PlayerAttackID myPreparingAbility = PlayerAttackID::Count;
	PlayerAttackID myPlayerAbilityState;

	// Animations
	void InitializeArmBones();
	void GetBoneHierarchy(const Tga::Skeleton* skeleton, size_t boneIndex, std::vector<size_t>& outBoneIndices);
	void ApplyArmAnimation(Tga::LocalSpacePose& basePose, const Tga::LocalSpacePose& armPose, const std::vector<size_t>& armBoneIndices);
	void PlayLeftArmAnimation(const Tga::StringId& animationId);
	void PlayRightArmAnimation(const Tga::StringId& animationId);
	
	bool mySkipUpdate = false;
	Tga::Vector3f myDirection;

	//Animation
	Tga::StringId myAttackAnimations[3];
	bool myIAmDead = false;
#ifndef _RETAIL
	bool myIsInvincible = true;
#endif;
	float myDeathTimer = DEATH_DURATION;

	PlayerState myState;
	Tga::LocalSpacePose myModifiedLocalPose;
	// Player data
	Tga::Vector3f myStartPos;
	Tga::Vector3f myRespawnPos;
	float mySpeed = 400.f;
	float mySpeedMultiplier = 1.f;

	int myAttackDmgMelee = 25;
	int myAttackDmgRanged = 25;

	int myPoints = 0;
	int myComboMultiplier = 1;     
	float myComboTimeLeft = 0.f;
	float myInfoTextTimeLeft = 0.f;
	static constexpr float kComboDuration = 3.f;
	static constexpr int kPointsMax = 50;
	void AddKillScore(int basePoints);
	void ResetCombo();


	void ResetInfoText();

	float myPitch = 0.f;    // radians
	float myYaw = 0.f;    // radians
	float myMouseSensitivity = 0.002f;
	float myCameraDistance = 750.f;      // current distance
	float myMinCameraDistance = 450.f;   // current closest
	float myMaxCameraDistance = 1500.f;   // furthest zoom out
	float myCameraZoomStep = 80.f;       // how much each wheel tick changes

	PlayerWeapons myWeapons;

	///////////////////////////////////////////////////////////////////////////////
	// --- Weapon handling ---
	void EquipWeapon(WeaponType t);
	void FireEquippedWeaponOnce(); 
	void SendPointsChangeToUI();
	void SendComboChangeToUI();

	// --- Fire / reload / swap state ---
	bool  myWantsToAutoFire = false;
	bool  myIsFiring = false;
	bool armsInitialized = false;
	float myFireTimer = 0.f; 

	static constexpr float kWeaponSwapLockDuration = 1.0f;
	float myIdleTime;

	bool GODMODE;
	// AUDIO
	const float myLeftFootStepTimerMax = 1.f;
	float myLeftFootStepTimer = myLeftFootStepTimerMax;

	const float myRightFootStepTimerMax = 1.7f;
	float myRightFootStepTimer = myRightFootStepTimerMax;

	bool myAllowLook = false; // eller true beroende p� default

};