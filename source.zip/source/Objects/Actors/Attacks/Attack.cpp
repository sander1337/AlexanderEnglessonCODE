﻿#include "stdafx.h"
#include "Attack.h"

#include <GameWorld.h>
#include <SceneManagement/GameScene.h>
#include <Audio/AudioManager.h>
#include <Audio/DamagedByType.h>
#include <Collisions/Narrow/Collider.h>
#include <Objects/Actors/Enemy/Enemy.h>
#include "../Actor.h"
#include "../../StaticObjects/DestructibleObject.h"
#include "../../StaticObjects/PickupObject.h"

static Tga::StringId PickHitVFXFromAttackObject(Tga::StringId attackObjectId)
{
	using namespace Tga;

	if (attackObjectId == "Player_MachineGun_Bullet"_tgaid)
		return "VFX_MG_Hit"_tgaid;

	if (attackObjectId == "Player_Revolver_Bullet"_tgaid)
		return "VFX_Revolver_Hit"_tgaid;

	if (attackObjectId == "Player_Shotgun_pellets"_tgaid)
		return "VFX_Shotgun_Hit"_tgaid;

	if (attackObjectId == "Player_RocketLauncher_rocket"_tgaid)
		return "VFX_Rocket_Explosion"_tgaid;

	// default
	return "VFX_Default_Hit"_tgaid;
}

Attack::Attack(const Tga::AttackProp& someAttackProps)
	: myActivationTime(someAttackProps.activationDelay),
	myDeactivationTime(someAttackProps.activationDelay + someAttackProps.duration),
	myDamageType(someAttackProps.damage),
	myAttackObject(someAttackProps.attackObject) 
{
}

void Attack::Init()
{
	SetShouldRender(false);
}

void Attack::Update(const float aDeltaTime)
{
	//Handle activation and death of attack
	if (!myHasBeenActivated && myLifeTime >= myActivationTime)
	{
		Activate();
	}
	else if (myLifeTime >= myDeactivationTime)
	{
		Deactivate();
		return;
	}

	if (myHasBeenActivated)
	{
		AttackLogic(aDeltaTime);

		//Check if attack hit anything
		std::shared_ptr gameScene = GameWorld::GetInstance().GetCurrentGameScene().lock();

		if (!gameScene)
		{
			return;
		}

		auto actors = gameScene->GetActorsInBounds(GetCollider()->GetBounds());

		std::shared_ptr caster = myCaster.lock();

		if (!caster)
		{
			return;
		}

		for (std::weak_ptr weakObj : actors)
		{
			if (std::shared_ptr targetActor = weakObj.lock())
			{

				if (caster != targetActor)
				{
					if (myHitOnce)
					{
						//Skip already hit actors
						if (auto hitIt = std::ranges::find(myHitActors, targetActor.get()); hitIt != myHitActors.end())
						{
							continue;
						}
					}
					if (targetActor->GetCollider()->Collision(*GetCollider()))
					{
						const bool isCasterEnemy = caster->GetActorType() != ActorType::Player;
						const bool isTargetEnemy = targetActor->GetActorType() != ActorType::Player;

						if (isCasterEnemy != isTargetEnemy) // Same types can't hurt each other
						{
							targetActor->TakeDamage(myDamage);
							myHitActors.push_back(targetActor.get());

							//VFXManager::GetInstance()->PlayVFX("Player_Slash_1_VFX"_tgaid, GetTransform());
							//if (GetAttackObject() == "Player_RocketLauncher_rocket"_tgaid)
							//{
							//const auto vfxId = PickHitVFXFromAttackObject(GetAttackObject());
							//VFXManager::GetInstance()->PlayVFX(vfxId, GetTransform());
							//VFXManager::GetInstance()->PlayVFX("Hag_Buff_VFX"_tgaid, GetTransform());
							//}
							Deactivate();
						}
					}
				}
			}
		}

		// Destructibles
		auto destuctibleObjects = gameScene->GetDestructibleObjectsInBounds(GetCollider()->GetBounds());
		for (std::weak_ptr weakObj : destuctibleObjects)
		{
			if (std::shared_ptr targetDestObj = weakObj.lock())
			{
				if (targetDestObj->GetCollider()->Collision(*GetCollider()))
				{
					const bool isCasterPlayer = caster->GetActorType() == ActorType::Player;

					if (isCasterPlayer) // Same types can't hurt each other
					{
						targetDestObj->TakeDamage(myDamage);
						Deactivate();

					}
				}
			}
		}

		// todo :: Also be able to attack Pickups? uncomment v
		/*auto pickupObjects = gameScene.lock()->GetPickupObjectsInBounds(GetCollider()->GetBounds());
		for (std::weak_ptr weakObj : pickupObjects)
		{
			if (std::shared_ptr targetDestObj = weakObj.lock())
			{
				if (std::shared_ptr caster = myCaster.lock())
				{
					if (targetDestObj->GetCollider()->Collision(*GetCollider()))
					{
						const bool isCasterPlayer = caster->GetActorType() == ActorType::Player;

						if (isCasterPlayer) // Same types can't hurt each other
						{
							targetDestObj->TakeDamage(myDamage);
						}
					}
				}
			}
		}*/

	}
	
	myLifeTime += aDeltaTime;
}

void Attack::Activate()
{
	SetShouldRender(true);
	myHasBeenActivated = true;
}

void Attack::Deactivate()
{
	myHasBeenActivated = false;
	myMarkedForDelete = true;
}