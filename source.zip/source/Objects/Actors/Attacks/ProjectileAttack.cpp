﻿#include "stdafx.h"
#include "ProjectileAttack.h"
#include "../../../Graphics/VFXManager.h"
#include "../../../GameWorld.h"
#include "../../../SceneManagement/GameScene.h"
#include "../Actor.h"

#include <tge/drawers/DebugDrawer.h>

ProjectileAttack::ProjectileAttack(const Tga::AttackProp& someAttackProps) : Attack(someAttackProps), myProjectileSpeed(someAttackProps.projectileSpeed)
{
}

void ProjectileAttack::Init()
{
	Attack::Init();
	myHasStart = false;
	myShootDebugDrawLineStartPos.y += myShootDebugDrawLineStartPos.y + 150;

}


void ProjectileAttack::AttackLogic(const float aDeltaTime)
{
	// sätt startpos exakt när vi börjar röra oss / första tick
	if (!myHasStart)
	{
		myShootDebugDrawLineStartPos = GetTransform().GetPosition();
		myHasStart = true;
	}

	const auto transform = GetTransform();
	SetPosition(transform.GetForward().GetNormalized() * myProjectileSpeed * aDeltaTime + transform.GetPosition());

	if (!isActivated)
	{
		std::shared_ptr actor = myCaster.lock();

		std::shared_ptr gameScene = GameWorld::GetInstance().GetCurrentGameScene().lock();

		if (!gameScene->GetSpawnedObjects().empty())
		{
			auto& spawned = gameScene->GetSpawnedObjects();

			auto it = std::find_if(spawned.begin(), spawned.end(),
				[&](const std::shared_ptr<SpawnedObject>& p) {	return p->GetTransform() == GetTransform();	});

			if (it != spawned.end())
			{
				myVfx = *it;
				isActivated = true;
			}
		}

	}

	if (myVfx)
	{
		myVfx->SetPosition(GetTransform().GetPosition());
	}
}

void ProjectileAttack::DebugRender()
{
	auto& debug = Tga::Engine::GetInstance()->GetDebugDrawer();
	debug.DrawLine(myShootDebugDrawLineStartPos, GetTransform().GetPosition(), Tga::Color(1, 0, 0, 1));
}


