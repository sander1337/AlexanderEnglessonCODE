﻿#pragma once
//#pragma message(__FILE__" was compiled")
#include "../../GameObject.h"
#include <Utilities/Picking.h>

enum class DamageType : std::uint8_t;
class Actor;


class Attack : public GameObject
{
public:
    explicit Attack(const Tga::AttackProp& someAttackProps);
    explicit Attack() = default;

    const Tga::StringId& GetAttackObject() const { return myAttackObject; } 


    void Init() override;

    void Update(float aDeltaTime) override;

    void Activate();
    void Deactivate();
    void SetCaster(const std::shared_ptr<Actor>& aCaster)
    {
        myCaster = aCaster;
    }
    std::weak_ptr<Actor> GetCastor() { return myCaster; }
    void SetDamage(const int aDamage)
    {
        myDamage = aDamage;
    }

    Tga::StringId myAttackObject = {};

protected:
    virtual void AttackLogic([[maybe_unused]] const float aDeltaTime) {} 
    
    std::weak_ptr<Actor> myCaster;
    bool myHasBeenActivated = false;
    bool myHitOnce = true;
    
private:
    std::vector<Actor*> myHitActors; //this is lwk problematic
    float myActivationTime = 0.0f; //todo remove activationTime
    float myDeactivationTime = 0.1f;
    float myLifeTime = 0.f;
    int myDamage = 0;
    DamageType myDamageType;
};