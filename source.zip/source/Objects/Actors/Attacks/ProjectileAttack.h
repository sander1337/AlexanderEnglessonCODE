﻿#pragma once
//#pragma message(__FILE__" was compiled")
#include "Attack.h"
#include "../../../Graphics/SpawnedObject.h"


class ProjectileAttack : public Attack
{
public:
	ProjectileAttack(const Tga::AttackProp& someAttackProps);

	void AttackLogic(float aDeltaTime) override;
	void DebugRender() override; // om du har debugrender virtuellt
	void Init() override;

private:
	float myProjectileSpeed = 100.f;
	bool isActivated = false;

	bool myHasStart = false;
	Tga::Vector3f myShootDebugDrawLineStartPos{};

	std::shared_ptr<SpawnedObject> myVfx;
};
