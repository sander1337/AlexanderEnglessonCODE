﻿#pragma once
//#pragma message(__FILE__" was compiled")
#include "Attack.h"

class FollowingAttack : public Attack
{
public:
	using Attack::Attack;
	
	void AttackLogic(float aDeltaTime) override;
	void SetPosFromCaster(Tga::Vector3f anOffset);

private:
	Tga::Vector3f myPosFromCaster;
};
