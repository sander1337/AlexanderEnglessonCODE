﻿#include "stdafx.h"
#include "FollowingAttack.h"
#include "../Actor.h"

void FollowingAttack::AttackLogic(const float /*aDeltaTime*/)
{
    if (auto actor = myCaster.lock())
    {
        const auto& camTr = Picking::GetInstance()->GetCamera()->GetTransform();

        constexpr float headHeight = 150.f;
        constexpr float backOffset = 20.f;

        const Tga::Vector3f up = { 0.f, 1.f, 0.f };

        // Use camera forward (more stable than GetTransform().GetForward() here)
        Tga::Vector3f forward = camTr.GetForward();
        forward.y = 0.f;
        forward.Normalize();

        const Tga::Vector3f pos =
            actor->GetTransform().GetPosition() + up * headHeight - forward * backOffset;

        Tga::Matrix4x4f tr = camTr;   
        tr.SetPosition(pos);

        SetTransform(tr);             
    }
}

void FollowingAttack::SetPosFromCaster(Tga::Vector3f anOffset)
{
	myPosFromCaster = anOffset;
}
