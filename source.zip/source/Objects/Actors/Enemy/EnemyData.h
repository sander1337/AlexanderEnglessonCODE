#pragma once

struct EnemyBaseData
{
	float aggroRange = 700.f;
	float attackSpeed = 50.f;
	float attackRange = 100.f;
	float attackInterval = 1.5f;
	float pathRecalculateInterval = 0.1f;
	float pathRecalculateTimer = 0.1f;
	float speed = 100.f;
	int attackDmg = 10;
};

struct HumanData : EnemyBaseData
{
	//float pathRecalculateTimer = 2.f;
};