#pragma once

#include "Objects/Actors/Actor.h"
#include "Objects/Actors/AbilityCasting/AttackingAbility.h"
#include "../source/Events/EventManager.h"
#include "../Game/source/Graphics/VFXmanager.h"

class SpawnedObject;
struct SteeringOutput;
struct EnemyBaseData;
enum class EnemyStateID : uint8_t;


class Enemy : public Actor, public Observer
{
public:
	Enemy() = default;
	~Enemy() override;

	void Init() override;
	void Update(float aDeltaTime) override;
	void ResetMe() override;
	virtual void UpdateAbilities(float aDeltaTime);
	void ApplySteering(const SteeringOutput& aSteeringOutput, float aDeltaTime);
	virtual bool TryAttack();
	virtual bool SucceedAttack();
	virtual bool IsAttacking();
	void ReceiveEvent(const Message& aMessage) override;
	virtual EnemyBaseData& GetData() = 0;

	void UpdateAnimation(float aDeltaTime);

	void SetPath(const std::vector<Tga::Vector3f>& aPath);
	void SetAnimation(EnemyStateID aState);
	void ClearPath();
	void OnDeath() override;

	virtual void ResetWhenPlayerDies();

	bool GetOnlyRunBaseLogic() { return myOnlyRunBaseLogic; }
	int GetHealth() { return myHealth; }
	int GetMaxHealth() { return myMaxHealth; }
	std::vector<Tga::Vector3f>& GetPath()
	{
		return myPath;
	}

	void PlayEnemyVFX();

	Tga::AnimationPlayer* GetCurrentAnimation() { return myCurrentAnimation; }

protected:
	//VFX STUFF for all enemies
	std::weak_ptr<SpawnedObject> myAuraVFX{};
	bool myHasTriggeredVFXDeath = false;

	std::unique_ptr<AttackingAbility> myAbility;
	EnemyStateID mySelectedAnimation;
	bool myHasAttacked = false;

	std::vector<Tga::Vector3f> myPath;

	Tga::Vector3f myStartingPos;
};