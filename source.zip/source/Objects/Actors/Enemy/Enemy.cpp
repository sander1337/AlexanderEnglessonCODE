#include "stdafx.h"

#include "Enemy.h"
#include <GameWorld.h>
#include <SceneManagement/GameScene.h>
#include <tge/model/AnimatedModelInstance.h>
#include <Events/EventManager.h>
#include <Graphics/VFXmanager.h>
#include <Audio/AudioManager.h>
#include <Utilities/PollingStation.h>
#include <Utilities/Blackboard.h>
#include "../../Behaviors/StateMachine.h"
#include "../AbilityCasting/AttackingAbility.h"
#include "../../Controller/Controller.h"
#include "../../Controller/HumanController.h"

#include "Objects/Behaviors/HumanBrainTree.h"


Enemy::~Enemy() {}

void Enemy::Init()
{
	// DONT CALL
}

void Enemy::Update(float aDeltaTime)
{
	GameObject::Update(aDeltaTime);
	if (myOnlyRunBaseLogic)
	{
		UpdateAnimation(aDeltaTime);
		return;
	}

	UpdateAbilities(aDeltaTime);

	if (myHealth < myMaxHealth)
	{
		AI::HurtInfo hurtInfo{ myHealth, myMaxHealth, GetPosition(), GetTransform() };
		AI::PollingStation3D::Get().SetHurtActorInfo(this, hurtInfo);
	}
	if (myHealth > 0.f)
	{
		if (!myPath.empty())
		{
			Tga::Vector3f target = myPath.back();
			myActorData.myController->SetTargetPosition(target);
			Tga::Vector3f direction = target - GetPosition();
			float distance = direction.Length();

			if (distance < 5.f)
			{
				myPath.pop_back();
			}
		}

		ControllerOutput controllerOutput = myActorData.myController->Update(this, aDeltaTime);
		ApplySteering(controllerOutput.steeringOutput, aDeltaTime);
	}
	else
	{
		OnDeath();
	}
	UpdateAnimation(aDeltaTime);
	PlayEnemyVFX();

	Actor::Update(aDeltaTime);
}

void Enemy::UpdateAbilities(float aDeltaTime)
{
	myAbility->Update(aDeltaTime);
}

void Enemy::ApplySteering(const SteeringOutput& aSteeringOutput, float aDeltaTime)
{
	Tga::Vector3f velocity = aSteeringOutput.velocity;

	if (velocity.LengthSqr() > 0.001f)
	{
		Tga::Vector3f newPosition = GetPosition();

		newPosition += velocity * aDeltaTime;
		std::shared_ptr gameScene = GameWorld::GetInstance().GetCurrentGameScene().lock();
		newPosition += gameScene->CheckStaticCollisions(GetCollider());

		myModel->GetTransform().SetPosition(newPosition);

		AI::PollingStation3D::Get().UpdateActorPos(this, GetPosition());

		RotateTowardsVelocityOrDirection(velocity, aDeltaTime);
	}
}

bool Enemy::TryAttack()
{
	const Tga::Vector3f targetPos = Blackboard::GetInstance()->GetVector3("playerPosition");

	return myAbility->TryActivate(targetPos);
}

bool Enemy::SucceedAttack()
{
	return true;
}

bool Enemy::IsAttacking()
{
	return !myAbility->GetIsCasting();
}

void Enemy::ReceiveEvent([[maybe_unused]] const Message& aMessage)
{
	//switch (aMessage.eventType)
	//{
		//default:
		//{
		//	break;
		//}
	//}
}

void Enemy::ResetWhenPlayerDies()
{
	return;
}

void Enemy::ResetMe()
{
	myMarkedForDelete = false;
	myHealth = myMaxHealth;
	SetPosition(myStartingPos);
	myPath.clear();
	myAnimatedObject.currentAnimation = "Idle"_tgaid;

	dynamic_cast<HumanController*>(myActorData.myController.get())->SetStateIdle();
}

void Enemy::SetPath(const std::vector<Tga::Vector3f>& aPath)
{
	myPath = aPath;

	if (myPath.empty())
	{
		SetAnimation(EnemyStateID::Idle);
	}
}

void Enemy::SetAnimation(EnemyStateID aState)
{
	if (mySelectedAnimation != aState)
	{
		mySelectedAnimation = aState;
	}
	else if (myCurrentAnimationState == Tga::AnimationState::Finished)
	{
		myCurrentAnimation->Stop();
		myCurrentAnimation->Play();
	}
}

void Enemy::ClearPath()
{
	myPath.clear();
}

void Enemy::OnDeath()
{
	myMarkedForDelete = true;

	Message msg{};
	msg.eventType = Event::EnemyDied;
	msg.data = 10;
	EventManager::GetInstance()->SendEventMessage(msg);
}

void Enemy::UpdateAnimation(float aDeltaTime)
{
	if (!myAnimatedObject.model)
	{
		return;
	}

	myCurrentAnimationState = myAnimatedObject.animations[myAnimatedObject.currentAnimation].GetState();
	myCurrentAnimation->Update(aDeltaTime);
	myAnimatedObject.model->SetPose(*myCurrentAnimation);

	bool ready = myCurrentAnimationState == Tga::AnimationState::Finished || myAnimatedObject.animations[myAnimatedObject.currentAnimation].GetIsLooping();

	//Return if the current animation isn't done yet

	if (mySelectedAnimation != EnemyStateID::Death)
	{
		if (!ready)
		{
			return;
		}
	}

	switch (mySelectedAnimation)
	{
	case EnemyStateID::Attack:
	{
		myAnimatedObject.currentAnimation = "Attack"_tgaid;
		break;
	}
	case EnemyStateID::Wander:
	case EnemyStateID::Engage:
	{
		myAnimatedObject.currentAnimation = "Walk"_tgaid;
		break;
	}
	case EnemyStateID::Death:
	{
		myAnimatedObject.currentAnimation = "Death"_tgaid;
		break;
	}
	default:
	{
		myAnimatedObject.currentAnimation = "Idle"_tgaid;
		break;
	}
	}
	//If animation is "stuck", revert to idle
	if (myCurrentAnimationState == Tga::AnimationState::Finished && !myAnimatedObject.animations[myAnimatedObject.currentAnimation].GetIsLooping() && mySelectedAnimation != EnemyStateID::Death)
	{
		mySelectedAnimation = EnemyStateID::Idle;
		myAnimatedObject.currentAnimation = "Idle"_tgaid;
	}

	if (myCurrentAnimation != &myAnimatedObject.animations[myAnimatedObject.currentAnimation])
	{
		if (myCurrentAnimation != nullptr)
		{
			myCurrentAnimation->Stop();
		}

		myCurrentAnimation = &myAnimatedObject.animations[myAnimatedObject.currentAnimation];
		myCurrentAnimation->Play();
	}
}

void Enemy::PlayEnemyVFX()
{
	//if (GetCurrentAnimationID() == "Attack"_tgaid)
	//{
	//	switch (GetActorType())
	//	{
	//		default:
	//		{
	//			break;
	//		}
	//	}
	//}
}