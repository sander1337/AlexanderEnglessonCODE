#pragma once

#include "../Enemy.h"
#include "../EnemyData.h"
#include "Objects/Controller/HumanController.h"


class Human : public Enemy
{
public:
    Human() = default;
    ~Human() override = default;

    void Update(float aDeltaTime) override;
    void Init() override;
    void ApplyProps(const std::vector<Tga::ScenePropertyDefinition>& someProperties) override;

    ActorType GetActorType() const override { return ActorType::Enemy; }
    HumanData& GetData() override;

private:
    float myGruntTimer = 0;
    float myGruntInterval = 10.f;
    HumanData myData;
};