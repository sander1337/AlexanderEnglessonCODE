#include "stdafx.h"
#include "Human.h"

#include "../../../../Utilities/RandomGenerator.h"
#include "../../AbilityCasting/Ability.h"
#include "Objects/Controller/HumanController.h"
#include "Objects/Behaviors/HumanBrainTree.h"
#include "../../AbilityCasting/AttackingAbility.h"

#include <tge/script/CopyOnWriteWrapper.h>
#include <tge/scene/ScenePropertyTypes.h>


void Human::Init()
{
	//myHumanController.Init(this);
	//Enemy::Init();
	myStartingPos = myModel->GetTransform().GetPosition();

	myActorData.myController = std::make_unique<HumanController>();
	myActorData.myController->Init(this);
	myAbility = std::make_unique<AttackingAbility>(shared_from_this(), TargetType::Directional, "Human_Attack", 0.f, 0.0f, myData.attackDmg);
	myGruntTimer = RandomGenerator::GetFloat(0.f, myGruntInterval);
}

void Human::ApplyProps(const std::vector<Tga::ScenePropertyDefinition>& someProperties)
{
	for (auto& property : someProperties)
	{
		if (property.type == Tga::GetPropertyType<Tga::CopyOnWriteWrapper<Tga::EnemyExposed>>())
		{
			myHealth = property.value.Get<Tga::CopyOnWriteWrapper<Tga::EnemyExposed>>()->Get().hp;
			myMaxHealth = property.value.Get<Tga::CopyOnWriteWrapper<Tga::EnemyExposed>>()->Get().hp;
			int attackDmg = property.value.Get<Tga::CopyOnWriteWrapper<Tga::EnemyExposed>>()->Get().enemyAttackDmg;
			attackDmg;
			myData.aggroRange = property.value.Get<Tga::CopyOnWriteWrapper<Tga::EnemyExposed>>()->Get().enemyAggroRange;
			myData.attackInterval = property.value.Get<Tga::CopyOnWriteWrapper<Tga::EnemyExposed>>()->Get().enemyAttackInterval;
			myData.attackRange = property.value.Get<Tga::CopyOnWriteWrapper<Tga::EnemyExposed>>()->Get().enemyAttackRange;
			myData.attackSpeed = property.value.Get<Tga::CopyOnWriteWrapper<Tga::EnemyExposed>>()->Get().enemyAttackSpeed;
			myData.speed = property.value.Get<Tga::CopyOnWriteWrapper<Tga::EnemyExposed>>()->Get().enemySpeed;
			//myAbility = std::make_unique<AttackingAbility>(shared_from_this(), TargetType::Directional, "Human_Attack", 1.f /*/ myData.attackInterval*/, 0.5f, myData.attackDmg);
		}
	}
}

void Human::Update(float aDeltaTime)
{
	Enemy::Update(aDeltaTime);

	if (mySelectedAnimation == EnemyStateID::Death && !myHasTriggeredVFXDeath)
	{
		if (!myAuraVFX.expired())
		{
			myAuraVFX.lock()->JumpToSecondLastKey();
		}
		myHasTriggeredVFXDeath = true;
	}
}

HumanData& Human::GetData()
{
	return myData;
}

