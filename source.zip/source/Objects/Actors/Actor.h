#pragma once
#include <stdafx.h>
#include "../AnimatedObject.h"
#include "ActorData.h"
#include "../GameObject.h"
#include "../../Utilities/SharedFromThis.h"
#include <tge/animation/AnimationPlayer.h>

enum class DamageType : std::uint8_t;
enum class ActorType;

namespace AI
{
	class Controller;
}
namespace Tga
{
	class AnimationPlayer;
	class Texture;
}
enum class ActorType
{
	Player,
	Enemy,

	Count
};


class Actor : public GameObject, public Utilities::EnableSharedFromThis<Actor>
{
public:
	Actor() = default;
	~Actor() override = default;

	void Init() override;
	virtual void ApplyProps([[maybe_unused]] const std::vector<Tga::ScenePropertyDefinition>& someProperties) {}
	void Update(float aDeltaTime) override;

	void SetAnimatedObject(AnimatedObject& aAnimatedObject) override;
	AnimatedObject GetAnimatedObject() override;

	void RotateTowardsVelocityOrDirection(const Tga::Vector3f& aVelocity, float aDeltaTime, float aMaxTurnSpeed = 180.f);
	void InstantRotateTowardsVelocityOrDirection(const Tga::Vector3f& aVelocity);
	void SetShowSeparationCircle(bool show) { ShowSeparationCircle = show; }

	bool GetShowSeparationCircle() const { return ShowSeparationCircle; }
	AI::Controller* GetController();
	ActorData& GetActorData() { return myActorData; }
	virtual ActorType GetActorType() const = 0;
	Tga::AnimationPlayer* GetCurrentAnimation() { return myCurrentAnimation; }
	const Tga::AnimationState& GetCurrentAnimationState() const { return myCurrentAnimationState; }
	const Tga::StringId GetCurrentAnimationID() const { return myAnimatedObject.currentAnimation; }
	bool IsCurrentAnimationFinished();

	const int GetHealth() const { return myHealth; }
	const int GetMaxHealth() const { return myMaxHealth; }
	virtual bool GetIsFullHealth() { return myHealth >= myMaxHealth; }
	virtual void TakeDamage(int someDamage);
	virtual void ReceiveHealing(int someHealth);
	virtual void OnDeath() {};

	std::shared_ptr<Actor> GetAsActor() { return std::dynamic_pointer_cast<Actor>(shared_from_this()); }

	virtual float GetSpeed() const { return 0.f; }

	Tga::Matrix4x4f GetBoneTransformInModelSpace(const std::string& aBoneToFind);


protected:
	int myMaxHealth = 100;
	int myHealth = myMaxHealth;

	bool ShowSeparationCircle = true;

	ActorData myActorData;
	AnimatedObject myAnimatedObject;
	Tga::AnimationState myCurrentAnimationState;
	Tga::AnimationPlayer* myCurrentAnimation = nullptr;
	Tga::AnimationPlayer* myLeftArmAnimation = nullptr;
	Tga::AnimationPlayer* myRightArmAnimation = nullptr;
};