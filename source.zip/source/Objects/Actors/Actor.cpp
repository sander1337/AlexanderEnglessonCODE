#include "stdafx.h"
#include "Actor.h"

#include "magic_enum/magic_enum.hpp"
#include "../source/Utilities/BlackBoard.h"
#include "../source/Audio/AudioManager.h"

#include "../Game/source/Audio/DamagedByType.h"

void Actor::Init()
{
}

void Actor::SetAnimatedObject(AnimatedObject& aAnimatedObject)
{
	myAnimatedObject = aAnimatedObject;
	myCurrentAnimation = &myAnimatedObject.animations[myAnimatedObject.currentAnimation];
}

AnimatedObject Actor::GetAnimatedObject()
{
	return myAnimatedObject;
}

void Actor::Update([[maybe_unused]] float aDeltaTime)
{
	GameObject::Update(aDeltaTime);

	if (myOnlyRunBaseLogic)
	{
		return;
	}	
}

AI::Controller* Actor::GetController()
{
	return myActorData.myController.get();
}

bool Actor::IsCurrentAnimationFinished()
{
	return myCurrentAnimationState == Tga::AnimationState::Finished || myAnimatedObject.animations[myAnimatedObject.currentAnimation].GetIsLooping();
}

void Actor::TakeDamage(int someDamage)
{
	if (myHealth > 0)
	{
		myHealth -= someDamage;
	}

	if (myHealth <= 0)
	{
		OnDeath();
	}
	
}

void Actor::ReceiveHealing(int someHealth)
{
	myHealth += someHealth;
	myHealth = std::min(myHealth, myMaxHealth);
}

void Actor::RotateTowardsVelocityOrDirection(const Tga::Vector3f& aVelocity, float aDeltaTime, float aMaxTurnSpeed)
{
	if (aVelocity.LengthSqr() < 0.0001f)
	{
		return;
	}

	// --- Convert velocity to a yaw angle ---
	float desiredYawDeg = atan2f(aVelocity.x, aVelocity.z) * FMath::RadToDeg;

	// --- Normalize to -180..180 for smooth turning ---
	auto Wrap180 = [](float angle)
		{
			while (angle > 180.0f)
			{
				angle -= 360.0f;
			}

			while (angle < -180.0f)
			{
				angle += 360.0f;
			}

			return angle;
		};

	float deltaYaw = Wrap180(desiredYawDeg - myActorData.currentYawDeg);

	// --- Limit turning speed ---
	float maxTurnThisFrame = aMaxTurnSpeed * aDeltaTime; // degrees per second

	// Clamp how much we can turn this frame
	if (fabs(deltaYaw) > maxTurnThisFrame)
	{
		deltaYaw = (deltaYaw > 0.f) ? maxTurnThisFrame : -maxTurnThisFrame;
	}

	// --- Apply rotation ---
	myActorData.currentYawDeg = Wrap180(myActorData.currentYawDeg + deltaYaw);

	// --- Apply to transform ---
	SetRotation({ 0.f, myActorData.currentYawDeg, 0.f });
}

void Actor::InstantRotateTowardsVelocityOrDirection(const Tga::Vector3f& aVelocity)
{
	if (aVelocity.LengthSqr() < 0.0001f)
	{
		return;
	}

	// --- Convert velocity to yaw angle in degrees ---
	float desiredYawDeg = atan2f(aVelocity.x, aVelocity.z) * FMath::RadToDeg;

	// --- Normalize to -180..180 (optional, keeps rotation consistent) ---
	auto Wrap180 = [](float angle)
		{
			while (angle > 180.0f)
			{
				angle -= 360.0f;
			}

			while (angle < -180.0f)
			{
				angle += 360.0f;
			}

			return angle;
		};

	myActorData.currentYawDeg = Wrap180(desiredYawDeg);

	// --- Apply instantly to transform ---
	SetRotation({ 0.f, myActorData.currentYawDeg, 0.f });
}


Tga::Matrix4x4f Actor::GetBoneTransformInModelSpace(const std::string& aBoneToFind)
{
	const Tga::Skeleton* skeleton = GetModelInstance()->GetModel()->GetSkeleton();

	Tga::ModelSpacePose modelSpace;
	const Tga::LocalSpacePose currentPose = myCurrentAnimation->GetLocalSpacePose();
	skeleton->ConvertPoseToModelSpace(currentPose, modelSpace);

	size_t index = skeleton->JointNameToIndex.find(aBoneToFind)->second;

	if (index > skeleton->JointNameToIndex.size())
	{
		return Tga::Matrix4x4f();
	}

	return modelSpace.JointTransforms[index];

}