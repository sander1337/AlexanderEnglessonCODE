#include "stdafx.h"
#include "GameObject.h"

#include "../Collisions/Narrow/Collider.h"
#include "../Utilities/Blackboard.h"
#include <tge/model/BaseModelInstance.h>
#include <tge/render/EffectMaterial.h>
#include <cassert>

#include "AnimatedObject.h"
#include <tge/script/ScriptRuntimeInstance.h>
#include <tge/script/ScriptManager.h>

void GameObject::Init()
{
    for (auto& components : myComponents | std::views::values)
    {
        for (const auto& component : components) 
        {
			component->Init();
        }
    }
}

void GameObject::SetAnimatedObject(AnimatedObject& /*unused*/)
{
}

AnimatedObject GameObject::GetAnimatedObject()
{
    return {};
}

void GameObject::OnCollision(const std::shared_ptr<Collider>& /*unused*/)
{
}

void GameObject::SetModelInstance(const std::shared_ptr<BaseModelInstance>& aModelInstance)
{
    myModel = aModelInstance;
}

void GameObject::SetPosition(const Tga::Vector3f& aPosition) const
{
    if (myModel)
    {
        myModel->GetTransform().SetPosition(aPosition);
    }
    else if (mySprite3DInstanceData)
    {
        mySprite3DInstanceData->myTransform.SetPosition(aPosition);
    }

  //  INFO_PRINT("Setting Position of GameObject that has no model or sprite");
}

void GameObject::SetRotation(const Tga::Vector3f& aRotation) const
{
    if (myModel)
        myModel->GetTransform().SetRotation(aRotation);
}

void GameObject::SetScale(const Tga::Vector3f& aScale)
{
    myScale = aScale;
}

void GameObject::SetTransform(const Tga::Matrix4x4f& aTransform) const
{
    if (myModel)
    {
        myModel->SetTransform(aTransform);
    }
    else if (mySprite3DInstanceData)
    {
        mySprite3DInstanceData->myTransform = aTransform;
    }

   // INFO_PRINT("Trying to set transform of GameObject that has no model or sprite");
}

void GameObject::SetShouldRender(const bool aShouldRender)
{
    myShouldRender = aShouldRender;
}

void GameObject::SetTag(Tga::Tag aTag)
{
    myTag = aTag;
}

void GameObject::SetEffectMaterial(const std::shared_ptr<EffectMaterial>& aEffectMaterial)
{
    myEffectMaterial = aEffectMaterial;
}

void GameObject::Set3DSpriteInstance(const std::shared_ptr<Tga::Sprite3DInstanceData>& aSprite)
{
    mySprite3DInstanceData = aSprite;
}

void GameObject::SetSpriteSharedData(const std::shared_ptr<Tga::SpriteSharedData>& aSpriteSharedData)
{
    mySharedData = aSpriteSharedData;
}

void GameObject::SetRenderType(const RenderType aRenderType)
{
    myRenderType = aRenderType;
}

void GameObject::CreateCollider(const std::shared_ptr<Collider>& aCollider)
{
    myCollider = aCollider;
}

Tga::Vector3f GameObject::GetPosition()
{
    if (myModel)
    {
        return myModel->GetTransform().GetPosition();
    }

	if (mySprite3DInstanceData)
    {
        return mySprite3DInstanceData->myTransform.GetPosition();
    }

    INFO_PRINT("Trying to return position of GameObject that has no model or sprite");

    return { 0,0,0 };
}

Tga::Vector3f GameObject::GetPosition() const
{
    if (myModel)
    {
        return myModel->GetTransform().GetPosition();
    }
    if (mySprite3DInstanceData)
    {
        return mySprite3DInstanceData->myTransform.GetPosition();
    }

    INFO_PRINT("Trying to return position of GameObject that has no model or sprite");
    return { 0,0,0 };
}

std::shared_ptr<BaseModelInstance> GameObject::GetModelInstance()
{
    return myModel;
}

const std::shared_ptr<BaseModelInstance> GameObject::GetModelInstance() const
{
    return myModel;
}

Tga::SpriteSharedData* GameObject::GetSpriteSharedData()
{
    return mySharedData.get();
}

const Tga::SpriteSharedData* GameObject::GetSpriteSharedData() const
{
    return mySharedData.get();
}

std::shared_ptr<Tga::Sprite3DInstanceData>& GameObject::Get3DSpriteInstance()
{
    return mySprite3DInstanceData;
}

const std::shared_ptr<Tga::Sprite3DInstanceData>& GameObject::Get3DSpriteInstance() const
{
    return mySprite3DInstanceData;
}

const Tga::Matrix4x4f& GameObject::GetTransform() const
{
    if (myModel)
    {
        return myModel->GetTransform();
    }
    if (mySprite3DInstanceData)
    {
	    return mySprite3DInstanceData->myTransform;
    }

    INFO_PRINT("Trying to return transform of GameObject that has no model or sprite");
    static Tga::Matrix4x4f const dummy = Tga::Matrix4x4f::CreateIdentityMatrix();
    return dummy;
}

const std::shared_ptr<Collider>& GameObject::GetCollider()
{
    return myCollider;
}

bool GameObject::GetShouldRender() const
{
    return myShouldRender;
}

Tga::Tag GameObject::GetTag() const
{
    return myTag;
}

const std::shared_ptr<EffectMaterial>& GameObject::GetEffectMaterial()
{
    return myEffectMaterial;
}

const std::shared_ptr<EffectMaterial>& GameObject::GetEffectMaterial() const
{
    return myEffectMaterial;
}

bool GameObject::GetMarkedForDelete() const
{
    return myMarkedForDelete;
}

RenderType GameObject::GetRenderType() const
{
    return myRenderType;
}

void GameObject::SetTerrain(bool abool)
{
    isTerrain = abool;
}

bool GameObject::GetIsTerrain()
{
    return isTerrain;
}

void GameObject::Update([[maybe_unused]] float aDeltaTime)
{
    if (!IsWithinUpdateRange())
    {
        myOnlyRunBaseLogic = true;
        return;
    }

    myOnlyRunBaseLogic = false;

    for (auto& pair : myComponents)
    {
        for (auto& component : pair.second)
        {
            component->Update(aDeltaTime);
        }
    }
}

void GameObject::DebugRender()
{
    if (myCollider)
    {
        myCollider->DebugRender();
    }
}

void GameObject::ResetMe()
{
}

bool GameObject::IsWithinUpdateRange()
{
    constexpr float updateRange = 3000.f;

    Tga::Vector3f playerPosition = Blackboard::GetInstance()->GetVector3("playerPosition");

    float distanceSqr = (playerPosition - GetPosition()).LengthSqr();

    return distanceSqr < updateRange * updateRange;
}





