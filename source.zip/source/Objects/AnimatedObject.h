#pragma once
//#pragma message(__FILE__" was compiled")
#include <tge/animation/AnimationPlayer.h>
#include <tge/stringRegistry/StringRegistry.h>

namespace Tga
{
	class AnimatedModelInstance;
}

struct AnimatedObject
{
	Tga::BlendState blendState;
	std::shared_ptr <Tga::AnimatedModelInstance> model = nullptr;
	std::unordered_map<Tga::StringId, Tga::AnimationPlayer> animations;

	Tga::StringId currentAnimation = {};
	Tga::StringId previousState = {};

	float blendValue = 1.f;
	float blendSpeed = 3.f;

	void SetAnimationWithBlending(const Tga::StringId aAnimation, const float aBlendValue, const float aBlendSpeed)
	{
		if (currentAnimation == aAnimation)
		{
			return;
		}

		previousState = currentAnimation;
		currentAnimation = aAnimation;
		animations[currentAnimation].Play();

		blendValue = aBlendValue;
		blendSpeed = aBlendSpeed;
	}
};