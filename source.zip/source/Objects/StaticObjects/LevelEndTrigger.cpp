#include "stdafx.h"
#include "LevelEndTrigger.h"

#include <Collisions/Narrow/Collider.h>
#include <Events/EventManager.h>
#include <SceneManagement/SceneID.h>


LevelEndTrigger::LevelEndTrigger(const Tga::TriggerData& aFromEditorData) 
{
	switch (aFromEditorData.levelEnd.level)
	{
		case 1:
		{
			myNextLevelID = SceneID::Level1;
			break;
		}
		case 2:
		{
			myNextLevelID = SceneID::Level2;
			break;
		}
		case 3:
		{
			myNextLevelID = SceneID::EndScreen;
			break;
		}
		default:
		{
			myNextLevelID = SceneID::Count;
			break;
		}
	}
}

void LevelEndTrigger::OnCollision(const std::shared_ptr<Collider>& anOther)
{
	if (anOther->GetOwner()->GetTag() == Tga::Tag::Player)
	{
		Message message;

		message.eventType = Event::SwitchLevel;
		message.data = myNextLevelID;

		EventManager::GetInstance()->SendEventMessage(message);
	}
}
