#pragma once
#include "../GameObject.h"
#include "../AnimatedObject.h"

class GameScene;

class DestructibleObject : public GameObject
{
public:
	DestructibleObject();
	~DestructibleObject() override = default;

	void Init() override;
	void Update(float aDeltaTime) override;
	void ResetMe() override;

	void TakeDamage(int someDamage);

	void SetAnimatedObject(AnimatedObject& aAnimatedObject) override;
private:
	void SetAnimatedModel();
	void SetStaticModel();

private:
	AnimatedObject myAnimatedObject;
	//Tga::AnimationState myCurrentAnimationState;
	int myHealth = 1;
	bool myIsDestroyed = false;
	bool myHasPlayedAudio = false;
	float stayAfterDestroyedTimer = 2.f;
};