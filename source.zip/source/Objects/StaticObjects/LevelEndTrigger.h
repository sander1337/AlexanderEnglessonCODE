#pragma once
//#pragma message(__FILE__" was compiled")
#include "../GameObject.h"
#include <SceneManagement/SceneID.h>

class LevelEndTrigger : public GameObject
{
public:
	
	LevelEndTrigger() = default;
	LevelEndTrigger(const Tga::TriggerData& aFromEditorData);
	~LevelEndTrigger() override = default;

	void OnCollision(const std::shared_ptr<Collider>& anOther) override;

private:
	SceneID myNextLevelID;
};

