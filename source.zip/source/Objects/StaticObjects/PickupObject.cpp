#include "stdafx.h"
#include "PickupObject.h"
#include <Input/InputMapper.h>
#include <tge/input/InputManager.h>
#include <tge/model/AnimatedModelInstance.h>
#include <tge/model/ModelInstance.h>
#include <tge/model/ModelFactory.h>
#include <tge/shaders/ModelShader.h>
#include <SceneManagement/GameScene.h>
#include <Audio/AudioManager.h>
#include <Utilities/ConstantIdentifiers.h>
#include "../Actors/Actor.h"


PickupObject::PickupObject(const Tga::PickUpData& aPropsData) : myType(aPropsData.pickUpType)
{

}

void PickupObject::Init()
{
	myYRotaion = 0;
}

void PickupObject::Update(float aDeltaTime)
{
	float speed = 150.f;
	myYRotaion += speed * aDeltaTime; // degrees per second (adjust speed)
	if (myYRotaion >= 360.0f)
	{
		myYRotaion -= 360.0f;
	}

	Tga::Matrix4x4f transform = GetTransform();
	transform.SetRotation({ 0.0f, myYRotaion, 0.0f });
	SetTransform(transform);

	if (myIsDestroyed)
	{
		Message msg{};
		msg.eventType = Event::PickUp;
		msg.data = myType;
		EventManager::GetInstance()->SendEventMessage(msg);

		myMarkedForDelete = true;
	}
}

void PickupObject::TakeDamage(int someDamage)
{
	if (myHealth > 0)
	{
		myHealth -= someDamage;
	}
	else
	{
		if (!myHasPlayedAudio)
		{
			//AudioManager::GetInstance()->PlayOneShotAudio(AudioConstExpr::SFX_DESTRUCTIBLE, this->GetTransform());
			myHasPlayedAudio = true;
		}

		//SetAnimatedModel();
		myIsDestroyed = true;
	}
}

void PickupObject::SetStaticModel()
{
	std::shared_ptr<Tga::ModelInstance> instance = Tga::ModelFactory::GetInstance().GetModelInstance(myModel->GetModel()->GetPath());

	instance->SetTransform(GetTransform());

	SetRenderType(RenderType::Model);
	SetModelInstance(instance);
	myModel = instance;
}

void PickupObject::ResetMe()
{
	myHealth = 1;
	myHasPlayedAudio = false;
	myIsDestroyed = false;
	SetStaticModel();
}