#pragma once
//#pragma message(__FILE__" was compiled")
#include "../GameObject.h"

namespace Tga
{
	enum class ScriptedEventType : std::uint8_t;
}

class ScriptedEventTrigger : public GameObject
{
public:
	ScriptedEventTrigger() = default;
	ScriptedEventTrigger(const Tga::TriggerData& aFromEditorData);
	~ScriptedEventTrigger() override = default;

	void SetEvent(Tga::ScriptedEventType aScriptedEvent) { myScriptedEvent = aScriptedEvent; }

	//void Update(float aDeltaTime) override;
	void OnCollision(const std::shared_ptr<Collider>& anOther) override;

private:

	Tga::ScriptedEventType myScriptedEvent;
};