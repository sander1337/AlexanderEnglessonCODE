#pragma once
#include "../GameObject.h"
#include "../AnimatedObject.h"
#include <tge/scene/ScenePropertyTypes.h>

class GameScene;

class PickupObject : public GameObject
{
public:
	PickupObject(const Tga::PickUpData& aPropsData);
	~PickupObject() override = default;

	void Init() override;
	void Update(float aDeltaTime) override;
	void ResetMe() override;

	void TakeDamage(int someDamage);

private:
	void SetStaticModel();

private:
	int myHealth = 1;
	bool myIsDestroyed = false;
	bool myHasPlayedAudio = false;
	float stayAfterDestroyedTimer = 2.f;
	float myYRotaion = 0;

	Tga::PickUpType myType;
};