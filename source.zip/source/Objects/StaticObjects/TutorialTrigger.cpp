#include "stdafx.h"
#include "TutorialTrigger.h"

#include <Collisions/Narrow/Collider.h>
#include <Events/EventManager.h>
#include <memory>

TutorialTrigger::TutorialTrigger(const Tga::TriggerData& aFromEditorData)
    : myLifeTime(aFromEditorData.tutorial.lifeTime)
    , myFadeTime(aFromEditorData.tutorial.fadeTime)
    , myTutorialSceneID(SceneIDFromTutorialType(aFromEditorData.tutorial.tutorialType))
    , mySteps(aFromEditorData.tutorial.steps) 
{
}

void TutorialTrigger::OnCollision(const std::shared_ptr<Collider>& anOther)
{
    if (myIsTriggered)
        return;

    if (anOther && anOther->GetOwner() && anOther->GetOwner()->GetTag() == Tga::Tag::Player)
    {
        myIsTriggered = true;

        // Start first step
        if (!mySteps.empty())
        {
            myStepIndex = 0;
            myStepTimeLeft = mySteps[0].duration;
            SendTopText(mySteps[0].text);
        }
        else
        {
            // No steps in editor => clear just in case
            myStepIndex = -1;
            myStepTimeLeft = 0.f;
            SendTopText("");
        }
    }
}

void TutorialTrigger::Update(float aDeltaTime)
{
    if (!myIsTriggered)
        return;

    // Nothing to play
    if (myStepIndex < 0 || myStepIndex >= (int)mySteps.size())
        return;

    myStepTimeLeft -= aDeltaTime;
    if (myStepTimeLeft > 0.f)
        return;

    // Advance to next step
    ++myStepIndex;

    if (myStepIndex >= (int)mySteps.size())
    {
        // Finished all steps => reset/clear
        myStepIndex = -1;
        myStepTimeLeft = 0.f;
        SendTopText("");
        return;
    }

    myStepTimeLeft = mySteps[myStepIndex].duration;
    SendTopText(mySteps[myStepIndex].text);
}

SceneID TutorialTrigger::SceneIDFromTutorialType(Tga::TutorialType /*aTutorialType*/)
{
    return SceneID::Count;
}

void TutorialTrigger::SendTopText(const std::string& text)
{
    Message msg{};
    msg.eventType = Event::TopTextChange;
    msg.data = text; // std::string i variant/any
    EventManager::GetInstance()->SendEventMessage(msg);
}