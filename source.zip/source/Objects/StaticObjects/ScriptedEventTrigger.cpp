#include "stdafx.h"
#include "ScriptedEventTrigger.h"
#include <Events/EventManager.h>
#include <tge/Scene/ScenePropertyTypes.h>
#include <Collisions/Narrow/Collider.h>

#include <Audio/AudioManager.h>
#include <Utilities/ConstantIdentifiers.h>
#include <SceneManagement/SceneID.h>
#include "Utilities/BlackBoard.h"

ScriptedEventTrigger::ScriptedEventTrigger(const Tga::TriggerData& aFromEditorData) : myScriptedEvent(aFromEditorData.scriptedEvent.event)
{
}

void ScriptedEventTrigger::OnCollision(const std::shared_ptr<Collider>& anOther)
{
	if (anOther->GetOwner()->GetTag() == Tga::Tag::Player)
	{
		Message message;
		message.eventType = Event::PlayScriptedEvent;
		message.data = myScriptedEvent;


		EventManager::GetInstance()->SendEventMessage(message);
		myMarkedForDelete = true;
	}
}