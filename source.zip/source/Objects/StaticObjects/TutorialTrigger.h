#pragma once
//#pragma message(__FILE__" was compiled")
#include "../GameObject.h"
#include <tge/scene/ScenePropertyTypes.h>
#include <SceneManagement/SceneID.h>

class TutorialTrigger : public GameObject
{
public:
    TutorialTrigger() = default;
    TutorialTrigger(const Tga::TriggerData& aFromEditorData);
    ~TutorialTrigger() override = default;

    void Update(float aDeltaTime) override;
    void OnCollision(const std::shared_ptr<Collider>& anOther) override;

private:
    SceneID SceneIDFromTutorialType(Tga::TutorialType aTutorialType);
    void SendTopText(const std::string& text);

    float myLifeTime = 3.f;
    float myFadeTime = 0.5f;
    float myCurrentTime = 0.f;
    bool myIsTriggered = false;
    SceneID myTutorialSceneID = SceneID::Count;

    // NEW: data from editor
    std::vector<Tga::TutorialStepData> mySteps;
    int myStepIndex = -1;
    float myStepTimeLeft = 0.f;
};