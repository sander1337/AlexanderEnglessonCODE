#include "stdafx.h"
#include "DestructibleObject.h"
#include <Input/InputMapper.h>
#include <tge/input/InputManager.h>
#include <tge/model/AnimatedModelInstance.h>
#include <tge/model/ModelInstance.h>
#include <tge/model/ModelFactory.h>
#include <tge/shaders/ModelShader.h>
#include <SceneManagement/GameScene.h>
#include <Audio/AudioManager.h>
#include <Utilities/ConstantIdentifiers.h>
#include "../Actors/Actor.h"


DestructibleObject::DestructibleObject()
{
}

void DestructibleObject::Init()
{
}

void DestructibleObject::Update(float aDeltaTime)
{
	if (myIsDestroyed)
	{
		if (!myAnimatedObject.model->IsValid())
		{
			return;
		}
		// this is only temporary. We need to decide how we should set the animations. 
		// We could set object type in init and then have a switch case in here to set the animation.
		if (myAnimatedObject.currentAnimation != "destroyed"_tgaid)
		{
			myAnimatedObject.currentAnimation = "destroyed"_tgaid;
			myAnimatedObject.animations[myAnimatedObject.currentAnimation] = Tga::ModelFactory::GetInstance().GetAnimationPlayer("assets/environment/TempBreakables/Totem/TotemArmature@Destruction.fbx", myAnimatedObject.model->GetModel());
			myAnimatedObject.animations[myAnimatedObject.currentAnimation].SetIsLooping(false);
			myAnimatedObject.animations[myAnimatedObject.currentAnimation].Play();
			if (!myAnimatedObject.animations[myAnimatedObject.currentAnimation].GetAnimation())
			{
				std::cout << "Failed to load animation\n";
			}
		}
		myAnimatedObject.animations[myAnimatedObject.currentAnimation].Update(aDeltaTime);
		if (myAnimatedObject.model)
		{
		myAnimatedObject.model->SetPose(myAnimatedObject.animations[myAnimatedObject.currentAnimation]);
			myModel = myAnimatedObject.model;
		}
		else
		{
			myModel = nullptr;
		}

		stayAfterDestroyedTimer -= aDeltaTime;

		bool ready = myAnimatedObject.animations[myAnimatedObject.currentAnimation].GetState() == Tga::AnimationState::Finished;
		if (ready && stayAfterDestroyedTimer <= 0)
		{
			myMarkedForDelete = true;
		}
	}
}

void DestructibleObject::TakeDamage(int someDamage)
{
	if (myHealth > 0)
	{
		myHealth -= someDamage;

		if (myHealth < 0)
		{
			if (!myHasPlayedAudio)
			{
				//AudioManager::GetInstance()->PlayOneShotAudio(AudioConstExpr::SFX_DESTRUCTIBLE, this->GetTransform());
				myHasPlayedAudio = true;
			}
			SetAnimatedModel();
			myIsDestroyed = true;
		}
	}
}

void DestructibleObject::SetAnimatedObject(AnimatedObject& aAnimatedObject)
{
	myAnimatedObject = aAnimatedObject;
}

void DestructibleObject::SetAnimatedModel()
{
	if (myAnimatedObject.model)
	{
		return;
	}
	auto newInstance = Tga::ModelFactory::GetInstance().GetAnimatedModelInstance(myModel->GetModel()->GetPath());

	newInstance->CopyTexturesFromModelToModel(myModel);

	newInstance->SetTransform(myModel->GetTransform());
	myAnimatedObject.model = std::dynamic_pointer_cast<Tga::AnimatedModelInstance>(newInstance);
	myModel = newInstance;
}

void DestructibleObject::SetStaticModel()
{
	std::shared_ptr<Tga::ModelInstance> instance = Tga::ModelFactory::GetInstance().GetModelInstance(myModel->GetModel()->GetPath());

	instance->SetTransform(GetTransform());

	SetRenderType(RenderType::Model);
	SetModelInstance(instance);
	myModel = instance;
}

void DestructibleObject::ResetMe()
{
	myHealth = 1;
	myHasPlayedAudio = false;
	myIsDestroyed = false;
	SetStaticModel();
}