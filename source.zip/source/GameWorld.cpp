#include "stdafx.h"
#include "GameWorld.h"

#include "Render/RenderManager.h"
#include "SceneManagement/SceneManager.h"
#include "States/InGame.h"
#include "Audio/AudioManager.h"
#include "SceneManagement/GameScene.h"

using namespace Tga;

GameWorld* GameWorld::myInstance = nullptr;

GameWorld::GameWorld()
{
    if (myInstance == nullptr)
    {
        myInstance = this;
    }
}

GameWorld::~GameWorld()
{
    if (myInstance == this)
    {
        myInstance = nullptr;
    }
}

void GameWorld::Init(const char* aPath)
{
    mySceneManager = std::make_shared<SceneManager>();
    myRenderManager = std::make_shared<RenderManager>();

    {
        mySceneManager->Init();
        AudioManager::GetInstance()->Init();
    }

    myRenderManager->Init();
    
    const SceneID sceneToLoad = mySceneManager->ReturnSceneID(aPath);
    myStateStack.Init(sceneToLoad, mySceneManager, myRenderManager);
}

void GameWorld::Update([[maybe_unused]] float aDeltaTime)
{
    if (!myStateStack.empty())
    {
        Tga::Camera* gameSceneCamera = nullptr;
        if (myStateStack.GetCurrentState()->GetID() == StateID::InGame)
        {
            gameSceneCamera = myStateStack.GetCurrentState()->GetActiveCamera().get();
        }

        AudioManager::GetInstance()->Update(gameSceneCamera);
        myStateStack.Update(aDeltaTime);
        UpdateImGui();
    }
}

void GameWorld::Render()
{
    if (myStateStack.empty())
    {
        PostQuitMessage(0);
    }
    myStateStack.Render();
}

std::weak_ptr<GameScene> GameWorld::GetCurrentGameScene() const
{
	return std::dynamic_pointer_cast<GameScene>(myStateStack.GetState(StateID::InGame)->GetScene().lock());
}

std::weak_ptr<RunTimeScene> GameWorld::GetCurrentScene() const
{
    return myStateStack.GetCurrentState()->GetScene();
}

std::weak_ptr<SceneManager> GameWorld::GetSceneManager() const
{
    return mySceneManager;
}

std::weak_ptr<RenderManager> GameWorld::GetRenderManager() const
{
	return myRenderManager;
}

const StateStack* GameWorld::GetStateStack() const
{
    return &myStateStack;
}

void GameWorld::UpdateImGui()
{
#ifndef _RETAIL

	ImGui::SetNextWindowSize(ImVec2(900, 600), ImGuiCond_FirstUseEver);

    if (!ImGui::Begin("Debug Menu", nullptr, ImGuiWindowFlags_NoCollapse))
    {
        ImGui::End();
        return;
    }

    // Sidebar selection
    static int selectedSection = 0;
    const char* sections[] = { "Enemies", "Camera", "Lights", "Level Select", "Player", "PostProcessing", "DebugDrawing", "Settings" };

    const float leftPanelWidth = 150.0f;
    const float spacing = 6.0f;

    // --- Left Panel (sidebar)
    ImGui::BeginChild("LeftPanel", ImVec2(leftPanelWidth, 0), true, ImGuiWindowFlags_NoScrollWithMouse);
    {
        for (int i = 0; i < IM_ARRAYSIZE(sections); ++i)
        {
            if (ImGui::Selectable(sections[i], selectedSection == i))
                selectedSection = i;
        }
    }
    ImGui::EndChild();

    ImGui::SameLine(0.0f, spacing);

    // Right side: dynamic content
    ImGui::BeginChild("RightPanel", ImVec2(0, 0), true);
    {
        switch (selectedSection)
        {
        case 0: myImGuiDebug.DrawEnemiesTab(); break;
        case 1: myImGuiDebug.DrawCameraTab(myStateStack); break;
        case 2: myImGuiDebug.DrawLightsTab(*myRenderManager, myStateStack); break;
        case 3: myImGuiDebug.DrawLevelSelectTab(myStateStack); break;
        case 4: myImGuiDebug.DrawPlayerTab(myStateStack); break;
        case 5: myImGuiDebug.DrawPostProcessingTab(*myRenderManager); break;
        case 6: myImGuiDebug.DrawDebugDrawingTab(*myRenderManager); break;
        case 7: myImGuiDebug.DrawOptions(*myRenderManager); break;
        }
    }
    ImGui::EndChild();

    ImGui::End();
#endif
}

std::weak_ptr<GameObject> GameWorld::LoadAssetToScene(const Tga::StringId& anObjectID, const Tga::Matrix4x4f& aMatrix, bool aMarkForAdd)
{
    return mySceneManager->LoadAssetToScene(GetCurrentGameScene().lock(), anObjectID, aMatrix, aMarkForAdd);
}