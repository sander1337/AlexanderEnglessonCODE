#pragma once
#include "RenderCommand.h"
#include <vector>

namespace Tga
{
	class GraphicsStateStack;
}

namespace NCE
{

    class RenderCommandExecutor
    {
    public:
        static void Execute(const NCE::RenderCommand& aCmd, Tga::GraphicsStateStack& aGraphicsStateStack);
        static void ExecuteBatch(const std::vector<NCE::RenderCommand>& someCommands, Tga::GraphicsStateStack& aGraphicsStateStack);
    };
}
