#include "stdafx.h"
#include "FrustumCuller.h"
#include "tge/graphics/Camera.h"
#include <tge/model/model.h>

using namespace Tga;


void FrustumCuller::UpdateFrustum(const Tga::Camera* aCamera)
{
    if (aCamera == nullptr) return;

    const auto& projection{ aCamera->GetProjection() };
    const auto& cameraToWorld{ aCamera->GetTransform() };
    float nearPlane{};
    float farPlane{};
    aCamera->GetFrustumPlanes(nearPlane, farPlane);

    Vector3f nearTopLeft;
    Vector3f nearTopRight;
    Vector3f nearBottomLeft;
    Vector3f nearBottomRight;
    Vector3f farTopLeft;
    Vector3f farTopRight;
    Vector3f farBottomLeft;
    Vector3f farBottomRight;

    if (aCamera->GetProjectionType() == Camera::ProjectionType::Perspective)
    {
        Vector3f topLeftCorner{ -1.f / projection(1, 1), 1.f / projection(2, 2), 1.f };
        topLeftCorner.Normalize();

        Vector3f bottomRightCorner{ 1.f / projection(1, 1), -1.f / projection(2, 2), 1.f };
        bottomRightCorner.Normalize();

        Vector3f topRightCorner{ 1.f / projection(1, 1), 1.f / projection(2, 2), 1.f };
        topRightCorner.Normalize();

        Vector3f bottomLeftCorner{ -1.f / projection(1, 1), -1.f / projection(2, 2), 1.f };
        bottomLeftCorner.Normalize();

        nearTopLeft = nearPlane * topLeftCorner * cameraToWorld;
        nearBottomRight = nearPlane * bottomRightCorner * cameraToWorld;
        nearTopRight = nearPlane * topRightCorner * cameraToWorld;
        nearBottomLeft = nearPlane * bottomLeftCorner * cameraToWorld;

        farTopLeft = farPlane * topLeftCorner * cameraToWorld;
        farBottomRight = farPlane * bottomRightCorner * cameraToWorld;
        farTopRight = farPlane * topRightCorner * cameraToWorld;
        farBottomLeft = farPlane * bottomLeftCorner * cameraToWorld;
    }
    else
    {
        float left{};
        float right{};
        float top{};
        float bottom{};
       
        aCamera->GetOrthoExtent(left, right, bottom, top);
        const Vector3f camPos{ cameraToWorld.GetPosition() };
        const Vector3f forward{ cameraToWorld.GetForward() };
        const Vector3f rightV{ cameraToWorld.GetRight() };
        const Vector3f upV{ cameraToWorld.GetUp() };

        nearTopLeft = camPos + forward * nearPlane + left * rightV + top * upV;
        nearTopRight = camPos + forward * nearPlane + right * rightV + top * upV;
        nearBottomLeft = camPos + forward * nearPlane + left * rightV + bottom * upV;
        nearBottomRight = camPos + forward * nearPlane + right * rightV + bottom * upV;

        farTopLeft = camPos + forward * farPlane + left * rightV + top * upV;
        farTopRight = camPos + forward * farPlane + right * rightV + top * upV;
        farBottomLeft = camPos + forward * farPlane + left * rightV + bottom * upV;
        farBottomRight = camPos + forward * farPlane + right * rightV + bottom * upV;
    }

    {
        
        myFrustum.left.pos = { nearTopLeft };
        myFrustum.left.normal = (nearTopLeft - farTopLeft).Cross(nearTopLeft - nearBottomLeft).GetNormalized();
        myFrustum.right.pos = { nearTopRight };
        myFrustum.right.normal = (nearBottomRight - nearTopRight).Cross(farTopRight - nearTopRight).GetNormalized();
        myFrustum.top.pos = { nearTopLeft };
        myFrustum.top.normal = (nearTopRight - nearTopLeft).Cross(farTopLeft - nearTopLeft).GetNormalized();
        myFrustum.bottom.pos = { nearBottomLeft };
        myFrustum.bottom.normal = (farBottomRight - nearBottomRight).Cross(nearBottomRight - nearBottomLeft).GetNormalized();
        myFrustum.nearPlane.pos = { nearBottomLeft };
        myFrustum.nearPlane.normal = (nearBottomRight - nearBottomLeft).Cross(nearTopRight - nearBottomRight).GetNormalized();
        myFrustum.farPlane.pos = { farBottomLeft };
        myFrustum.farPlane.normal = (farTopRight - farBottomRight).Cross(farBottomRight - farBottomLeft).GetNormalized();
    }

#ifndef _RETAIL
    myNearTl = nearTopLeft;
    myNearTR = nearTopRight;
    myNearBL = nearBottomLeft;
    myNearBR = nearBottomRight;

    myFarTL = farTopLeft;
    myFarTR = farTopRight;
    myFarBL = farBottomLeft;
    myFarBR = farBottomRight;
#endif
}

bool FrustumCuller::CheckBounds(const Matrix4x4f& aMatrix, const float aMaxScale, const Model& aModel) const
{
    const int meshCount{ static_cast<int>(aModel.GetMeshCount()) };
    for (int i = 0; i < meshCount; ++i)
    {
        const BoxSphereBounds& bounds{ aModel.GetMeshData(i).Bounds };
        Vector3f transformedCenter = bounds.Center * aMatrix;

        if (CheckFrustum(transformedCenter, aMaxScale * bounds.Radius))
        {
            return true;
        }
    }

    //Engine::GetDebugDrawer().DrawSphere(transformedCenter, radius);

    return false;
}

bool FrustumCuller::CheckFrustum(const Vector3f& aCenter, const float aRadius) const
{
    if (myFrustum.top.normal.Dot(aCenter - myFrustum.top.pos) <= -aRadius)
    {
        return false;
    }
    if (myFrustum.right.normal.Dot(aCenter - myFrustum.right.pos) <= -aRadius)
    {
        return false;
    }
    if (myFrustum.bottom.normal.Dot(aCenter - myFrustum.bottom.pos) <= -aRadius)
    {
        return false;
    }
    if (myFrustum.left.normal.Dot(aCenter - myFrustum.left.pos) <= -aRadius)
    {
        return false;
    }
    if (myFrustum.nearPlane.normal.Dot(aCenter - myFrustum.nearPlane.pos) <= -aRadius)
    {
        return false;
    }
    if (myFrustum.farPlane.normal.Dot(aCenter - myFrustum.farPlane.pos) <= -aRadius)
    {
        return false;
    }

    return true;
}