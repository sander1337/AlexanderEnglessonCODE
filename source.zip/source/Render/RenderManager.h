#pragma once
//#pragma message(__FILE__" was compiled")
#include "FrustumCuller.h"
#include "GBuffer.h"
#include "PostProcessingValues.h"
#include "../Game/source/Input/InputMapper.h"
#include <tge/graphics/Camera.h>
#include <tge/Graphics/DepthBuffer.h>
#include <tge/graphics/RenderTarget.h>
#include "RenderData.h"
#include "RenderResources.h"
#include "../Graphics/VFXinfo.h"

#include <tge/drawers/ModelDrawer.h>
#include <tge/graphics/GraphicsEngine.h>
#include <tge/scene/Scene.h>

class BaseModelInstance;
class GameObject;
class MenuScene;
class SpawnedObject;

namespace Tga
{
	class ModelInstance;
	class AmbientLight;
	class DirectionalLight;
	class GraphicsStateStack;
	class SpotLight;
	class PointLight;
}

class GameScene;


enum class RenderMode
{
	Final,
	Albedo,
	WorldPosition,
	Normals,
	Material,
	Fx,
	Count,
};

//struct SortedObject
//{
//	RenderType renderType;
//	float distanceToCamera;
//	// Mesh:
//	const BaseModelInstance* model = nullptr;
//	Tga::Matrix4x4f modelTransform;
//	// Sprite:
//	const Tga::SpriteSharedData* sharedData = nullptr;
//	Tga::Sprite3DInstanceData* sprite = nullptr;
//	Tga::Vector4f color;
//	VFXInstanceData vfxInstanceData;
//	EffectMaterial* effectMaterial = nullptr;
//	bool isVFX = true;
//	Tga::RasterizerState rasterizerStat;
//	Tga::BlendState blendState;
//
//};

//struct RenderData
//{
//	Tga::DepthBuffer shadowMap;
//	Tga::RenderTarget intermediateTexture;
//	Tga::RenderTarget waterLayer;
//	std::vector<Tga::RenderTarget> postProcessRenderTargets;
//	std::shared_ptr<Tga::DirectionalLight> directionalLight;
//	std::shared_ptr<Tga::AmbientLight> ambientLight;
//	//std::vector<std::shared_ptr<Tga::SpotLight>> spotLights;
//	std::vector<std::shared_ptr<Tga::PointLight>> pointlights;
//	std::unordered_map<Tga::StringId, Tga::SpriteSharedData> mySpriteSharedData;
//	std::unordered_map<Tga::StringId, std::unique_ptr<Tga::SpriteShader>> mySpriteShaders;
//	std::vector<SortedObject> sortedPostGBufferList;
//	PostProcessingValues postProcessingValues;
//
//	unsigned int shadowMapResolution = 2048;
//	float shadowMapScale = 3000.f;
//
//};


class RenderManager : public InputObserver
{
public:
	RenderManager() = default;
	~RenderManager() override = default;

	void Init(bool aInGame = true/*, Tga::LightPreviewSettings* someSettings = nullptr*/);
	void SetupLights(/*Tga::LightPreviewSettings* someSettings = nullptr*/);
	void SetupShadowSettings();
	void SetupRenderTargets(const Tga::Vector2ui& aResolution);

	// Build render command lists from a game scene or editor scene
	// This function translates GameObjects into pure rendering data
	NCE::RenderData BuildRenderDataFromScene(GameScene& aGameScene);

	// Execute the full render pipeline using pre-built render data
	// This function is modular and can be called by both game and editor
	void ExecuteRenderPipeline(const NCE::RenderData& renderData, Tga::DepthBuffer* aDepthBuffer = nullptr, bool aRenderToBackBuffer = true);

	void RenderScene(GameScene& aGameScene, bool aShowHudEditGrid = false);
	void RenderScene(MenuScene& aMenuScene);

	void UpdateShadows(const Tga::Vector3f aShadowFocusPosition, Tga::DirectionalLight& aDirectionalLight);
	void ReceiveInput(InputEvent aGameEvent, const std::any& someData) override;
	void CycleRenderMode();
	void Resize(const Tga::Vector2ui& aResolution);
	void ResizeGBuffer(const Tga::Vector2ui& aResolution);
	void BakeLightVolumeShadow(const Tga::DirectionalLight* light, const NCE::RenderData& renderData, Tga::GraphicsStateStack& stateStack);

	void AddBloom(Tga::GraphicsStateStack& aGraphicsStateStack, Tga::GraphicsEngine& aGraphicsEngine);
	void HandleResolutionChange();

	// Individual render passes
	void RenderShadowPass(const NCE::RenderData& renderData, Tga::GraphicsStateStack& stateStack);
	void RenderGBufferPass(const NCE::RenderData& renderData, Tga::GraphicsStateStack& stateStack, Tga::DepthBuffer* aDepthBuffer);
	void RenderDecalPass(const NCE::RenderData& renderData, Tga::GraphicsStateStack& stateStack, Tga::DepthBuffer* aDepthBuffer);
	void RenderLightPass(const NCE::RenderData& renderData, Tga::GraphicsStateStack& stateStack);
	void RenderWaterPass(const NCE::RenderData& renderData, Tga::GraphicsStateStack& stateStack, Tga::DepthBuffer* aDepthBuffer);
	void RenderTransparentPass(const NCE::RenderData& renderData, Tga::GraphicsStateStack& stateStack, Tga::DepthBuffer* aDepthBuffer); // Still uses old system for now
	void RenderBloomPass(Tga::GraphicsStateStack& stateStack);
	void RenderPostProcessing(Tga::GraphicsStateStack& stateStack);



#ifndef _RETAIL
	void RenderDebugPass(Tga::GraphicsStateStack& stateStack);
#endif

	// ***** DebugDraw *****
	void DrawNavmeshLines(GameScene& aGameScene);
	void DrawColliders(const std::vector<std::shared_ptr<GameObject>>& someGameObjects);
	// *********************

	void SetDrawNavMesh(bool aDrawNavMesh);
	void SetDrawNavMeshPortals(bool aDrawNavMeshPortals);
	void SetDrawColliders(bool aDrawColliders);
	void SetIsFullScreen(bool aIsFullScreen);
	void SetDrawGui(bool aDrawGUI);

	NCE::RenderData& GetRenderData();
	NCE::RenderResources& GetRenderResources();
	int GetRenderMode() const;
	PostProcessingValues& GetPostProcessingValues();
	bool GetDrawNavMesh() const;
	bool GetDrawNavMeshPortals() const;
	bool GetDrawColliders() const;
	bool GetDrawGUI() const;
	bool GetIsFullScreen() const;
	std::shared_ptr<Tga::DirectionalLight>& GetDirectionalLight();
	std::shared_ptr<Tga::AmbientLight>& GetAmbientLight();

private:

	struct ShaderLibrary
	{
		const Tga::ModelShader* defaultShader = nullptr;
		const Tga::ModelShader* defaultAnimatedShader = nullptr;
		const Tga::ModelShader* shadowShader = nullptr;
		const Tga::ModelShader* animatedShadowShader = nullptr;
		const Tga::ModelShader* gBufferShader = nullptr;
		const Tga::ModelShader* animatedGBufferShader = nullptr;
		const Tga::ModelShader* waterShader = nullptr;
		const Tga::ModelShader* pointLightVolumeShader = nullptr;
		const Tga::ModelShader* directionalLightVolumeShader = nullptr;

		void Init(Tga::GraphicsEngine& graphicsEngine);
	};

	NCE::RenderResources myRenderResources;
	ShaderLibrary myShaderLibrary;
	NCE::RenderData myRenderData;
	FrustumCuller myFrustumCuller;
	GBuffer myGBuffer;
	Tga::Camera myShadowCamera;
	RenderMode myRenderMode = RenderMode::Final;
	bool myDrawNavmesh = false;
	bool myDrawNavmeshPortals = false;
	bool myDrawColliders = false;
	bool drawGUI = true;
	bool isFullScreen = false;
};

