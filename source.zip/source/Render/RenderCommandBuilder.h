#pragma once
#include "RenderCommand.h"
#include <memory>
#include <vector>

class SpawnedObject;

namespace Tga
{
	class SceneCache;
	class AnimatedModelInstance;
	class ModelInstance;
}

class GameObject;

namespace NCE
{
    class Decal;

    class RenderCommandBuilder
    {
    public:
        // Returns one command per mesh
        static std::vector<RenderCommand> BuildFromGameObject(const GameObject& aObj);
        static std::vector<RenderCommand> BuildFromModelInstance(const Tga::ModelInstance& aInstance, const Tga::ModelShader* aShaderOverride = nullptr);
        static std::vector<RenderCommand> BuildFromAnimatedModelInstance(const Tga::AnimatedModelInstance& aInstance, const Tga::ModelShader* aShaderOverride = nullptr);
        static std::vector<RenderCommand> BuildFromSpawnedObject(const SpawnedObject& aSpawnedObject);
        static std::vector<RenderCommand> BuildFromDecal(const NCE::Decal& aDecal);
       // static std::vector<RenderCommand> BuildFromSceneObject(const Tga::SceneObject& sceneObject, Tga::SceneObjectDefinitionManager& definitionManager, Tga::SceneCache& cache);
    };
}