#include "stdafx.h"
#include "GBuffer.h"

#include <tge/graphics/DX11.h>

// TODO: Check what needs to be added for the GBuffer stuff

GBuffer GBuffer::Create(Tga::Vector2ui aSize)
{
	HRESULT result;
	std::array<DXGI_FORMAT, (int)GBufferTexture::Count> textureFormats =
	{
	DXGI_FORMAT_R32G32B32A32_FLOAT,// Position
	DXGI_FORMAT_R8G8B8A8_UNORM_SRGB,// Albedo
	DXGI_FORMAT_R10G10B10A2_UNORM,// Normal,
	DXGI_FORMAT_R8G8B8A8_UNORM,// Material
	DXGI_FORMAT_R8G8B8A8_UNORM// Fx
	};

	GBuffer returnGBuffer;
	D3D11_TEXTURE2D_DESC desc = { 0 };
	desc.Width = aSize.X;
	desc.Height = aSize.Y;
	desc.MipLevels = 1;
	desc.ArraySize = 1;
	desc.SampleDesc.Count = 1;
	desc.SampleDesc.Quality = 0;
	desc.Usage = D3D11_USAGE_DEFAULT;
	desc.BindFlags = D3D11_BIND_RENDER_TARGET | D3D11_BIND_SHADER_RESOURCE;
	desc.CPUAccessFlags = 0;
	desc.MiscFlags = 0;

	for (unsigned int idx = 0; idx < (int)GBufferTexture::Count; idx++)
	{
		desc.Format = textureFormats[idx];
		result = Tga::DX11::Device->CreateTexture2D(&desc, nullptr, &returnGBuffer.myTextures[idx]);

		assert(SUCCEEDED(result));

		result = Tga::DX11::Device->CreateRenderTargetView(
			returnGBuffer.myTextures[idx].Get(),
			nullptr,
			returnGBuffer.myRenderTargetViews[idx].GetAddressOf());

		assert(SUCCEEDED(result));

		result = Tga::DX11::Device->CreateShaderResourceView(
			returnGBuffer.myTextures[idx].Get(),
			nullptr,
			returnGBuffer.myShaderResourceViews[idx].GetAddressOf());

		assert(SUCCEEDED(result));
	}



	returnGBuffer.myViewport = std::make_shared<D3D11_VIEWPORT>(
		D3D11_VIEWPORT{
		0,
		0,
		static_cast<float>(desc.Width),
		static_cast<float>(desc.Height),
		0,
		1
		});
	return returnGBuffer;
}

void GBuffer::ClearTextures()
{
	Tga::Vector4f clearColor = { 0,0,0,0 };
	for (unsigned int idx = 0; idx < (int)GBufferTexture::Count; idx++)
	{
		Tga::DX11::Context->ClearRenderTargetView(myRenderTargetViews[idx].Get(), &clearColor.X);
	}
}

void GBuffer::SetAsActiveTarget(Tga::DepthBuffer* aDepth)
{
	if (aDepth)
	{
		Tga::DX11::Context->OMSetRenderTargets((int)GBufferTexture::Count, myRenderTargetViews[0].GetAddressOf(), aDepth->GetDepthStencilView());
	}
	else
	{
		Tga::DX11::Context->OMSetRenderTargets((int)GBufferTexture::Count, myRenderTargetViews[0].GetAddressOf(), nullptr);
	}
	Tga::DX11::Context->RSSetViewports(1, myViewport.get());
}

// For setting a span of targets
void GBuffer::SetAsActiveTarget(unsigned int aStartSlot, unsigned int aSlotCount, Tga::DepthBuffer* aDepth)
{
	if (aDepth)
	{
		Tga::DX11::Context->OMSetRenderTargets(aSlotCount, myRenderTargetViews[aStartSlot].GetAddressOf(), aDepth->GetDepthStencilView());
	}
	else
	{
		Tga::DX11::Context->OMSetRenderTargets(aSlotCount, myRenderTargetViews[aStartSlot].GetAddressOf(), nullptr);
	}
	Tga::DX11::Context->RSSetViewports(1, myViewport.get());
}

void GBuffer::SetAsResourceOnSlot(GBufferTexture aTexture, unsigned aSlot)
{
	Tga::DX11::Context->PSSetShaderResources(aSlot, 1, myShaderResourceViews[(int)aTexture].GetAddressOf());
}
void GBuffer::SetAllAsResources(unsigned aSlot)
{
	Tga::DX11::Context->PSSetShaderResources(aSlot, (int)GBufferTexture::Count, myShaderResourceViews[0].GetAddressOf());
}

ComPtr<ID3D11Texture2D> GBuffer::GetTexture2D(GBufferTexture aTexture)
{
	return myTextures[static_cast<int>(aTexture)];
}
