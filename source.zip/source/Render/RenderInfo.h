#pragma once
#include <cstdint>

enum class RenderType : uint8_t
{
    Sprite,
    Model,
    AnimatedModel,
    Count,
};
