#pragma once
//#pragma message(__FILE__" was compiled")
#include <tge/math/matrix4x4.h>
#include <tge/math/Vector3.h>
#include <tge/model/Model.h>

namespace Tga
{
	class Model;
	class Camera;
}

class FrustumCuller
{
	public:
	    void UpdateFrustum(const Tga::Camera* aCamera);
	    [[nodiscard]] bool CheckBounds(const Tga::Matrix4x4f& aMatrix, float aMaxScale, const Tga::Model& aModel) const;
	    [[nodiscard]] bool CheckFrustum(const Tga::Vector3f& aCenter, float aRadius) const;

	///*#ifndef _RETAIL
	//    void DebugDraw() const;
	//#endif*/
	private:
	    struct Plane
	    {
	        Tga::Vector3f pos;
	        Tga::Vector3f normal;
	    };

	    struct Frustum
	    {
	        Plane top, right, bottom, left, nearPlane, farPlane;
	    };

	    Frustum myFrustum;
	#ifndef _RETAIL
	    Tga::Vector3f myNearTl, myNearTR, myNearBL, myNearBR;
	    Tga::Vector3f myFarTL, myFarTR, myFarBL, myFarBR;
	#endif
};


