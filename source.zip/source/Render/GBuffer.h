#pragma once
//#pragma message(__FILE__" was compiled")
#include <array>
#include <d3d11.h>
#include <memory>
#include <tge/Graphics/DepthBuffer.h>
#include <tge/math/Vector2.h>
#include <wrl/client.h>

class GBuffer
{
public:
	enum class GBufferTexture
	{
		WorldPosition, // Wastes space and can be reconstructed from depth and screen pos, but we store it for simplicity
		Albedo,
		Normal, // stored as 0.5f + 0.5f*normal
		Material,
		FX, // Stores fx texture, but has free space for more things if needed!
		Count
	};
	std::array<Microsoft::WRL::ComPtr<ID3D11Texture2D>, (int)GBufferTexture::Count> myTextures;
	std::array< ComPtr<ID3D11RenderTargetView>, (int)GBufferTexture::Count> myRenderTargetViews;
	std::array< ComPtr<ID3D11ShaderResourceView>, (int)GBufferTexture::Count> myShaderResourceViews;
	std::shared_ptr<const D3D11_VIEWPORT> myViewport;
public:
	GBuffer() = default;
	~GBuffer() = default;
	static GBuffer Create(Tga::Vector2ui aSize);
	void ClearTextures();
	void SetAsActiveTarget(Tga::DepthBuffer* aDepth = nullptr);
	void SetAsActiveTarget(unsigned int aStartSlot, unsigned int aSlotCount, Tga::DepthBuffer* aDepth = nullptr);
	void SetAsResourceOnSlot(GBufferTexture aTexture, unsigned int aSlot);
	void SetAllAsResources(unsigned aSlot);
	ComPtr<ID3D11Texture2D> GetTexture2D(GBufferTexture aTexture);

};



