#include "stdafx.h"
#include "RenderManager.h"

#include "RenderCommand.h"
#include "RenderCommandBuilder.h"
#include "RenderCommandExecutor.h"

#include <tge/Engine.h>
#include <tge/graphics/DX11.h>
#include "../SceneManagement/GameScene.h"
#include <tge/graphics/GraphicsEngine.h>
#include <tge/drawers/ModelDrawer.h>
#include "../Objects/Actors/Player/Player.h"
#include "../Collisions/Narrow/Collider.h"
#include <tge/drawers/SpriteDrawer.h>
#include <tge/navmesh/navmesh.h>
#include "../Graphics/SpawnedObject.h"
#include "../UI/Button.h"
#include "../UI/ToolTip.h"
#include "../SceneManagement/MenuScene.h"
#include "../Utilities/BlackBoard.h"

#include <tge/model/AnimatedModelInstance.h>
#include <tge/util/StringCast.h>

using namespace Tga;

void RenderManager::Init(bool aInGame/*, Tga::LightPreviewSettings* someSettings*/)
{
	Tga::Vector2ui resolution = DX11::GetResolution();
	auto& graphicsEngine = Tga::Engine::GetInstance()->GetGraphicsEngine();
	myShaderLibrary.Init(graphicsEngine);
	myGBuffer = GBuffer::Create(DX11::GetResolution());
	SetupLights(/*someSettings*/);
	SetupShadowSettings();
	SetupRenderTargets(resolution);
	myRenderResources.postProcessingValues.Init();

	if (aInGame)
	{
		RegisterToMapper(InputEvent::ChangeRenderMode);
	}
}

void RenderManager::ShaderLibrary::Init(Tga::GraphicsEngine& graphicsEngine)
{
	auto& modelDrawer = graphicsEngine.GetModelDrawer();
	defaultShader = &modelDrawer.GetDefaultShader();
	defaultAnimatedShader = &modelDrawer.GetDefaultAnimatedShader();
	shadowShader = &modelDrawer.GetDefaultShadowShader();
	animatedShadowShader = &modelDrawer.GetAnimatedShadowShader();
	gBufferShader = &modelDrawer.GetGeometryShader();
	animatedGBufferShader = &modelDrawer.GetAnimatedGeometryShader();
	pointLightVolumeShader = &modelDrawer.GetPointLightShader();
	directionalLightVolumeShader = &modelDrawer.GetDirectionalLightVolumeShader();
}

void RenderManager::SetupLights()
{
	float lightIntensity = 1.f;

	Vector3f const rotation = { -35.2f, -180.f, 0.f };
	Matrix4x4f lightTransform = Matrix4x4f::CreateFromRollPitchYaw(rotation);
	Vector3f const forward = lightTransform.GetForward().GetNormalized();
	lightTransform.SetPosition(forward * 800.f);

	Color dLightColor = Color{ 1.f, 0.95f, 0.9f };
	auto dLight = DirectionalLight(lightTransform, dLightColor, lightIntensity);

	lightIntensity = 100.f;

	std::wstring cubeMap = string_cast<std::wstring>(Settings::ResolveGameAssetPath("assets/lights/cubemap/T_Cubemap.dds"));
	auto aLight = AmbientLight(cubeMap, Color{ 0.4f, 0.5f, 0.6f }, lightIntensity);

	if (myRenderResources.ambientLight == nullptr)
	{
	myRenderResources.ambientLight = std::make_shared<AmbientLight>(aLight);
	}

	if (myRenderResources.directionalLight == nullptr)
	{
	myRenderResources.directionalLight = std::make_shared<DirectionalLight>(dLight);
	myRenderResources.directionalLight->SetRotation(rotation);
}
}

void RenderManager::SetupShadowSettings()
{
	myRenderResources.shadowMap = DepthBuffer::Create({ myRenderResources.shadowMapResolution, myRenderResources.shadowMapResolution });

	//myShadowCamera.SetTransform(myRenderResources.directionalLight->GetTransform());
	myShadowCamera.SetOrtographicProjection(-myRenderResources.shadowMapScale, myRenderResources.shadowMapScale, -myRenderResources.shadowMapScale, myRenderResources.shadowMapScale, 5000.f, -5000.f);
	myShadowCamera.SetProjectionType(Camera::ProjectionType::Ortoraphic);
}

void RenderManager::SetupRenderTargets(const Tga::Vector2ui& aResolution)
{
	myRenderResources.intermediateTexture = RenderTarget::Create(aResolution, DXGI_FORMAT_R32G32B32A32_FLOAT);
	myRenderResources.waterLayer = RenderTarget::Create(aResolution, DXGI_FORMAT_R32G32B32A32_FLOAT);

	Tga::Vector2ui currentResolution = myRenderResources.intermediateTexture.GetResolution();
	Tga::RenderTarget renderTarget = RenderTarget::Create(currentResolution, DXGI_FORMAT_R32G32B32A32_FLOAT);

	myRenderResources.bloomRenderTargets.clear();

	myRenderResources.bloomRenderTargets.push_back(renderTarget);

	for (int i = 0; i < static_cast<int>(ResolutionRenderTargets::Count); i++)
	{
		currentResolution = myRenderResources.bloomRenderTargets[i].GetResolution();
		currentResolution.x /= 2;
		currentResolution.y /= 2;
		if ((currentResolution.y <= 0.f) || (currentResolution.x <= 0.f))
		{
			break;
		}

		renderTarget = RenderTarget::Create(currentResolution, DXGI_FORMAT_R32G32B32A32_FLOAT);
		myRenderResources.bloomRenderTargets.push_back(renderTarget);
	}
}

NCE::RenderData RenderManager::BuildRenderDataFromScene(GameScene& aGameScene)
{
	NCE::RenderData data;
	data.Clear();

	// ***** CAMERA *****
	const Tga::Camera& currentCamera = *aGameScene.GetActiveCamera();
	data.camera = &currentCamera;

	// ***** LIGHTS *****
	data.directionalLight = myRenderResources.directionalLight.get();
	data.ambientLight = myRenderResources.ambientLight.get();

	// Collect point lights
	for (const auto& light : aGameScene.GetPointLights())
	{
		data.pointLights.push_back(light.get());
	}

	// Collect directional light volumes
	for (const auto& light : aGameScene.GetDirectionalLights())
	{
		data.directionalLightVolumes.push_back(light.get());
	}

	// ***** SHADOW FOCUS *****
	if (const auto player = aGameScene.GetPlayer().lock())
	{
		data.shadowFocusPosition = player->GetPosition();
	}

	// ***** CULL AND BUILD COMMANDS *****
	myFrustumCuller.UpdateFrustum(&currentCamera);

	size_t objectCount = aGameScene.GetGameObjects().size();
	size_t spawnedObjectCount = aGameScene.GetSpawnedObjects().size();

	data.opaqueCommands.reserve(objectCount);
	data.shadowCommands.reserve(objectCount);
	data.transparentCommands.reserve(objectCount / 4 + spawnedObjectCount);
	data.decalCommands.reserve(aGameScene.GetDecals().size());

	for (auto& gameObject : aGameScene.GetGameObjects())
	{
		if (!gameObject->GetShouldRender())
			continue;

		// Build commands first
		auto commands = NCE::RenderCommandBuilder::BuildFromGameObject(*gameObject);

		if (commands.empty())
			continue;

		// Determine properties based on type
		bool isTransparent = false;
		bool isWater = false;
		bool castsShadow = false;

		if (gameObject->GetRenderType() == RenderType::Sprite)
		{
			isTransparent = true;
		}
		else if (gameObject->GetRenderType() == RenderType::Model || gameObject->GetRenderType() == RenderType::AnimatedModel)
		{
			auto modelInstance = gameObject->GetModelInstance();
			if (!modelInstance || !modelInstance->IsValid())
			{
				continue;
			}

			// Frustum cull models
			const Tga::Vector3f scale = gameObject->GetScale();
			const float maxScale = FMath::Max(scale.x, FMath::Max(scale.y, scale.z));

			if (!myFrustumCuller.CheckBounds(modelInstance->GetTransform(),maxScale, *modelInstance->GetModel()))
			{
				continue;
			}

			isTransparent = modelInstance->GetBlendState() != Tga::BlendState::Disabled;
			isWater = gameObject->GetTag() == Tag::Water;
			castsShadow = modelInstance->GetCastsShadow();
		}
		else
		{
			ERROR_PRINT("Gameobject missing required RenderType!");
			continue;
		}

		// Sort into appropriate command lists
		if (isTransparent)
		{
			if (isWater)
			{
				data.waterCommands.insert(data.waterCommands.end(), commands.begin(), commands.end());
			}
			else
			{
				// Calculate sort key for back-to-front sorting
				Tga::Vector3f objPos = gameObject->GetPosition();
				Tga::Vector3f camPos = currentCamera.GetTransform().GetPosition();
				float distSq = (objPos - camPos).LengthSqr();

				for (auto& cmd : commands)
				{
					cmd.sortKey = distSq;
				}

				data.transparentCommands.insert(data.transparentCommands.end(), commands.begin(), commands.end());
			}
		}
		else
		{
			// Opaque
			data.opaqueCommands.insert(data.opaqueCommands.end(), commands.begin(), commands.end());

			// Shadow casters
			if (castsShadow)
			{
				data.shadowCommands.insert(data.shadowCommands.end(), commands.begin(), commands.end());
			}
		}
	}

	// ***** BUILD VFX/SPAWNED OBJECT COMMANDS *****
	for (auto& spawnedObject : aGameScene.GetSpawnedObjects())
	{
		auto commands = NCE::RenderCommandBuilder::BuildFromSpawnedObject(*spawnedObject);

		// Calculate sort key for back-to-front sorting
		Tga::Vector3f objPos = spawnedObject->GetPosition();
		Tga::Vector3f camPos = currentCamera.GetTransform().GetPosition();
		float distSq = (objPos - camPos).LengthSqr();

		for (auto& cmd : commands)
		{
			cmd.sortKey = distSq;
		}

		data.transparentCommands.insert(data.transparentCommands.end(), commands.begin(), commands.end());
	}

	// ***** BUILD VFX/SPAWNED OBJECT COMMANDS *****
	for (auto& decal : aGameScene.GetDecals())
	{
		auto commands = NCE::RenderCommandBuilder::BuildFromDecal(*decal);

		// Calculate sort key for back-to-front sorting
		Tga::Vector3f objPos = decal->GetTransform().GetPosition();
		Tga::Vector3f camPos = currentCamera.GetTransform().GetPosition();
		float distSq = (objPos - camPos).LengthSqr();

		for (auto& cmd : commands)
		{
			cmd.sortKey = distSq;
		}

		data.decalCommands.insert(data.decalCommands.end(), commands.begin(), commands.end());
	}

	// Sort transparent back-to-front (includes both transparent GameObjects and VFX)
	std::sort(data.transparentCommands.begin(), data.transparentCommands.end(),
		[](const NCE::RenderCommand& a, const NCE::RenderCommand& b) {
			return a.sortKey > b.sortKey;
		});

	return data;
}

void RenderManager::ExecuteRenderPipeline(const NCE::RenderData& renderData, Tga::DepthBuffer* aDepthBuffer, bool aRenderToBackBuffer)
{
	auto& engine = *Engine::GetInstance();
	auto& graphicsEngine = engine.GetGraphicsEngine();
	auto& graphicsStateStack = graphicsEngine.GetGraphicsStateStack();

	Tga::DepthBuffer* depthBuffer = aDepthBuffer ? aDepthBuffer : Tga::DX11::DepthBuffer;

	if (!renderData.camera || !renderData.directionalLight || !renderData.ambientLight)
	{
		ERROR_PRINT("RenderData missing required camera or lights!");
		return;
	}

	// ***** DEFAULT VALUES *****
	graphicsStateStack.SetPostProcessingValues(myRenderResources.postProcessingValues);
	graphicsStateStack.SetRenderMode(myRenderMode);
	graphicsStateStack.SetCamera(*renderData.camera);
	graphicsStateStack.SetSamplerState(Tga::SamplerFilter::Trilinear, Tga::SamplerAddressMode::Wrap);
	graphicsStateStack.SetRasterizerState(Tga::RasterizerState::BackfaceCulling);
	graphicsStateStack.SetDepthStencilState(Tga::DepthStencilState::WriteLessOrEqual);
	graphicsStateStack.SetBlendState(Tga::BlendState::Disabled);

	// ***** RENDER PASSES *****
	RenderShadowPass(renderData, graphicsStateStack);
	RenderGBufferPass(renderData, graphicsStateStack, depthBuffer);
	RenderDecalPass(renderData, graphicsStateStack, depthBuffer);
	RenderLightPass(renderData, graphicsStateStack);
	RenderWaterPass(renderData, graphicsStateStack, depthBuffer);
	RenderTransparentPass(renderData, graphicsStateStack, depthBuffer);
	RenderBloomPass(graphicsStateStack);

	if (aRenderToBackBuffer)
	{
		RenderPostProcessing(graphicsStateStack);
	}
}

void RenderManager::UpdateShadows(const Tga::Vector3f aShadowFocusPosition, DirectionalLight& aDirectionalLight)
{
	myShadowCamera.SetTransform(myRenderResources.directionalLight->GetTransform());
	const float shadowMapScale = myRenderResources.shadowMapScale;
	const float ShadowMapResolution = static_cast<float>(myRenderResources.shadowMapResolution);

	Tga::Vector3f shadowPos;

	{
		// round shadow map camera position to texel size
		// this makes it jitter less when moving the camera

		Tga::Matrix4x4f shadowCameraMatrix = myShadowCamera.GetTransform();
		Tga::Vector3f forward = shadowCameraMatrix.GetForward();
		Tga::Vector3f right = shadowCameraMatrix.GetRight();
		Tga::Vector3f up = shadowCameraMatrix.GetUp();

		float f = aShadowFocusPosition.Dot(forward);
		float r = aShadowFocusPosition.Dot(right);
		float u = aShadowFocusPosition.Dot(up);

		float texelWorldSize = (2.f * shadowMapScale / ShadowMapResolution);
		r = texelWorldSize * std::round(r / texelWorldSize);
		u = texelWorldSize * std::round(u / texelWorldSize);
		
		shadowPos = f * forward + r * right + u * up;
	}

	myShadowCamera.GetTransform().SetPosition(shadowPos);

	myShadowCamera.GetTransform().SetRotation(aDirectionalLight.GetTransform().GetRotationAsQuaternion().GetYawPitchRoll());
	aDirectionalLight.SetTransform(myShadowCamera.GetTransform());
}

void RenderManager::ReceiveInput(InputEvent aGameEvent, const std::any& someData)
{
	UNREFERENCED_PARAMETER(someData);

	switch (aGameEvent)
	{
	case InputEvent::ChangeRenderMode:
	{
		CycleRenderMode();
		break;
	}
	default:
	{
		break;
	}
	}
}

void RenderManager::CycleRenderMode()
{
	int mode = static_cast<int>(myRenderMode);
	mode = (mode + 1) % static_cast<int>(RenderMode::Count);
	myRenderMode = static_cast<RenderMode>(mode);
}

void RenderManager::Resize(const Tga::Vector2ui& aResolution)
{
	myGBuffer = GBuffer::Create(aResolution);
	SetupRenderTargets(aResolution);
}

void RenderManager::ResizeGBuffer(const Tga::Vector2ui& aResolution)
{
	myGBuffer = GBuffer::Create(aResolution);
}

void RenderManager::BakeLightVolumeShadow(const Tga::DirectionalLight* light,const NCE::RenderData& renderData,Tga::GraphicsStateStack& stateStack)
{
	// Create shadow map for this light
	Tga::DepthBuffer shadowMap = DepthBuffer::Create({
		myRenderResources.shadowMapResolution,
		myRenderResources.shadowMapResolution
		});

	// Use light's position as shadow focus (static)
	Tga::Vector3f lightFocusPos = light->GetTransform().GetPosition();

	// Update shadow camera for this light
	UpdateShadows(lightFocusPos, *const_cast<Tga::DirectionalLight*>(light));

	stateStack.Push();
	{
		stateStack.SetRasterizerState(Tga::RasterizerState::Shadow);
		stateStack.SetCamera(myShadowCamera);

		// Unbind shadow map from shader slots
		ID3D11ShaderResourceView* nullView = nullptr;
		Tga::DX11::Context->PSSetShaderResources(5, 1, &nullView);

		// Render shadows to this light's shadow map
		shadowMap.Clear();
		shadowMap.SetAsActiveTarget();

		// Override to shadow shaders
		std::vector<NCE::RenderCommand> shadowCommands;
		shadowCommands.reserve(renderData.shadowCommands.size());
		for (const auto& cmd : renderData.shadowCommands)
		{
			const Tga::ModelShader* shadowShader = cmd.boneTransforms
				? myShaderLibrary.animatedShadowShader
				: myShaderLibrary.shadowShader;
			shadowCommands.push_back(cmd.ApplyShader(shadowShader));
		}

		NCE::RenderCommandExecutor::ExecuteBatch(shadowCommands, stateStack);
	}
	stateStack.Pop();

	// Cache the shadow map
	myRenderResources.myLightVolumeShadowCache[light] = std::move(shadowMap);

}

void RenderManager::RenderScene(GameScene& aGameScene, bool aShowHudEditGrid)
{
	HandleResolutionChange();

	NCE::RenderData renderData = BuildRenderDataFromScene(aGameScene);
	ExecuteRenderPipeline(renderData);

	auto& graphicsEngine = Engine::GetInstance()->GetGraphicsEngine();
	graphicsEngine.GetGraphicsStateStack().SetSamplerState(
		Tga::SamplerFilter::Trilinear,
		Tga::SamplerAddressMode::Clamp);

	if (drawGUI)
	{
		aGameScene.RenderHUDGrid(aShowHudEditGrid);
		aGameScene.RenderHUD();
	}

	#ifndef _RETAIL
	// ***** DEBUG *****
	auto& stateStack = graphicsEngine.GetGraphicsStateStack();
	stateStack.Push();
	{
		Tga::DX11::BackBuffer->SetAsActiveTarget();
		stateStack.SetBlendState(Tga::BlendState::AlphaBlend);

		std::vector<std::shared_ptr<GameObject>> culledObjects;
		std::vector<std::shared_ptr<GameObject>> nonModelObjects;

		for (auto& gameObject : aGameScene.GetGameObjects())
		{
			if (gameObject->GetShouldRender())
			{
				if (auto modelInstance = gameObject->GetModelInstance())
				{
					if (modelInstance->IsValid())
					{
						culledObjects.push_back(gameObject);
					}
					else if (gameObject->GetCollider())
					{
						nonModelObjects.push_back(gameObject);
					}
				}
			}
		}

		DrawColliders(culledObjects);
		DrawColliders(nonModelObjects);
		DrawNavmeshLines(aGameScene);
	}
	stateStack.Pop();
	#endif
}

void RenderManager::RenderScene(MenuScene& aMenuScene)
{
	DX11::BackBuffer->SetAsActiveTarget(DX11::DepthBuffer);

	auto& engine = *Tga::Engine::GetInstance();

	auto& graphicsStateStack = engine.GetGraphicsEngine().GetGraphicsStateStack();
	graphicsStateStack.Push();
	graphicsStateStack.SetSamplerState(Tga::SamplerFilter::Trilinear, Tga::SamplerAddressMode::Clamp);
	graphicsStateStack.SetCamera(*aMenuScene.GetActiveCamera());
	graphicsStateStack.SetBlendState(Tga::BlendState::AlphaBlend);

	for (auto& sprite : aMenuScene.GetSprites())
	{
		sprite->Render();
	}
	for (auto id : aMenuScene.GetButtonDrawOrder())
	{
		auto& btns = aMenuScene.GetButtons();
		auto it = btns.find(id);
		if (it == btns.end()) continue;
		if (!it->second) continue;

		it->second->Render();
	}
	for (auto& tooltip : aMenuScene.GetToolTips())
	{
		tooltip->Render();
	}
	graphicsStateStack.Pop();
}

void RenderManager::RenderShadowPass(const NCE::RenderData& renderData, Tga::GraphicsStateStack& stateStack)
{
	if (renderData.shadowCommands.empty())
	{
		return;
	}

	// Update shadow camera
	UpdateShadows(renderData.shadowFocusPosition, *myRenderResources.directionalLight);
	myFrustumCuller.UpdateFrustum(&myShadowCamera);

	stateStack.Push();
	{
		stateStack.SetRasterizerState(Tga::RasterizerState::Shadow);
		stateStack.SetCamera(myShadowCamera);

		ID3D11ShaderResourceView* nullView = nullptr;
		Tga::DX11::Context->PSSetShaderResources(5, 1, &nullView);
		myRenderResources.shadowMap.Clear();
		myRenderResources.shadowMap.SetAsActiveTarget();

		// Override to shadow shaders
		std::vector<NCE::RenderCommand> shadowCommands;
		shadowCommands.reserve(renderData.shadowCommands.size());

		for (const auto& cmd : renderData.shadowCommands)
		{
			const Tga::ModelShader* shadowShader = cmd.boneTransforms
				? myShaderLibrary.animatedShadowShader
				: myShaderLibrary.shadowShader;

			shadowCommands.push_back(cmd.ApplyShader(shadowShader));
		}

		NCE::RenderCommandExecutor::ExecuteBatch(shadowCommands, stateStack);
	}
	stateStack.Pop();
}

void RenderManager::RenderGBufferPass(const NCE::RenderData& renderData, Tga::GraphicsStateStack& stateStack, Tga::DepthBuffer* aDepthBuffer)
{
	stateStack.Push();
	{
		myGBuffer.ClearTextures();

		std::array<ID3D11ShaderResourceView*, 5> nullViews = {};
		Tga::DX11::Context->PSSetShaderResources(6, 5, nullViews.data());

		stateStack.SetBlendState(Tga::BlendState::Disabled);
		myGBuffer.SetAsActiveTarget(aDepthBuffer);

		// Render opaque geometry
		NCE::RenderCommandExecutor::ExecuteBatch(renderData.opaqueCommands, stateStack);

		//Tga::DX11::Context->CopyResource(myGBuffer.GetTexture2D(GBuffer::GBufferTexture::WorldPosition).Get(),  )
	}
	stateStack.Pop();
}

void RenderManager::RenderDecalPass(const NCE::RenderData& renderData, Tga::GraphicsStateStack& stateStack, Tga::DepthBuffer* aDepthBuffer)
{
	stateStack.Push();
	{
		stateStack.SetRasterizerState(RasterizerState::FrontfaceCulling);
		stateStack.SetBlendState(BlendState::AlphaBlend);
		stateStack.SetSamplerState(SamplerFilter::Trilinear, SamplerAddressMode::Clamp);
		stateStack.SetDepthStencilState(DepthStencilState::ReadOnlyGreater);
		unsigned int startSlot = (int)(GBuffer::GBufferTexture::Albedo);
		myGBuffer.SetAsActiveTarget(startSlot, (int)(GBuffer::GBufferTexture::Count)-startSlot, aDepthBuffer);
		myGBuffer.SetAsResourceOnSlot(GBuffer::GBufferTexture::WorldPosition, 6);

		// Render decals
		NCE::RenderCommandExecutor::ExecuteBatch(renderData.decalCommands, stateStack);
	}
	stateStack.Pop();
}

void RenderManager::RenderLightPass(const NCE::RenderData& renderData, Tga::GraphicsStateStack& stateStack)
{
	//auto& engine = *Engine::GetInstance();
	//auto& graphicsEngine = engine.GetGraphicsEngine();

	//stateStack.Push();
	//{
	//	stateStack.SetFullScreenLightSamplers();

	//	Tga::Color clearColor = engine.GetClearColor();
	//	myRenderResources.intermediateTexture.Clear({clearColor.r, clearColor.g, clearColor.b, clearColor.a });
	//	myRenderResources.intermediateTexture.SetAsActiveTarget();

	//	// Set main directional light
	//	myRenderResources.directionalLight->SetProjectionMatrix(myShadowCamera.GetProjection());
	//	stateStack.SetDirectionalLight(*renderData.directionalLight);
	//	stateStack.SetAmbientLight(*renderData.ambientLight);

	//	// Bind GBuffer and shadow map
	//	myRenderResources.shadowMap.SetAsResourceOnSlot(5);
	//	myGBuffer.SetAllAsResources(6);

	//	// Fullscreen deferred light pass
	//	graphicsEngine.GetFullScreenEffectGPass().Render();

	//	stateStack.SetDepthStencilState(Tga::DepthStencilState::ReadOnlyGreater);
	//	stateStack.SetRasterizerState(Tga::RasterizerState::FrontfaceCulling);
	//	stateStack.SetBlendState(Tga::BlendState::AdditiveBlend);

	//	// Draw point lights
	//	stateStack.ClearPointLights();
	//	for (const auto* light : renderData.pointLights)
	//	{
	//		stateStack.AddPointLight(*light);
	//		graphicsEngine.GetModelDrawer().DrawLight(light->GetModelInstance());
	//	}

	//	// Draw directional light volumes
	//	for (const auto* light : renderData.directionalLightVolumes)
	//	{
	//		// Temporarily update shadow camera for this light
	//		UpdateShadows(renderData.shadowFocusPosition, *const_cast<Tga::DirectionalLight*>(light));
	//		const_cast<Tga::DirectionalLight*>(light)->SetProjectionMatrix(myShadowCamera.GetProjection());
	//		stateStack.SetDirectionalLight(*light);
	//		graphicsEngine.GetModelDrawer().DrawDirectionalLightVolume(light->GetModelInstance());
	//	}

	//	// Restore main directional light
	//	stateStack.SetDirectionalLight(*renderData.directionalLight);
	//}
	//stateStack.Pop();

	auto& engine = *Engine::GetInstance();
	auto& graphicsEngine = engine.GetGraphicsEngine();

	stateStack.Push();
	{
		stateStack.SetFullScreenLightSamplers();
		Tga::Color clearColor = engine.GetClearColor();
		myRenderResources.intermediateTexture.Clear({clearColor.r, clearColor.g, clearColor.b, clearColor.a });
		myRenderResources.intermediateTexture.SetAsActiveTarget();

		// ***** MAIN DIRECTIONAL LIGHT *****
		myRenderResources.directionalLight->SetProjectionMatrix(myShadowCamera.GetProjection());
		stateStack.SetDirectionalLight(*renderData.directionalLight);
		stateStack.SetAmbientLight(*renderData.ambientLight);

		// Bind main shadow map and GBuffer
		myRenderResources.shadowMap.SetAsResourceOnSlot(5);
		myGBuffer.SetAllAsResources(6);

		// Fullscreen deferred light pass
		graphicsEngine.GetFullScreenEffectGPass().Render();

		// ***** ADDITIVE LIGHTING *****
		stateStack.SetDepthStencilState(Tga::DepthStencilState::ReadOnlyGreater);
		stateStack.SetRasterizerState(Tga::RasterizerState::FrontfaceCulling);
		stateStack.SetBlendState(Tga::BlendState::AdditiveBlend);

		// Draw point lights
		for (const auto* light : renderData.pointLights)
		{
			stateStack.ClearPointLights();
			stateStack.AddPointLight(*light);
			graphicsEngine.GetModelDrawer().DrawLight(light->GetModelInstance());
		}

		// ***** DRAW DIRECTIONAL LIGHT VOLUMES WITH CACHED SHADOWS *****
		for (const auto* light : renderData.directionalLightVolumes)
		{
			// Check if we have a cached shadow map
			auto it = myRenderResources.myLightVolumeShadowCache.find(light);
			if (it == myRenderResources.myLightVolumeShadowCache.end())
			{
				// ***** BAKE SHADOW MAP ON FIRST USE *****
				BakeLightVolumeShadow(light, renderData, stateStack);
				it = myRenderResources.myLightVolumeShadowCache.find(light);
			}

			// ***** BIND THIS LIGHT'S SHADOW MAP *****
			it->second.SetAsResourceOnSlot(5);

			// Update light parameters
			Tga::Vector3f lightFocusPos = light->GetTransform().GetPosition();
			UpdateShadows(lightFocusPos, *const_cast<Tga::DirectionalLight*>(light));
			const_cast<Tga::DirectionalLight*>(light)->SetProjectionMatrix(myShadowCamera.GetProjection());

			stateStack.SetDirectionalLight(*light);
			graphicsEngine.GetModelDrawer().DrawDirectionalLightVolume(light->GetModelInstance());
		}

		// ***** RESTORE MAIN DIRECTIONAL LIGHT *****
		myRenderResources.shadowMap.SetAsResourceOnSlot(5);
		stateStack.SetDirectionalLight(*renderData.directionalLight);
	}
	stateStack.Pop();
}

void RenderManager::RenderWaterPass(const NCE::RenderData& renderData, Tga::GraphicsStateStack& stateStack, Tga::DepthBuffer* aDepthBuffer)
{
	if (renderData.waterCommands.empty())
		return;

	auto& graphicsEngine = Engine::GetInstance()->GetGraphicsEngine();

	stateStack.Push();
	{
		ID3D11ShaderResourceView* nullSRV = nullptr;
		Tga::DX11::Context->PSSetShaderResources(1, 1, &nullSRV);

		myRenderResources.waterLayer.SetAsActiveTarget();
		myRenderResources.intermediateTexture.SetAsResourceOnSlot(1);
		graphicsEngine.GetFullscreenEffectCopy().Render();

		Tga::DX11::Context->PSSetShaderResources(1, 1, &nullSRV);

		myRenderResources.intermediateTexture.SetAsActiveTarget(aDepthBuffer);
		myRenderResources.waterLayer.SetAsResourceOnSlot(22);
		myGBuffer.SetAllAsResources(6);

		// Override to water shader
		std::vector<NCE::RenderCommand> waterCommands;
		waterCommands.reserve(renderData.waterCommands.size());

		for (const auto& cmd : renderData.waterCommands)
		{
			waterCommands.push_back(cmd.ApplyShader(myShaderLibrary.waterShader));
		}

		NCE::RenderCommandExecutor::ExecuteBatch(waterCommands, stateStack);
	}
	stateStack.Pop();
}

void RenderManager::RenderTransparentPass(const NCE::RenderData& renderData, Tga::GraphicsStateStack& stateStack, Tga::DepthBuffer* aDepthBuffer)
{
	if (renderData.transparentCommands.empty())
		return;

	stateStack.Push();
	{
		myGBuffer.SetAllAsResources(6);
		myRenderResources.intermediateTexture.SetAsActiveTarget(aDepthBuffer);

		stateStack.SetBlendState(Tga::BlendState::AddAndFadeBackground);
		stateStack.SetDepthStencilState(Tga::DepthStencilState::ReadOnlyLess);
		stateStack.SetRasterizerState(Tga::RasterizerState::NoFaceCulling);
		stateStack.SetSamplerState(Tga::SamplerFilter::Trilinear, Tga::SamplerAddressMode::Wrap);

		// Execute all transparent/VFX commands (sorted back-to-front)
		NCE::RenderCommandExecutor::ExecuteBatch(renderData.transparentCommands, stateStack);
	}
	stateStack.Pop();
}

void RenderManager::RenderBloomPass(Tga::GraphicsStateStack& stateStack)
{
	stateStack.Push();
	{
		stateStack.SetBlendState(Tga::BlendState::Disabled);
		stateStack.SetSamplerState(Tga::SamplerFilter::Trilinear, Tga::SamplerAddressMode::Clamp);

		AddBloom(stateStack, Engine::GetInstance()->GetGraphicsEngine());
	}
	stateStack.Pop();
}

void RenderManager::RenderPostProcessing(Tga::GraphicsStateStack& stateStack)
{
	auto& graphicsEngine = Engine::GetInstance()->GetGraphicsEngine();

	stateStack.Push();
	{
		Tga::DX11::BackBuffer->SetAsActiveTarget();
		myRenderResources.intermediateTexture.SetAsResourceOnSlot(1);
		graphicsEngine.GetFullscreenEffectTonemap().Render();
	}
	stateStack.Pop();
}

#ifndef _RETAIL
void RenderManager::RenderDebugPass(Tga::GraphicsStateStack& stateStack)
{
	stateStack.Push();
	{
		Tga::DX11::BackBuffer->SetAsActiveTarget();
		stateStack.SetBlendState(Tga::BlendState::AlphaBlend);

		// Debug drawing still uses old system
		// We'll keep the existing code for now
	}
	stateStack.Pop();
}
#endif


void RenderManager::AddBloom(GraphicsStateStack& aGraphicsStateStack, GraphicsEngine& aGraphicsEngine)
{
	RenderTarget previouslyWrittenToTarget = myRenderResources.intermediateTexture;

	for (int i = 1; i < myRenderResources.bloomRenderTargets.size(); i++)
	{
		RenderTarget currentRenderTarget = myRenderResources.bloomRenderTargets[i];
		currentRenderTarget.SetAsActiveTarget();
		previouslyWrittenToTarget.SetAsResourceOnSlot(1);
		aGraphicsEngine.GetFullScreenEffectDownSample().Render();
		previouslyWrittenToTarget = currentRenderTarget;
		aGraphicsStateStack.SetDepthStencilState(DepthStencilState::WriteLess);
	}

	aGraphicsStateStack.SetBlendState(BlendState::AlphaBlend);

	for (size_t i = myRenderResources.bloomRenderTargets.size() - 2; i > 0; i--)
	{
		RenderTarget currentRenderTarget = myRenderResources.bloomRenderTargets[i];
		currentRenderTarget.SetAsActiveTarget();
		previouslyWrittenToTarget.SetAsResourceOnSlot(1);
		aGraphicsEngine.GetFullScreenEffectUpsampleAndScaleBloom().Render();
		previouslyWrittenToTarget = currentRenderTarget;
	}

	myRenderResources.intermediateTexture.SetAsActiveTarget();
	previouslyWrittenToTarget.SetAsResourceOnSlot(1);
	aGraphicsEngine.GetFullScreenEffectUpsampleAndScaleBloom().Render();
}

void RenderManager::HandleResolutionChange()
{
	bool windowResized = Blackboard::GetInstance()->GetBool("windowResized");

	if (windowResized)
	{
		isFullScreen = !isFullScreen;
		myGBuffer = GBuffer::Create(DX11::GetResolution());

		myRenderResources.intermediateTexture = RenderTarget::Create(DX11::GetResolution(), DXGI_FORMAT_R32G32B32A32_FLOAT);
		myRenderResources.waterLayer = RenderTarget::Create(DX11::GetResolution(), DXGI_FORMAT_R32G32B32A32_FLOAT);

		Blackboard::GetInstance()->SetBool("windowResized", false);
	}
}

void RenderManager::DrawNavmeshLines(GameScene& aGameScene)
{
	if (myDrawNavmesh)
	{
		Navmesh& navmesh = *aGameScene.GetNavmesh();
		if (&navmesh != nullptr)
		{
			Tga::DebugDrawer& debugDrawer = Tga::Engine::GetInstance()->GetDebugDrawer();
			navmesh.RenderNavmesh(debugDrawer);
			navmesh.RenderConnections(debugDrawer);
			if (myDrawNavmeshPortals)
			{
				navmesh.RenderPortals();
			}
		}
	}
}

void RenderManager::DrawColliders(const std::vector<std::shared_ptr<GameObject>>& someGameObjects)
{
	if (myDrawColliders)
	{
		for (auto& gameObject : someGameObjects)
		{
			gameObject->DebugRender();
			if (auto& collider = gameObject->GetCollider())
			{
				collider->DebugRender();
			}
		}
	}
}

void RenderManager::SetDrawNavMesh(bool aDrawNavMesh)
{
	myDrawNavmesh = aDrawNavMesh;
}

void RenderManager::SetDrawNavMeshPortals(bool aDrawNavMeshPortals)
{
	myDrawNavmeshPortals = aDrawNavMeshPortals;
}

void RenderManager::SetDrawColliders(bool aDrawColliders)
{
	myDrawColliders = aDrawColliders;
}

void RenderManager::SetIsFullScreen(bool aIsFullScreen)
{
	isFullScreen = aIsFullScreen;
}

void RenderManager::SetDrawGui(bool aDrawGUI)
{
	drawGUI = aDrawGUI;
}

NCE::RenderData& RenderManager::GetRenderData()
{
	return myRenderData;
}

NCE::RenderResources& RenderManager::GetRenderResources()
{
	return myRenderResources;
}

int RenderManager::GetRenderMode() const
{
	return static_cast<int>(myRenderMode);
}

PostProcessingValues& RenderManager::GetPostProcessingValues()
{
	return myRenderResources.postProcessingValues;
}

bool RenderManager::GetDrawNavMesh() const
{
	return myDrawNavmesh;
}

bool RenderManager::GetDrawNavMeshPortals() const
{
	return myDrawNavmeshPortals;
}

bool RenderManager::GetDrawColliders() const
{
	return myDrawColliders;
}

bool RenderManager::GetDrawGUI() const
{
	return drawGUI;
}

bool RenderManager::GetIsFullScreen() const
{
	return isFullScreen;
}

std::shared_ptr<Tga::DirectionalLight>& RenderManager::GetDirectionalLight()
{
	return myRenderResources.directionalLight;
}

std::shared_ptr<Tga::AmbientLight>& RenderManager::GetAmbientLight()
{
	return myRenderResources.ambientLight;
}
