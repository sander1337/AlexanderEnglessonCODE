#pragma once
#include <tge/Graphics/DepthBuffer.h>
#include <tge/graphics/RenderTarget.h>
#include <tge/graphics/DirectionalLight.h>
#include <tge/graphics/AmbientLight.h>
#include <tge/graphics/PointLight.h>
#include "PostProcessingValues.h"
#include <memory>
#include <mutex>
#include <vector>

enum class ResolutionRenderTargets
{
    Count = 6
};

//struct SortedObject;

struct SpriteSharedDataKey
{
    Tga::StringId texture0;
    Tga::StringId texture1;
    Tga::StringId texture2;
    Tga::StringId texture3;
    Tga::StringId pixelShader;
    bool isBillboard;
    Tga::RasterizerState rasterizerState;
    Tga::BlendState blendState;
    Tga::DepthStencilState depthStencilState;
    Tga::SamplerFilter samplerFilter;

    bool operator==(const SpriteSharedDataKey& other) const
    {
        return texture0 == other.texture0 &&
            texture1 == other.texture1 &&
            texture2 == other.texture2 &&
            texture3 == other.texture3 &&
            pixelShader == other.pixelShader &&
            isBillboard == other.isBillboard &&
            rasterizerState == other.rasterizerState &&
            blendState == other.blendState &&
            depthStencilState == other.depthStencilState &&
            samplerFilter == other.samplerFilter;
    }
};

template<>
struct std::hash<SpriteSharedDataKey>
{
    size_t operator()(const SpriteSharedDataKey& key) const
    {
        size_t h = 0;
        h ^= std::hash<Tga::StringId>()(key.texture0);
        h ^= std::hash<Tga::StringId>()(key.texture1) << 1;
        h ^= std::hash<Tga::StringId>()(key.texture2) << 2;
        h ^= std::hash<Tga::StringId>()(key.texture3) << 3;
        h ^= std::hash<Tga::StringId>()(key.pixelShader) << 4;
        h ^= std::hash<bool>()(key.isBillboard) << 5;
        h ^= std::hash<int>()(static_cast<int>(key.rasterizerState)) << 6;
        h ^= std::hash<int>()(static_cast<int>(key.blendState)) << 7;
        h ^= std::hash<int>()(static_cast<int>(key.depthStencilState)) << 8;
        h ^= std::hash<int>()(static_cast<int>(key.samplerFilter)) << 9;
        return h;
    }
};

namespace NCE
{
    struct RenderResources
    {
        std::mutex mySpriteCacheMutex;

        std::unordered_map<SpriteSharedDataKey, std::shared_ptr<Tga::SpriteSharedData>> mySpriteSharedDataTest;
        //std::unordered_map<Tga::StringId, std::shared_ptr<Tga::SpriteSharedData>> mySpriteSharedData;
        std::unordered_map<Tga::StringId, std::unique_ptr<Tga::SpriteShader>> mySpriteShaders;
        std::unordered_map<const Tga::DirectionalLight*, Tga::DepthBuffer> myLightVolumeShadowCache;

        Tga::DepthBuffer shadowMap;
        Tga::RenderTarget intermediateTexture;
        Tga::RenderTarget waterLayer;
        std::vector<Tga::RenderTarget> bloomRenderTargets;

        std::shared_ptr<Tga::DirectionalLight> directionalLight;
        std::shared_ptr<Tga::AmbientLight> ambientLight;

        PostProcessingValues postProcessingValues;

        unsigned int shadowMapResolution = 2048;
        float shadowMapScale = 3000.f;
    };
}
