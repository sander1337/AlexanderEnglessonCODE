#pragma once
#include <cstdint>
#include "RenderCommand.h"
#include <tge/graphics/Camera.h>
#include <tge/graphics/DirectionalLight.h>
#include <tge/graphics/AmbientLight.h>
#include <tge/graphics/PointLight.h>
#include "../../../Game/source/SpotLight.h"
#include <vector>

enum class RenderType : uint8_t
{
    Sprite,
    Model,
    AnimatedModel,
    Count,
};

namespace NCE
{
  /*  struct SpriteRenderCommand;
    struct LightVolumeRenderCommand;*/

    struct RenderData
    {
        //std::unordered_map<Tga::StringId, Tga::SpriteSharedData> mySpriteSharedData;
        //std::unordered_map<Tga::StringId, std::unique_ptr<Tga::SpriteShader>> mySpriteShaders;

        // ***** COMMANDS *****
        std::vector<RenderCommand> opaqueCommands;
        std::vector<RenderCommand> shadowCommands;
        std::vector<RenderCommand> transparentCommands;
        std::vector<RenderCommand> waterCommands;
        std::vector<RenderCommand> decalCommands;

        // ***** SPRITES / VFX *****
        // std::vector<SpriteRenderCommand> spriteCommands;

        // ***** CAMERA *****
        const Tga::Camera* camera = nullptr;

        // ***** LIGHTS *****
        Tga::DirectionalLight* directionalLight = nullptr;
        Tga::AmbientLight* ambientLight = nullptr;
        std::vector<Tga::PointLight*> pointLights;
        std::vector<Tga::SpotLight*> spotLights;
        std::vector<const Tga::DirectionalLight*> directionalLightVolumes;

        // ***** SHADOW DATA *****
        Tga::Vector3f shadowFocusPosition; // Where shadows are centered (e.g., player position)

        // ***** DEBUG DATA ***** (optional)
        bool drawColliders = false;
        bool drawNavmesh = false;

        void Clear()
        {
            opaqueCommands.clear();
            shadowCommands.clear();
            transparentCommands.clear();
            waterCommands.clear();
            decalCommands.clear();
            pointLights.clear();
            spotLights.clear();
            camera = nullptr;
            directionalLight = nullptr;
            ambientLight = nullptr;
            shadowFocusPosition = {};
            drawColliders = false;
            drawNavmesh = false;
        }

        // Helper to get total command count
        size_t GetTotalCommandCount() const
        {
            return opaqueCommands.size() +
                shadowCommands.size() +
                transparentCommands.size() +
                waterCommands.size() +
                decalCommands.size();
        }
    };
}