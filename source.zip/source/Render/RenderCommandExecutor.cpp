#include "stdafx.h"
#include "RenderCommandExecutor.h"

#include <tge/drawers/SpriteDrawer.h>
#include <tge/graphics/DX11.h>
#include <tge/graphics/GraphicsStateStack.h>
#include <tge/render/EffectMaterial.h>

using namespace Tga;

void NCE::RenderCommandExecutor::Execute(const NCE::RenderCommand& aCmd, Tga::GraphicsStateStack& aGraphicsStateStack)
{
    if (!aCmd.IsValid())
        return;

    // Set VFX data if needed
    if (aCmd.isVFX)
    {
        aGraphicsStateStack.SetVFXInstanceData(aCmd.vfxInstanceData);
    }

    // Set render states
    aGraphicsStateStack.SetRasterizerState(aCmd.rasterizerState);
    aGraphicsStateStack.SetBlendState(aCmd.blendState);
    aGraphicsStateStack.SetDepthStencilState(aCmd.depthStencilState);
    aGraphicsStateStack.SetObjectShouldFade(aCmd.shouldFade);

    // Bind effect material if present
    if (aCmd.effectMaterial)
    {
        aGraphicsStateStack.BindEffectMaterial(*const_cast<EffectMaterial*>(aCmd.effectMaterial));
    }

    if (aCmd.type == RenderCommandType::Mesh)
    {
        // Build texture array (use command textures if provided, else model defaults)
        const TextureResource* finalTextures[4];
        const TextureResource* const* defaultTextures = aCmd.model->GetDefaultTextures(aCmd.meshIndex);
        for (int i = 0; i < 4; i++)
        {
            finalTextures[i] = aCmd.textures[i] ? aCmd.textures[i] : defaultTextures[i];
        }

        const Model::MeshData& meshData = aCmd.GetMeshData();
        aCmd.shader->Render(finalTextures, meshData, aCmd.transform, aCmd.boneTransforms);
    }
    else if (aCmd.type == RenderCommandType::Sprite)
    {
        // Sprites are batched in ExecuteBatch, so this shouldn't be called directly
        // But if it is, we can render it individually
        auto& spriteDrawer = Engine::GetInstance()->GetGraphicsEngine().GetSpriteDrawer();
        SpriteBatchScope batch = spriteDrawer.BeginBatch(*aCmd.spriteSharedData);
        batch.Draw(&aCmd.spriteInstance, 1);
    }
    else if (aCmd.type == RenderCommandType::Decal)
    {
        const TextureResource* finalTextures[4];
        const TextureResource* const* defaultTextures = aCmd.model->GetDefaultTextures(aCmd.meshIndex);
        NCE::DecalData decalData = { .decalInverse = aCmd.transform.GetInverse() };
        for (int i = 0; i < 4; i++)
        {
            finalTextures[i] = aCmd.textures[i] ? aCmd.textures[i] : defaultTextures[i];
            decalData.texturesEnabled[i] = aCmd.texturesEnabled[i];
        }

        aGraphicsStateStack.SetDecalParameters(decalData);
        const Model::MeshData& meshData = aCmd.GetMeshData();
        aCmd.shader->Render(finalTextures, meshData, aCmd.transform, aCmd.boneTransforms);
    }

    // Unbind effect material if present
    if (aCmd.effectMaterial)
    {
        aGraphicsStateStack.UnbindEffectMaterial();
    }
}

void NCE::RenderCommandExecutor::ExecuteBatch(const std::vector<NCE::RenderCommand>& someCommands, GraphicsStateStack& aGraphicsStateStack)
{
    if (someCommands.empty())
    {
        return;
    }

    auto& engine = *Tga::Engine::GetInstance();
    auto& spriteDrawer = engine.GetGraphicsEngine().GetSpriteDrawer();

    // ***** GET CAMERA INFO FOR BILLBOARDING *****
    const Tga::Camera& camera = aGraphicsStateStack.GetCamera();
    const Tga::Vector3f cameraPos = camera.GetTransform().GetPosition();
    const Tga::Vector3f cameraUp = camera.GetTransform().GetUp();

    // Sprite batching state
    const Tga::SpriteSharedData* currentBatchShared = nullptr;
    std::vector<Tga::Sprite3DInstanceData> currentSpriteBatch;

    bool materialCurrentlyBound = false;

    auto FlushSpriteBatch = [&]()
        {
            if (currentSpriteBatch.empty())
            {
                return;
            }

            aGraphicsStateStack.SetRasterizerState(currentBatchShared->rasterizerState);
            aGraphicsStateStack.SetBlendState(currentBatchShared->blendState);
            aGraphicsStateStack.SetDepthStencilState(currentBatchShared->depthStencilState);
            aGraphicsStateStack.SetSamplerState(currentBatchShared->samplerFilter, SamplerAddressMode::Wrap);

			// Do not!!!!! remove the mosewings around the SpriteBatchScope. Rendering happens in the destructor of SpriteBatchScope....
		    {
            Tga::SpriteBatchScope batch = spriteDrawer.BeginBatch(*currentBatchShared);
            batch.Draw(currentSpriteBatch.data(), currentSpriteBatch.size());
		    }

            currentSpriteBatch.clear();
            currentBatchShared = nullptr;

            if (materialCurrentlyBound)
            {
                aGraphicsStateStack.UnbindEffectMaterial();
                materialCurrentlyBound = false;
            }
        };

    for (const auto& cmd : someCommands)
    {
        if (!cmd.IsValid())
        {
            continue;
        }

        // Set VFX data if needed
        if (cmd.isVFX)
        {
            aGraphicsStateStack.SetVFXInstanceData(cmd.vfxInstanceData);
        }

        // Bind effect material if present
        bool hasMaterial = cmd.effectMaterial != nullptr;

        if (cmd.type == RenderCommandType::Sprite)
        {

            // Wording is a bit off here but -> flush with old material state
            if (hasMaterial != materialCurrentlyBound)
        {
                FlushSpriteBatch();
        }

            // Flush if switching sprite shared data
            if (currentBatchShared != nullptr && currentBatchShared != cmd.spriteSharedData)
            {
                FlushSpriteBatch();
            }

            // Bind the corresponding material for the current batch
            if (hasMaterial && !materialCurrentlyBound)
            {
                aGraphicsStateStack.BindEffectMaterial(*cmd.effectMaterial);
                materialCurrentlyBound = true;
            }

            currentBatchShared = cmd.spriteSharedData;

            // ***** BILLBOARD *****
            Tga::Sprite3DInstanceData instance = cmd.spriteInstance;

            if (cmd.spriteSharedData->isBillboard)
            {
                const Tga::Vector3f pos = instance.myTransform.GetPosition();

                Tga::Vector3f forwardDir = (pos - cameraPos).GetNormalized();
                Tga::Vector3f rightDir = forwardDir.Cross(-1.f * cameraUp).GetNormalized();
                Tga::Vector3f upDir = forwardDir.Cross(rightDir).GetNormalized();

                float width = instance.mySize.x;
                float height = instance.mySize.y;

                instance.myTransform.SetPosition(
                    pos
                    - 0.5f * width * rightDir
                    + 0.5f * height * upDir
                    - 0.5f * forwardDir
                );

                instance.myTransform.SetRight(width * rightDir);
                instance.myTransform.SetUp(height * upDir);
                instance.myTransform.SetForward(forwardDir);
            }

            currentSpriteBatch.push_back(instance);
        }
        else if (cmd.type == RenderCommandType::Decal)
        {
            FlushSpriteBatch();
            const TextureResource* finalTextures[4];
            const TextureResource* const* defaultTextures = cmd.model->GetDefaultTextures(cmd.meshIndex);
            DecalData decalData = { .decalInverse = cmd.transform.GetInverse() };
            for (int i = 0; i < 4; i++)
            {
                finalTextures[i] = cmd.textures[i] ? cmd.textures[i] : defaultTextures[i];
                decalData.texturesEnabled[i] = cmd.texturesEnabled[i];
            }

            aGraphicsStateStack.SetDecalParameters(decalData);
            const Model::MeshData& meshData = cmd.GetMeshData();
            cmd.shader->Render(finalTextures, meshData, cmd.transform, cmd.boneTransforms);
        }
        else // Mesh
        {
            // Flush sprites before drawing mesh
            FlushSpriteBatch();

            if (hasMaterial)
            {
                aGraphicsStateStack.BindEffectMaterial(*cmd.effectMaterial);
            }

            aGraphicsStateStack.SetRasterizerState(cmd.rasterizerState);
            aGraphicsStateStack.SetBlendState(cmd.blendState);
            aGraphicsStateStack.SetDepthStencilState(cmd.depthStencilState);
            aGraphicsStateStack.SetObjectShouldFade(cmd.shouldFade);

            const TextureResource* finalTextures[4];
            const TextureResource* const* defaultTextures = cmd.model->GetDefaultTextures(cmd.meshIndex);
            for (int i = 0; i < 4; i++)
            {
                finalTextures[i] = cmd.textures[i] ? cmd.textures[i] : defaultTextures[i];
            }

            const Model::MeshData& meshData = cmd.GetMeshData();
            cmd.shader->Render(finalTextures, meshData, cmd.transform, cmd.boneTransforms);

        if (hasMaterial)
        {
            aGraphicsStateStack.UnbindEffectMaterial();
        }
    }
    }

    // Flush any remaining sprites
    FlushSpriteBatch();
}