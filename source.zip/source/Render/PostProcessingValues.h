#pragma once
//#pragma message(__FILE__" was compiled")
//enum class ResolutionRenderTargets
//{
//	Full,
//	Half,
//	Third,
//	Fourth,
//	Fifth,
//	Sixth,
//	Count,
//};

class PostProcessingValues
{
public:
	PostProcessingValues() = default;
	~PostProcessingValues() = default;

	void Init();

	void SetTint(Tga::Vector3f aTint);
	void SetBlackPoint(Tga::Vector3f aBlackPoint);
	void SetContrast(Tga::Vector3f aContrast);
	void SetExposure(float anExposure);
	void SetSaturation(float aSaturation);
	void SetBloomBlendingFactor(float aBloomBlendingFactor);
	void SetEmissiveFactor(float aEmissiveFactor);

	Tga::Vector3f GetTint() const;
	Tga::Vector3f GetBlackPoint() const;
	Tga::Vector3f GetContrast() const;
	float GetExposure() const;
	float GetSaturation() const;
	float GetBloomBlendingFactor() const;
	float GetEmissiveFactor() const;

private:
	Tga::Vector3f myTint;
	Tga::Vector3f myBlackPoint;
	Tga::Vector3f myContrast;
	float myExposure;
	float mySaturation;
	float myBloomBlendingFactor;
	float myEmissiveFactor;
};

