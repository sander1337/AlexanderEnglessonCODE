#pragma once

#include "../Graphics/VFXinfo.h"
#include <tge/model/Model.h>
#include <tge/shaders/ModelShader.h>
#include <tge/render/RenderCommon.h>
#include <tge/math/Matrix4x4.h>

class EffectMaterial;

namespace NCE
{
    enum class RenderCommandType
    {
        Mesh,
        Sprite,
        Decal
    };

    struct RenderCommand
    {
        RenderCommandType type = RenderCommandType::Mesh;

        // === MESH DATA ===
        const Tga::Model* model = nullptr;
        int meshIndex = 0;
        Tga::Matrix4x4f transform;
        const Tga::TextureResource* textures[4] = { nullptr };
        const Tga::ModelShader* shader = nullptr;
        const Tga::Matrix4x4f* boneTransforms = nullptr;

        // === SPRITE DATA ===
        const Tga::SpriteSharedData* spriteSharedData = nullptr;
        Tga::Sprite3DInstanceData spriteInstance;

        // === RENDER STATES ===
        Tga::RasterizerState rasterizerState = Tga::RasterizerState::BackfaceCulling;
        Tga::BlendState blendState = Tga::BlendState::Disabled;
        Tga::DepthStencilState depthStencilState = Tga::DepthStencilState::WriteLess;
        Tga::SamplerFilter samplerFilter = Tga::SamplerFilter::Trilinear;
        Tga::SamplerAddressMode samplerAddressMode = Tga::SamplerAddressMode::Wrap;

        // === OPTIONAL EXTRAS ===
        EffectMaterial* effectMaterial = nullptr;
        uint32_t texturesEnabled[4] = { false, false, false, false };

        // === VFX DATA ===
        bool isVFX = false;
        VFXInstanceData vfxInstanceData;

        // === SORTING/FILTERING ===
        float sortKey = 0.f;
        bool castsShadows = true;
        bool shouldFade = false;

        // Validation
        bool IsValid() const
        {
            if (type == RenderCommandType::Mesh || type == RenderCommandType::Decal)
            {
                return model != nullptr &&
                    meshIndex >= 0 &&
                    meshIndex < static_cast<int>(model->GetMeshCount()) &&
                    shader != nullptr;
            }
            else // Sprite
            {
                return spriteSharedData != nullptr;
            }
        }

        const Tga::Model::MeshData& GetMeshData() const
        {
            return model->GetMeshData(meshIndex);
        }

        // Helper: Create a copy with a different shader
        RenderCommand ApplyShader(const Tga::ModelShader* aNewShader) const
        {
            RenderCommand copy = *this;
            copy.shader = aNewShader;
            return copy;
        }

        // Helper: Create a copy with different render states
        RenderCommand ApplyStates(
            Tga::RasterizerState aRasterizerState,
            Tga::BlendState aBlendState,
            Tga::DepthStencilState aDepthStencilState) const
        {
            RenderCommand copy = *this;
            copy.rasterizerState = aRasterizerState;
            copy.blendState = aBlendState;
            copy.depthStencilState = aDepthStencilState;
            return copy;
        }
    };
}
