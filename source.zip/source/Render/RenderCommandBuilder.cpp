#include "stdafx.h"
#include "RenderCommandBuilder.h"

#include "Graphics/SpawnedObject.h"
#include "Objects/GameObject.h"
#include <tge/model/ModelInstance.h>
#include <tge/model/AnimatedModelInstance.h>
#include <tge/render/Decal.h>
//#include "../../source/Editor/TGEditor/Scene/SceneUtil.h"

std::vector<NCE::RenderCommand> NCE::RenderCommandBuilder::BuildFromGameObject(const GameObject& aObj)
{
    std::vector<RenderCommand> commands;

    // ***** HANDLE SPRITES *****
    if (aObj.GetRenderType() == RenderType::Sprite)
    {
        auto sprite3D = aObj.Get3DSpriteInstance();
        auto spriteSharedData = aObj.GetSpriteSharedData();

        if (!sprite3D || !spriteSharedData)
            return commands;

        RenderCommand cmd = {};
        cmd.type = RenderCommandType::Sprite;
        cmd.spriteSharedData = spriteSharedData;
        cmd.spriteInstance = *sprite3D;
        cmd.blendState = Tga::BlendState::AddAndFadeBackground;
        cmd.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;
        cmd.rasterizerState = Tga::RasterizerState::NoFaceCulling;

        // Effect material
        if (aObj.GetEffectMaterial())
        {
            cmd.effectMaterial = aObj.GetEffectMaterial().get();
        }

        commands.push_back(cmd);
        return commands;
    }

    // ***** HANDLE MODELS *****
    auto modelInstance = aObj.GetModelInstance();
    if (!modelInstance || !modelInstance->IsValid())
        return commands;

    const auto& model = modelInstance->GetModel();
    const size_t meshCount = model->GetMeshCount();
    commands.reserve(meshCount);

    // Determine shader based on animation
    const Tga::ModelShader* shader = modelInstance->GetShader().get();
    const Tga::Matrix4x4f* boneTransforms = nullptr;

    if (auto animatedModel = std::dynamic_pointer_cast<Tga::AnimatedModelInstance>(modelInstance))
    {
        boneTransforms = animatedModel->GetBoneTransforms();
    }

    for (size_t i = 0; i < meshCount; ++i)
    {
        RenderCommand cmd = {};
        cmd.type = RenderCommandType::Mesh;
        cmd.model = model.get();
        cmd.meshIndex = static_cast<int>(i);
        cmd.transform = modelInstance->GetTransform();
        cmd.shader = shader;
        cmd.boneTransforms = boneTransforms;
        cmd.rasterizerState = modelInstance->GetRasterizerState();
        cmd.blendState = modelInstance->GetBlendState();
        cmd.depthStencilState = Tga::DepthStencilState::WriteLessOrEqual;
        cmd.castsShadows = modelInstance->GetCastsShadow();
        cmd.shouldFade = aObj.GetShouldFade();

        // Copy textures
        const Tga::TextureResource* const* meshTextures = modelInstance->GetTextures(i);
        for (int j = 0; j < 4; ++j)
        {
            cmd.textures[j] = meshTextures[j];
        }

        // Effect material
        if (aObj.GetEffectMaterial())
        {
            cmd.effectMaterial = aObj.GetEffectMaterial().get();
        }

        commands.push_back(cmd);
    }

    return commands;
}

std::vector<NCE::RenderCommand> NCE::RenderCommandBuilder::BuildFromModelInstance(const Tga::ModelInstance& instance, const Tga::ModelShader* shaderOverride)
{
    std::vector<RenderCommand> commands;

    if (!instance.IsValid())
    {
        return commands;
    }

    auto model                          = instance.GetModel();
    const Tga::ModelShader* finalShader = shaderOverride ? shaderOverride : instance.GetShader().get();

    if (!finalShader)
    {
        return commands;
    }

    const size_t meshCount = model->GetMeshCount();
    commands.reserve(meshCount);

    for (size_t i = 0; i < meshCount; i++)
    {
        RenderCommand cmd = {};
        cmd.model = model.get();
        cmd.meshIndex = static_cast<int>(i);
        cmd.transform = instance.GetTransform();
        cmd.shader = finalShader;
        cmd.rasterizerState = instance.GetRasterizerState();
        cmd.blendState = instance.GetBlendState();
        cmd.castsShadows = instance.GetCastsShadow();

        // Copy textures for this mesh
        const Tga::TextureResource* const* meshTextures = instance.GetTextures(i);
        for (int j = 0; j < 4; j++)
        {
            cmd.textures[j] = meshTextures[j];
        }

        commands.push_back(cmd);
    }

    return commands;
}

std::vector<NCE::RenderCommand> NCE::RenderCommandBuilder::BuildFromAnimatedModelInstance(const Tga::AnimatedModelInstance& instance, const Tga::ModelShader* shaderOverride)
{
    std::vector<RenderCommand> commands;

    if (!instance.IsValid())
    {
        return commands;
    }

    auto model                          = instance.GetModel();
    const Tga::ModelShader* finalShader = shaderOverride ? shaderOverride : instance.GetShader().get();

    if (!finalShader)
    {
        return commands;
    }

    const size_t meshCount = model->GetMeshCount();
    commands.reserve(meshCount);

    // Get bone transforms
    const Tga::Matrix4x4f* boneTransforms = instance.GetBoneTransforms();

    for (size_t i = 0; i < meshCount; i++)
    {
        RenderCommand cmd = {};
        cmd.model = model.get();
        cmd.meshIndex = static_cast<int>(i);
        cmd.transform = instance.GetTransform();
        cmd.shader = finalShader;
        cmd.rasterizerState = instance.GetRasterizerState();
        cmd.blendState = instance.GetBlendState();
        cmd.castsShadows = instance.GetCastsShadow();
        cmd.boneTransforms = boneTransforms;

        // Copy textures for this mesh
        const Tga::TextureResource* const* meshTextures = instance.GetTextures(i);
        for (int j = 0; j < 4; j++)
        {
            cmd.textures[j] = meshTextures[j];
        }

        commands.push_back(cmd);
    }

    return commands;
}

std::vector<NCE::RenderCommand> NCE::RenderCommandBuilder::BuildFromSpawnedObject(const SpawnedObject& aSpawnedObject)
{
    std::vector<NCE::RenderCommand> commands;

    if (aSpawnedObject.GetVFXType() == VFXType::Model)
    {
        // Build model commands
        auto modelInstance = aSpawnedObject.GetModelInstancePtr();
        if (!modelInstance || !modelInstance->IsValid())
            return commands;

        const auto& model = modelInstance->GetModel();
        const size_t meshCount = model->GetMeshCount();
        commands.reserve(meshCount);

        for (size_t i = 0; i < meshCount; ++i)
        {
	        NCE::RenderCommand cmd = {};
            cmd.type               = NCE::RenderCommandType::Mesh;
            cmd.model              = model.get();
            cmd.meshIndex          = static_cast<int>(i);
            cmd.transform          = aSpawnedObject.GetTransform();
            cmd.shader             = modelInstance->GetShader().get();
            cmd.rasterizerState    = modelInstance->GetRasterizerState();
            cmd.blendState         = modelInstance->GetBlendState();
            cmd.depthStencilState  = Tga::DepthStencilState::ReadOnlyLess;

            // Copy textures
            const Tga::TextureResource* const* meshTextures = modelInstance->GetTextures(i);
            for (int j = 0; j < 4; ++j)
            {
                cmd.textures[j] = meshTextures[j];
            }

            // VFX data
            cmd.isVFX = true;
            cmd.vfxInstanceData.color = aSpawnedObject.GetColor();
            cmd.vfxInstanceData.lifetime = aSpawnedObject.GetLifetime();
            cmd.vfxInstanceData.timeSpawned = aSpawnedObject.GetSpawnedTime();

            // Effect material
            if (aSpawnedObject.GetEffectMaterial())
            {
                cmd.effectMaterial = aSpawnedObject.GetEffectMaterial().get();
            }

            commands.push_back(cmd);
        }
    }
    else if (aSpawnedObject.GetVFXType() == VFXType::Sprite)
    {
        // Build sprite command
        NCE::RenderCommand cmd     = {};
        cmd.type              = NCE::RenderCommandType::Sprite;
        cmd.spriteSharedData  = aSpawnedObject.GetSpriteSharedData();
        cmd.spriteInstance    = *aSpawnedObject.Get3DSpriteInstance();
        cmd.spriteInstance.myTransform  = aSpawnedObject.GetTransform();

        // VFX data
        cmd.isVFX = true;
        cmd.vfxInstanceData.color = aSpawnedObject.GetColor();
        cmd.vfxInstanceData.lifetime = aSpawnedObject.GetLifetime();
        cmd.vfxInstanceData.timeSpawned = aSpawnedObject.GetSpawnedTime();

        // Effect material
        if (aSpawnedObject.GetEffectMaterial())
        {
            cmd.effectMaterial = aSpawnedObject.GetEffectMaterial().get();
        }

        commands.push_back(cmd);
    }

    return commands;
}

std::vector<NCE::RenderCommand> NCE::RenderCommandBuilder::BuildFromDecal(const NCE::Decal& aDecal)
{
    std::vector<RenderCommand> commands;

    if (!aDecal.GetModelInstance().IsValid())
    {
        return commands;
    }

    RenderCommand cmd = {};
    cmd.type = RenderCommandType::Decal;
    cmd.model = aDecal.GetModelInstance().GetModel().get();
    cmd.meshIndex = 0;
    cmd.transform = aDecal.GetTransform();
    cmd.shader = aDecal.GetModelInstance().GetShader().get();
    cmd.rasterizerState = Tga::RasterizerState::FrontfaceCulling;
    cmd.blendState = Tga::BlendState::AlphaBlend;
    cmd.depthStencilState = Tga::DepthStencilState::ReadOnlyLessOrEqual;
    cmd.texturesEnabled[0] = aDecal.GetTextureIsEnabled(GBuffer::GBufferTexture::Albedo);
    cmd.texturesEnabled[1] = aDecal.GetTextureIsEnabled(GBuffer::GBufferTexture::Normal);
    cmd.texturesEnabled[2] = aDecal.GetTextureIsEnabled(GBuffer::GBufferTexture::Material);
    cmd.texturesEnabled[3] = aDecal.GetTextureIsEnabled(GBuffer::GBufferTexture::FX);

    for (int i = 0; i < 4; ++i)
    {
        cmd.textures[i] = aDecal.GetModelInstance().GetTextures(0)[i];
    }

    commands.push_back(cmd);
    return commands;
}
