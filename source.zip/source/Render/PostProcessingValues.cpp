#include "stdafx.h"
#include "PostProcessingValues.h"

void PostProcessingValues::Init()
{
	SetBlackPoint(Tga::Vector3f{ 0.f, 0.f, 0.f });
	SetContrast({ 1.f, 1.f, 1.f });
	SetTint(Tga::Vector3f{ 1.f, 1.f, 1.f });
	SetExposure(0.f);
	SetSaturation(1.f);
	SetBloomBlendingFactor(0.2f);
	SetEmissiveFactor(1.f);
}

void PostProcessingValues::SetTint(Tga::Vector3f aTint)
{
	myTint = aTint;
}

void PostProcessingValues::SetBlackPoint(Tga::Vector3f aBlackPoint)
{
	myBlackPoint = aBlackPoint;
}

void PostProcessingValues::SetContrast(Tga::Vector3f aContrast)
{
	myContrast = aContrast;
}

void PostProcessingValues::SetExposure(float anExposure)
{
	myExposure = anExposure;
}

void PostProcessingValues::SetSaturation(float aSaturation)
{
	mySaturation = aSaturation;
}

void PostProcessingValues::SetBloomBlendingFactor(float aBloomBlendingFactor)
{
	myBloomBlendingFactor = aBloomBlendingFactor;
}

void PostProcessingValues::SetEmissiveFactor(float aEmissiveFactor)
{
	myEmissiveFactor = aEmissiveFactor;
}

Tga::Vector3f PostProcessingValues::GetTint() const
{
	return myTint;
}

Tga::Vector3f PostProcessingValues::GetBlackPoint() const
{
	return myBlackPoint;
}

Tga::Vector3f PostProcessingValues::GetContrast() const
{
	return myContrast;
}

float PostProcessingValues::GetExposure() const
{
	return myExposure;
}

float PostProcessingValues::GetSaturation() const
{
	return mySaturation;
}

float PostProcessingValues::GetBloomBlendingFactor() const
{
	return myBloomBlendingFactor;
}

float PostProcessingValues::GetEmissiveFactor() const
{
	return myEmissiveFactor;
}
