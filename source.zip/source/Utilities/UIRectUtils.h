#pragma once
#include <tge/math/vector2.h>

struct Rect
{
    Tga::Vector2f min;
    Tga::Vector2f max;
};

inline float Clamp01(float v)
{
    return std::max(0.f, std::min(1.f, v));
}

inline Rect MakeRectCenterSize(const Tga::Vector2f& c, float w, float h)
{
    const Tga::Vector2f half{ w * 0.5f, h * 0.5f };
    return { c - half, c + half };
}

inline bool PointInRectCenterSize(const Tga::Vector2f& p, const Tga::Vector2f& c, const Tga::Vector2f& size)
{
    const Tga::Vector2f h{ size.x * 0.5f, size.y * 0.5f };
    return p.x >= c.x - h.x && p.x <= c.x + h.x &&
        p.y >= c.y - h.y && p.y <= c.y + h.y;
}

inline bool Overlaps(const Rect& a, const Rect& b)
{
    return !(a.max.x <= b.min.x || a.min.x >= b.max.x ||
        a.max.y <= b.min.y || a.min.y >= b.max.y);
}

inline bool PointInAabb(const Tga::Vector2f& p, const Tga::Vector2f& mn, const Tga::Vector2f& mx)
{
    return p.x >= mn.x && p.x <= mx.x &&
        p.y >= mn.y && p.y <= mx.y;
}

inline bool PointInRect(const Tga::Vector2f& p, const Rect& r)
{
    return PointInAabb(p, r.min, r.max);
}
