﻿#pragma once
#include <string>
#include <cstdio>      // sprintf_s
#include <tge/text/text.h>
#include "../States/ActionBars/ActionBarSpell.h" // adjust path if needed

namespace UI
{
    inline std::string FormatManaLine(const ActionBarSpell& s)
    {
        if (s.manaCost <= 0) return "";
        return std::to_string(s.manaCost) + " Mana";
    }

    inline std::string FormatCastLine(const ActionBarSpell& s)
    {
        if (s.castTime <= 0.f) return "Instant cast";
        char buf[64];
        sprintf_s(buf, "%.2f sec cast", s.castTime);
        return std::string(buf);
    }

    inline std::string WrapTextToWidth(
        Tga::Text& measureText,
        const std::string& in,
        float maxWidthPx)
    {
        if (in.empty()) return "";

        std::string out;
        std::string line;
        std::string word;

        auto lineWidth = [&](const std::string& s)
            {
                measureText.SetText(s.c_str());
                return measureText.GetWidth();
            };

        auto flushWord = [&]()
            {
                if (word.empty()) return;

                std::string testLine = line.empty() ? word : (line + " " + word);

                if (lineWidth(testLine) <= maxWidthPx)
                {
                    line = testLine;
                }
                else
                {
                    // ✅ avoid emitting empty line (causes "pushed down")
                    if (line.empty())
                    {
                        line = word;
                    }
                    else
                    {
                        if (!out.empty()) out += "\n";
                        out += line;
                        line = word;
                    }
                }

                word.clear();
            };

        for (char c : in)
        {
            if (c == '\n')
            {
                flushWord();
                if (!out.empty()) out += "\n";
                out += line;
                line.clear();
            }
            else if (c == ' ')
            {
                flushWord();
            }
            else
            {
                word.push_back(c);
            }
        }

        flushWord();

        if (!line.empty())
        {
            if (!out.empty()) out += "\n";
            out += line;
        }

        return out;
    }

    inline void SetTextCentered(Tga::Text& t, const Tga::Vector2f& center)
    {
        // Text position is TOP-LEFT, so we offset by half width/height
        // Height isn't exposed? If not, approximate with font size.
        const float w = t.GetWidth();

        // If you don't have GetHeight(), use a tuned constant per font size:
        const float approxH = 24.f; // tweak if FontSize_24, otherwise adjust

        t.SetPosition({ center.x - w * 0.5f, center.y - approxH * 0.5f });
    }

    // Wrap using your existing WrapTextToWidth function (the one you moved to UI namespace).
    inline void SetWrappedTextLeft(Tga::Text& t, Tga::Text& measure, const std::string& s,
        float maxWidth, const Tga::Vector2f& topLeft)
    {
        t.SetText(WrapTextToWidth(measure, s, maxWidth).c_str());
        t.SetPosition(topLeft);
    }

    inline void SetTextCenteredX(Tga::Text& t, float centerX, float y)
    {
        t.SetPosition({ centerX - t.GetWidth() * 0.5f, y });
    }

    inline void SetTextCenteredXYApprox(Tga::Text& t, const Tga::Vector2f& center, float approxH)
    {
        t.SetPosition({ center.x - t.GetWidth() * 0.5f, center.y - approxH * 0.5f });
    }
}
