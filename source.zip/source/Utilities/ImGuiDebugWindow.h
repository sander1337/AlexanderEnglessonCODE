#pragma once
class Player;
class RenderManager;
class StateStack;

class ImGuiDebugWindow
{
public:
	ImGuiDebugWindow() = default;
	~ImGuiDebugWindow() = default;

	 void DrawEnemiesTab();
     void DrawCameraTab(const StateStack& aStateStack);
	 void DrawLightsTab(RenderManager& aRenderManager, const StateStack& aStateStack);
	 void DrawLevelSelectTab(const StateStack& aStateStack);
     void DrawPlayerTab(const StateStack& aStateStack);
	 void DrawPostProcessingTab(RenderManager& aRenderManager);
	 void DrawDebugDrawingTab(RenderManager& aRenderManager);
	 void DrawOptions(RenderManager& aRenderManager);

private:
};

