#pragma once
//#pragma message(__FILE__" was compiled")
#include <memory>


namespace Utilities
{
	class EnableSharedFromThisBase : public std::enable_shared_from_this<EnableSharedFromThisBase>
	{
	public:
		virtual ~EnableSharedFromThisBase() = default;
	};
	template<typename T>
	class EnableSharedFromThis : public virtual EnableSharedFromThisBase
	{
	public:
		//Function hides the one from the standard library
		std::shared_ptr<T> shared_from_this()
		{
			return std::dynamic_pointer_cast<T>(EnableSharedFromThisBase::shared_from_this());
		}
		//Function hides the one from the standard library
		std::shared_ptr<const T> shared_from_this() const
		{
			return std::dynamic_pointer_cast<const T>(EnableSharedFromThisBase::shared_from_this());
		}
		//Function hides the one from the standard library
		std::weak_ptr<T> weak_from_this()
		{
			return std::weak_ptr<T>(std::dynamic_pointer_cast<T>(EnableSharedFromThisBase::shared_from_this()));
		}
		//Function hides the one from the standard library
		std::weak_ptr<const T> weak_from_this() const
		{
			return std::weak_ptr<const T>(std::dynamic_pointer_cast<const T>(EnableSharedFromThisBase::shared_from_this()));
		}
	};
}