#include "stdafx.h"
#include "PollingStation.h"

#include "../source/Objects/Actors/Player/Player.h"

inline void AI::PollingStation3D::UpdateActorPos(Actor* anID, const Tga::Vector3f& aPos, float aRadius)
{
	myActorID_Pos[anID] = aPos;
	myActorRadii[anID] = aRadius;
}

void AI::PollingStation3D::SetHurtActorInfo(Actor* anActor, HurtInfo& someInfo)
{
	if (myHurtActors.contains(anActor))
	{
		if (someInfo.health > 0)
		{
			myHurtActors[anActor] = someInfo;
		}
		else
		{
			myHurtActors.erase(anActor);
		}
	}
	else if (someInfo.health > 0)
	{
		myHurtActors.try_emplace(anActor, someInfo);
	}
}

void AI::PollingStation3D::UpdateCurrentSceneID(SceneID& aSceneID)
{
	myCurrentSceneID = aSceneID;
}

SceneID& AI::PollingStation3D::GetCurrentSceneID()
{
	return myCurrentSceneID;
}

void AI::PollingStation3D::SetPlayerPtr(Player* aPlayerPtr)
{
	myPlayerPtr = aPlayerPtr;
}

Player* AI::PollingStation3D::GetPlayer()
{
	return myPlayerPtr;
}