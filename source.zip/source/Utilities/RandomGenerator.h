#pragma once
//#pragma message(__FILE__" was compiled")
#include <random>
#include <tge/math/vector2.h>

class RandomGenerator
{
public:
	~RandomGenerator();
	RandomGenerator(const RandomGenerator&)            = delete;
	RandomGenerator& operator=(const RandomGenerator&) = delete;

	static RandomGenerator* GetInstance();

	[[nodiscard]] static int GetInt(int aMinInt, int aMaxInt);
	[[nodiscard]] static float GetFloat(float aMinFloat, float aMaxFloat);
	static bool GetBool();
	Tga::Vector2f Get2DScreenPosition(float aMaxXScreen, float aMaxYScreen);
	float GetBinomial();
	Tga::Vector2f Get2DVelocity(float aMinXValue, float aMaxXValue, float aMinYValue, float aMaxYValue);

private:
	RandomGenerator();

	static RandomGenerator* myInstance;
	static std::random_device myRandomDevice;
	static std::mt19937 myGenerator;
};

