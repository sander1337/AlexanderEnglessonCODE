
#include "stdafx.h"
#include "ImGuiDebugWindow.h"

#include "PollingStation.h"
#include "../source/Objects/Actors/Actor.h"
#include "../States/StateStack.h"
#include "../Render/RenderManager.h"
#include "../States/InGame.h"
#include "../source/Events/EventManager.h"
#include <imgui/imgui.h>
#include "../source/SceneManagement/SceneID.h"
#include <tge/graphics/AmbientLight.h>
#include <tge/graphics/DirectionalLight.h>
#include "../SceneManagement/RunTimeScene.h"
#include "../SceneManagement/GameScene.h"

#include <tge/graphics/PointLight.h>
#include "../source/Utilities/BlackBoard.h"
#include "Objects/Actors/Player/Player.h"

class Actor;


void ImGuiDebugWindow::DrawEnemiesTab()
{
	ImGui::Text("Enemy Debug Options");
	ImGui::Separator();
}

void ImGuiDebugWindow::DrawCameraTab(const StateStack& aStateStack)
{
	std::shared_ptr<Tga::Camera> sceneCamera = aStateStack.GetCurrentState()->GetScene().lock()->GetActiveCamera();

	static Tga::Vector3f rotation = sceneCamera->GetTransform().GetRotationAsQuaternion().GetYawPitchRoll();

	if (ImGui::DragFloat3("Rotation", &rotation.x, 1.f, -180.f, 180.f))
		sceneCamera->GetTransform().SetRotation(rotation);

	float xOffset = sceneCamera->GetXOffsetFromPlayer();
	if (ImGui::DragFloat("X offset from player", &xOffset, 1.f, -1500.f, 1500.f))
		sceneCamera->SetXOffsetFromPlayer(xOffset);

	float yOffset = sceneCamera->GetYOffsetFromPlayer();
	if (ImGui::DragFloat("Y offset from player", &yOffset, 1.f, 0.f, 1500.f))
		sceneCamera->SetYOffsetFromPlayer(yOffset);

	float zOffset = sceneCamera->GetZOffsetFromPlayer();
	if (ImGui::DragFloat("Z offset from player", &zOffset, 1.f, -1500.f, 1500.f))
		sceneCamera->SetZOffsetFromPlayer(zOffset);
}

void ImGuiDebugWindow::DrawLightsTab(RenderManager& aRenderManager, const StateStack& aStateStack)
{
	NCE::RenderResources& renderResources = aRenderManager.GetRenderResources();

	if (renderResources.directionalLight == nullptr || renderResources.ambientLight == nullptr) return;
	// --- Directional light ---
	Tga::Vector3f directionalLightRotation = renderResources.directionalLight->GetRotation();
	if (ImGui::DragFloat3("Main Directional Rotation", &directionalLightRotation.x, 0.1f, -180.f, 180.f, "%.2f"))
	{
		renderResources.directionalLight->SetRotation(directionalLightRotation);
		renderResources.directionalLight->GetTransform().SetRotation(directionalLightRotation);
	}

	Tga::Color directionalLightColor = renderResources.directionalLight->GetColor();
	if (ImGui::ColorEdit3("Main Directional Color", &directionalLightColor.r, ImGuiColorEditFlags_Float))
	{
		renderResources.directionalLight->SetColor(directionalLightColor);
	}

	Tga::DirectionalLight& sun = *renderResources.directionalLight;

	float sunIntensity = sun.GetIntensity();
	if (ImGui::DragFloat("Sun Intensity", &sunIntensity, 0.01f, 0.0f, 100.0f, "%.2f"))
	{
		sun.SetIntensity(sunIntensity);
		ImGui::SameLine();
		ImGui::TextDisabled("(%.0f%%)", sunIntensity); // show percent relative to 100
	}

	float shadowMin = sun.GetShadowMinFactor();
	if (ImGui::DragFloat("Shadow Intensity", &shadowMin, 0.01f, 0.0f, 1.0f, "%.2f"))
	{
		sun.SetShadowMinFactor(shadowMin);
	}

	// --- Ambient light ---
	Tga::AmbientLight& amb = *renderResources.ambientLight;
	float ambIntensity = amb.GetIntensity();
	if (ImGui::DragFloat("Ambient Intensity", &ambIntensity, 10.0f, 0.0f, 10000.0f, "%.2f"))
	{
		amb.SetIntensity(ambIntensity);
		ImGui::SameLine();
		ImGui::TextDisabled("(%.0f%%)", ambIntensity * 2.0f);
	}

	// --- Directional Lights ---
	GameScene& gameScene = *std::dynamic_pointer_cast<GameScene>(aStateStack.GetCurrentState()->GetScene().lock());
	auto& directionalLights = gameScene.GetDirectionalLights();

	if (!directionalLights.empty() && ImGui::CollapsingHeader("Directional Volume Lights", ImGuiTreeNodeFlags_DefaultOpen))
	{
		Tga::Color commonColor = directionalLights[0]->GetColor();
		float commonIntensity = directionalLights[0]->GetIntensity();
		float commonRange = directionalLights[0]->GetRange();

		bool colorChanged = ImGui::ColorEdit3("Color##Directional", &commonColor.r, ImGuiColorEditFlags_Float);

		// Fine-tuned intensity: 0 - 10
		bool intensityChanged = ImGui::DragFloat(
			"Intensity##Directional",
			&commonIntensity,
			0.01f,   // drag speed (fine)
			0.0f,
			10.0f,
			"%.3f"
		);

		// Less fine-tuned range
		bool rangeChanged = ImGui::DragFloat(
			"Range##Directional",
			&commonRange,
			5.0f,   // faster change
			0.0f,
			10000.0f,
			"%.1f"
		);

		if (colorChanged || intensityChanged || rangeChanged)
		{
			for (auto& light : directionalLights)
			{
				if (colorChanged)
					light->SetColor(commonColor);
				if (intensityChanged)
					light->SetIntensity(commonIntensity);
				if (rangeChanged)
					light->SetRange(commonRange);
			}
		}
	}

	auto& pointLights = gameScene.GetPointLights();

	if (!pointLights.empty() && ImGui::CollapsingHeader("Point Lights", ImGuiTreeNodeFlags_DefaultOpen))
	{
		Tga::Color commonColor = pointLights[0]->GetColor();
		float commonIntensity = pointLights[0]->GetIntensity();
		float commonRange = pointLights[0]->GetRange();

		bool colorChanged = ImGui::ColorEdit3("Color##Point", &commonColor.r, ImGuiColorEditFlags_Float);

		bool intensityChanged = ImGui::DragFloat(
			"Intensity##Point",
			&commonIntensity,
			0.1f,
			0.0f,
			100.0f,
			"%.2f"
		);

		bool rangeChanged = ImGui::DragFloat(
			"Range##Point",
			&commonRange,
			2.0f,
			0.0f,
			5000.0f,
			"%.1f"
		);

		if (colorChanged || intensityChanged || rangeChanged)
		{
			for (auto& light : pointLights)
			{
				if (colorChanged)
					light->SetColor(commonColor);
				if (intensityChanged)
					light->SetIntensity(commonIntensity);
				if (rangeChanged)
					light->SetRange(commonRange);
			}
		}
	}
}

void ImGuiDebugWindow::DrawLevelSelectTab(const StateStack& aStateStack)
{
	static int currentIndex = 0;
	const char* levelNames[] = {"Level1", "Level2", "Asset Gym", "Player Gym", "AI Gym", "Animation Gym", "VFX Gym" };

	if (ImGui::Combo("Select Level", &currentIndex, levelNames, IM_ARRAYSIZE(levelNames)))
	{
		InGame* inGameState = dynamic_cast<InGame*>(aStateStack.GetCurrentState());
		if (inGameState)
		{
			switch (currentIndex)
			{
			case 0: inGameState->SwitchLevel(SceneID::Level1); break;
			case 1: inGameState->SwitchLevel(SceneID::Level2); break;
			case 2: inGameState->SwitchLevel(SceneID::AssetGym); break;
			case 3: inGameState->SwitchLevel(SceneID::PlayerGym); break;
			case 4: inGameState->SwitchLevel(SceneID::AIGym); break;
			case 5: inGameState->SwitchLevel(SceneID::AnimationGym); break;
			case 6: inGameState->SwitchLevel(SceneID::VFXGym); break;
			}
		}
	}
}

void ImGuiDebugWindow::DrawPlayerTab(const StateStack& /*aStateStack*/)
{
	ImGui::Text("Player Stats_____");

	Player* player = AI::PollingStation3D::Get().GetPlayer();
	if (!player)
	{
		ImGui::Text("No player found");
		return;
	}

	ImGui::Text("Health: %i", player->GetHealth());
	if (ImGui::SmallButton("-10 Health"))
	{
		player->TakeDamage(10);
		player->SendHealthEvent();
	}
	ImGui::SameLine();
	if (ImGui::SmallButton("+10 Health"))
	{
		player->ReceiveHealing(10);
		player->SendHealthEvent();
	}
	ImGui::Separator();

	PlayerWeapons& weapons = player->GetWeapons();          // <-- NEW
	const PlayerWeapons& cweapons = player->GetWeapons();   // const view if you want

	if (ImGui::CollapsingHeader("Weapons & Ammo", ImGuiTreeNodeFlags_DefaultOpen))
	{
		const WeaponType equipped = weapons.GetEquippedType();

		if (ImGui::BeginTable("WeaponAmmoTable", 6,
			ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg | ImGuiTableFlags_Resizable))
		{
			ImGui::TableSetupColumn("Equipped");
			ImGui::TableSetupColumn("Weapon");
			ImGui::TableSetupColumn("Mag");
			ImGui::TableSetupColumn("Reserve");
			ImGui::TableSetupColumn("Reloading");
			ImGui::TableSetupColumn("Actions");
			ImGui::TableHeadersRow();

			const int weaponCount = static_cast<int>(WeaponType::Count);

			for (int i = 0; i < weaponCount; ++i)
			{
				const WeaponType wt = static_cast<WeaponType>(i);
				const WeaponDef def = cweapons.GetDef(wt);
				const auto& a = cweapons.GetAmmo(wt); // WeaponAmmoState from PlayerWeapons.h

				ImGui::TableNextRow();

				ImGui::TableSetColumnIndex(0);
				ImGui::TextUnformatted((wt == equipped) ? ">>" : "");

				ImGui::TableSetColumnIndex(1);
				ImGui::Text("%s", PlayerWeapons::ToString(wt));

				ImGui::TableSetColumnIndex(2);
				ImGui::Text("%d / %d", a.mag, def.magSize);

				ImGui::TableSetColumnIndex(3);
				ImGui::Text("%d / %d", a.reserve, def.maxReserve);

				ImGui::TableSetColumnIndex(4);
				if (a.reloading)
					ImGui::Text("YES (%.2fs)", a.reloadTimer);
				else
					ImGui::TextUnformatted("no");

				ImGui::TableSetColumnIndex(5);

				ImGui::PushID(i);

				if (ImGui::SmallButton("+1 Mag"))
					weapons.DebugAddAmmo(wt, +1, 0);
				ImGui::SameLine();
				if (ImGui::SmallButton("-1 Mag"))
					weapons.DebugAddAmmo(wt, -1, 0);

				ImGui::SameLine();
				if (ImGui::SmallButton("+10 Res"))
					weapons.DebugAddAmmo(wt, 0, +10);
				ImGui::SameLine();
				if (ImGui::SmallButton("-10 Res"))
					weapons.DebugAddAmmo(wt, 0, -10);

				ImGui::PopID();
			}

			ImGui::EndTable();
		}

		ImGui::Separator();

		// ---- Edit specific weapon ----
		static int selectedWeaponIndex = 0;
		const int weaponCount = static_cast<int>(WeaponType::Count);
		ImGui::SliderInt("Selected weapon index", &selectedWeaponIndex, 0, weaponCount - 1);

		const WeaponType selWt = static_cast<WeaponType>(selectedWeaponIndex);
		const WeaponDef selDef = cweapons.GetDef(selWt);
		const auto& selAmmo = cweapons.GetAmmo(selWt);

		ImGui::Text("Selected: %s", PlayerWeapons::ToString(selWt));

		// IMPORTANT: don't overwrite the input every frame, it makes InputInt unusable.
		static int newMag = 0;
		static int newReserve = 0;
		static int lastIndex = -1;

		if (lastIndex != selectedWeaponIndex)
		{
			lastIndex = selectedWeaponIndex;
			newMag = selAmmo.mag;
			newReserve = selAmmo.reserve;
		}

		ImGui::InputInt("Set Mag", &newMag);
		ImGui::InputInt("Set Reserve", &newReserve);

		if (ImGui::Button("Apply Set"))
			weapons.DebugSetAmmo(selWt, newMag, newReserve);

		ImGui::SameLine();
		if (ImGui::Button("Fill Mag"))
			weapons.DebugSetAmmo(selWt, selDef.magSize, selAmmo.reserve);

		ImGui::SameLine();
		if (ImGui::Button("Fill Reserve"))
			weapons.DebugSetAmmo(selWt, selAmmo.mag, selDef.maxReserve);
	}
}


void ImGuiDebugWindow::DrawPostProcessingTab(RenderManager& aRenderManager)
{
	NCE::RenderResources& renderResources = aRenderManager.GetRenderResources();

	// ---------------------------------------
	// Bloom
	// ---------------------------------------
	{
		float bloom = renderResources.postProcessingValues.GetBloomBlendingFactor();
		ImGui::Text("Bloom");
		ImGui::SameLine();
		ImGui::SliderFloat("##Bloom", &bloom, 0.0f, 1.0f, "%.3f", ImGuiSliderFlags_AlwaysClamp);

		if (ImGui::IsItemHovered())
		{
			ImGui::SetTooltip("Controls how much the bright areas bleed into surrounding pixels.\n"
				"0 = No bloom\n"
				"1 = Very strong glow");
		}

		renderResources.postProcessingValues.SetBloomBlendingFactor(bloom);
	}


	// ---------------------------------------
	// Exposure
	// ---------------------------------------
	{
		float exposure = renderResources.postProcessingValues.GetExposure();
		ImGui::Text("Exposure");
		ImGui::SameLine();
		ImGui::SliderFloat("##Exposure", &exposure, -2.0f, 4.0f, "%.3f", ImGuiSliderFlags_AlwaysClamp);

		if (ImGui::IsItemHovered())
		{
			ImGui::SetTooltip("Overall scene brightness.\n"
				"Negative = darker\n"
				"Positive = brighter\n"
				"Typical usable range: [-1, 2]");
		}

		renderResources.postProcessingValues.SetExposure(exposure);
	}


	// ---------------------------------------
	// Saturation
	// ---------------------------------------
	{
		float sat = renderResources.postProcessingValues.GetSaturation();
		ImGui::Text("Saturation");
		ImGui::SameLine();
		ImGui::SliderFloat("##Saturation", &sat, 0.0f, 3.0f, "%.3f", ImGuiSliderFlags_AlwaysClamp);

		if (ImGui::IsItemHovered())
		{
			ImGui::SetTooltip("Color intensity.\n"
				"0 = grayscale\n"
				"1 = normal colors\n"
				"2+ = very vivid");
		}

		renderResources.postProcessingValues.SetSaturation(sat);
	}


	// ---------------------------------------
	// Contrast
	// ---------------------------------------
	{
		Tga::Vector3f contrast = renderResources.postProcessingValues.GetContrast();
		ImGui::Text("Contrast (RGB)");
		ImGui::SliderFloat3("##Contrast", &contrast.x, 0.5f, 2.0f, "%.3f", ImGuiSliderFlags_AlwaysClamp);

		if (ImGui::IsItemHovered())
		{
			ImGui::SetTooltip("How strong the difference between light and dark is.\n"
				"1 = neutral\n"
				"<1 = flatter\n"
				">1 = punchier contrast\n"
				"Per-channel control allows color grading.");
		}

		renderResources.postProcessingValues.SetContrast(contrast);
	}


	// ---------------------------------------
	// Tint
	// ---------------------------------------
	{
		Tga::Vector3f tint = renderResources.postProcessingValues.GetTint();
		ImGui::Text("Tint (RGB)");
		ImGui::SliderFloat3("##Tint", &tint.x, 0.0f, 2.0f, "%.3f", ImGuiSliderFlags_AlwaysClamp);

		if (ImGui::IsItemHovered())
		{
			ImGui::SetTooltip("Color tint applied after tonemapping.\n"
				"1 = neutral\n"
				"<1 dips channel intensity\n"
				">1 boosts channel intensity.\n"
				"Common for warm/cold grading.");
		}

		renderResources.postProcessingValues.SetTint(tint);
	}


	// ---------------------------------------
	// Black Point
	// ---------------------------------------
	{
		Tga::Vector3f bp = renderResources.postProcessingValues.GetBlackPoint();
		ImGui::Text("Black Point (RGB)");
		ImGui::SliderFloat3("##BlackPoint", &bp.x, -0.2f, 0.5f, "%.3f", ImGuiSliderFlags_AlwaysClamp);

		if (ImGui::IsItemHovered())
		{
			ImGui::SetTooltip("Shifts the darkness floor.\n"
				"Lower values deepen blacks.\n"
				"Higher values fade blacks toward gray.\n");
		}

		renderResources.postProcessingValues.SetBlackPoint(bp);
	}

	// ---------------------------------------
	// Emissivefactor
	// ---------------------------------------
	{
		float emissive = renderResources.postProcessingValues.GetEmissiveFactor();
		ImGui::Text("Emissive Factor");
		ImGui::SameLine();
		ImGui::SliderFloat("##EmissiveFactor", &emissive, 0.0f, 100.0f, "%.3f", ImGuiSliderFlags_AlwaysClamp);

		if (ImGui::IsItemHovered())
		{
			ImGui::SetTooltip("Emissive Factor.\n"
				"How vivid the Emissive textures look\n");
		}

		renderResources.postProcessingValues.SetEmissiveFactor(emissive);
	}
}

void ImGuiDebugWindow::DrawDebugDrawingTab(RenderManager& aRenderManager)
{
	bool drawNavMesh = aRenderManager.GetDrawNavMesh();
	if (ImGui::Checkbox("Draw Navmesh", &drawNavMesh))
	{
		aRenderManager.SetDrawNavMesh(drawNavMesh);
	}
	bool drawPortals = aRenderManager.GetDrawNavMeshPortals();
	if (ImGui::Checkbox("Draw Navmesh Portals", &drawPortals))
	{
		aRenderManager.SetDrawNavMeshPortals(drawPortals);
	}

	bool drawColliders = aRenderManager.GetDrawColliders();
	if (ImGui::Checkbox("Draw Colliders", &drawColliders))
	{
		aRenderManager.SetDrawColliders(drawColliders);
	}
}

void ImGuiDebugWindow::DrawOptions(RenderManager& aRenderManager)
{
	bool isFullscreen = aRenderManager.GetIsFullScreen();

	if (ImGui::Checkbox("Fullscreen", &isFullscreen))
	{
		Tga::Engine::GetInstance()->SetFullScreen(isFullscreen);
	}

	bool drawGui = aRenderManager.GetDrawGUI();

	if (ImGui::Checkbox("Draw GUI", &drawGui))
	{
		aRenderManager.SetDrawGui(drawGui);
	}
}
