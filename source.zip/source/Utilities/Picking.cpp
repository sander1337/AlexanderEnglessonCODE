#include "stdafx.h"
#include "Picking.h"
#include "../source/SceneManagement/GameScene.h"
#include <tge/graphics/Camera.h>
#include <tge/navmesh/navmesh.h>

using Tga::Vector2f;
using Tga::Vector3f;

Picking* Picking::myInstance = nullptr;

Picking::~Picking()
{
	delete myInstance;
	myInstance = nullptr;
}

void Picking::Init(const std::shared_ptr<Tga::Camera>& aCamera)
{
	myCameraReference = aCamera;
}

Picking* Picking::GetInstance()
{
	if (myInstance == nullptr)
	{
		myInstance = new Picking;
	}

	return myInstance;
}

Vector3f Picking::PickingToWorldPos(const Vector2f& aMousePosition, const Vector3f& anActorPosition, bool aFindNearestNode)
{
	if (myGameScene->GetNavmesh() == nullptr)
	{
		return Vector3f{};
	}
	Ray ray = myCameraReference->PerformPicking(aMousePosition);
	// if (myGameScene->GetNavmesh() == nullptr)
	// {
	// 	ray.direction.Normalize();
	// 	float groundPlaneY = 0.f;
	// 	Tga::Vector3f hitPoint;
	// 	if (std::abs(ray.direction.y) > 1e-6f) // Avoid divide by zero
	// 	{
	// 		float t = (groundPlaneY - ray.origin.y) / ray.direction.y;
	// 		if (t >= 0.0f) // Intersection is in front of the camera
	// 		{
	// 			hitPoint = ray.origin + ray.direction * t;
	// 		}
	// 	}
	// }
	return myGameScene->GetNavmesh()->GetPositionFromNavmesh(ray, anActorPosition, aFindNearestNode);
}
Tga::Vector3f Picking::NearestInNavmesh(const Tga::Vector3f& aPosition)
{
	if (myGameScene == nullptr)
	{
		return aPosition;
	}
	if (myGameScene->GetNavmesh() == nullptr)
	{
		return aPosition;
	}

	return myGameScene->GetNavmesh()->FindNearestInNavmesh(aPosition);
}
std::vector<Tga::Vector3f> Picking::PickingToWorldPath(const Vector2f& aMousePosition, const Vector3f& anActorPosition)
{
	Ray ray = myCameraReference->PerformPicking(aMousePosition);
	if (myGameScene->GetNavmesh() == nullptr)
	{
		ray.direction.Normalize();
		float groundPlaneY = 0.f;
		Tga::Vector3f hitPoint;
		if (std::abs(ray.direction.y) > 1e-6f) // Avoid divide by zero
		{
			float t = (groundPlaneY - ray.origin.y) / ray.direction.y;
			if (t >= 0.0f) // Intersection is in front of the camera
			{
				hitPoint = ray.origin + ray.direction * t;
			}
		}
		return  std::vector<Vector3f>{hitPoint};
	}
	std::vector<Tga::Vector3f> path = myGameScene->GetNavmesh()->GetPathFromNavmesh(ray, anActorPosition);

	return path;
	// IF FUNNELING CRASHES - comment out "return path;" and use the lines below instead to save the other group members long ass trips around the map
	// 
	//if (path.size() > 0)
	//{
	//	return std::vector<Tga::Vector3f>{path.back()};
	//}
	//return std::vector<Tga::Vector3f>{};
}

std::vector<Tga::Vector3f> Picking::GetWorldPath(const Tga::Vector3f& aTargetPosition, const Tga::Vector3f& anActorPosition)
{
	if (myGameScene->GetNavmesh() == nullptr)
	{
		return std::vector<Tga::Vector3f>();
	}

	return myGameScene->GetNavmesh()->GetPathFromNavmesh(aTargetPosition, anActorPosition);
}



void Picking::SwitchScene(GameScene* aGameScene)
{
	myGameScene = aGameScene;
}
