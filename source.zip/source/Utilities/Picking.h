#pragma once
//#pragma message(__FILE__" was compiled")
//#include <tge/graphics/Camera.h>
#include <vector>

namespace Tga
{
	class Camera;
}

class GameScene;

class Picking
{
public:
	~Picking();

	void Init(const std::shared_ptr<Tga::Camera>& aCamera);
	static Picking* GetInstance();
	Tga::Vector3f PickingToWorldPos(const Tga::Vector2f& aMousePosition, const Tga::Vector3f& anActorPosition, bool aFindNearestNode = true);
	Tga::Vector3f NearestInNavmesh(const Tga::Vector3f& aPosition);
	std::vector<Tga::Vector3f> PickingToWorldPath(const Tga::Vector2f& aMousePosition, const Tga::Vector3f& anActorPosition);
	std::vector<Tga::Vector3f> GetWorldPath(const Tga::Vector3f& aTargetPosition, const Tga::Vector3f& anActorPosition);
	void SwitchScene(GameScene* aGameScene);
	std::shared_ptr<Tga::Camera> GetCamera() const { return myCameraReference; }
private:
	Picking() = default;
	static Picking* myInstance;
	std::shared_ptr<Tga::Camera> myCameraReference;


	Tga::Vector3f myPickingPosition;
	GameScene* myGameScene;
};