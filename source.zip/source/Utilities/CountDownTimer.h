#pragma once
//#include "pch.h"

inline bool Timer(float& aTimer, const float& aMaxTime, float aDeltaTime) // Returns true when timer reaches zero and is reset
{
	if (aTimer > 0.f)
	{
		aTimer -= aDeltaTime;
		return false;
	}
	else
	{
		aTimer = aMaxTime;
		return true;
	}
}