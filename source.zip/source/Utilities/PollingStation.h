﻿#pragma once

#include <tge/math/vector.h>
#include <tge/math/Matrix.h>
#include <unordered_map>
#include <vector>
#include <optional>

class Actor;
class Player;
enum class SceneID : uint8_t;


namespace AI
{
	struct HurtInfo
	{
		int health;
		int maxHealth;
		Tga::Vector3f worldPos;
		Tga::Matrix4x4f transform;
	};

	class PollingStation3D
	{
	public:
		static PollingStation3D& Get()
		{
			static PollingStation3D s; return s;
		}

		void UpdateActorPos(Actor* anID, const Tga::Vector3f& aPos)
		{
			myActorID_Pos[anID] = aPos;
		}

		void UpdateActorPos(Actor* anID, const Tga::Vector3f& aPos, float aRadius);

		std::vector<Tga::Vector3f> GetNeighbourPositions(Actor* aMe, float aRadius, bool anExcludePlayer = true) const
		{
			std::vector<Tga::Vector3f> out;
			const float r2 = aRadius * aRadius;
			auto itMe = myActorID_Pos.find(aMe);
			if (itMe == myActorID_Pos.end())
			{
				return out;
			}
			const Tga::Vector3f myPos = itMe->second;

			for (auto& actorID_Pos : myActorID_Pos)
			{
				if (actorID_Pos.first == aMe)
				{
					continue;
				}

				// Skip player if needed
				if (anExcludePlayer && HasPlayerPos() && actorID_Pos.second == myPlayerPos.value())
				{
					continue;
				}

				Tga::Vector3f d = actorID_Pos.second - myPos;
				if (d.LengthSqr() <= r2)
				{
					out.push_back(actorID_Pos.second);
				}
			}
			return out;
		}

		std::vector<Tga::Vector3f> GetNeighbourPositions(const Tga::Vector3f& aMyPos, [[maybe_unused]] float aRadius, bool anExcludePlayer = true) const
		{
			std::vector<Tga::Vector3f> out;
			const float r2 = 1000 * 1000;

			for (auto& actorID_Pos : myActorID_Pos)
			{
				if (anExcludePlayer && HasPlayerPos() && actorID_Pos.second == myPlayerPos.value())
				{
					continue;
				}

				Tga::Vector3f d = actorID_Pos.second - aMyPos;
				auto dist = d.LengthSqr();
				if (dist <= r2)
				{
					out.push_back(actorID_Pos.second);
				}
			}

			return out;
		}

		std::vector<Actor*> GetNeighbourIDs(Actor* aMe, float aRadius, bool anExcludePlayer = true) const
		{
			std::vector<Actor*> actors;
			const float r2 = aRadius * aRadius;
			auto itMe = myActorID_Pos.find(aMe);
			if (itMe == myActorID_Pos.end())
			{
				return actors;
			}
			const Tga::Vector3f posOfMe = itMe->second;

			for (auto& actor : myActorID_Pos)
			{
				if (actor.first == aMe)
				{
					continue;
				}

				// Skip player if needed
				if (anExcludePlayer && HasPlayerPos() && actor.second == myPlayerPos.value())
				{
					continue;
				}

				Tga::Vector3f d = actor.second - posOfMe;
				if (d.LengthSqr() <= r2)
				{
					actors.push_back(actor.first);
				}
			}
			return actors;
		}

		std::unordered_map<Actor*, Tga::Vector3f> GetNeighbourPtr_Pos(Actor* aMe, float aRadius, bool anExcludePlayer = true) const
		{
			std::unordered_map<Actor*, Tga::Vector3f> neighbours;
			const float r2 = aRadius * aRadius;
			auto itMe = myActorID_Pos.find(aMe);
			if (itMe == myActorID_Pos.end())
			{
				return neighbours;
			}
			const Tga::Vector3f posOfMe = itMe->second;

			for (auto& actor : myActorID_Pos)
			{
				if (actor.first == aMe)
				{
					continue;
				}

				// Skip player if needed
				if (anExcludePlayer && HasPlayerPos() && actor.second == myPlayerPos.value())
				{
					continue;
				}

				Tga::Vector3f d = actor.second - posOfMe;
				if (d.LengthSqr() <= r2)
				{
					neighbours[actor.first] = actor.second;
				}
			}
			return neighbours;
		}

		void SetPlayerPos(const Tga::Vector3f& aPos) { myPlayerPos = aPos; myHasPlayer = true; }
		bool HasPlayerPos() const { return myHasPlayer; }
		std::optional<Tga::Vector3f> GetPlayerPos() const { return myPlayerPos; }

		float GetRadius(Actor* anID) const
		{
			auto it = myActorRadii.find(anID);
			return (it != myActorRadii.end()) ? it->second : 0.f;
		}
		const std::unordered_map<Actor*, Tga::Vector3f>& GetAllActors() const
		{
			return myActorID_Pos;
		}
		void UnregisterActor(Actor* anID)
		{
			myActorID_Pos.erase(anID);
			myActorRadii.erase(anID);
		}

		std::unordered_map<Actor*, HurtInfo>& GetHurtActors() {return myHurtActors;};
		void SetHurtActorInfo(Actor* anActor, HurtInfo& someInfo);

		void UpdateCurrentSceneID(SceneID& aSceneID);
		SceneID& GetCurrentSceneID();

		void SetPlayerPtr(Player* aPlayerPtr);
		Player* GetPlayer();

	private:
		std::unordered_map<Actor*, Tga::Vector3f> myActorID_Pos;
		std::unordered_map<Actor*, float> myActorRadii;

		bool myHasPlayer = false;
		std::optional<Tga::Vector3f> myPlayerPos;

		std::unordered_map <Actor*, HurtInfo> myHurtActors;

		SceneID myCurrentSceneID;

		Player* myPlayerPtr = nullptr;

	};
}