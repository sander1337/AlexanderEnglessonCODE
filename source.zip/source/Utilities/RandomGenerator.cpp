#include "stdafx.h"
#include "RandomGenerator.h"

RandomGenerator* RandomGenerator::myInstance = nullptr;
std::random_device RandomGenerator::myRandomDevice;
std::mt19937 RandomGenerator::myGenerator(myRandomDevice());

RandomGenerator::RandomGenerator() = default;

RandomGenerator::~RandomGenerator()
{
	delete myInstance;
	myInstance = nullptr;
}

RandomGenerator* RandomGenerator::GetInstance()
{
	if (myInstance == nullptr)
	{
		myInstance = new RandomGenerator();
	}

	return myInstance;
}

int RandomGenerator::GetInt(const int aMinInt, const int aMaxInt)
{
	std::uniform_int_distribution<int> value(aMinInt, aMaxInt);

	return value(myGenerator);
}

float RandomGenerator::GetFloat(float aMinFloat, float aMaxFloat)
{
	std::uniform_real_distribution<float> value(aMinFloat, aMaxFloat);

	return value(myGenerator);
}

bool RandomGenerator::GetBool()
{
	std::uniform_int_distribution<int> value(0, 1);
	return value(myGenerator);
}

Tga::Vector2f RandomGenerator::Get2DScreenPosition(float aMaxXScreen, float aMaxYScreen)
{
	std::uniform_real_distribution<float> xValue(0.f, aMaxXScreen);
	std::uniform_real_distribution<float> yValue(0.f, aMaxYScreen);

	float x = xValue(myGenerator);
	float y = yValue(myGenerator);
	
	return Tga::Vector2f(x, y);
}

float RandomGenerator::GetBinomial()
{
	std::uniform_real_distribution<float> firstValue(0.f, 1.f);
	std::uniform_real_distribution<float> secondValue(0.f, 1.f);

	float first = firstValue(myGenerator);
	float second = secondValue(myGenerator);

	return first - second;
}

Tga::Vector2f RandomGenerator::Get2DVelocity(float aMinXValue, float aMaxXValue, float aMinYValue, float aMaxYValue)
{
	std::uniform_real_distribution<float> xValue(aMinXValue, aMaxXValue);
	std::uniform_real_distribution<float> yValue(aMinYValue, aMaxYValue);

	float x = xValue(myGenerator);
	float y = yValue(myGenerator);

	return Tga::Vector2f(x, y);
}
