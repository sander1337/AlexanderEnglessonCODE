#pragma once
#include <string_view>

// ***** Scenes *****
#pragma region SCENES
constexpr std::string_view TGS_LEVEL_1_NAME = "levels\\Level1\\Level1.tgs";
constexpr std::string_view TGS_LEVEL_2_NAME = "levels\\Level2\\Level2.tgs";
constexpr std::string_view TGS_ASSET_GYM_NAME = "levels\\AssetGym\\AssetGym.tgs";
constexpr std::string_view TGS_PLAYER_GYM_NAME = "levels\\PlayerGym\\PlayerGym.tgs";
constexpr std::string_view TGS_AI_GYM_NAME = "levels\\AIGym\\AIGym.tgs";
constexpr std::string_view TGS_ANIMATION_GYM_NAME = "levels\\AnimationGym\\AnimationGym.tgs";
constexpr std::string_view TGS_VFX_GYM_NAME = "levels\\VFXGym\\VFXGym.tgs";
constexpr std::string_view TGS_MAIN_MENU_NAME = "levels\\menus\\MainMenu.tgs";
constexpr std::string_view TGS_CREDITS_MENU_NAME = "levels\\menus\\Credits.tgs";
constexpr std::string_view TGS_LEVELSELECT_MENU_NAME = "levels\\menus\\LevelSelect.tgs";
constexpr std::string_view TGS_OPTIONS_MENU_NAME = "levels\\menus\\Options.tgs";
constexpr std::string_view TGS_PAUSE_MENU_NAME = "levels\\menus\\Pause.tgs";
constexpr std::string_view TGS_HUD_NAME = "levels\\hud\\HUD.tgs";
constexpr std::string_view TGS_HUDMAINMENU_NAME = "levels\\menus\\HudMainMenu.tgs";


#pragma endregion

// ***** AUDIO *****
namespace AudioConstExpr
{
// BANKS
	constexpr std::string_view BANK_MASTER = "bank:/Master";
	constexpr std::string_view BANK_MASTER_STRINGS = "bank:/Master.strings";

// BUSES
	constexpr std::string_view BUS_MASTER = "bus:/";
	constexpr std::string_view BUS_REVERB = "bus:/Reverb";

// EVENTS
	// music
	constexpr std::string_view VARMKORV = "event:/varmkorv";

	// sfx
	constexpr std::string_view FOOTSTEP = "event:/FootStep";
	constexpr std::string_view KNIFESTAB = "event:/KnifeStab";

		// Player
		constexpr std::string_view PLAYERGUNSHOT = "event:/PlayerGunShot";

// PARAMETERS
	constexpr std::string_view PARAM_1 = "parameter:/Parameter 1";
}