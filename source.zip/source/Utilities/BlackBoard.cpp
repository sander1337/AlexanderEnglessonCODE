#include "stdafx.h"
#include "BlackBoard.h"

Blackboard* Blackboard::myInstance = nullptr;

Blackboard::~Blackboard()
{
	delete myInstance;
	myInstance = nullptr;
}