#include "stdafx.h"
#include "GameWorld.h"
#include "Input/InputMapper.h"
#include "Utilities/ConstantIdentifiers.h"

#include <tge/input/InputManager.h>
#include <tge/settings/settings.h>
#include <tge/error/ErrorManager.h>
#include <tge/ui/cursor.h>
#include <tge/script/ScriptManager.h>

std::unique_ptr<Tga::InputManager> locInputManager;

LRESULT GameWinProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	if (locInputManager->UpdateEvents(message, wParam, lParam)) {
		return 0;
	}

	hWnd;
	switch (message)
	{
	
		/*case WM_ACTIVATEAPP:
		{
			if (wParam)
			{
				Tga::InputManager* inputManager = InputMapper::GetInstance().GetInputManager();

				if (inputManager)
				{
					inputManager->CaptureMouse();
				}
			}
			else
			{
				Tga::InputManager* inputManager = InputMapper::GetInstance().GetInputManager();

				if (inputManager)
				{
					inputManager->ReleaseMouse();
				}
			}
		}*/

		// this message is read when the window is closed
		case WM_DESTROY:
		{
			// close the application entirely
			PostQuitMessage(0);
			return 0;
		}
	}

	return 0;
}


void Go(const char* aSceneToLoad)
{
	Tga::LoadSettings(TGE_PROJECT_SETTINGS_FILE);

	Tga::EngineConfiguration &cfg = Tga::Settings::GetEngineConfiguration();
	
	cfg.myWinProcCallback = [](HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {return GameWinProc(hWnd, message, wParam, lParam); };
#ifdef _DEBUG
	cfg.myActivateDebugSystems = Tga::DebugFeature::Fps | Tga::DebugFeature::Mem | Tga::DebugFeature::Filewatcher | Tga::DebugFeature::Cpu | Tga::DebugFeature::Drawcalls | Tga::DebugFeature::OptimizeWarnings;
#else
	cfg.myActivateDebugSystems = Tga::DebugFeature::Filewatcher;
#endif

	if (!Tga::Engine::Start())
	{
		ERROR_PRINT("Fatal error! Engine could not start!");
		system("pause");
		return;
	}

	{
		Tga::Engine& engine = *Tga::Engine::GetInstance();
		engine.SetFullScreen(false);
		Tga::Color bgColor(0.f, 0.f, 0.f, 1.f);
		engine.SetClearColor(bgColor);

		GameWorld gameWorld;

		locInputManager = std::make_unique<Tga::InputManager>(*engine.GetHWND());
		InputMapper inputMapper(*locInputManager);

		// Cursor shit
		NCE::Cursor& cursor = engine.GetCursor();
		cursor.Init(*locInputManager, "assets/UI/textures/T_UI_Cursor_idle.dds");
		cursor.LoadCursorTexture("Hover"_tgaid, "assets/UI/textures/T_UI_Cursor_hover.dds");

		if (aSceneToLoad == nullptr)
		{
#ifdef _DEBUG
		aSceneToLoad = TGS_AI_GYM_NAME.data();
#else
		aSceneToLoad = TGS_AI_GYM_NAME.data();
#endif
#ifdef _RETAIL

		engine.SetFullScreen(true);
#endif
		}

		Tga::ScriptManager::GetInstance()->Init();
		
		gameWorld.Init(aSceneToLoad);

		while (engine.BeginFrame())
		{
			inputMapper.Update();
			gameWorld.Update(engine.GetDeltaTime());
			gameWorld.Render();

			engine.EndFrame();
		}
	}

	Tga::Engine::GetInstance()->Shutdown();
}