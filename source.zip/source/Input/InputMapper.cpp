#include "InputMapper.h"
#include <stdafx.h>
#include <tge/input/InputManager.h>

#include "../GameWorld.h"
#include "../SceneManagement/GameScene.h"
#include "../Collisions/Narrow/Raycast.h"
#include "../Collisions/Narrow/CapsuleCollider.h"
#include "../Collisions/Narrow/BoxCollider.h"
#include "../Utilities/Picking.h"
#include "../Objects/Actors/Actor.h"
#include "../States/StateStack.h"
#include "../States/State.h"



void InputObserver::RegisterToMapper(InputEvent anEventToFollow)
{
	InputMapper::GetInstance().Register(anEventToFollow, weak_from_this());
}

void InputObserver::UnRegisterToMapper(InputEvent anEventToFollow)
{
	InputMapper::GetInstance().UnRegister(anEventToFollow, weak_from_this());
}

void InputObserver::RegisterToMapper(std::initializer_list<InputEvent> someEvents)
{
	InputMapper& inputMapper = InputMapper::GetInstance();
	const std::weak_ptr<InputObserver>& thisObserver = weak_from_this();
	for (const auto& event : someEvents)
	{
		inputMapper.Register(event, thisObserver);
	}
}

void InputObserver::UnRegisterToMapper(std::initializer_list<InputEvent> someEvents)
{
	InputMapper& inputMapper = InputMapper::GetInstance();
	const std::weak_ptr<InputObserver>& thisObserver = weak_from_this();
	for (const auto& event : someEvents)
	{
		inputMapper.UnRegister(event, thisObserver);
	}
}

Tga::InputManager* InputMapper::GetInputManager()
{

	if (myInstance)
	{
		if (myInstance->inputManagerBound)
		{
			return &myInstance->myInputManager;
		}
	}

	return nullptr;
}

InputMapper* InputMapper::myInstance = nullptr;

InputMapper::InputMapper(Tga::InputManager& anInputManager) : myInputManager(anInputManager)
{
	if (myInstance && myInstance != this)
	{
		delete this;
	}
	else
	{
		myInstance = this;
	}

	inputManagerBound = true;
}

InputMapper& InputMapper::GetInstance()
{
	return *myInstance;
}

void InputMapper::Register(InputEvent anEventToFollow, const std::weak_ptr<InputObserver>& anObserver)
{
	myObservers[anEventToFollow].emplace_back(anObserver);
}

void InputMapper::UnRegister(InputEvent anEventToFollow, const std::weak_ptr<InputObserver>& anObserver)
{
	if (anObserver.expired())
	{
		return;
	}

	auto& observerList = myObservers[anEventToFollow];
	//Predicate for what conditions an observer should be removed
	auto removalPredicate = [&anObserver](const std::weak_ptr<InputObserver>& aRegisteredObserver)
		{
			return aRegisteredObserver.lock() == anObserver.lock();
		};
	//Remove every single instance of that observer
	std::erase_if(observerList, removalPredicate);
}

void InputMapper::Update()
{
	myInputManager.Update();
	UpdateKeyboard();
	UpdateMouse();
	myIsUsingController = myXInput.Refresh();
	if (myIsUsingController)
	{
		UpdateGamepad();
	}
}

void InputMapper::NotifyObservers(InputEvent aGameEvent, const std::any& someData)
{
	// Checking size because if something UnRegister during the loop, which happens when we push and pop states,
	// the game crashes. This was an easy way to check if the loop should stop. 
	size_t observerSize = myObservers[aGameEvent].size();

	for (std::weak_ptr<InputObserver>& observer : myObservers[aGameEvent])
	{
		observer.lock()->ReceiveInput(aGameEvent, someData);

		if (observerSize != myObservers[aGameEvent].size())
		{
			break;
		}
	}
}

static std::shared_ptr<Actor> CheckMouseHoverOverEnemy(const Tga::Vector2f someMouseScreenCoordinates)
{
	if (std::shared_ptr<GameScene> gameScene = GameWorld::GetInstance().GetCurrentGameScene().lock())
	{
		for (const std::weak_ptr<Actor>& actorLocked : gameScene->GetActors())
		{
			if (std::shared_ptr actor = actorLocked.lock())
			{
				if (actor->GetActorType() != ActorType::Player)
				{
					if (const auto collider = std::dynamic_pointer_cast<CapsuleCollider>(actor->GetCollider()))
					{
						if (Raycast::IsRayOverlapping(Picking::GetInstance()->GetCamera()->PerformPicking(someMouseScreenCoordinates), *collider))
						{
							return actor;
						}
					}
				}
			}
		}
	}
	return nullptr;
}

static std::shared_ptr<GameObject> CheckMouseHoverOverDestructibles(const Tga::Vector2f someMouseScreenCoordinates)
{
	if (std::shared_ptr<GameScene> gameScene = GameWorld::GetInstance().GetCurrentGameScene().lock())
	{
		for (const std::weak_ptr<GameObject>& objectLocked : gameScene->GetGameObjects())
		{
			if (std::shared_ptr object = objectLocked.lock())
			{
				if (object->GetTag() == Tga::Tag::Destructible)
				{
					if (const auto collider = std::dynamic_pointer_cast<CapsuleCollider>(object->GetCollider()))
					{
						if (Raycast::IsRayOverlapping(Picking::GetInstance()->GetCamera()->PerformPicking(someMouseScreenCoordinates), *collider))
						{
							return object;
						}
					}
				}
			}
		}
	}
	return nullptr;
}

void InputMapper::UpdateKeyboard()
{
	const Tga::Vector2ui intResolution = Tga::Engine::GetInstance()->GetRenderSize();
	const Tga::Vector2f resolution = { static_cast<float>(intResolution.x), static_cast<float>(intResolution.y) };
	Tga::Vector2f mouseScreenCoordinates = { myInputManager.GetMousePosition().x,  resolution.y - myInputManager.GetMousePosition().y };
	
//In-game:
	if (CheckButtonInput(InputAction::KeyF, ButtonState::Down))
	{
		NotifyObservers(InputEvent::AttackLeft);
	}
	if (CheckButtonInput(InputAction::KeyR, ButtonState::Down))
	{
		NotifyObservers(InputEvent::Reload);
	}
	if (CheckButtonInput(InputAction::KeyI, ButtonState::Down))
	{
		NotifyObservers(InputEvent::PlayerWeaponInfo);
	}
		//TODO: turn into vector later
	Tga::Vector2f moveAxis = { 0.f, 0.f };

	if (CheckButtonInput(InputAction::KeyW, ButtonState::Holding)) moveAxis.myY += 1.f;
	if (CheckButtonInput(InputAction::KeyS, ButtonState::Holding)) moveAxis.myY -= 1.f;
	if (CheckButtonInput(InputAction::KeyD, ButtonState::Holding)) moveAxis.myX += 1.f;
	if (CheckButtonInput(InputAction::KeyA, ButtonState::Holding)) moveAxis.myX -= 1.f;

	//SPELLBOOK
	if (CheckButtonInput(InputAction::KeyN, ButtonState::Down))
	{
		NotifyObservers(InputEvent::ToggleSpellBook);
	}

	if (CheckButtonInput(InputAction::Key1, ButtonState::Down)) NotifyObservers(InputEvent::ActionKeyPressed, 1);
	if (CheckButtonInput(InputAction::Key2, ButtonState::Down)) NotifyObservers(InputEvent::ActionKeyPressed, 2);
	if (CheckButtonInput(InputAction::Key3, ButtonState::Down)) NotifyObservers(InputEvent::ActionKeyPressed, 3);
	if (CheckButtonInput(InputAction::Key4, ButtonState::Down)) NotifyObservers(InputEvent::ActionKeyPressed, 4);
	if (CheckButtonInput(InputAction::Key5, ButtonState::Down)) NotifyObservers(InputEvent::ActionKeyPressed, 5);
	if (CheckButtonInput(InputAction::Key6, ButtonState::Down)) NotifyObservers(InputEvent::ActionKeyPressed, 6);
	if (CheckButtonInput(InputAction::Key7, ButtonState::Down)) NotifyObservers(InputEvent::ActionKeyPressed, 7);
	if (CheckButtonInput(InputAction::Key8, ButtonState::Down)) NotifyObservers(InputEvent::ActionKeyPressed, 8);
	if (CheckButtonInput(InputAction::Key9, ButtonState::Down)) NotifyObservers(InputEvent::ActionKeyPressed, 9);




	NotifyObservers(InputEvent::MoveAxis, moveAxis);

	if (CheckButtonInput(InputAction::Shift, ButtonState::Down))
	{
		NotifyObservers(InputEvent::SpeedUp);
	}
	if (CheckButtonInput(InputAction::Shift, ButtonState::Released))
	{
		NotifyObservers(InputEvent::SlowDown);
	}


//Menu:

	if (CheckButtonInput(InputAction::Escape, ButtonState::Down))
	{
		NotifyObservers(InputEvent::Pause);
	}
	if (CheckButtonInput(InputAction::MouseL, ButtonState::Down))
	{
		NotifyObservers(InputEvent::MenuLClick, mouseScreenCoordinates);
	}
	if (CheckButtonInput(InputAction::MouseL, ButtonState::Released))
	{
		NotifyObservers(InputEvent::MenuLRelease, mouseScreenCoordinates);
	}
	
// FREEFLY --------------------------------

	if (CheckButtonInput(InputAction::MouseR, ButtonState::Holding))
	{
		NotifyObservers(InputEvent::RotateFreefly, myInputManager.GetMouseDelta());
	}

	if (CheckButtonInput(InputAction::KeyW, ButtonState::Holding))
	{
		NotifyObservers(InputEvent::FwdFreefly);
	}
	if (CheckButtonInput(InputAction::KeyA, ButtonState::Holding))
	{
		NotifyObservers(InputEvent::LeftFreefly);
	}
	if (CheckButtonInput(InputAction::KeyS, ButtonState::Holding))
	{
		NotifyObservers(InputEvent::BackFreefly);
	}
	if (CheckButtonInput(InputAction::KeyD, ButtonState::Holding))
	{
		NotifyObservers(InputEvent::RightFreefly);
	}
	if (CheckButtonInput(InputAction::KeyQ, ButtonState::Holding))
	{
		NotifyObservers(InputEvent::DownFreefly);
	}
	if (CheckButtonInput(InputAction::KeyE, ButtonState::Holding))
	{
		NotifyObservers(InputEvent::UpFreefly);
	}

	if (CheckButtonInput(InputAction::Enter, ButtonState::Released))
	{
		NotifyObservers(InputEvent::ToggleFreefly);

	}

	if (CheckButtonInput(InputAction::ShiftL, ButtonState::Holding))
	{
		NotifyObservers(InputEvent::ShiftFreeflyDown);
	}
	if (CheckButtonInput(InputAction::ShiftL, ButtonState::Released))
	{
		NotifyObservers(InputEvent::ShiftFreeflyUp);
	}

	if (CheckButtonInput(InputAction::Escape, ButtonState::Released))
	{
		NotifyObservers(InputEvent::Back);
		
		NotifyObservers(InputEvent::Pause);
	}

	if (CheckButtonInput(InputAction::KeyF6, ButtonState::Released))
	{
		NotifyObservers(InputEvent::ChangeRenderMode);
	}

	if (CheckButtonInput(InputAction::KeyF1, ButtonState::Released))
	{
		NotifyObservers(InputEvent::CaptureMouse);
	}
}

void InputMapper::UpdateMouse()
{
	const Tga::Vector2ui resI = Tga::Engine::GetInstance()->GetRenderSize();
	const Tga::Vector2f res{ (float)resI.x, (float)resI.y };

	const Tga::Vector2f mouseScreen{
		myInputManager.GetMousePosition().x,
		res.y - myInputManager.GetMousePosition().y
	};

	NotifyObservers(InputEvent::Hover, mouseScreen);

	const bool lmbHeld = myInputManager.IsKeyHeld(VK_LBUTTON);
	const bool rmbHeld = myInputManager.IsKeyHeld(VK_RBUTTON);

	// RMB capture/hide mouse
	if (rmbHeld && !myMouseLook)
	{
		myMouseLook = true;
		myInputManager.HideMouse();
		myInputManager.CaptureMouse();
	}
	else if (!rmbHeld && myMouseLook)
	{
		myMouseLook = false;
		myInputManager.ShowMouse();
		myInputManager.ReleaseMouse();
	}

	const Tga::Vector2f delta = myInputManager.GetMouseDelta();
	if (delta.myX != 0.f || delta.myY != 0.f)
	{
		if (rmbHeld)
		{
			NotifyObservers(InputEvent::LookAroundAndTurnPlayer, delta);
		}
		else if (lmbHeld)
		{
			NotifyObservers(InputEvent::LookAround, delta);
		}
	}

	const int wheel = myInputManager.GetMouseWheelDelta();
	if (wheel > 0)
	{
		NotifyObservers(InputEvent::CameraZoomIn);
	}
	else if (wheel < 0)
	{
		NotifyObservers(InputEvent::CameraZoomOut);
	}
}
namespace { //Anonymous workspace
	static XINPUT_GAMEPAD localCurrentXInputState{};
	static XINPUT_GAMEPAD localPreviousXInputState{};
	static bool ReadXInputButton(XINPUT_GAMEPAD aGamepadState, WORD anInputKey)
	{
		return (aGamepadState.wButtons & anInputKey) != 0;
	}
}

//Partial gamepad support
void InputMapper::UpdateGamepad()
{
	//Update XInput states
	localPreviousXInputState = localCurrentXInputState;
	localCurrentXInputState = *myXInput.GetState();
	//All gamepad input-mapping goes here:
}

bool InputMapper::CheckButtonInput(InputAction anInputAction, ButtonState aButtonState)
{
	if (anInputAction < InputAction::GamepadDPadUp || anInputAction > InputAction::GamepadY) //If the input action is not a gamepad button action
	{
		switch (aButtonState)
		{
		case ButtonState::Down:
			{
				return myInputManager.IsKeyPressed((int)anInputAction);
			}
		case ButtonState::Holding:
			{
				return myInputManager.IsKeyHeld((int)anInputAction);
			}
		case ButtonState::Released:
			{
				return myInputManager.IsKeyReleased((int)anInputAction);
			}
		}
	}
	else
	{
		WORD xInputKey = 1 << ((WORD)anInputAction - (WORD)InputAction::GamepadDPadUp); //Convert the input action into an xInput key
		switch (aButtonState)
		{
		case ButtonState::Down:
			{
				return ReadXInputButton(localPreviousXInputState, xInputKey) == false && ReadXInputButton(localCurrentXInputState, xInputKey) == true;
			}
		case ButtonState::Holding:
			{
				return ReadXInputButton(localPreviousXInputState, xInputKey) == true && ReadXInputButton(localCurrentXInputState, xInputKey) == true;
			}
		case ButtonState::Released:
			{
				return ReadXInputButton(localPreviousXInputState, xInputKey) == true && ReadXInputButton(localCurrentXInputState, xInputKey) == false;
			}
		}
	}
	return false;
}