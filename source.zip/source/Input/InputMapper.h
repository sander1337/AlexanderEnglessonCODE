#pragma once

#include <any>
#include <map>
#include <memory>
#include <vector>

#include "tge/input/XInput.h"
#include "InputActions.h"
#include "../Utilities/SharedFromThis.h"


namespace Tga
{
	class InputManager;
}

class InputObserver : public Utilities::EnableSharedFromThis<InputObserver>
{
public:
	InputObserver() = default;

	virtual void ReceiveInput(InputEvent aGameEvent, const std::any& someData) = 0;

	virtual void RegisterInput() {};
	virtual void UnregisterInput() {};
	void RegisterToMapper(InputEvent anEventToFollow);
	void UnRegisterToMapper(InputEvent anEventToFollow);
	void RegisterToMapper(std::initializer_list<InputEvent> someEvents);
	void UnRegisterToMapper(std::initializer_list<InputEvent> someEvents);
};

class InputMapper
{
public:
	static Tga::InputManager* GetInputManager(); // todo: function for debugging classes without registering them.
	InputMapper(Tga::InputManager& anInputManager);

	void Register(InputEvent anEventToFollow, const std::weak_ptr<InputObserver>& anObserver);
	void UnRegister(InputEvent anEventToFollow, const std::weak_ptr<InputObserver>& anObserver);
	void Update();	
	
	static InputMapper& GetInstance();

private:
	void NotifyObservers(InputEvent aGameEvent, const std::any& someData = nullptr);
	void UpdateKeyboard();
	void UpdateMouse();
	void UpdateGamepad();
	bool CheckButtonInput(InputAction anInputAction, ButtonState aButtonState);

	//Each GameEvent has a list of all observers that are currently registered to it.
	std::map<InputEvent, std::vector<std::weak_ptr<InputObserver>>> myObservers;

	Tga::InputManager& myInputManager;
	Tga::XInput myXInput{ 0.2f, 0.2f };
	bool myIsUsingController = false;
	bool inputManagerBound = false;
	static InputMapper* myInstance;
	bool myMouseLook = false;

};