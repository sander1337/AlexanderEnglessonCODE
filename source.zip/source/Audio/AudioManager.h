#pragma once
#include <xstring>
#include <tge/audio/FMOD/core/inc/fmod.hpp>
#include <tge/audio/FMOD/studio/inc/fmod_studio.hpp>

#include <unordered_map>

enum class PlayerAttackID : uint8_t;
enum class ActorType;
enum class SceneID : std::uint8_t;

enum class AudioIdentifier
{
	// music and ambience

	// general
	FOOTSTEPS,
	MELEE,
	RANGED,
	DEATH,
	IDLE,

	// enemies

	// player

	Count
};

enum class ParameterType : uint8_t
{
	//Standard,
	//Cave,
	Count
};

enum class AudioBusType : uint8_t
{
	Master,
	SFX,
	Ambience,
	Music,
	Count
};

enum class FootstepSurface
{
	Count
};


class AudioManager
{
	AudioManager() = default;
	std::string GetBankPath(const std::string_view& anAsset);
	static AudioManager* myInstance;

	FMOD_3D_ATTRIBUTES myListener;
	FMOD::System* myCoreSystem = nullptr;
	FMOD::Studio::System* myStudioSystem = nullptr;
	FMOD::Studio::Bank* myMasterBank = nullptr;
	FMOD::Studio::Bank* myStringBank = nullptr;
	FMOD::Studio::EventInstance* myReverbInstance = nullptr;

	mutable std::unordered_map<std::string, FMOD::Studio::EventInstance*> myEventInstances;
	std::unordered_map<ActorType, FMOD::Studio::EventInstance*> myFootstepInstances;
	std::unordered_map<int, FMOD::Studio::EventInstance*> myLoopingSounds;

	int myNextSoundId = 1;
	float myReverbType = 1.f;
	float mySurfaceType = 0.f;

public:
	~AudioManager();
	static AudioManager* GetInstance();
	bool Init();
	void Update(const Tga::Camera* aCamera);
	void RunUpdateCycle() const;

// Calculate / Params
	void UpdateListener(const Tga::Matrix4x4f& aCameraTransform, const Tga::Vector3f& aPlayerPosition);
	Tga::Vector3f ConvertToMeters(Tga::Vector3f& aPosition);
	const char* GetFootstepEvent(ActorType aType) const;
	void SetFootstepSurface(ActorType aActorType, FootstepSurface aSurface);
	//void SetReverbType(ParameterType aParameterType) const;
	//void SetSurfaceParameter(ParameterType aParameterType) const;
	void SetSurfaceType(FootstepSurface aParameterType);
	int PlayLoopingAudio(const std::string_view& aFmodLink, const Tga::Matrix4x4f& aTransform);
	void UpdateLoopingAudio(int aId, const Tga::Matrix4x4f& aTransform);
	void StopLoopingAudio(int aId);
	//void MuteAllNonBossIdleSounds(bool aStupidFuckingFunctionWhyIsThisShitNeededIDontCareButThisIsNeededAtTheMoment);

	// Play
	void PlayFootsteps(ActorType aActorType, const Tga::Matrix4x4f& aTransform);
	void PlayOneShotAudio(const std::string_view& aFmodLink, const Tga::Matrix4x4f& aTransform);
	void PlayNonSpazializedAudio(const std::string_view& aFmodLink) const;
	void PlayStoppableAudio(const std::string_view& aFmodLink);
	void PlayActorAudio(ActorType anActorType, AudioIdentifier anAudioIdentifier, const Tga::Matrix4x4f& aTransform);
	void PlayPlayerSpecificAudio(PlayerAttackID anAudioIdentifier, const Tga::Matrix4x4f& aTransform);
	void PlayMusic(AudioIdentifier anAudioIdentifier);
	void PlayAmbience(AudioIdentifier anAudioIdentifier);
	void PlaySceneAudio(SceneID anAudioIdentifier);

// Stop
	void StopWithFade(const std::string_view& aFmodLink);
	void StopImmediately(const std::string_view& aFmodLink);

// Volume
	void SetMasterVolume(float aVolume);
	void SetBusVolume(const std::string_view& busPath, float aVolume);
	void SetSFXVolume(float aVolume);
	void SetAmbienceVolume(float aVolume);
	void SetMusicVolume(float aVolume);
	float GetBusVolume(const std::string_view& busPath) const;
	float GetVolume(AudioBusType anAudioType) const;
};