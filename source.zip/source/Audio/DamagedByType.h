#pragma once

#include <tge/math/FMath.h>

enum class DamageType : std::uint8_t
{
	// enemies
	ENEMY_DAMAGED_BY_BOW,
	ENEMY_DAMAGED_BY_AXE,
	ENEMY_DAMAGED_BY_AXE_FIRE,
	ENEMY_DAMAGED_BY_BOW_FIRE,
	ENEMY_DAMAGED_BY_FIRE,

	// player
	PLAYER_DAMAGED_BY_MUD,
	PLAYER_DAMAGED_BY_SCYTHE,
	PLAYER_DAMAGED_BY_SWORD
};