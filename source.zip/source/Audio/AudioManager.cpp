#include "stdafx.h"
#include "AudioManager.h"

#include <tge/audio/FMOD/core/inc/fmod.hpp>
#include <string>
#include <tge/settings/settings.h>

#include "../source/Objects/Actors/Player/PlayerAbility.h"
#include "../source/Objects/Actors/Actor.h"
#include "../source/SceneManagement/SceneID.h"
#include "../Utilities/ConstantIdentifiers.h"
#include "Utilities/BlackBoard.h"

#include <tge/graphics/Camera.h>

AudioManager* AudioManager::myInstance = nullptr;


AudioManager::~AudioManager()
{
	delete myInstance;
	myInstance = nullptr;
}
AudioManager* AudioManager::GetInstance()
{
	if (myInstance == nullptr)
	{
		myInstance = new AudioManager;
	}

	return myInstance;
}

bool AudioManager::Init()
{
	FMOD_RESULT result;
	myStudioSystem = nullptr;
	result = FMOD::Studio::System::create(&myStudioSystem);

	if (result != FMOD_OK)
	{
		return false;
	}

	FMOD::Studio::System::create(&myStudioSystem);

	myStudioSystem->initialize(
		1024,
		FMOD_STUDIO_INIT_LIVEUPDATE | FMOD_STUDIO_INIT_NORMAL,
		FMOD_INIT_NORMAL,
		nullptr
	);

	myStudioSystem->getCoreSystem(&myCoreSystem);

	myStudioSystem->loadBankFile(GetBankPath("audio/Master.bank").c_str(), FMOD_STUDIO_LOAD_BANK_NORMAL, &myMasterBank);
	myStudioSystem->loadBankFile(GetBankPath("audio/Master.strings.bank").c_str(), FMOD_STUDIO_LOAD_BANK_NORMAL, &myStringBank);

	return true;
}
void AudioManager::Update(const Tga::Camera* aCamera)
{
	if (aCamera != nullptr)
	{
		//Tga::Vector3f playerPos = Blackboard::GetInstance()->GetVector3("playerPosition");
		//UpdateListener(aCamera->GetTransform(), playerPos);
	}

	//myStudioSystem->update();
}

void AudioManager::RunUpdateCycle() const
{
	//myStudioSystem->update();
}

void AudioManager::UpdateListener(const Tga::Matrix4x4f& aCameraTransform, const Tga::Vector3f& aPlayerPosition)
{
	Tga::Vector3f pos = aPlayerPosition;
	Tga::Vector3f up = aCameraTransform.GetUp().GetNormalized();
	Tga::Vector3f forward = aCameraTransform.GetForward().GetNormalized();

	myListener.position = { ConvertToMeters(pos).x,  ConvertToMeters(pos).y,  ConvertToMeters(pos).z };
	myListener.forward = { forward.x, forward.y, forward.z };
	myListener.up = { up.x, up.y, up.z };

	myStudioSystem->setListenerAttributes(0, &myListener);
}

Tga::Vector3f AudioManager::ConvertToMeters(Tga::Vector3f& aPosition)
{
	aPosition.x *= 0.01f;
	aPosition.y *= 0.01f;
	aPosition.z *= 0.01f;

	return aPosition;
}

const char* AudioManager::GetFootstepEvent(ActorType aType) const
{
	switch (aType)
	{
		case ActorType::Player:    return "event:/Player/Movement/Player_Footsteps";
		default: return nullptr;
	}
}

void AudioManager::PlayFootsteps(ActorType aActorType, const Tga::Matrix4x4f& aTransform)
{
	const char* eventName = GetFootstepEvent(aActorType);
	if (!eventName)
	{
		return;
	}

	FMOD::Studio::EventDescription* desc = nullptr;
	myStudioSystem->getEvent(eventName, &desc);

	FMOD::Studio::EventInstance* instance = nullptr;
	desc->createInstance(&instance);

	Tga::Vector3f pos = aTransform.GetPosition();
	Tga::Vector3f up = aTransform.GetUp().GetNormalized();
	Tga::Vector3f forward = aTransform.GetForward().GetNormalized();

	FMOD_3D_ATTRIBUTES attributes = {};
	attributes.position = { ConvertToMeters(pos).x, ConvertToMeters(pos).y, ConvertToMeters(pos).z };
	attributes.forward = { forward.x, forward.y, forward.z };
	attributes.up = { up.x, up.y, up.z };

	instance->set3DAttributes(&attributes);

	instance->setParameterByName("Surface", mySurfaceType);

	instance->start();
}

void AudioManager::SetFootstepSurface(ActorType aActorType, FootstepSurface aSurface)
{
	auto it = myFootstepInstances.find(aActorType);

	if (it == myFootstepInstances.end())
	{
		return;
	}

	it->second->setParameterByName("Surface", static_cast<float>(aSurface));
}

std::string AudioManager::GetBankPath(const std::string_view& anAsset)
{
	return Tga::Settings::ResolveGameAssetPath(anAsset);
}

//////////////////////////////////////////////////////

// FMOD decides if it loops or not
void AudioManager::PlayOneShotAudio(const std::string_view& aFmodLink, const Tga::Matrix4x4f& aTransform)
{
	FMOD::Studio::EventDescription* eventDescription = nullptr;
	myStudioSystem->getEvent(aFmodLink.data(), &eventDescription);

	FMOD::Studio::EventInstance* eventInstance = nullptr;
	eventDescription->createInstance(&eventInstance);

	Tga::Vector3f pos = aTransform.GetPosition();
	Tga::Vector3f up = aTransform.GetUp().GetNormalized();
	Tga::Vector3f forward = aTransform.GetForward().GetNormalized();

	FMOD_3D_ATTRIBUTES attributes = {};
	attributes.position = { ConvertToMeters(pos).x, ConvertToMeters(pos).y, ConvertToMeters(pos).z };
	attributes.forward = { forward.x, forward.y, forward.z };
	attributes.up = { up.x, up.y, up.z };

	eventInstance->set3DAttributes(&attributes);

	eventInstance->start();
}



// FMOD decides if it loops or not
void AudioManager::PlayNonSpazializedAudio(const std::string_view& aFmodLink) const
{
	FMOD::Studio::EventDescription* eventDescription = nullptr;
	myStudioSystem->getEvent(aFmodLink.data(), &eventDescription);

	FMOD::Studio::EventInstance* eventInstance = nullptr;
	eventDescription->createInstance(&eventInstance);

	eventInstance->start();
}
// FMOD decides if it loops or not
void AudioManager::PlayStoppableAudio(const std::string_view& aFmodLink)
{
	auto it = myEventInstances.find(aFmodLink.data());

	// If instance already exists, check if it's playing
	if (it != myEventInstances.end())
	{
		FMOD_STUDIO_PLAYBACK_STATE state;
		it->second->getPlaybackState(&state);

		if (state == FMOD_STUDIO_PLAYBACK_PLAYING)
		{
			return; // Already playing, do nothing
		}
	}

	FMOD::Studio::EventDescription* eventDescription = nullptr;
	myStudioSystem->getEvent(aFmodLink.data(), &eventDescription);

	FMOD::Studio::EventInstance* eventInstance = nullptr;
	eventDescription->createInstance(&eventInstance);

	eventInstance->start();
	myEventInstances[aFmodLink.data()] = eventInstance;
}
void AudioManager::StopWithFade(const std::string_view& aFmodLink)
{
	auto it = myEventInstances.find(aFmodLink.data());
	if (it == myEventInstances.end())
	{
		return; // not playing
	}

	FMOD::Studio::EventInstance* eventInstance = it->second;
	eventInstance->stop(FMOD_STUDIO_STOP_ALLOWFADEOUT);
	//eventInstance->release();

	myEventInstances.erase(it);
}
void AudioManager::StopImmediately(const std::string_view& aFmodLink)
{
	auto it = myEventInstances.find(aFmodLink.data());
	if (it == myEventInstances.end())
	{
		return; // not playing
	}

	FMOD::Studio::EventInstance* eventInstance = it->second;
	eventInstance->stop(FMOD_STUDIO_STOP_IMMEDIATE);
	eventInstance->release();

	myEventInstances.erase(it);
}


//void AudioManager::SetReverbType(ParameterType aParameterType) const
//{
//	myStudioSystem->setParameterByName("ReverbType", static_cast<float>(aParameterType));
//}

//void AudioManager::SetSurfaceParameter(ParameterType aParameterType) const
//{
//	myStudioSystem->setParameterByName("Surface", static_cast<float>(aParameterType));
//}

void AudioManager::SetSurfaceType(FootstepSurface aParameterType)
{
	mySurfaceType =  static_cast<float>(aParameterType);
}


int AudioManager::PlayLoopingAudio(const std::string_view& aFmodLink, const Tga::Matrix4x4f& aTransform)
{
	int id = myNextSoundId++;

	FMOD::Studio::EventDescription* desc = nullptr;
	myStudioSystem->getEvent(aFmodLink.data(), &desc);

	FMOD::Studio::EventInstance* instance = nullptr;
	desc->createInstance(&instance);

	Tga::Vector3f pos = aTransform.GetPosition();
	Tga::Vector3f up = aTransform.GetUp().GetNormalized();
	Tga::Vector3f forward = aTransform.GetForward().GetNormalized();

	FMOD_3D_ATTRIBUTES attributes = {};
	attributes.position = { ConvertToMeters(pos).x, ConvertToMeters(pos).y, ConvertToMeters(pos).z };
	attributes.forward = { forward.x, forward.y, forward.z };
	attributes.up = { up.x, up.y, up.z };

	instance->set3DAttributes(&attributes);

	instance->start();

	myLoopingSounds[id] = instance;
	return id;
}

void AudioManager::UpdateLoopingAudio(int aId, const Tga::Matrix4x4f& aTransform)
{
	auto it = myLoopingSounds.find(aId);
	if (it == myLoopingSounds.end())
	{
		return;
	}

	FMOD::Studio::EventInstance* instance = it->second;

	Tga::Vector3f pos = aTransform.GetPosition();
	Tga::Vector3f up = aTransform.GetUp().GetNormalized();
	Tga::Vector3f forward = aTransform.GetForward().GetNormalized();

	FMOD_3D_ATTRIBUTES attributes = {};
	attributes.position = { ConvertToMeters(pos).x, ConvertToMeters(pos).y, ConvertToMeters(pos).z };
	attributes.forward = { forward.x, forward.y, forward.z };
	attributes.up = { up.x, up.y, up.z };

	instance->set3DAttributes(&attributes);
}

void AudioManager::StopLoopingAudio(int aId)
{
	auto it = myLoopingSounds.find(aId);
	if (it != myLoopingSounds.end())
	{
		it->second->stop(FMOD_STUDIO_STOP_ALLOWFADEOUT);
		it->second->release();
		myLoopingSounds.erase(it);
	}
}

//////////////////////////////////////////////////////

void AudioManager::PlayActorAudio(ActorType anActorType, AudioIdentifier anAudioIdentifier, const Tga::Matrix4x4f& aTransform)
{
	aTransform;
	switch (anAudioIdentifier)
	{
		case AudioIdentifier::FOOTSTEPS:
		{
			switch (anActorType)
			{
			case ActorType::Player:
				break;
			}

			break;
		}
		case AudioIdentifier::MELEE:
		{
			switch (anActorType)
			{
			case ActorType::Player:
				break;
			}

			break;
		}
		case AudioIdentifier::RANGED:
		{
			switch (anActorType)
			{
			case ActorType::Player:
				break;
			}

			break;
		}
		case AudioIdentifier::DEATH:
		{
			switch (anActorType)
			{
			case ActorType::Player:
				break;
			}

			break;
		}
		case AudioIdentifier::IDLE:
		{
			switch (anActorType)
			{
				case ActorType::Player:
				{
					break;
				}
			}

			break;
		}
	}
}
void AudioManager::PlayPlayerSpecificAudio(PlayerAttackID anAudioIdentifier, const Tga::Matrix4x4f& aTransform)
{
	aTransform;
	switch (anAudioIdentifier)
	{
		case PlayerAttackID::Stabby:
		{
			break;
		}
		case PlayerAttackID::PewPew:
		{
			break;
		}
		default:
		{
			break;
		}
	}
}

void AudioManager::PlayMusic(AudioIdentifier /*anAudioIdentifier*/)
{
	//switch (anAudioIdentifier)
}
void AudioManager::PlayAmbience(AudioIdentifier /*anAudioIdentifier*/)
{
	//switch (anAudioIdentifier)
}

void AudioManager::PlaySceneAudio(SceneID anAudioIdentifier)
{
	switch (anAudioIdentifier)
	{
		case SceneID::Level1:
		{
			break;
		}
		case SceneID::Level2:
		{
			break;
		}

		case SceneID::MainMenu:
		{
			break;
		}
		case SceneID::Options:
		{
			break;
		}
		case SceneID::LevelSelect:
		{
			break;
		}
		case SceneID::Credits:
		{
			break;
		}
		case SceneID::HUD:
		{
			break;
		}
		default:
		{
			break;
		}
	}
}

//////////////////////////////////////////////////////

void AudioManager::SetMasterVolume(float aVolume)
{
	FMOD::Studio::Bus* bus = nullptr;
	myStudioSystem->getBus(AudioConstExpr::BUS_MASTER.data(), &bus);
	if (!bus)
	{
		return;
	}

	bus->setVolume(aVolume);
}
void AudioManager::SetBusVolume(const std::string_view& busPath, float aVolume)
{
	FMOD::Studio::Bus* bus = nullptr;
	myStudioSystem->getBus(busPath.data(), &bus);
	if (!bus)
	{
		return;
	}

	bus->setVolume(aVolume);
}
//
//void AudioManager::SetSFXVolume(float aVolume)
//{
//	SetBusVolume(AudioConstExpr::BUS_SFX, aVolume);
//}
//void AudioManager::SetAmbienceVolume(float aVolume)
//{
//	SetBusVolume(AudioConstExpr::BUS_AMB, aVolume);
//}
//void AudioManager::SetMusicVolume(float aVolume)
//{
//	SetBusVolume(AudioConstExpr::BUS_MUS, aVolume);
//}

float AudioManager::GetBusVolume(const std::string_view& busPath) const
{
	FMOD::Studio::Bus* bus = nullptr;
	myStudioSystem->getBus(busPath.data(), &bus);
	if (!bus)
	{
		return 0.f;
	}

	float volume = 0.f;
	bus->getVolume(&volume);

	return volume;
}

float AudioManager::GetVolume(AudioBusType anAudioType) const
{
	switch (anAudioType)
	{
		case AudioBusType::Master:
		{
			return GetBusVolume(AudioConstExpr::BUS_MASTER);
		}
		/*case AudioBusType::SFX:
		{
			return GetBusVolume(AudioConstExpr::BUS_SFX);
		}
		case AudioBusType::Ambience:
		{
			return GetBusVolume(AudioConstExpr::BUS_AMB);
		}
		case AudioBusType::Music:
		{
			return GetBusVolume(AudioConstExpr::BUS_MUS);
		}*/
	}
	return 0.5f;
}