#pragma once

#include <tge/graphics/Light.h>

namespace Tga
{
	class SpotLight : public Light
	{
	protected:
		Vector3f myDirection;
		float myRange = 10.0f;
		float myInnerAngle;
		float myOuterAngle;

	public:
		SpotLight() :
			Light(Matrix4x4f{}, {}, {})
		{
		};

		SpotLight(const Matrix4x4f& someTransform, const Color& aColor, float aIntensity, float someRange, Vector3f aDirection,
			float aInnerAngle, float aOuterAngle) :
			Light(someTransform, aColor, aIntensity),
			myDirection(aDirection),
			myRange(someRange),
			myInnerAngle(aInnerAngle),
			myOuterAngle(aOuterAngle)

		{
		}
		~SpotLight() override = default;

		void SetRange(float someRange);
		float GetRange() const {return myRange;}

		Vector3f GetDirection() const {return myDirection;}

		float GetInnerAngle() const {return myInnerAngle;}
		float GetOuterAngle() const {return myOuterAngle; }

		void SetSpeed(float aSpeed) { mySpeed = aSpeed; }
		float GetSpeed() { return mySpeed; }

	private:
		float mySpeed = 100.f;
	};
} // namespace Tga

