#pragma once
//#pragma message(__FILE__" was compiled")
//// GOTTA FIX TEXTURE PATHS TO TGE'S NEW VERSION
#include "SpawnedObject.h"

#include <unordered_map>
#include <tge\scene\SceneObjectDefinition.h>
#include "VFXinfo.h"
#include <tge/math/Vector3.h>
#include <tge/math/Matrix4x4.h>

class VFXManager
{
public:

	VFXAsset GetVFX(Tga::StringId aVFX);
	const std::unordered_map<Tga::StringId, VFXAsset>& GetCached3DVFX();

	static VFXManager* GetInstance();
	static void DestroyInstance();
	void CacheVfx(std::vector<Tga::ScenePropertyDefinition>& someSceneObjectProperties, Tga::StringId aStringID, Tga::TextureManager& aTextureManager);
	void PlayVFX(Tga::StringId id, const Tga::Vector3f& pos);
	void PlayVFX(Tga::StringId id, const Tga::Matrix4x4f& aTransform);

	std::shared_ptr<SpawnedObject> PlayVFXReturnObject(Tga::StringId vfxName, const Tga::Matrix4x4f& aTransform);

#ifndef _RETAIL
	void DebugSpawnAllVfx();
#endif

private:
	static VFXManager* ourInstance;
	std::unordered_map<Tga::StringId, VFXAsset> myCachedVFXAssets;

	//std::unordered_map<Tga::StringId, VFXInfo> myCachedVFX;
	//static float ourDefaultFPS;
	//Tga::Camera* myCamera;
};