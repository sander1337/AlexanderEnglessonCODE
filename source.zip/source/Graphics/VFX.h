//#pragma once
////#pragma message(__FILE__" was compiled")
//// GOTTA FIX TEXTURE PATHS TO TGE'S NEW VERSION
//
//#include <tge/stringRegistry/StringRegistry.h>
//#include <map>
//#include "VFXinfo.h"
//
//class GameScene;
//
//class VFX
//{
//public:
//	// Singleton access
//	static VFX* GetInstance();
//	static void DestroyInstance();
//
//	VFX();
//	void Update();
//	void Render();
//	void RenderBehind();
//	void RenderInFront();
//	void PlayVFX(Tga::StringId aVFX, const Tga::Vector3f& aPosition = Tga::Vector3f::Zero);
//	/*void PlayVFX(Tga::StringId aVFX, bool atrue);
//	void PlayVFX(VFXType aVFXType);*/
//	void StopVFX(Tga::StringId aVFX);
//	void StopVFX(VFXType aVFXType);
//	void UpdateVFX(VFXInfo* aVFX);
//	void UpdateModelVFX(VFXInfo* aVFX);
//	void SetPosition(Tga::Vector3f& aColliderPos, Tga::Vector3f aDirection = Tga::Vector3f{ 1.0f, 0.f, 1.f });
//	void SetSize(Tga::Vector2f& aSize);
//	void SetScale(Tga::Vector3f& aScalar);
//	int GetAmount();
//
//	Tga::StringId ConvertVFXTypeToStringId(VFXType aVFXType);
//	VFXType ConvertStringIdToVFXType(Tga::StringId anAnimation);
//
//	// ---- Debug ----
//
//	void DebugSpawnAllVfx();
//
//private:
//	static VFX* ourInstance;
//
//	void SetTransformForSpecificVFX(Tga::Matrix4x4f aTransform, VFXInfo* aVFX, bool aBillboard = true);
//	void SetPositionForSpecificVFX(Tga::Vector3f& aPosition, VFXInfo* aVFX);
//	void RescaleSpecificVFX(VFXInfo* aVFX);
//	void RotateSpecificVFX(float anAngle, VFXInfo* aVFX);
//	Tga::Matrix4x4f CreateBillboardMatrix(const Tga::Vector3f& aPosition, const Tga::Vector3f& aTargetPosition, const Tga::Vector3f aScale);
//	Tga::Matrix4x4f CreateBulletMatrix(const Tga::Matrix4x4f& aTransform, const Tga::Vector3f& aScale);
//
//	// The int represents layer order, the vector holds all the VFX on that layer
//	std::vector<VFX3DData> my3DVfx;
//	std::map<int, std::vector<VFXInfo>> myVFXAll;
//	Tga::Vector2f mySize;
//	Tga::Vector2f myPivot;
//	Tga::Vector3f myScale{ 1.f,1.f, 1.f };
//
//	bool mySlowmo = false;
//};
