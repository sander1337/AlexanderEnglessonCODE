#pragma once
//#pragma message(__FILE__" was compiled")
// Need to clean up a bunch here

#include <tge/sprite/sprite.h>
#include <tge/stringRegistry/StringRegistry.h>
#include <unordered_map>

namespace Tga
{
	struct GameSpriteData;
	class SceneObject;
	struct ScenePropertyDefinition;
}

enum Orientation
{
	Left,
	Right
};

// Rename FlipBookData
struct SpriteInfo3D
{
	bool loop;
	bool hasLeftAndRight;
	int frames;
	int columns;
	int rows;
	float fps;
	Tga::SpriteSharedData sharedDataRight;
	Tga::SpriteSharedData sharedDataLeft;
	Tga::SpriteSharedData sharedData;
};

// Rename FlipBookSprite?
class GameSprite
{
public:
	GameSprite();

	void Update();
	void Render();
	void UpdateAndRender();
	Tga::SpriteSharedData* GetSharedData();
	Tga::Sprite3DInstanceData* GetSpriteInstance();
	
	void Init(const Tga::GameSpriteData& someSpriteData, const Tga::SceneObject& anObject);
	void AddSpriteFromFilePath(std::string& aFilePath);

	void PlayAnimation(Tga::StringId anAnimation);
	Tga::StringId GetCurrentAnimation();

	// vvv Rename GetCurrentFlipBook
	SpriteInfo3D GetSprite();

	void SetPosition(Tga::Vector3f aPosition);
	void SetPosition(Tga::Vector2f aPosition);
	Tga::Vector2f GetPosVec2() const;

	void SetTransformFromSceneObject(const Tga::SceneObject& anObject);
	void SetScale(Tga::Vector3f aScalar);
	void SetTransform(Tga::Matrix4x4f aTransform);
	void SetRotation(Tga::Vector3f aEuler);

	void SetSize(Tga::Vector2f aSize);
	Tga::Vector2f GetSize();

	Tga::Vector3f GetScale();
	
	void SetColor(Tga::Color aColor);
	Tga::Color GetColor();

	void SetTemporaryFPS(float anFPS);
	void SetAnimationSpecificFPS(Tga::StringId anAnimationState, float anFPS);

	int GetCurrentFrame() const;
	bool GetIsFinished();

	void SetShader(Tga::SpriteShader* aShader, Tga::StringId anAnimation = ""_tgaid);

	int GetFrameAmount(Tga::StringId aAnimationState);
	void IncreaseSpriteCount(int aFrames = 1);
	void DecreaseSpriteCount(int aFrames = 1);
	// vvv Rename SetCurrentFrame
	void SetSpriteCount(int aCurrentFrame);

private:
	std::unordered_map<Tga::StringId, SpriteInfo3D> mySprites;
	int myCurrentFrame;
	Tga::StringId myCurrentAnimation;
	Orientation myOrientation;
	Tga::Sprite3DInstanceData my3DSpriteInstance;
	float myCountdown;
	float myFPS;
	float myUpcomingFPS;
	Tga::Vector2f mySize;
	Tga::Vector2f myPivot;
	Tga::Vector3f myScale;
	Tga::Vector3f myRotation;
	Tga::Vector2f myPosition;
	bool myHasTint = false;
	bool myHasOpacity = false;
	float myDarkestValue;
	float myAngle;

	bool mySlowmo = false;
};