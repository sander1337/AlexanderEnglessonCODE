#include "stdafx.h"
#include "VFXManager.h"

// GOTTA FIX TEXTURE PATHS TO TGE'S NEW VERSION

#include "SpawnedObject.h"
#include "../GameWorld.h"

#include <tge/scene/ScenePropertyTypes.h>
#include <tge/texture/TextureManager.h>
#include <tge/engine.h>
#include <tge/error/ErrorManager.h>
#include <tge/model/ModelFactory.h>
#include <tge\graphics\Camera.h>
#include <tge/render/EffectMaterial.h>
#include "../Render/RenderManager.h"
#include "../SceneManagement/GameScene.h"

VFXManager* VFXManager::ourInstance = nullptr;
//float VFXManager::ourDefaultFPS = 1.f / 24.f;

using namespace Tga;

VFXAsset VFXManager::GetVFX(Tga::StringId aVFX)
{
	auto it = myCachedVFXAssets.find(aVFX);

	if (it != myCachedVFXAssets.end())
	{
		return it->second;
	}
	else
	{
		ERROR_PRINT("Asked for VFX type %s which does not exist in the registry! Returned inaccurate VFXAsset.", aVFX.GetString());
	}

	return VFXAsset();
}

const std::unordered_map<Tga::StringId, VFXAsset>& VFXManager::GetCached3DVFX()
{
	return myCachedVFXAssets;
}

VFXManager* VFXManager::GetInstance()
{
	if (ourInstance == nullptr)
	{
		ourInstance = new(VFXManager);
		//ourDefaultFPS = 1.f / 24.f;
	}

	return ourInstance;
}

void VFXManager::DestroyInstance()
{
	delete ourInstance;
}

void VFXManager::CacheVfx(std::vector<Tga::ScenePropertyDefinition>& someSceneObjectProperties, StringId aStringID, TextureManager& aTextureManager)
{
	VFXAsset vfxAsset;

	for (Tga::ScenePropertyDefinition& property : someSceneObjectProperties)
	{
		// --- Model ---
		if (property.type == Tga::GetPropertyType<Tga::CopyOnWriteWrapper<Tga::SceneModel>>())
		{
			const Tga::SceneModel& model = property.value.Get<Tga::CopyOnWriteWrapper<Tga::SceneModel>>()->Get();
			std::shared_ptr<ModelInstance> instance = Tga::ModelFactory::GetInstance().GetModelInstance(model);

			instance->SetRasterizerState(model.rasterizerState);
			instance->SetBlendState(model.blendState);

			vfxAsset.modelInstance = instance;
			vfxAsset.type = VFXType::Model;
		}
		if (property.type == Tga::GetPropertyType<Tga::CopyOnWriteWrapper<Tga::SceneSprite>>())
		{
			const Tga::SceneSprite& editorSprite = property.value.Get<Tga::CopyOnWriteWrapper<Tga::SceneSprite>>()->Get();
			RenderManager& renderManager         = *GameWorld::GetInstance().GetRenderManager().lock();
			NCE::RenderResources& renderResources = renderManager.GetRenderResources();

			// ***** BUILD CACHE KEY *****
			SpriteSharedDataKey cacheKey;
			cacheKey.texture0 = editorSprite.textures[0];
			cacheKey.texture1 = editorSprite.textures[1];
			cacheKey.texture2 = editorSprite.textures[2];
			cacheKey.texture3 = editorSprite.textures[3];
			cacheKey.pixelShader = editorSprite.shader.pixel;
			cacheKey.isBillboard = editorSprite.hasBillBoardEffect;
			cacheKey.rasterizerState = editorSprite.rasterizerState;
			cacheKey.blendState = editorSprite.blendState;
			cacheKey.depthStencilState = editorSprite.depthStencilState;
			cacheKey.samplerFilter = editorSprite.samplerfilter;

			//// Texture key 
			//const char* texturePath = editorSprite.textures[0].GetString();
			//Tga::StringId textureID = Tga::StringRegistry::RegisterOrGetString(texturePath);

			std::scoped_lock lock(renderResources.mySpriteCacheMutex);

			// Try to reuse shared data 
			auto sharedIt = renderResources.mySpriteSharedDataTest.find(cacheKey);
			if (sharedIt == renderResources.mySpriteSharedDataTest.end())
			{
				// Create new shared data
				Tga::SpriteSharedData sharedData = {};

				auto LoadIfNotEmpty = [&](const Tga::StringId& aStringId, TextureSrgbMode aMode) -> Texture*
					{
						const char* p = aStringId.GetString();
						if (!p || p[0] == '\0')
						{
							return nullptr;
						}
						return aTextureManager.GetTexture(p, aMode);
					};

				sharedData.myTexture = LoadIfNotEmpty(editorSprite.textures[0], TextureSrgbMode::ForceSrgbFormat);
				sharedData.myMaps[0] = LoadIfNotEmpty(editorSprite.textures[1], TextureSrgbMode::ForceNoSrgbFormat);
				sharedData.myMaps[1] = LoadIfNotEmpty(editorSprite.textures[2], TextureSrgbMode::ForceNoSrgbFormat);
				sharedData.myMaps[2] = LoadIfNotEmpty(editorSprite.textures[3], TextureSrgbMode::ForceNoSrgbFormat);
				sharedData.isBillboard = editorSprite.hasBillBoardEffect;
				sharedData.rasterizerState = editorSprite.rasterizerState;
				sharedData.depthStencilState = editorSprite.depthStencilState;
				sharedData.samplerFilter = editorSprite.samplerfilter;
				sharedData.blendState = editorSprite.blendState;

				// Optional custom pixel shader 
				if (!editorSprite.shader.pixel.IsEmpty())
				{
					const char* pixelPath = editorSprite.shader.pixel.GetString();
					Tga::StringId shaderID = Tga::StringRegistry::RegisterOrGetString(pixelPath);

					auto shaderIt = renderResources.mySpriteShaders.find(shaderID);
					if (shaderIt == renderResources.mySpriteShaders.end())
					{
						auto shader = std::make_unique<Tga::SpriteShader>();
						shader->Init("Shaders/instanced_sprite_shader_VS", pixelPath);
						sharedData.myCustomShader = shader.get();
						renderResources.mySpriteShaders.emplace(shaderID, std::move(shader));
					}
					else
					{
						sharedData.myCustomShader = shaderIt->second.get();
					}
				}

				sharedIt = renderResources.mySpriteSharedDataTest.emplace(cacheKey, std::make_shared<SpriteSharedData>(sharedData)).first;
			}
			std::shared_ptr<Sprite3DInstanceData> instance = std::make_shared<Sprite3DInstanceData>();
			instance->mySize = editorSprite.size;

			vfxAsset.type = VFXType::Sprite;
			vfxAsset.sprite3DInstanceData = std::move(instance);
			vfxAsset.spriteSharedData = sharedIt->second;
		}

		if (property.type == Tga::GetPropertyType<Tga::CopyOnWriteWrapper<Tga::VFXData>>())
		{
			const Tga::VFXData& editorData = property.value.Get<Tga::CopyOnWriteWrapper<Tga::VFXData>>()->Get();

			vfxAsset.shouldLoop = editorData.shouldLoop;
			vfxAsset.lifetime = editorData.lifetime;
			// Copy Size Data
			vfxAsset.sizeOverLifetime.clear();
			for (const auto& key : editorData.sizeOverLifetime)
			{
				vfxAsset.sizeOverLifetime.push_back({ key.time, key.value });
			}
			// Copy Rotation data
			vfxAsset.RotationOverLifetime = editorData.rotationOverTime;
			// Copy X velocity curve
			vfxAsset.velocityOverLifetimeX.clear();
			for (const auto& key : editorData.velocityX)
			{
				vfxAsset.velocityOverLifetimeX.push_back({ key.time, key.value });
			}
			// Copy Y velocity curve
			vfxAsset.velocityOverLifetimeY.clear();
			for (const auto& key : editorData.velocityY)
			{
				vfxAsset.velocityOverLifetimeY.push_back({ key.time, key.value });
			}
			// Copy Z velocity curve
			vfxAsset.velocityOverLifetimeZ.clear();
			for (const auto& key : editorData.velocityZ)
			{
				vfxAsset.velocityOverLifetimeZ.push_back({ key.time, key.value });
			}
			// --- Copy Color Curves (new) ---
			vfxAsset.colorOverLifetimeR.clear();
			for (const auto& key : editorData.colorR)
			{
				vfxAsset.colorOverLifetimeR.push_back({ key.time, key.value });
			}
			vfxAsset.colorOverLifetimeG.clear();
			for (const auto& key : editorData.colorG)
			{
				vfxAsset.colorOverLifetimeG.push_back({ key.time, key.value });
			}
			vfxAsset.colorOverLifetimeB.clear();
			for (const auto& key : editorData.colorB)
			{
				vfxAsset.colorOverLifetimeB.push_back({ key.time, key.value });
			}
			vfxAsset.colorOverLifetimeA.clear();
			for (const auto& key : editorData.colorA)
			{
				vfxAsset.colorOverLifetimeA.push_back({ key.time, key.value });
			}
		}
		if (property.type == Tga::GetPropertyType<Tga::CopyOnWriteWrapper<Tga::EffectMaterialData>>())
		{
			const Tga::EffectMaterialData& editorData = property.value.Get<Tga::CopyOnWriteWrapper<Tga::EffectMaterialData>>()->Get();

			std::shared_ptr<EffectMaterial> effectMaterial = std::make_shared<EffectMaterial>();

			EffectParameters effectParameters;

			effectParameters.customParametersVector4 = editorData.customParameterVector4;
			effectParameters.customParametersVector2 = editorData.customParameterVector2;
			effectParameters.customParametersVector2second = editorData.customParameterVector2second;
			effectParameters.customParameter1 = editorData.customParameter1;
			effectParameters.customParameter2 = editorData.customParameter2;
			effectParameters.customParameter3 = editorData.customParameter3;
			effectParameters.customParameter4 = editorData.customParameter4;
			effectParameters.customParameter5 = editorData.customParameter5;
			effectParameters.customParameter6 = editorData.customParameter6;

			effectMaterial->SetEffectParameters(effectParameters);

			for (int i = 0; i < MAX_CUSTOM_TEXTURES; i++)
			{
				if (!editorData.textures[i].IsEmpty())
				{
					TextureSrgbMode srgbMode = editorData.isSRGB[i] ? TextureSrgbMode::ForceSrgbFormat : TextureSrgbMode::ForceNoSrgbFormat;
					Texture* texture = aTextureManager.GetTexture(editorData.textures[i].GetString(), srgbMode);

					if (texture)
					{
						effectMaterial->SetTexture(i, texture);
					}
				}
			}

			vfxAsset.effectMaterial = std::move(effectMaterial);
		}
	}
	
	myCachedVFXAssets.emplace(aStringID, vfxAsset);
}

void VFXManager::PlayVFX(Tga::StringId id, const Tga::Vector3f& pos)
{
	PlayVFX(id, Matrix4x4f::CreateFromTranslation(pos));
}

void VFXManager::PlayVFX(Tga::StringId id, const Tga::Matrix4x4f& aTransform)
{
	GameScene& gameScene = *GameWorld::GetInstance().GetCurrentGameScene().lock();

	auto it = myCachedVFXAssets.find(id);
	if (it == myCachedVFXAssets.end())
	{
		std::cout << "Caching VFX '" << id.GetString() << "'\n";
		GameWorld::GetInstance().LoadAssetToScene(id, aTransform, true);
		it = myCachedVFXAssets.find(id);
		if (it == myCachedVFXAssets.end())
		{
			std::cerr << "Failed to cache VFX '" << id.GetString() << "'\n";
			return;
		}
	}
	const VFXAsset& asset = it->second;


	auto obj = std::make_shared<SpawnedObject>();
	obj->Init();

	// Clone the asset into the runtime object

	if (asset.type == VFXType::Sprite)
	{
		std::shared_ptr<Sprite3DInstanceData> const instance = std::make_shared<Sprite3DInstanceData>(*asset.sprite3DInstanceData);
		obj->Set3DSpriteInstance(instance);
		obj->SetSpriteSharedData(asset.spriteSharedData);
	}
	else
	{
		std::shared_ptr<ModelInstance> instance = std::make_shared<ModelInstance>(*asset.modelInstance);
		obj->SetModelInstance(std::move(instance));
	}
	obj->SetType(asset.type);
	obj->SetLifeTime(asset.lifetime);
	obj->SetSizeOverLifetime(asset.sizeOverLifetime);
	obj->SetVelocityOverLifetimeX(asset.velocityOverLifetimeX);
	obj->SetVelocityOverLifetimeY(asset.velocityOverLifetimeY);
	obj->SetVelocityOverLifetimeZ(asset.velocityOverLifetimeZ);
	obj->SetRotationOverLifetime(asset.RotationOverLifetime);
	obj->SetColorOverLifetimeR(asset.colorOverLifetimeR);
	obj->SetColorOverLifetimeG(asset.colorOverLifetimeG);
	obj->SetColorOverLifetimeB(asset.colorOverLifetimeB);
	obj->SetColorOverLifetimeA(asset.colorOverLifetimeA);
	obj->SetShouldLoop(asset.shouldLoop);
	obj->SetEffectMaterial(asset.effectMaterial);

	float totalTime = Engine::GetInstance()->GetTotalTime();
	obj->SetSpawnedTime(totalTime);

	
	obj->SetTransform(aTransform); 

	gameScene.AddSpawnedObject(obj);
}

std::shared_ptr<SpawnedObject> VFXManager::PlayVFXReturnObject(Tga::StringId vfxName, const Tga::Matrix4x4f& aTransform)
{
	auto it = myCachedVFXAssets.find(vfxName);
	if (it == myCachedVFXAssets.end())
	{
		std::cout << "Caching VFX '" << vfxName.GetString() << "'\n";
		GameWorld::GetInstance().LoadAssetToScene(vfxName, aTransform, true);
		it = myCachedVFXAssets.find(vfxName);
		if (it == myCachedVFXAssets.end())
		{
			std::cerr << "Failed to cache VFX '" << vfxName.GetString() << "'\n";
			return nullptr;
		}
	}

	// We now have the asset cached
	const VFXAsset& asset = it->second;

	// --------------------------------------
   // Create runtime instance
   // --------------------------------------
	std::shared_ptr<SpawnedObject> obj = std::make_shared<SpawnedObject>();
	obj->Init();

	// 3D sprite OR 3D model
	if (asset.type == VFXType::Sprite)
	{
		obj->Set3DSpriteInstance(asset.sprite3DInstanceData);
		obj->SetSpriteSharedData(asset.spriteSharedData);
	}
	else
	{
		obj->SetModelInstance(std::make_shared<ModelInstance>(*asset.modelInstance));
	}

	obj->SetType(asset.type);

	// Transform
	obj->SetTransform(aTransform);

	// Lifetime
	obj->SetLifeTime(asset.lifetime);
	obj->SetSpawnedTime(Engine::GetInstance()->GetTotalTime());

	// Curves and behavior
	obj->SetSizeOverLifetime(asset.sizeOverLifetime);
	obj->SetVelocityOverLifetimeX(asset.velocityOverLifetimeX);
	obj->SetVelocityOverLifetimeY(asset.velocityOverLifetimeY);
	obj->SetVelocityOverLifetimeZ(asset.velocityOverLifetimeZ);
	obj->SetRotationOverLifetime(asset.RotationOverLifetime);

	obj->SetColorOverLifetimeR(asset.colorOverLifetimeR);
	obj->SetColorOverLifetimeG(asset.colorOverLifetimeG);
	obj->SetColorOverLifetimeB(asset.colorOverLifetimeB);
	obj->SetColorOverLifetimeA(asset.colorOverLifetimeA);

	obj->SetShouldLoop(asset.shouldLoop);
	obj->SetEffectMaterial(asset.effectMaterial);

	// --------------------------------------
	// Add to the scene
	// --------------------------------------
	auto scene = GameWorld::GetInstance().GetCurrentGameScene().lock();
	scene->AddSpawnedObject(obj);

	return obj;
}

#ifndef _RETAIL
void VFXManager::DebugSpawnAllVfx()
{
	const float spacing = 500.f;
	const float heightOffset = 50.f;
	const int perRow = 3;

	int index = 0;

	for (auto& vfx : myCachedVFXAssets)
	{
		vfx.second.shouldLoop = true;
		int row = index / perRow;
		int col = index % perRow;

		Matrix4x4f transform;

		if (vfx.second.modelInstance)
		{
			transform = vfx.second.modelInstance->GetTransform();
		}
		else
		{
			transform = vfx.second.sprite3DInstanceData->myTransform;
		}

		Vector3f pos = {
			col * spacing,
			heightOffset,
			row * spacing
		};
		
		transform.SetPosition(pos);

		PlayVFX(vfx.first, transform);

		++index;
	}

}
#endif
