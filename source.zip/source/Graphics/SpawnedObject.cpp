#include "stdafx.h"
#include "SpawnedObject.h"
#include "tge/drawers/ModelDrawer.h"
#include "tge/Graphics/GraphicsStateStack.h"
void SpawnedObject::Init()
{
    myElapsed = 0.f;
}

void SpawnedObject::Update(float aDeltaTime)
{
    if (myLifetime > 0.f)
    {
        myElapsed += aDeltaTime;

        // Start Over if looping
        if (myElapsed >= myLifetime)
        {
            if (myShouldLoop)
            {
                myElapsed = 0.f; // restart the timeline
            }
            else
            {
                return; // stop updating
            }
        }

        // --- Evaluate size over lifetime ---
        if (!mySizeOverLifetime.empty())
        {
            float t = std::clamp(myElapsed / myLifetime, 0.0f, 1.0f);

            // Linear interpolation between curve keys
            size_t segment = 0;
            while (segment + 1 < mySizeOverLifetime.size() && mySizeOverLifetime[segment + 1].time < t)
                ++segment;

            if (segment + 1 >= mySizeOverLifetime.size())
                myCurrentSize = mySizeOverLifetime.back().value;
            else
            {
                const auto& k0 = mySizeOverLifetime[segment];
                const auto& k1 = mySizeOverLifetime[segment + 1];
                float localT = (t - k0.time) / (k1.time - k0.time);
                myCurrentSize = k0.value * (1.0f - localT) + k1.value * localT;
            }
        }

        // --- Rotation over lifetime ---
        float t = std::clamp(myElapsed / myLifetime, 0.0f, 1.0f);
        Tga::Vector3f currentRotation = myRotationOverLifetime * t;

        if (currentRotation.Length() > 0)
        {
            ApplyRotation(currentRotation);
        }

        // --- Position update based on velocity over lifetime ---
        Tga::Vector3f velocity(0.0f, 0.0f, 0.0f);

        auto EvaluateCurve = [&](const std::vector<Curve>& curve) -> float {
            if (curve.empty()) return 0.f;
            size_t segment = 0;
            while (segment + 1 < curve.size() && curve[segment + 1].time < t)
                ++segment;
            if (segment + 1 >= curve.size()) return curve.back().value;

            const auto& k0 = curve[segment];
            const auto& k1 = curve[segment + 1];
            float localT = (t - k0.time) / (k1.time - k0.time);
            return k0.value * (1.0f - localT) + k1.value * localT;
            };

        velocity.x = EvaluateCurve(myVelocityOverLifetimeX);
        velocity.y = EvaluateCurve(myVelocityOverLifetimeY);
        velocity.z = EvaluateCurve(myVelocityOverLifetimeZ);

        // Get current position, add displacement, set new position
        Tga::Vector3f currentPosition = GetPosition();
        currentPosition += velocity * 100.f * aDeltaTime;
        SetPosition(currentPosition);

        UpdateTransform();
    }
}

void SpawnedObject::JumpToSecondLastKey()
{
    if (mySizeOverLifetime.empty())
    {
        return;
    }
    if (mySizeOverLifetime.size() < 2)
        return;

    // Set the elapsed time to the second-last key
    const Curve& key = mySizeOverLifetime[mySizeOverLifetime.size() - 2];
    myElapsed = key.time * myLifetime;

    // Recalculate values for this moment
    float t = std::clamp(myElapsed / myLifetime, 0.f, 1.f);

    myCurrentSize = EvaluateCurve(mySizeOverLifetime, t);
    ApplyScale(myCurrentSize);
    
    Tga::Vector3f rotation = myRotationOverLifetime * t;
    ApplyRotation(rotation);

    // Fix shader timing
    mySpawnedTime = Tga::Engine::GetInstance()->GetTotalTime() - myElapsed;

}

bool SpawnedObject::IsExpired() const
{
    return (myLifetime > 0.f && myElapsed >= myLifetime);
}

bool SpawnedObject::SetIsExpired(bool aIsExpired)
{
    myIsExpired = aIsExpired;
    return myIsExpired;
}
void SpawnedObject::SetSpawnedTime(float aTotalTime)
{
    mySpawnedTime = aTotalTime;
}

void SpawnedObject::SetModelInstance(const std::shared_ptr <Tga::ModelInstance> aInstance)
{
    myModelInstance = aInstance;
}

void SpawnedObject::SetPosition(const Tga::Vector3f aPosition)
{
    if (myVFXType == VFXType::Sprite)
    {
        if (mySprite3DInstanceData)
        {
            mySprite3DInstanceData->myTransform.SetPosition(aPosition);
        }
    }
    else if (myModelInstance)
    {
        myModelInstance->GetTransform().SetPosition(aPosition);
    }
}

void SpawnedObject::SetTransform(const Tga::Matrix4x4f aTransform)
{
   // myTransform = aTransform;
    if (myVFXType == VFXType::Sprite)
    {
        if (mySprite3DInstanceData)
        {
            mySprite3DInstanceData->myTransform = aTransform;
        }
    }
    else
    {
        if (myModelInstance)
        {
            myModelInstance->SetTransform(aTransform);
        }
    }
}

const Tga::Matrix4x4f& SpawnedObject::GetTransform() const
{
   // return myTransform;
    if (myVFXType == VFXType::Sprite)
    {
       return mySprite3DInstanceData->myTransform;
    }
    else
    {
       return myModelInstance->GetTransform();
    }
}

void SpawnedObject::SetRotation(const Tga::Vector3f aRotation)
{
    myModelInstance->GetTransform().SetRotation(aRotation);
}

void SpawnedObject::Set3DSpriteInstance(const std::shared_ptr<Tga::Sprite3DInstanceData>& aSprite)
{
    mySprite3DInstanceData = aSprite;
}

void SpawnedObject::SetSpriteSharedData(const std::shared_ptr<Tga::SpriteSharedData>& aSpriteSharedData)
{
    mySharedData = aSpriteSharedData;
}

void SpawnedObject::SetLifeTime(const float aLifeTime)
{
    myLifetime = aLifeTime;
}

void SpawnedObject::SetSizeOverLifetime(const std::vector<Curve>& aCurve)
{
    mySizeOverLifetime = aCurve;
}

void SpawnedObject::SetType(VFXType aVFXType)
{
    myVFXType = aVFXType;
}

void SpawnedObject::SetSpriteSize(float aScale)
{
    mySpriteSize = aScale;
}

Tga::SpriteSharedData* SpawnedObject::GetSpriteSharedData()
{
    return mySharedData.get();
}

const Tga::SpriteSharedData* SpawnedObject::GetSpriteSharedData() const
{
    return mySharedData.get();
}

std::shared_ptr<Tga::Sprite3DInstanceData>& SpawnedObject::Get3DSpriteInstance() 
{
    return mySprite3DInstanceData;
}

const std::shared_ptr<Tga::Sprite3DInstanceData>& SpawnedObject::Get3DSpriteInstance() const
{
    return mySprite3DInstanceData;
}

const Tga::ModelInstance& SpawnedObject::GetModelInstance() const
{
    return *myModelInstance;
}

const std::shared_ptr<Tga::ModelInstance>& SpawnedObject::GetModelInstancePtr() const
{
    return myModelInstance;
}

const BaseModelInstance* SpawnedObject::GetBaseModelInstance()
{
    return myModelInstance.get();
}

const Tga::Vector3f SpawnedObject::GetPosition() const
{
    //return myTransform.GetPosition();
    if (myVFXType == VFXType::Sprite)
    {
        if (mySprite3DInstanceData)
        {
            return mySprite3DInstanceData->myTransform.GetPosition();
        }
        
    }

    if (myModelInstance)
    {
        return myModelInstance->GetTransform().GetPosition();
    }

    return { 0.f, 0.f, 0.f };
}


float SpawnedObject::GetSizeAtElapsed() const
{
    if (mySizeOverLifetime.empty())
        return 1.0f; // default size

    float t = (myLifetime > 0.f) ? myElapsed / myLifetime : 0.f;
    t = std::clamp(t, 0.0f, 1.0f);

    // Find which segment we're in
    size_t segment = 0;
    while (segment + 1 < mySizeOverLifetime.size() && mySizeOverLifetime[segment + 1].time < t)
        ++segment;

    // Handle endpoints
    if (segment + 1 >= mySizeOverLifetime.size())
        return mySizeOverLifetime.back().value;

    // Linear interpolation between segment and next
    const auto& k0 = mySizeOverLifetime[segment];
    const auto& k1 = mySizeOverLifetime[segment + 1];
    float localT = (t - k0.time) / (k1.time - k0.time);
    return k0.value * (1.0f - localT) + k1.value * localT;
}

void SpawnedObject::ApplyRotation(const Tga::Vector3f& rot)
{
    if (myVFXType == VFXType::Sprite)
    {
        mySprite3DInstanceData->myTransform.SetRotation(rot);
    }
    else
    {
        myModelInstance->GetTransform().SetRotation(rot);
    }
}

void SpawnedObject::ApplyScale(float scale)
{
    if (myVFXType == VFXType::Sprite)
    {
        mySprite3DInstanceData->myTransform.SetScale({ scale, scale, scale });
    }
    else
    {
        myModelInstance->GetTransform().SetScale({ scale, scale, scale });
    }
}

void SpawnedObject::UpdateTransform()
{
    // this check is needed for now.
    Tga::Matrix4x4f originalTransform;
    Tga::Vector3f pivot = { 0.f, 0.f, 0.f };
    if (myVFXType == VFXType::Model && myModelInstance->IsValid())
    {
    	originalTransform = myModelInstance->GetTransform();
    	pivot = myModelInstance->GetModel()->GetMeshData(0).Bounds.Center;
    }
    else if (mySprite3DInstanceData)
    {
        originalTransform = mySprite3DInstanceData->myTransform;
    }
    else
    {
        return;
    }

    // --- Keep original position ---
    Tga::Vector3f originalPosition = originalTransform.GetPosition();

    // --- Remove translation temporarily ---
    Tga::Matrix4x4f localTransform = originalTransform;
    localTransform.SetPosition(Tga::Vector3f(0, 0, 0));

    // --- Scale around pivot ---
    localTransform.Translate(-pivot); // move pivot to origin

    // Replace current scale with new one
    localTransform.SetScale(Tga::Vector3f(myCurrentSize, myCurrentSize, myCurrentSize));

    localTransform.Translate(pivot); // move pivot back

    // --- Restore world position ---
    localTransform.SetPosition(originalPosition);

    if (myVFXType == VFXType::Model)
    {
        myModelInstance->SetTransform(localTransform);
    }
    else
    {
        mySprite3DInstanceData->myTransform = localTransform;
    }
}
