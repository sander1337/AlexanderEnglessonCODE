﻿#pragma once
//#pragma message(__FILE__" was compiled")
#include <tge/sprite/sprite.h>
#include <tge/stringRegistry/StringRegistry.h>
#include <tge/model/ModelInstance.h>

class EffectMaterial;

enum class VFXType : uint8_t
{
    Model,
    Sprite,
    Count
};

struct Curve
{
    float time;  // normalized [0,1]
    float value; // size
};

struct VFXAsset
{
    // --- If model --- TODO: Make smart pointer
    std::shared_ptr<Tga::ModelInstance> modelInstance;

    // --- If sprite ---
    std::shared_ptr<Tga::Sprite3DInstanceData> sprite3DInstanceData = nullptr;
    std::shared_ptr<Tga::SpriteSharedData> spriteSharedData = nullptr;
    // -----------------
    VFXType type;
    std::shared_ptr<EffectMaterial> effectMaterial = nullptr;

    

    float lifetime;
    bool shouldLoop;
    std::vector<Curve> sizeOverLifetime;
    Tga::Vector3f RotationOverLifetime;

    // === Velocity ===
    std::vector<Curve> velocityOverLifetimeX;   // X velocity curve
    std::vector<Curve> velocityOverLifetimeY;   // Y velocity curve
    std::vector<Curve> velocityOverLifetimeZ;   // Z velocity curve

    // === Color Over Lifetime ===
    std::vector<Curve> colorOverLifetimeR;
    std::vector<Curve> colorOverLifetimeG;
    std::vector<Curve> colorOverLifetimeB;
    std::vector<Curve> colorOverLifetimeA;
};


struct VFXInstanceData
{
    // ---- Global Simulation Settings ----
    float timeSpawned;
    float lifetime;
    Tga::Vector4f color;
};
