#pragma once
//#pragma message(__FILE__" was compiled")
#include "VFXinfo.h"

namespace Tga
{
    class ModelDrawer;
    class GraphicsStateStack;
}

class EffectMaterial;

class SpawnedObject
{
public:
    void Init();
    void Update(float aDeltaTime);
    void JumpToSecondLastKey();
    //void Render(Tga::ModelDrawer& aDrawer, Tga::GraphicsStateStack& aStateStack);
    float GetSizeAtElapsed() const;
    void ApplyRotation(const Tga::Vector3f& rot);
    void ApplyScale(float scale);
    void UpdateTransform();

    void SetModelInstance(const std::shared_ptr <Tga::ModelInstance> aInstance);
    void SetPosition(const Tga::Vector3f aPosition);
    void SetTransform(const Tga::Matrix4x4f aTransform);
    const Tga::Matrix4x4f& GetTransform() const;
    void SetRotation(const Tga::Vector3f aRotation);
    void Set3DSpriteInstance(const std::shared_ptr<Tga::Sprite3DInstanceData>& aSprite3DInstanceData);
    void SetSpriteSharedData(const std::shared_ptr<Tga::SpriteSharedData>& aSpriteSharedData);
    void SetLifeTime(const float aLifeTime);
    void SetSizeOverLifetime(const std::vector<Curve>& aCurve);
    void SetRotationOverLifetime(const Tga::Vector3f& aRotation) { myRotationOverLifetime = aRotation; }
    void SetShouldLoop(bool aShouldLoop) { myShouldLoop = aShouldLoop; }
    void SetType(VFXType aVFXType);
    void SetSpriteSize(float aScale);

    // === New velocity setters ===
    void SetVelocityOverLifetimeX(const std::vector<Curve>& aCurve) { myVelocityOverLifetimeX = aCurve; }
    void SetVelocityOverLifetimeY(const std::vector<Curve>& aCurve) { myVelocityOverLifetimeY = aCurve; }
    void SetVelocityOverLifetimeZ(const std::vector<Curve>& aCurve) { myVelocityOverLifetimeZ = aCurve; }

    void SetColorOverLifetimeR(const std::vector<Curve>& aCurve) { myColorOverLifetimeR = aCurve; }
    void SetColorOverLifetimeG(const std::vector<Curve>& aCurve) { myColorOverLifetimeG = aCurve; }
    void SetColorOverLifetimeB(const std::vector<Curve>& aCurve) { myColorOverLifetimeB = aCurve; }
    void SetColorOverLifetimeA(const std::vector<Curve>& aCurve) { myColorOverLifetimeA = aCurve; }
    void SetEffectMaterial(const std::shared_ptr<EffectMaterial>& aEffectMaterial) { myEffectMaterial = aEffectMaterial; }


    Tga::Vector4f GetColor() const {
        float t = (myLifetime > 0.f) ? std::clamp(myElapsed / myLifetime, 0.f, 1.f) : 0.f;

        float r = EvaluateCurve(myColorOverLifetimeR, t);
        float g = EvaluateCurve(myColorOverLifetimeG, t);
        float b = EvaluateCurve(myColorOverLifetimeB, t);
        float a = EvaluateCurve(myColorOverLifetimeA, t);

        return { r, g, b, a };
    }

    float EvaluateCurve(const std::vector<Curve>& curve, float t) const {
        if (curve.empty()) return 1.f; // default to 1
        // TODO: linear interpolation between keys
        for (size_t i = 1; i < curve.size(); ++i) {
            if (t <= curve[i].time) {
                float t0 = curve[i - 1].time;
                float t1 = curve[i].time;
                float v0 = curve[i - 1].value;
                float v1 = curve[i].value;
                float localT = (t - t0) / (t1 - t0);
                return v0 * (1.0f - localT) + v1 * localT;
            }
        }
        return curve.back().value;
    }

    Tga::SpriteSharedData* GetSpriteSharedData();
    const Tga::SpriteSharedData* GetSpriteSharedData() const;
    std::shared_ptr<Tga::Sprite3DInstanceData>& Get3DSpriteInstance();
    const std::shared_ptr<Tga::Sprite3DInstanceData>& Get3DSpriteInstance() const;
    const Tga::ModelInstance& GetModelInstance() const;
    const std::shared_ptr<Tga::ModelInstance>& GetModelInstancePtr() const;
    const BaseModelInstance* GetBaseModelInstance();
    const Tga::Vector3f GetPosition() const;
    const std::shared_ptr<EffectMaterial>& GetEffectMaterial() const { return myEffectMaterial; }
    float GetSpawnedTime() const { return mySpawnedTime; }
    float GetLifetime() const { return myLifetime; }
    const VFXType& GetVFXType() const { return myVFXType; }
    float GetSpriteSize() { return mySpriteSize; }
    bool ShouldLoop() { return myShouldLoop; }
    void SetSpawnedTime(float aTotalTime);
    bool IsExpired() const;
    bool SetIsExpired(bool aIsExpired);
    bool GetIsExpired() { return myIsExpired; }

private:
    VFXType myVFXType = VFXType::Count;
    std::shared_ptr <Tga::ModelInstance> myModelInstance;
    std::shared_ptr<Tga::Sprite3DInstanceData> mySprite3DInstanceData = nullptr;
    std::shared_ptr<Tga::SpriteSharedData> mySharedData = nullptr;
    std::shared_ptr<EffectMaterial> myEffectMaterial = nullptr;
    float myLifetime = -1.f; // seconds (-1 = infinite)
    float myElapsed = 0.f;
    float mySpawnedTime;
    bool myShouldLoop;
    std::vector<Curve> mySizeOverLifetime;
    float myCurrentSize = 1.0f;
    float mySpriteSize;
    Tga::Vector3f myRotationOverLifetime;
    // === Velocity curves ===
    std::vector<Curve> myVelocityOverLifetimeX;
    std::vector<Curve> myVelocityOverLifetimeY;
    std::vector<Curve> myVelocityOverLifetimeZ;

    std::vector<Curve> myColorOverLifetimeR;
    std::vector<Curve> myColorOverLifetimeG;
    std::vector<Curve> myColorOverLifetimeB;
    std::vector<Curve> myColorOverLifetimeA;
    bool myIsExpired;

};
