﻿//#include "stdafx.h"
//#include "VFX.h"
//
////// GOTTA FIX TEXTURE PATHS TO TGE'S NEW VERSION
//
//#include "SpawnedObject.h"
//#include "VFXManager.h"
//#include "../GameWorld.h"
//
//#include <tge/engine.h>
//#include <tge/graphics/GraphicsStateStack.h>
//#include <tge/graphics/GraphicsEngine.h>
//#include <tge/drawers/SpriteDrawer.h>
//#include <tge/math/Matrix2x2.h>
//#include <tge/graphics/Camera.h>
//#include <tge/graphics/DX11.h>
//#include "../SceneManagement/GameScene.h"
//
//#include "../source/SceneManagement/SceneID.h"
//
//#include <tge/drawers/ModelDrawer.h>
//
//using namespace Tga;
//
//VFX* VFX::ourInstance = nullptr;
//
//
//VFX* VFX::GetInstance()
//{
//	if (!ourInstance)
//	{
//		ourInstance = new VFX();
//	}
//	return ourInstance;
//}
//
//void VFX::DestroyInstance()
//{
//	delete ourInstance;
//	ourInstance = nullptr;
//}
//
//
//VFX::VFX()
//{
//	mySlowmo = false;
//	myScale = Tga::Vector3f{ 0.5f, 0.5f, 0.5f };
//}
//
//
//void VFX::Update()
//{
//	// UPDATE THE FRAMES FOR EACH VFX
//	for (auto& layerIterator : myVFXAll)
//	{
//		auto& it = layerIterator.second;
//		for (int j = 0; j < it.size(); j++)
//		{
//			UpdateVFX(&it[j]);
//		}
//	}
//
//	// DELETE THE VFX THAT HAS FINISHED AND IS NOT MEANT TO LOOP
//	for (auto& layerIterator : myVFXAll)
//	{
//		auto& it = layerIterator.second;
//		for (int j = 0; j < it.size(); j++)
//		{
//			if (it[j].spriteInstance.myIsHidden)
//			{
//				it.erase(it.begin() + j);
//			}
//		}
//		//if (it.empty())
//		//{
//		//	myVFXAll.erase(layerIterator);
//		//}
//	}
//}
//
//void VFX::Render()
//{
//	Update();
//
//	auto& engine = *Tga::Engine::GetInstance();
//
//	auto& graphicsStateStack = engine.GetGraphicsEngine().GetGraphicsStateStack();
//	graphicsStateStack.Push();
//	graphicsStateStack.SetCamera(graphicsStateStack.GetCamera());
//	graphicsStateStack.SetBlendState(Tga::BlendState::AlphaBlend);
//
//	auto& spriteDrawer = engine.GetGraphicsEngine().GetSpriteDrawer();
//	auto& modelDrawer = engine.GetGraphicsEngine().GetModelDrawer();
//
//	for (auto& layerIterator : myVFXAll)
//	{
//		auto& effects = layerIterator.second;
//		for (auto& effect : effects)
//		{
//			if (effect.isModel)
//			{
//
//				if (effect.modelInstance.GetShader() == nullptr)
//				{
//					// ✅ Render model-based VFX
//					modelDrawer.Draw(effect.modelInstance);
//				}
//				else
//				{
//					// ✅ Render model-based VFX + its shader
//					modelDrawer.Draw(effect.modelInstance, *effect.modelInstance.GetShader());
//				}
//			}
//			else
//			{
//				// ✅ Render sprite-based VFX
//				spriteDrawer.Draw(effect.sharedData, effect.spriteInstance);
//			}
//		}
//	}
//
//	graphicsStateStack.Pop();
//}
//
//void VFX::RenderBehind()
//{
//	auto& engine = *Tga::Engine::GetInstance();
//
//	auto& graphicsStateStack = engine.GetGraphicsEngine().GetGraphicsStateStack();
//	graphicsStateStack.Push();
//	graphicsStateStack.SetCamera(graphicsStateStack.GetCamera());
//	graphicsStateStack.SetBlendState(Tga::BlendState::AlphaBlend);
//
//	for (auto& layerIterator : myVFXAll)
//	{
//		auto& it = layerIterator.second;
//		for (int j = 0; j < it.size(); j++)
//		{
//			if (it[j].renderBehind)
//			{
//				Tga::Engine::GetInstance()->GetGraphicsEngine().GetSpriteDrawer().Draw(it[j].sharedData, it[j].spriteInstance);
//			}
//		}
//	}
//	graphicsStateStack.Pop();
//}
//
//void VFX::RenderInFront()
//{
//	auto& engine = *Tga::Engine::GetInstance();
//
//	auto& graphicsStateStack = engine.GetGraphicsEngine().GetGraphicsStateStack();
//	graphicsStateStack.Push();
//	graphicsStateStack.SetCamera(graphicsStateStack.GetCamera());
//	graphicsStateStack.SetBlendState(Tga::BlendState::AlphaBlend);
//
//	for (auto& layerIterator : myVFXAll)
//	{
//		auto& it = layerIterator.second;
//		for (int j = 0; j < it.size(); j++)
//		{
//			if (!it[j].renderBehind)
//			{
//				Tga::Engine::GetInstance()->GetGraphicsEngine().GetSpriteDrawer().Draw(it[j].sharedData, it[j].spriteInstance);
//			}
//		}
//	}
//	graphicsStateStack.Pop();
//}
//
//void VFX::PlayVFX(Tga::StringId aVFX, const Tga::Vector3f& aPosition)
//{
//	VFX3DData vfx = VFXManager::GetInstance()->GetVFX(aVFX);
//
//	if (!vfx.modelInstance.GetModel())
//	{
//		std::cerr << "Tried to play a non-model VFX: " << aVFX.GetString() << std::endl;
//		return;
//	}
//
//	vfx.modelInstance.GetTransform().SetPosition(aPosition);
//
//	//if (myVFXAll.find(vfx.layer) != myVFXAll.end())
//	//{
//	//	if (vfx.singleInstance)
//	//	{
//	//		StopVFX(aVFX);
//	//	}
//	//	myVFXAll[vfx.layer].push_back(vfx);
//	//}
//	//else
//	//{
//	//	myVFXAll.emplace(vfx.layer, std::vector<VFXInfo>{vfx});
//	//}
//
//	my3DVfx.push_back(vfx);
//
//	std::shared_ptr<SpawnedObject> spawned = std::make_shared<SpawnedObject>();
//	spawned->Init();
//	spawned->SetModelInstance(vfx.modelInstance);
//	
//	spawned->SetLifeTime(vfx.lifetime); // lasts 3 seconds
//	spawned->SetSizeOverLifetime(vfx.sizeOverLifetime);
//	spawned->SetRotationOverLifetime(vfx.RotationOverLifetime);
//	spawned->SetVelocityOverLifetimeX(vfx.velocityOverLifetimeX);
//	spawned->SetVelocityOverLifetimeY(vfx.velocityOverLifetimeY);
//	spawned->SetVelocityOverLifetimeZ(vfx.velocityOverLifetimeZ);
//	float totaltime = Engine::GetInstance()->GetTotalTime();
//	spawned->SetSpawnedTime(totaltime);
//	spawned->SetColorOverLifetimeR(vfx.colorOverLifetimeR);
//	spawned->SetColorOverLifetimeG(vfx.colorOverLifetimeG);
//	spawned->SetColorOverLifetimeB(vfx.colorOverLifetimeB);
//	spawned->SetColorOverLifetimeA(vfx.colorOverLifetimeA);
//	spawned->SetShouldLoop(vfx.shouldLoop);
//	spawned->SetEffectMaterial(vfx.effectMaterial);
//
//	std::shared_ptr gameScene = GameWorld::GetInstance().GetCurrentGameScene().lock();
//
//	std::cout << static_cast<int>(gameScene->GetSceneID()) << "\n";
//
//	if (gameScene->GetSceneID() == SceneID::TestScene)
//	{
//		spawned->SetShouldLoop(true);
//	}
//
//	gameScene->AddSpawnedObject(spawned);
//
//	//aScene->AddSpawnedObject(spawned);
//}
//
//
//
////void VFX::PlayVFX(Tga::StringId aVFX, bool atrue)
////{
////	atrue;
////	// Get the VFX definition from registry
////	VFXInfo vfx = VFXManager::GetInstance()->GetVFX(aVFX);
////
////	// Make sure it’s a 3D model VFX
////	if (!vfx.isModel)
////	{
////		std::cerr << "VFX::PlayModelVFX called with a non-model VFX: " << aVFX.GetString() << std::endl;
////		return;
////	}
////
////	// Make sure the layer exists or create it
////	if (myVFXAll.find(vfx.layer) != myVFXAll.end())
////	{
////		if (vfx.singleInstance)
////		{
////			StopVFX(aVFX);
////		}
////		myVFXAll[vfx.layer].push_back(vfx);
////	}
////	else
////	{
////		myVFXAll.emplace(vfx.layer, std::vector<VFXInfo>{ vfx });
////	}
////}
////
////void VFX::PlayVFX(VFXType aVFXType)
////{
////	PlayVFX(ConvertVFXTypeToStringId(aVFXType),true);
////}
//
//void VFX::StopVFX(Tga::StringId aVFX)
//{
//	for (auto& layerIterator : myVFXAll)
//	{
//		auto& it = layerIterator.second;
//		for (int j = 0; j < it.size(); j++)
//		{
//			if (it[j].type == aVFX)
//			{
//				it.erase(it.begin() + j);
//			}
//		}
//	}
//}
//
//void VFX::StopVFX(VFXType aVFXType)
//{
//	StopVFX(ConvertVFXTypeToStringId(aVFXType));
//}
//
//void VFX::UpdateVFX(VFXInfo* aVFX)
//{
//	if (aVFX->isModel)
//	{
//		UpdateModelVFX(aVFX);
//		return;
//	}
//	// SWITCHING FRAMES
//	if (aVFX->countDown >= aVFX->fps)
//	{
//		aVFX->countDown = 0.f;
//		// IF WE'VE REACHED THE FINAL FRAME OF THE ANIMATION
//		if (aVFX->currentFrame >= aVFX->frames - 1)
//		{
//			aVFX->currentFrame = 0;
//			// IF THE ANIMATION IS NOT SUPPOSED TO LOOP, WE GO BACK TO THE PREVIOUS ANIMATION STATE
//			if (!aVFX->loop)
//			{
//				aVFX->spriteInstance.myIsHidden = true;
//				return;
//			}
//		}
//		// ADD TO THE SPRITECOUNT - THIS KEEPS TRACK OF WHICH FRAME WE'RE ON IN THE ANIMATION
//		else
//		{
//			aVFX->currentFrame++;
//			aVFX->spriteInstance.myColor = Tga::Color{ 1.f,1.f,1.f,1.f };
//		}
//	}
//	else if (mySlowmo)
//	{
//		aVFX->countDown += Tga::Engine::GetInstance()->GetDeltaTime() * 0.3f;
//	}
//	else
//	{
//		aVFX->countDown += Tga::Engine::GetInstance()->GetDeltaTime();
//	}
//
//	// THE RECT LOOKS AT HOW MANY FRAMES ARE IN THE SPRITESHEET AND WHICH FRAME WE'RE CURRENTLY ON
//		// AND THEN CREATES A RECT BASED ON THAT TO ENSURE WE GET THE RIGHT FRAME
//	int currentRow = aVFX->currentFrame / aVFX->framesPerRow;
//
//	float rectHorizontal = 1.f / static_cast<float>(aVFX->framesPerRow);
//	float rectVertical = 1.f / static_cast<float>(aVFX->rows);
//	aVFX->spriteInstance.myTextureRect = {
//		static_cast<float>(aVFX->currentFrame - aVFX->framesPerRow * currentRow) * rectHorizontal,
//		static_cast<float>(currentRow) * rectVertical,
//		(static_cast<float>(aVFX->currentFrame - aVFX->framesPerRow * currentRow) * rectHorizontal + rectHorizontal),
//		(static_cast<float>(currentRow) * rectVertical + rectVertical) };
//
//	
//
//	//if (aVFX->hasLeftAndRight)
//	//{
//	//	switch (aVFX->orientation)
//	//	{
//	//	case Orientation::Right:
//	//	{
//	//		aVFX->sharedData = aVFX->sharedDataRight;
//	//		break;
//	//	}
//	//	case Orientation::Left:
//	//	{
//	//		aVFX->sharedData = aVFX->sharedDataLeft;
//	//		break;
//	//	}
//	//	}
//	//}
//	//else if (aVFX->orientation == Orientation::Left)
//	//{
//	//	aVFX->spriteInstance.myTextureRect = {
//	//	(static_cast<float>(aVFX->currentFrame - aVFX->framesPerRow * currentRow) * rectHorizontal + rectHorizontal),
//	//	static_cast<float>(currentRow) * rectVertical,
//	//	static_cast<float>(aVFX->currentFrame - aVFX->framesPerRow * currentRow) * rectHorizontal,
//	//	(static_cast<float>(currentRow) * rectVertical + rectVertical) };
//	//}
//}
//
//void VFX::UpdateModelVFX(VFXInfo* aVFX)
//{
//    // Count down until the effect ends (if not looping)
//    aVFX->countDown += Tga::Engine::GetInstance()->GetDeltaTime();
//
//    // Example: auto-hide after 2 seconds if not looping
//    //const float effectDuration = 2.0f; // You can store this per effect later
//    //if (!aVFX->loop && aVFX->countDown >= effectDuration)
//    //{
//    //    // Hide or remove from active list
//    //    aVFX->modelInstance.GetTransform() = CreateScale(0.0f);
//    //    return;
//    //}
//
//    // Example transform animation: slowly rise and fade
//    Tga::Matrix4x4f& transform = aVFX->modelInstance.GetTransform();
//
// //   // Apply movement upwards over time
//	//Tga::Vector3f pos = GetTranslation(transform);
//	//pos.y += Tga::Engine::GetInstance()->GetDeltaTime() * 20.0f; // move upward
//	//SetTranslation(transform, pos);
//
//    // Optional rotation
//    Tga::Matrix4x4f rotation = Tga::Matrix4x4f::CreateRotationAroundY(aVFX->countDown * 1.5f);
//    transform = rotation * transform;
//}
//
//
//void VFX::SetPosition(Tga::Vector3f& aColliderPos, Tga::Vector3f aDirection)
//{
//
//	aDirection;
//	// Send Orientation as well
//
//	//////////////////auto collider = dynamic_cast<BoxCollider*>(&aCollider);
//	//////////////////Tga::Vector2f position = collider->GetPosition();
//	Tga::Vector2f pivot{ 0.f,0.f };
//	Tga::Vector3f position = aColliderPos;
//
//	for (auto& layerIterator : myVFXAll)
//	{
//		auto& it = layerIterator.second;
//		for (int j = 0; j < it.size(); j++)
//		{
//			//////////////////position = collider->GetPosition();
//
//			if (!it[j].doesMove && it[j].countDown > 0.f || !it[j].doesMove && it[j].currentFrame > 0)
//			{
//				continue;
//			}
//
//			pivot = { 0.f,0.f };
//			position = aColliderPos;
//			Tga::Matrix4x4f transform = Tga::Matrix4x4f::CreateIdentityMatrix();
//			transform.SetPosition(aColliderPos);
//
//			if (it[j].type == "SmokePuffs"_tgaid)
//			{
//				// set position to collider blah blah
//				SetPositionForSpecificVFX(aColliderPos, &it[j]);
//			}
//			else if (it[j].type == "Projectile"_tgaid)
//			{
//				// set position to collider blah blah
//				SetPositionForSpecificVFX(aColliderPos, &it[j]);
//			}
//			else if (it[j].type == "Bite"_tgaid)
//			{
//				// set position to collider blah blah
//				SetPositionForSpecificVFX(aColliderPos, &it[j]);
//			}
//			else if (it[j].type == "WindOne"_tgaid)
//			{
//				// set position to collider blah blah
//				//SetPositionForSpecificVFX(position, &it[j]);
//				SetTransformForSpecificVFX(transform, &it[j]);
//			}
//			else if (it[j].type == "WindTwo"_tgaid)
//			{
//				// set position to collider blah blah
//				//SetPositionForSpecificVFX(position, &it[j]);
//				SetTransformForSpecificVFX(transform, &it[j]);
//			}
//			else if (it[j].type == "WalkTrail"_tgaid)
//			{
//				// set position to collider blah blah
//				SetPositionForSpecificVFX(aColliderPos, &it[j]);
//			}
//			else if (it[j].type == "Interact_E"_tgaid)
//			{
//				// set position to collider blah blah
//				Tga::Vector3f pos = aColliderPos;
//				pos.y += 300;
//				SetPositionForSpecificVFX(pos, &it[j]);
//			}
//			else if (it[j].type == "Interact_X"_tgaid)
//			{
//				// set position to collider blah blah
//				Tga::Vector3f pos = transform.GetPosition();
//				pos.y += 300;
//				std::cout << pos << std::endl;
//				
//				transform.SetPosition(pos);
//				SetTransformForSpecificVFX(transform, &it[j], false);
//			}
//			else
//			{
//				// set position to collider blah blah
//				SetPositionForSpecificVFX(aColliderPos, &it[j]);
//			}
//		}
//	}
//}
//
//
//void VFX::SetTransformForSpecificVFX(Tga::Matrix4x4f aTransform, VFXInfo* aVFX, bool aBillboard)
//{
//	Tga::Vector2f position{ aTransform.GetPosition().x, aTransform.GetPosition().y };
//
//	Tga::Vector2f pivot = Tga::Vector2f(-aVFX->pivot.x, aVFX->pivot.y);
//	Tga::Matrix2x2f scalingMatrix = Tga::Matrix2x2f::CreateFromScale(Tga::Vector2f((aVFX->size.x) * myScale.x, (aVFX->size.y) * myScale.y));
//
//	Tga::Vector2f p = pivot * scalingMatrix + position;
//
//	Tga::Matrix4x4f transform
//	{
//		scalingMatrix(1,1),scalingMatrix(1,2),1,0,
//		scalingMatrix(2,1),scalingMatrix(2,2),1,0,
//		0     ,0     ,1,0,
//		p.x   ,p.y   ,aTransform.GetPosition().z,1,
//	};
//
//	aVFX->spriteInstance.myTransform = transform;
//	aVFX->spriteInstance.myTransform.SetPosition(transform.GetPosition());
//
//	if (aVFX->type == "Bullet"_tgaid)
//	{
//		Tga::Matrix4x4f billboard = CreateBulletMatrix(aTransform, myScale);
//
//		aVFX->spriteInstance.myTransform *= billboard;
//		aVFX->spriteInstance.myTransform.SetPosition(billboard.GetPosition());
//	}
//	else
//	{
//		GraphicsStateStack* graphicsStatestack = &Tga::Engine::GetInstance()->GetGraphicsEngine().GetGraphicsStateStack();
//
//		Tga::Matrix4x4f cameraTransform = graphicsStatestack->GetCamera().GetTransform();
//		Tga::Vector3f fromPos = aTransform.GetPosition();
//		Tga::Vector3f toPos = graphicsStatestack->GetCamera().GetTransform().GetPosition();
//
//		if (!aBillboard)
//		{
//			toPos = aTransform.GetPosition() - aTransform.GetRight();
//		}
//
//		Tga::Matrix4x4f billboard = CreateBillboardMatrix(fromPos, toPos, myScale);
//
//		aVFX->spriteInstance.myTransform *= billboard;
//		aVFX->spriteInstance.myTransform.SetPosition(billboard.GetPosition());
//	}
//}
//
//void VFX::SetPositionForSpecificVFX(Tga::Vector3f& aPosition, VFXInfo* aVFX)
//{
//	Tga::Vector2f position{ aPosition.x, aPosition.y };
//
//	Tga::Vector2f pivot = Tga::Vector2f(-aVFX->pivot.x, aVFX->pivot.y);
//	Tga::Matrix2x2f scalingMatrix = Tga::Matrix2x2f::CreateFromScale(Tga::Vector2f((aVFX->size.x) * myScale.x, (aVFX->size.y) * myScale.y));
//
//	Tga::Vector2f p = pivot * scalingMatrix + position;
//
//	Tga::Matrix4x4f transform
//	{
//		scalingMatrix(1,1),scalingMatrix(1,2),1,0,
//		scalingMatrix(2,1),scalingMatrix(2,2),1,0,
//		0     ,0     ,1,0,
//		p.x   ,p.y   ,aPosition.z,1,
//	};
//
//	aVFX->spriteInstance.myTransform = transform;
//
//	GraphicsStateStack* graphicsStatestack = &Tga::Engine::GetInstance()->GetGraphicsEngine().GetGraphicsStateStack();
//
//	Tga::Matrix4x4f cameraTransform = graphicsStatestack->GetCamera().GetTransform();
//	Tga::Vector3f fromPos = aPosition;
//	Tga::Vector3f toPos = graphicsStatestack->GetCamera().GetTransform().GetPosition();
//
//	Tga::Matrix4x4f billboard = CreateBillboardMatrix(fromPos, toPos, myScale);
//
//	aVFX->spriteInstance.myTransform *= billboard;
//	aVFX->spriteInstance.myTransform.SetPosition(billboard.GetPosition());
//
//}
//
//void VFX::RescaleSpecificVFX(VFXInfo* aVFX)
//{
//	Tga::Vector3f scale = { (aVFX->size.x) * myScale.x, (aVFX->size.y) * myScale.y, 1.f };
//	aVFX->spriteInstance.myTransform.Scale(scale);
//}
//
//void VFX::RotateSpecificVFX(float anAngle, VFXInfo* aVFX)
//{
//	Tga::Quaternion<float> quaternion(anAngle, 0.f, 0.f);
//	Tga::Matrix4x4f pivotMatrix = Tga::Matrix4x4f::CreateFromTranslation(Tga::Vector3f{ aVFX->size.x * aVFX->pivot.x * myScale.x, aVFX->size.y * -aVFX->pivot.y * myScale.y, 1.f } *-1.f);
//	Tga::Matrix4x4f scale = Tga::Matrix4x4f::CreateFromScale(Tga::Vector3f{ aVFX->size.x, aVFX->size.y, 1.f }*myScale);
//	Tga::Matrix4x4f rotation = Tga::Matrix4x4f::CreateFromRotation(quaternion);
//
//	Tga::Matrix4x4f translation = Tga::Matrix4x4f::CreateFromTranslation(aVFX->spriteInstance.myTransform.GetPosition());
//
//	Tga::Matrix4x4f transform = scale * pivotMatrix * rotation * translation;
//
//	aVFX->spriteInstance.myTransform = transform;
//}
//
//Tga::Matrix4x4f VFX::CreateBillboardMatrix(const Tga::Vector3f& aPosition, const Tga::Vector3f& aTargetPosition, const Tga::Vector3f aScale)
//{
//	Tga::Vector3f direction = aPosition - aTargetPosition;
//	direction.Normalize();
//
//	Tga::Vector3f up(0.0f, 1.0f, 0.0f);
//
//	Tga::Vector3f right = up.Cross(direction).GetNormalized();
//
//	up = direction.Cross(right).GetNormalized();
//
//	Tga::Matrix4x4f billboard = Tga::Matrix4x4f::CreateIdentityMatrix();
//	billboard.SetRight(right);
//	billboard.SetUp(up);
//	billboard.SetForward(direction);
//	billboard.Scale(aScale);
//	Tga::Vector3f pivotOffset = -0.5f * (right * aScale - up * aScale);
//	billboard.SetPosition(aPosition + pivotOffset);
//	return billboard;
//}
//
//Tga::Matrix4x4f VFX::CreateBulletMatrix(const Tga::Matrix4x4f& aTransform, const Tga::Vector3f& aScale)
//{
//	Tga::Vector3f direction = aTransform.GetForward();
//	Tga::Vector3f forward(0.f, 1.f, 0.f);
//
//	Tga::Vector3f up(direction);
//	Tga::Vector3f right = forward.Cross(up).GetNormalized();
//
//	Tga::Matrix4x4f billboard = Tga::Matrix4x4f::CreateIdentityMatrix();
//	billboard.SetRight(right);
//	billboard.SetUp(up);
//	billboard.SetForward(direction);
//	billboard.Scale(aScale);
//	Tga::Vector3f pivotOffset = -0.5f * (right * aScale - up * aScale);
//	billboard.SetPosition(aTransform.GetPosition() + pivotOffset);
//	return billboard;
//}
//
////void VFX::SetPosition(Tga::Vector2f& aPosition)
////{
////	Tga::Vector3f position{ aPosition.x, aPosition.y, 0.f };
////	SetPosition(position);
////}
//
//void VFX::SetSize(Tga::Vector2f& aSize)
//{
//	mySize = aSize;
//}
//
//void VFX::SetScale(Tga::Vector3f& aScalar)
//{
//	myScale = aScalar;
//}
//
//int VFX::GetAmount()
//{
//	int amount = 0;
//	for (auto& layerIterator : myVFXAll)
//	{
//		auto& it = layerIterator.second;
//		amount += static_cast<int>(it.size());
//	}
//	return amount;
//}
//
//Tga::StringId VFX::ConvertVFXTypeToStringId(VFXType aVFXType)
//{
//	Tga::StringId vfx = Tga::StringRegistry::RegisterOrGetString("Animation");
//
//	switch (aVFXType)
//	{
//	case Player_Attack:
//	{
//		vfx = Tga::StringRegistry::RegisterOrGetString("Player_Attack");
//		break;
//	}
//	case Player_AttackUp:
//	{
//		vfx = Tga::StringRegistry::RegisterOrGetString("Player_Attack_Up");
//		break;
//	}
//	case Player_AttackDown:
//	{
//		vfx = Tga::StringRegistry::RegisterOrGetString("Player_Attack_Down");
//		break;
//	}
//	case Player_Jump:
//	{
//		vfx = Tga::StringRegistry::RegisterOrGetString("Player_Jump");
//		break;
//	}
//	case Player_JumpDirectional:
//	{
//		vfx = Tga::StringRegistry::RegisterOrGetString("Player_JumpDirectional");
//		break;
//	}
//	case Player_Dash:
//	{
//		vfx = Tga::StringRegistry::RegisterOrGetString("Player_Dash");
//		break;
//	}
//	case Player_Heal:
//	{
//		vfx = Tga::StringRegistry::RegisterOrGetString("Player_Heal");
//		break;
//	}
//	case Player_Glow:
//	{
//		vfx = Tga::StringRegistry::RegisterOrGetString("Player_Glow");
//		break;
//	}
//	case Player_Damage:
//	{
//		vfx = Tga::StringRegistry::RegisterOrGetString("Player_Damage");
//		break;
//	}
//	case Enemy_Death:
//	{
//		vfx = Tga::StringRegistry::RegisterOrGetString("Enemy_Death");
//		break;
//	}
//	case Enemy_Damage:
//	{
//		vfx = Tga::StringRegistry::RegisterOrGetString("Enemy_Damage");
//		break;
//	}
//	case Enemy_Attack:
//	{
//		vfx = Tga::StringRegistry::RegisterOrGetString("Enemy_Attack");
//		break;
//	}
//	case Enemy_Particles:
//	{
//		vfx = Tga::StringRegistry::RegisterOrGetString("Enemy_Particles");
//		break;
//	}
//	}
//
//	return vfx;
//}
//
//VFXType VFX::ConvertStringIdToVFXType(Tga::StringId anAnimation)
//{
//	VFXType vfx = Count;
//
//	if (anAnimation == "SmokePuffs"_tgaid)
//	{
//		vfx = SmokePuffs;
//	}
//	else if (anAnimation == "Projectile"_tgaid)
//	{
//		vfx = Projectile;
//	}
//	else if (anAnimation == "Interact_E"_tgaid)
//	{
//		vfx = Interact_E;
//	}
//	else if (anAnimation == "Interact_X"_tgaid)
//	{
//		vfx = Interact_X;
//	}
//
//	return vfx;
//}
//
//void VFX::DebugSpawnAllVfx()
//{
//	auto& vfxManager = *VFXManager::GetInstance();
//
//
//	const float spacing = 500.f; // distance between each VFX
//	const int perRow = 3;        // how many before wrapping to next row
//
//	int index = 0;
//
//	for (const auto& [id, vfxData] : vfxManager.GetCached3DVFX())
//	{
//		const int row = index / perRow;
//		const int col = index % perRow;
//
//		Vector3f pos = {
//			col * spacing,
//			0.f,
//			row * spacing
//		};
//
//		PlayVFX(id, pos);
//		++index;
//	}
//
//}
//
////void VFX::SetParent(Destructible* aParent)
////{
////	myParent = aParent;
////}
