#include "stdafx.h"
#include "GameSprite.h"

// Need to clean up a bunch here and adjust to new TGE features, but after that we can use this for sprites

#include <tge/scene/ScenePropertyTypes.h>
#include <tge/script/BaseProperties.h>
#include <tge/texture/TextureManager.h>
#include <tge/engine.h>
#include <tge/error/ErrorManager.h>
#include <nlohmann/json.hpp>
#include <tge/sprite/sprite.h>
#include <fstream>
#include <tge/drawers/SpriteDrawer.h>
#include <tge/graphics/GraphicsEngine.h>
#include <tge/scene/SceneObject.h>

GameSprite::GameSprite() :
	myFPS(1.f / 24.f),
	myUpcomingFPS(0.f),
	myCurrentAnimation(Tga::StringRegistry::RegisterOrGetString("Static")),
	myOrientation(Orientation::Right),
	mySlowmo(false) {
}

void GameSprite::Update()
{
	auto it = mySprites.find(myCurrentAnimation);

	if (myCurrentAnimation != Tga::StringRegistry::RegisterOrGetString("Static"))
	{
		// SWITCHING FRAMES
		if (myCountdown >= myFPS)
		{
			myCountdown = 0.f;
			// IF WE'VE REACHED THE FINAL FRAME OF THE ANIMATION
			if (myCurrentFrame >= it->second.frames - 1)
			{
				myCurrentFrame = 0;
				// IF THE ANIMATION IS NOT SUPPOSED TO LOOP, WE GO BACK TO THE PREVIOUS ANIMATION STATE
				if (!it->second.loop)
				{
					if (myCurrentAnimation == "Destroy"_tgaid)
					{
						myCurrentFrame = mySprites.find(Tga::StringRegistry::RegisterOrGetString("Death"))->second.frames - 1;
					}
					else
					{
						if (mySprites.find(Tga::StringRegistry::RegisterOrGetString("Idle")) != mySprites.end())
						{
							myCurrentAnimation = Tga::StringRegistry::RegisterOrGetString("Idle");
						}
						else
						{
							myCurrentAnimation = Tga::StringRegistry::RegisterOrGetString("Static");
						}
					}
				}
			}
			// ADD TO THE SPRITECOUNT - THIS KEEPS TRACK OF WHICH FRAME WE'RE ON IN THE ANIMATION
			else
			{
				myCurrentFrame++;
			}
		}
		
		if (mySlowmo)
		{
			myCountdown += Tga::Engine::GetInstance()->GetDeltaTime() * 0.3f;
		}
		else
		{
			myCountdown += Tga::Engine::GetInstance()->GetDeltaTime();
		}

		// THE RECT LOOKS AT HOW MANY FRAMES ARE IN THE SPRITESHEET AND WHICH FRAME WE'RE CURRENTLY ON
		// AND THEN CREATES A RECT BASED ON THAT TO ENSURE WE GET THE RIGHT FRAME
		int currentRow = myCurrentFrame / mySprites.find(myCurrentAnimation)->second.columns;

		float rectHorizontal = 1.f / static_cast<float>(mySprites.find(myCurrentAnimation)->second.columns);
		float rectVertical = 1.f / static_cast<float>(mySprites.find(myCurrentAnimation)->second.rows);
		my3DSpriteInstance.myTextureRect = {
			static_cast<float>(myCurrentFrame - mySprites.find(myCurrentAnimation)->second.columns * currentRow) * rectHorizontal,
			static_cast<float>(currentRow) * rectVertical,
			(static_cast<float>(myCurrentFrame - mySprites.find(myCurrentAnimation)->second.columns * currentRow) * rectHorizontal + rectHorizontal),
			(static_cast<float>(currentRow) * rectVertical + rectVertical) };

		if (mySprites.find(myCurrentAnimation)->second.hasLeftAndRight)
		{

			switch (myOrientation)
			{
			case Orientation::Right:
			{
				mySprites.find(myCurrentAnimation)->second.sharedData = mySprites.find(myCurrentAnimation)->second.sharedDataRight;
				break;
			}
			case Orientation::Left:
			{
				mySprites.find(myCurrentAnimation)->second.sharedData = mySprites.find(myCurrentAnimation)->second.sharedDataLeft;
				break;
			}
			}
		}
		else if (myOrientation == Orientation::Left)
		{

			my3DSpriteInstance.myTextureRect = {
			(static_cast<float>(myCurrentFrame - mySprites.find(myCurrentAnimation)->second.columns * currentRow) * rectHorizontal + rectHorizontal),
			static_cast<float>(currentRow) * rectVertical,
			static_cast<float>(myCurrentFrame - mySprites.find(myCurrentAnimation)->second.columns * currentRow)* rectHorizontal,
			(static_cast<float>(currentRow) * rectVertical + rectVertical) };
		}
		return;
	}

	my3DSpriteInstance.myTextureRect = { 0.f, 0.f, 1.f, 1.f };

	if (mySprites.find(myCurrentAnimation)->second.hasLeftAndRight)
	{
		switch (myOrientation)
		{
		case Orientation::Right:
		{
			mySprites.find(myCurrentAnimation)->second.sharedData = mySprites.find(myCurrentAnimation)->second.sharedDataRight;
			break;
		}
		case Orientation::Left:
		{
			mySprites.find(myCurrentAnimation)->second.sharedData = mySprites.find(myCurrentAnimation)->second.sharedDataLeft;
			break;
		}
		}
	}
	else if (myOrientation == Orientation::Left)
	{
		my3DSpriteInstance.myTextureRect = { 1.f, 0.f, 0.f, 1.f };
	}
}


void GameSprite::Render()
{
	if (mySprites.empty())
	{
		return;
	}
	Tga::Engine::GetInstance()->GetGraphicsEngine().GetSpriteDrawer().Draw(*GetSharedData(), *GetSpriteInstance());
}

void GameSprite::UpdateAndRender()
{
	if (mySprites.empty())
	{
		return;
	}
	Update();
	Render();
}

SpriteInfo3D GameSprite::GetSprite()
{
	return mySprites.find(myCurrentAnimation)->second;
}

Tga::SpriteSharedData* GameSprite::GetSharedData()
{
	return &mySprites.find(myCurrentAnimation)->second.sharedData;
}

void GameSprite::Init(const Tga::GameSpriteData& someSpriteData, const Tga::SceneObject& anObject)
{
	auto& engine = *Tga::Engine::GetInstance();
	auto& textureManager = engine.GetTextureManager();

	Tga::SceneSprite spriteValues;
	std::string defaultPath;
	std::string stringPath;
	std::string renamedStringPath;
	std::string animationName;
	std::string texturePath;
	Tga::Texture* texture;
	Tga::SpriteSharedData sharedData;

	myCurrentFrame = -1;
	SpriteInfo3D spriteInfo;
	spriteInfo.frames = 1;
	spriteInfo.hasLeftAndRight = false;

	// DEFAULT ORIENTATION
	myOrientation = Orientation::Right;
	// TINT IS TURNED OFF BY DEFAULT AND DARKEST VALUE IS 0.2f IN EVERY COLOR CHANNEL
	myHasTint = false;
	myHasOpacity = false;
	myDarkestValue = 0.2f;

	//bool animate = true;
	mySprites.clear();

	// LOOP THROUGH THE PROPERTIES TO FIND THE ACTUAL SPRITE
	for (int i = 0; i < someSpriteData.sprites.size(); i++)
	{
		const Tga::SpriteAnimationData& sprite = someSpriteData.sprites[i];

		spriteValues = sprite.sprite;
		defaultPath = spriteValues.textures[0].GetString();
		texturePath = defaultPath;

		texture = textureManager.TryGetTexture(texturePath.c_str());
		sharedData.myTexture = texture;
		spriteInfo.sharedData = sharedData;
		spriteInfo.fps = 1.f / sprite.fps;

		mySize = sprite.cropSize;
		myPivot = spriteValues.pivot;
		my3DSpriteInstance.myIsHidden = false;
		my3DSpriteInstance.myTransform = Tga::Matrix4x4f::CreateFromScale(Tga::Vector3f{ spriteValues.size.x, spriteValues.size.y, 0.f });

		spriteInfo.frames = sprite.frames;
		spriteInfo.rows = sprite.rows;
		spriteInfo.columns = sprite.columns;
		spriteInfo.loop = sprite.loop;
		spriteInfo.hasLeftAndRight = sprite.hasLeftAndRight;

		mySprites.emplace(sprite.name, spriteInfo);
		if (i == someSpriteData.defaultIndex)
		{
			mySprites.emplace("Default"_tgaid, spriteInfo);
		}
	}

	PlayAnimation("Default"_tgaid);

	SetTransformFromSceneObject(anObject);
}

void GameSprite::AddSpriteFromFilePath(std::string& aFilePath)
{
	auto& engine = *Tga::Engine::GetInstance();
	auto& textureManager = engine.GetTextureManager();

	std::string texturePath;
	Tga::Texture* texture;
	Tga::SpriteSharedData sharedData;

	myCurrentFrame = -1;
	SpriteInfo3D spriteInfo;
	spriteInfo.frames = 1;
	spriteInfo.hasLeftAndRight = false;

	// DEFAULT ORIENTATION
	myOrientation = Orientation::Right;

	texturePath = aFilePath;

	texture = textureManager.TryGetTexture(texturePath.c_str());
	sharedData.myTexture = texture;
	spriteInfo.sharedData = sharedData;
	spriteInfo.fps = myFPS;

	mySize = texture->myImageSize;/*Tga::Vector2f{ texture->myImageSize.x,  texture->myImageSize.y }*/
	myPivot = Tga::Vector2f{ 0.5f, 0.5f };
	myScale = Tga::Vector3f{ 1.f,1.f,1.f };

	//mySpriteInstance.myUV = spriteValues.size;
	my3DSpriteInstance.myIsHidden = false;
	my3DSpriteInstance.myTransform = Tga::Matrix4x4f::CreateFromScale(Tga::Vector3f{ mySize.x, mySize.y, 0.f });

	mySprites.emplace(Tga::StringRegistry::RegisterOrGetString("Static"), spriteInfo);
}

void GameSprite::PlayAnimation(Tga::StringId anAnimation)
{
	if (myCurrentAnimation == anAnimation)
	{
		return;
	}
	if (mySprites.find(anAnimation) != mySprites.end() &&
		myCurrentAnimation != anAnimation ||
		mySprites.find(anAnimation) != mySprites.end() && anAnimation == Tga::StringRegistry::RegisterOrGetString("Damage"))
	{
		if (myCurrentAnimation == Tga::StringRegistry::RegisterOrGetString("Death") && !GetIsFinished())
		{
			return;
		}
		myCurrentAnimation = anAnimation;
		myCountdown = 0.f;
		myCurrentFrame = 0;
		myFPS = mySprites.find(anAnimation)->second.fps;
	}
	else
	{
		ERROR_PRINT("Tried to play an animation that does not exist!");
	}
}

Tga::StringId GameSprite::GetCurrentAnimation()
{
	auto it = mySprites.find(myCurrentAnimation);
	if (it == mySprites.end())
		return Tga::StringId(); // invalid / empty id

	return it->first;
}

Tga::Sprite3DInstanceData* GameSprite::GetSpriteInstance()
{
	return &my3DSpriteInstance;
}

void GameSprite::SetPosition(const Tga::Vector3f aPosition)
{
	Tga::Vector2f position{ aPosition.x, aPosition.y };

	Tga::Vector2f pivot = Tga::Vector2f(-myPivot.x, myPivot.y);
	Tga::Vector2f scale = Tga::Vector2f{ mySize.x * myScale.x, mySize.y * myScale.y };
	Tga::Matrix2x2f scalingMatrix = Tga::Matrix2x2f::CreateFromScale(scale);

	Tga::Vector2f p = pivot * scalingMatrix + position;

	Tga::Matrix4x4f transform
	{
		scalingMatrix(1,1),scalingMatrix(1,2),1,0,
		scalingMatrix(2,1),scalingMatrix(2,2),1,0,
		0     ,0     ,1,0,
		p.x   ,p.y   ,aPosition.z,1,
	};

	if (myHasTint && aPosition.z != 0.f)
	{
		float lightAdjustment = abs(aPosition.z) / 500.f;
		my3DSpriteInstance.myColor = Tga::Color{
			my3DSpriteInstance.myColor.r - lightAdjustment,
			my3DSpriteInstance.myColor.g - lightAdjustment,
			my3DSpriteInstance.myColor.b - lightAdjustment,
			my3DSpriteInstance.myColor.a };
		if (my3DSpriteInstance.myColor.r < myDarkestValue)
		{
			my3DSpriteInstance.myColor = Tga::Color{ myDarkestValue, myDarkestValue, myDarkestValue, my3DSpriteInstance.myColor.a };
		}

	}

	if (myHasOpacity && aPosition.z != 0.f)
	{
		float alphaAdjustment = abs(aPosition.z) / 5000.f;
		my3DSpriteInstance.myColor.a -= alphaAdjustment;
	}

	my3DSpriteInstance.myTransform = transform;
	myPosition = Tga::Vector2f{ my3DSpriteInstance.myTransform.GetPosition().x, my3DSpriteInstance.myTransform.GetPosition().y };
}

void GameSprite::SetPosition(const Tga::Vector2f aPosition)
{
	Tga::Vector3f position{ aPosition.x, aPosition.y, 0.f };
	SetPosition(position);
}

Tga::Vector2f GameSprite::GetPosVec2() const
{
	return myPosition;
}

void GameSprite::SetSize(const Tga::Vector2f aSize)
{
	mySize = aSize;

	Tga::Vector2f position{ my3DSpriteInstance.myTransform.GetPosition().x, my3DSpriteInstance.myTransform.GetPosition().y};
	Tga::Vector2f pivot = Tga::Vector2f(-myPivot.x, myPivot.y);
	Tga::Vector2f scale = Tga::Vector2f{ mySize.x * myScale.x, mySize.y * myScale.y };
	Tga::Matrix2x2f scalingMatrix = Tga::Matrix2x2f::CreateFromScale(scale);

	Tga::Vector2f p = pivot * scalingMatrix + position;

	Tga::Matrix4x4f transform
	{
		scalingMatrix(1,1),scalingMatrix(1,2),1,0,
		scalingMatrix(2,1),scalingMatrix(2,2),1,0,
		0     ,0     ,1,0,
		p.x   ,p.y   ,my3DSpriteInstance.myTransform.GetPosition().z,1,
	};

	my3DSpriteInstance.myTransform = transform;
	myPosition = Tga::Vector2f{ my3DSpriteInstance.myTransform.GetPosition().x, my3DSpriteInstance.myTransform.GetPosition().y };
}

Tga::Vector2f GameSprite::GetSize()
{
	return Tga::Vector2f{ std::abs(mySize.x * myScale.x), std::abs(mySize.y * myScale.y) };
}

void GameSprite::SetTransformFromSceneObject(const Tga::SceneObject& anObject)
{
	SetScale(anObject.GetScale());
	SetRotation(anObject.GetEuler());
	SetTransform(anObject.GetTransform());
}

void GameSprite::SetScale(const Tga::Vector3f aScalar)
{
	myScale = aScalar;
}

void GameSprite::SetTransform(Tga::Matrix4x4f aTransform)
{
	Tga::Matrix4x4f pivotMatrix = Tga::Matrix4x4f::CreateFromTranslation(Tga::Vector3f{ mySize.x * myPivot.x * myScale.x, mySize.y * -myPivot.y * myScale.y, 1.f } * -1.f);
	Tga::Matrix4x4f scale = Tga::Matrix4x4f::CreateFromScale(Tga::Vector3f{ mySize.x, mySize.y, 1.f }*myScale);
	Tga::Matrix4x4f rotation = Tga::Matrix4x4f::CreateFromRotation(myRotation);

	Tga::Matrix4x4f translation = Tga::Matrix4x4f::CreateFromTranslation(aTransform.GetPosition());

	Tga::Matrix4x4f transform = scale * pivotMatrix * rotation * translation;

	if (myHasTint && aTransform.GetPosition().z != 0.f)
	{
		float lightAdjustment = abs(aTransform.GetPosition().z) / 500.f;
		my3DSpriteInstance.myColor = Tga::Color{
			my3DSpriteInstance.myColor.r - lightAdjustment,
			my3DSpriteInstance.myColor.g - lightAdjustment,
			my3DSpriteInstance.myColor.b - lightAdjustment,
			my3DSpriteInstance.myColor.a };
		if (my3DSpriteInstance.myColor.r < myDarkestValue)
		{
			my3DSpriteInstance.myColor = Tga::Color{ myDarkestValue, myDarkestValue, myDarkestValue, my3DSpriteInstance.myColor.a };
		}
	}

	if (myHasOpacity && aTransform.GetPosition().z != 0.f)
	{
		float alphaAdjustment = abs(aTransform.GetPosition().z) / 5000.f;
		my3DSpriteInstance.myColor.a -= alphaAdjustment;
	}

	my3DSpriteInstance.myTransform = transform;
	myPosition = Tga::Vector2f{ my3DSpriteInstance.myTransform.GetPosition().x, my3DSpriteInstance.myTransform.GetPosition().y };
}

void GameSprite::SetRotation(Tga::Vector3f aEuler)
{
	myRotation = aEuler;
}

Tga::Vector3f GameSprite::GetScale()
{
	return myScale;
}

void GameSprite::SetColor(Tga::Color aColor)
{
	my3DSpriteInstance.myColor = aColor;
}

Tga::Color GameSprite::GetColor()
{
	return my3DSpriteInstance.myColor;
}

void GameSprite::SetTemporaryFPS(const float anFPS)
{
	myFPS = anFPS;
	myUpcomingFPS = anFPS;
}

void GameSprite::SetAnimationSpecificFPS(Tga::StringId anAnimationState, const float anFPS)
{
	if (mySprites.find(anAnimationState) != mySprites.end())
	{
 		mySprites.find(anAnimationState)->second.fps = anFPS;
	}
}

//void GameSprite::SetCurrentFrame(float aRect, int aFrameAmount)
//{
//	myCurrentFrame = aRect * aFrameAmount;
//}

int GameSprite::GetCurrentFrame() const
{
	return myCurrentFrame;
}

bool GameSprite::GetIsFinished()
{
	// IF WE'VE REACHED THE FINAL FRAME OF THE ANIMATION
	return (myCurrentFrame >= mySprites.find(myCurrentAnimation)->second.frames - 1);
}

void GameSprite::SetShader(Tga::SpriteShader* aShader, Tga::StringId anAnimation)
{
	auto it = mySprites.find(anAnimation);

	if (anAnimation == ""_tgaid)
	{
		for (auto& sprite : mySprites | std::views::values)
		{
			sprite.sharedData.myCustomShader = aShader;
			sprite.sharedDataLeft.myCustomShader = aShader;
			sprite.sharedDataRight.myCustomShader = aShader;
		}
	}
	else if (it != mySprites.end())
	{
		it->second.sharedData.myCustomShader = aShader;
		it->second.sharedDataLeft.myCustomShader = aShader;
		it->second.sharedDataRight.myCustomShader = aShader;
	}
	else
	{
		ERROR_PRINT("Tried to set shader to an animation that does not exist! No worries tho I'm just tellin' ya");
	}
}

int GameSprite::GetFrameAmount(const Tga::StringId aAnimationState)
{
	return mySprites.find(aAnimationState)->second.frames - 1;
}


void GameSprite::IncreaseSpriteCount(const int aFrames)
{
	myCurrentFrame += aFrames;

	if (myCurrentFrame >= mySprites.find(myCurrentAnimation)->second.frames - 1)
	{
		myCurrentFrame = mySprites.find(myCurrentAnimation)->second.frames - 1;
	}

	const int currentRow = myCurrentFrame / mySprites.find(myCurrentAnimation)->second.columns;

	const float rectHorizontal = 1.f / static_cast<float>(mySprites.find(myCurrentAnimation)->second.columns);
	const float rectVertical = 1.f / static_cast<float>(mySprites.find(myCurrentAnimation)->second.rows);
	my3DSpriteInstance.myTextureRect = {
		static_cast<float>(myCurrentFrame - mySprites.find(myCurrentAnimation)->second.columns * currentRow) * rectHorizontal,
		static_cast<float>(currentRow) * rectVertical,
		(static_cast<float>(myCurrentFrame - mySprites.find(myCurrentAnimation)->second.columns * currentRow) * rectHorizontal + rectHorizontal),
		(static_cast<float>(currentRow) * rectVertical + rectVertical) };
	//const float rect = 1.f / static_cast<float>(mySprites.find(myCurrentAnimation)->second.frames);
	//my3DSpriteInstance.myTextureRect = {
	//	static_cast<float>(mySpriteCount) * rect,
	//	0.f,
	//	(static_cast<float>(mySpriteCount) * rect + rect),
	//	1.f
	//};
}

void GameSprite::DecreaseSpriteCount(const int aFrames)
{
	myCurrentFrame -= aFrames;

	if (myCurrentFrame < 0)
	{
		myCurrentFrame = 0;
	}

	const int currentRow = myCurrentFrame / mySprites.find(myCurrentAnimation)->second.columns;

	const float rectHorizontal = 1.f / static_cast<float>(mySprites.find(myCurrentAnimation)->second.columns);
	const float rectVertical = 1.f / static_cast<float>(mySprites.find(myCurrentAnimation)->second.rows);
	my3DSpriteInstance.myTextureRect = {
		static_cast<float>(myCurrentFrame - mySprites.find(myCurrentAnimation)->second.columns * currentRow) * rectHorizontal,
		static_cast<float>(currentRow) * rectVertical,
		(static_cast<float>(myCurrentFrame - mySprites.find(myCurrentAnimation)->second.columns * currentRow) * rectHorizontal + rectHorizontal),
		(static_cast<float>(currentRow) * rectVertical + rectVertical) };
	//const float rect = 1.f / static_cast<float>(mySprites.find(myCurrentAnimation)->second.frames);
	//my3DSpriteInstance.myTextureRect = {
	//	static_cast<float>(mySpriteCount) * rect,
	//	0.f,
	//	(static_cast<float>(mySpriteCount) * rect + rect),
	//	1.f
	//};
}

void GameSprite::SetSpriteCount(const int aCurrentFrame)
{
	myCurrentFrame = aCurrentFrame;

	if (myCurrentFrame < 0)
	{
		myCurrentFrame = 0;
	}
	else if (myCurrentFrame >= mySprites.find(myCurrentAnimation)->second.frames - 1)
	{
		myCurrentFrame = mySprites.find(myCurrentAnimation)->second.frames - 1;
	}

	//myAnimationState = myUpcomingState;
	const int currentRow = myCurrentFrame / mySprites.find(myCurrentAnimation)->second.columns;

	const float rectHorizontal = 1.f / static_cast<float>(mySprites.find(myCurrentAnimation)->second.columns);
	const float rectVertical = 1.f / static_cast<float>(mySprites.find(myCurrentAnimation)->second.rows);
	my3DSpriteInstance.myTextureRect = {
		static_cast<float>(myCurrentFrame - mySprites.find(myCurrentAnimation)->second.columns * currentRow) * rectHorizontal,
		static_cast<float>(currentRow) * rectVertical,
		(static_cast<float>(myCurrentFrame - mySprites.find(myCurrentAnimation)->second.columns * currentRow) * rectHorizontal + rectHorizontal),
		(static_cast<float>(currentRow) * rectVertical + rectVertical) };
	//const float rect = 1.f / static_cast<float>(mySprites.find(myCurrentAnimation)->second.frames);
	//my3DSpriteInstance.myTextureRect = {
	//	static_cast<float>(mySpriteCount) * rect,
	//	0.f,
	//	(static_cast<float>(mySpriteCount) * rect + rect),
	//	1.f
	//};
}
