#include "stdafx.h"
#include "EventManager.h"


EventManager* EventManager::myInstance = nullptr;

EventManager::~EventManager()
{
	delete myInstance;
	myInstance = nullptr;
}

EventManager* EventManager::GetInstance()
{
	if (myInstance == nullptr)
	{
		myInstance = new EventManager;
	}
	return myInstance;
}

void EventManager::Subscribe(const Event aEvent, Observer* aObserver)
{
	auto it = std::find(myObservers[aEvent].begin(), myObservers[aEvent].end(), aObserver);
	//assert(it == myObservers[aMessageType].end() && "Observer already added!");
	if (it == myObservers[aEvent].end())
	{
		myObservers[aEvent].push_back(aObserver);
	}
	else
	{
#ifdef _DEBUG
		std::cout << "Tried to add PostMaster Observer: " << aObserver << " that was already added" << std::endl;
#endif
	}
}

void EventManager::UnSubscribe(const Event aEvent, Observer* aObserver)
{
	auto iterator = myObservers.find(aEvent);
	if (iterator == myObservers.end())
	{
		return;
	}

	auto& observerList = iterator->second;
	for (int i = 0; i < static_cast<int>(observerList.size()); ++i)
	{
		if (observerList[i] == aObserver)
		{
			observerList.erase(observerList.begin() + i);
			break;
		}
	}
}

void EventManager::SendEventMessage(Message& aMessage)
{
	auto it = myObservers.find(aMessage.eventType);

	if (it == myObservers.end())
		return;

	for (auto* observer : it->second)
	{
		if (observer) observer->ReceiveEvent(aMessage);
	}
}

Event EventManager::EventFromStringId(Tga::StringId /*aStringId*/)
{
	//if (aStringId == "Human_Attack"_tgaid)
	//{
	//	return Event::EnemyAttackedPlayer;
	//}
	return Event::Count;
}