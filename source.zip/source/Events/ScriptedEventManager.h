#pragma once
//#pragma message(__FILE__" was compiled")

namespace Tga
{
	class Camera;
}


class ScriptedEventManager
{
public:
	ScriptedEventManager() = default;
	~ScriptedEventManager() = default;

private:

};

