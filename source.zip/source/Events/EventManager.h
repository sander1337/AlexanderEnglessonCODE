#pragma once

#include <variant>
#include <unordered_map>
#include <tge/scene/ScenePropertyTypes.h>
#include "../Objects/Actors/Player/Weapon/WeaponDef.h"

enum class SceneID : std::uint8_t;
enum class ActorType;

namespace Tga
{
	enum class ScriptedEventType : std::uint8_t;
	enum class PickUpType : std::uint8_t;
	//enum class HUDType : std::uint8_t;
}

enum class Event
{
	// Scene
	SwitchLevel,
	ResetLevel,
	PlayScriptedEvent,
	PlayCutscene,
	PlayEnding,
	GameOver,

	// UI
	ShowToolTip,
	HideToolTip,
	HudLayoutSavePressed,

	// Enemy
	EnemyDied,
	//EnemyAttackedPlayer,

	// Player
	PlayerHealthChange,
	AmmoChange,
	PointsChange,
	ComboChange,
	ReloadChange,
	PickUp,
	TopTextChange,

	ToggleHudEditMode,
	CloseHudEditMenu,
	CloseSpellBook,
	ToggleSpellBook,
	ActionKeyPressed,

	PlayerBlink,

	Count
};

struct IntBarValues
{
	int currentValue;
	int maxValue;
};

struct ReloadHUDValues
{
	WeaponType weapon;
	float remaining; // sek kvar
	float duration;  // total reloadtid
	bool isReloading;
};

struct AmmoHUDValues
{
	WeaponType weapon; // vilket vapen som �r aktivt
	int mag;
	int magSize;
	int reserve;
	int maxReserve;
};

struct Message
{
	Event eventType;
	std::variant<float, SceneID, Tga::ScriptedEventType, int, IntBarValues, AmmoHUDValues, ReloadHUDValues, ActorType, Tga::HUDType, Tga::PickUpType, std::string > data;
};

class Observer
{
public:
	virtual ~Observer() = default;
	virtual void ReceiveEvent(const Message& aMessage) = 0;
};

class EventManager
{
public:

	EventManager(EventManager& other) = delete;
	void operator=(const EventManager&) = delete;
	~EventManager();

	static EventManager* GetInstance();
	void Subscribe(const Event aMsgType, Observer* aObserver);
	void UnSubscribe(const Event aMsgType, Observer* aObserver);
	void SendEventMessage(Message& aMessage);

	static Event EventFromStringId(Tga::StringId aStringId);

private:
	EventManager() = default;
	static EventManager* myInstance;

	std::unordered_map<Event, std::vector<Observer*>> myObservers;
};