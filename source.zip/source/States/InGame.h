#pragma once

#include "State.h"
#include "../Input/InputMapper.h"
#include <memory>


class GameScene;
class SceneManager;
class RenderManager;

class InGame : public State, public InputObserver
{
public:
    InGame(StateStack& aStateStack, const std::shared_ptr<SceneManager>& aSceneManager, const std::shared_ptr<RenderManager>& aRenderManager, const bool aLetThroughRender = false);
    ~InGame() override = default;

    void OnEnter() override;
    void OnExit() override;
    void Update(float aDeltaTime) override;
    void Render() override;

    void SwitchLevel(SceneID aSceneID);

    void RegisterInput();
    void UnregisterInput();
    void ReceiveInput(InputEvent aGameEvent, const std::any& someData) override;
    
    void ReceiveEvent(const Message& aMessage) override;

    StateID GetID() override;

private:
    bool gameOver = false;
    bool mouseLocked = false;
};