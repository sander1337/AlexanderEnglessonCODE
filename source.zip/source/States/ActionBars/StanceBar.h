#pragma once
#include <memory>
#include <array>
#include <tge/math/vector2.h>

#include "ActionBarSlotButton.h"
#include "ActionBarSpell.h"

class MenuScene;
class HUD;

enum class MageStance : int
{
    None = -1,
    Fire = 0,
    Frost = 1,
    Arcane = 2
};

enum class StanceBarOrientation : uint8_t
{
    Horizontal,
    Vertical
};

struct StanceBarLayout
{
    StanceBarOrientation orientation = StanceBarOrientation::Horizontal;
    float iconSize = 72.f;
    float padding = 6.f;
};

class StanceBar
{
public:
    void Init(HUD& hud, MenuScene& scene, const Tga::Vector2f& anchorPos);

    void Update(float dt);
    void RebuildLayout();

    void SetPosition(const Tga::Vector2f& pos);
    Tga::Vector2f GetPosition() const { return myAnchor; }

    void SetEditMode(bool on);
    void SetVisible(bool visible);
    bool IsVisible() const { return myVisible; }

    void SetActiveStance(MageStance stance);
    MageStance GetActiveStance() const { return myActiveStance; }

    void RenderDebugBounds(const Tga::Color& c) const;

    void SetLayout(const StanceBarLayout& layout);
    const StanceBarLayout& GetLayout() const { return myLayout; }

    const std::array<std::shared_ptr<ActionBarSlotButton>, 3>& GetSlots() const
    {
        return mySlots;
    }

    Tga::Vector2f GetBoundsMin() const;
    Tga::Vector2f GetBoundsMax() const;

private:
    void BuildSpells();
    void ApplyActiveVisuals();
    Tga::Vector2f GetSlotPos(int index) const;
    void ToggleStance(MageStance stance);

private:
    StanceBarLayout myLayout{};
    HUD* myHUD = nullptr;
    MenuScene* myScene = nullptr;

    std::array<std::shared_ptr<ActionBarSlotButton>, 3> mySlots;
    std::array<ActionBarSpell, 3> mySpells;

    Tga::Vector2f myAnchor{ 0.f, 0.f };
    bool myVisible = true;
    MageStance myActiveStance = MageStance::Fire;
};