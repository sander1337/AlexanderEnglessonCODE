#include "SpellBookSpellButton.h"
#include <tge/engine.h>
#include <tge/drawers/SpriteDrawer.h>
#include <tge/graphics/GraphicsEngine.h>
#include <tge/graphics/GraphicsStateStack.h>
#include <tge/texture/TextureManager.h>

void SpellBookSpellButton::SetHUD(HUD* hud)
{
    myHUD = hud;
}

void SpellBookSpellButton::SetSpell(const ActionBarSpell& s)
{
    mySpell = s;

    auto& engine = *Tga::Engine::GetInstance();
    auto& tm = engine.GetTextureManager();

    myIconShared.myTexture = tm.GetTexture(mySpell.iconTexturePath.c_str());
    myIconShared.blendState = Tga::BlendState::AlphaBlend;
    myIconShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    myIconInst.myPivot = { 0.5f, 0.5f };
    myIconInst.myColor = { 1.f, 1.f, 1.f, 1.f };
    myIconInst.myIsHidden = (myIconShared.myTexture == nullptr);

    SyncIcon();
}

void SpellBookSpellButton::SetVisible(bool v)
{
    myVisible = v;
}

void SpellBookSpellButton::Render()
{
    if (!myVisible) return;

    SyncIcon();

    auto& engine = *Tga::Engine::GetInstance();
    auto& gss = engine.GetGraphicsEngine().GetGraphicsStateStack();
    auto& spriteDrawer = engine.GetGraphicsEngine().GetSpriteDrawer();

    gss.Push();
    gss.SetBlendState(Tga::BlendState::AlphaBlend);

    if (!myIconInst.myIsHidden && myIconShared.myTexture)
        spriteDrawer.Draw(myIconShared, myIconInst);

#ifdef _DEBUG
    DebugDrawBounds({ 0.f, 0.7f, 1.f, 1.f });
#endif

    gss.Pop();
}

void SpellBookSpellButton::Update(float dt)
{
    if (!myVisible) return;
    Button::Update(dt);
}

void SpellBookSpellButton::OnLeftClick()
{
    if (!myHUD) return;
    myHUD->BeginDragFromSpell(mySpell);
}

void SpellBookSpellButton::SyncIcon()
{
    myIconInst.myPosition = GetPosition();
    myIconInst.mySize = GetHalfSize() * 2.f;
}