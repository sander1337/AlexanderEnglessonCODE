﻿// ActionBar.cpp
#include "ActionBar.h"
#include "../../SceneManagement/MenuScene.h"
#include <algorithm>
#include <tge/drawers/DebugDrawer.h>

#include "States/Hud/HUD.h"
#include "Utilities/UIRectUtils.h"

static Tga::Vector2f GetMouseWorldUI(Tga::InputManager* im, Tga::Camera* cam)
{
    const auto res = Tga::Engine::GetInstance()->GetRenderSize();
    const float H = (float)res.y;

    const Tga::Vector2f mouseScreen{ im->GetMousePosition().x, H - im->GetMousePosition().y };
    return cam->GetScreenToWorldCoordinatesVec2(mouseScreen);
}

void ActionBar::Init(HUD& hud, MenuScene& scene, int barId, int slotCount, const Tga::Vector2f& anchorPos)
{
    myHUD = &hud;        
    myScene = &scene;
    myBarId = barId;
    myAnchor = anchorPos;

    mySlots.clear();
    mySlots.reserve(slotCount);

    // ✅ Välj en “snygg slot frame” från dina assets:
    // Jag hade börjat med en neutral frame här:
    const char* slotFrameTex = "assets/ui/textures/ActionBarSlot.png";
    // (byt till din egen actionbar-slot när du har den)

    for (int i = 0; i < slotCount; ++i)
    {
        auto btn = std::make_shared<ActionBarSlotButton>();

        // Viktigt för HitTest + storlek
        btn->InitRuntime({ 0.f, 0.f }, { myLayout.iconSize, myLayout.iconSize });

        btn->SetOwner(this, i);
        btn->SetDraggable(false);

        // ✅ Slot frame + icon-size
        btn->SetSlotBackground(slotFrameTex);
        btn->SetIconSize(myLayout.iconSize);

        mySlots.push_back(btn);
        myScene->AddRuntimeButton(btn);
    }

    if (!mySlots.empty())
    {
        ActionBarSlotButton* parent = mySlots[0].get();
        for (int i = 1; i < (int)mySlots.size(); ++i)
            parent->AddChild(mySlots[i].get());

        // barn ska inte kunna dras individuellt
        for (int i = 1; i < (int)mySlots.size(); ++i)
            mySlots[i]->SetDraggable(false);
    }

    RebuildLayout();
}

void ActionBar::SetLayout(const ActionBarLayout& l)
{
    myLayout = l;

    myLayout.visibleSlots = std::max(1, std::min(myLayout.visibleSlots, (int)mySlots.size()));
    myLayout.rows = std::max(1, myLayout.rows);
    myLayout.columns = std::max(1, myLayout.columns);

    // ✅ Bestäm autoColumns från orientation (rekommenderat)
    myLayout.autoColumns = (myLayout.orientation == ActionBarOrientation::Horizontal);

    if (myLayout.autoColumns)
    {
        // Horizontal: rows styr, columns räknas
        myLayout.columns = (myLayout.visibleSlots + myLayout.rows - 1) / myLayout.rows;
        myLayout.columns = std::max(1, myLayout.columns);
    }
    else
    {
        // Vertical: columns styr, rows kan räknas om du vill,
        // men oftast vill du ha rows = 1 (ren stapel)
        myLayout.rows = 1;
    }

    RebuildLayout();
}

void ActionBar::SetAnchor(const Tga::Vector2f& p)
{
    myAnchor = p;
    RebuildLayout();
}

void ActionBar::SetSpell(int slotIndex, const ActionBarSpell& spell)
{
    if (slotIndex < 0 || slotIndex >= (int)mySlots.size()) return;
    mySlots[slotIndex]->SetSpell(spell);
}

void ActionBar::ClearSlot(int slotIndex)
{
    SetSpell(slotIndex, ActionBarSpell{});
}

void ActionBar::Update(float dt)
{
    (void)dt;
    if (!myVisible || mySlots.empty()) return;

    auto* im = InputMapper::GetInstance().GetInputManager();
    if (!im || !myHUD) return;

    auto* cam = myHUD->GetUICamera();
    if (!cam) return;

    const Tga::Vector2f mouseWorld = GetMouseWorldUI(im, cam);

    const int visible = std::min(myLayout.visibleSlots, (int)mySlots.size());
    for (int i = 0; i < visible; ++i)
    {
        auto& slot = mySlots[i];
        if (!slot) continue;

        if (slot->IsDragging())
        {
            myAnchor = mouseWorld - GetSlotOffset(i);
            RebuildLayout();
            break;
        }
    }
}


int ActionBar::HitTestSlot(const Tga::Vector2f& mouseWorld) const
{
    const int visible = std::min(myLayout.visibleSlots, (int)mySlots.size());
    for (int i = 0; i < visible; ++i)
    {
        auto& b = mySlots[i];
        const auto p = b->GetPosition();
        const auto h = b->GetHalfSize();

        const bool inside =
            mouseWorld.x >= p.x - h.x && mouseWorld.x <= p.x + h.x &&
            mouseWorld.y >= p.y - h.y && mouseWorld.y <= p.y + h.y;

        if (inside) return i;
    }
    return -1;
}

void ActionBar::BeginDrag(int slotIndex)
{
    if (slotIndex < 0 || slotIndex >= (int)mySlots.size()) return;

    myDragging = true;
    myDragFrom = slotIndex;
    myDragSpell = mySlots[slotIndex]->GetSpell();
    mySlots[slotIndex]->SetGhosted(true);
}

void ActionBar::UpdateDrag(const Tga::Vector2f& mouseWorld)
{
    if (!myDragging) return;

    // TODO: flytta drag-ghost sprite till mouseWorld
    (void)mouseWorld;
}

void ActionBar::EndDrag(const Tga::Vector2f& mouseWorld, bool copy)
{
    if (!myDragging) return;

    const int to = HitTestSlot(mouseWorld);

    mySlots[myDragFrom]->SetGhosted(false);

    if (to >= 0 && to != myDragFrom)
    {
        // swap eller move/copy
        if (copy)
        {
            mySlots[to]->SetSpell(myDragSpell);
        }
        else
        {
            auto a = mySlots[myDragFrom]->GetSpell();
            auto b = mySlots[to]->GetSpell();
            mySlots[to]->SetSpell(a);
            mySlots[myDragFrom]->SetSpell(b);
        }
    }

    myDragging = false;
    myDragFrom = -1;
    myDragSpell = {};
}

void ActionBar::RebuildLayout()
{
    if (!myScene) return;

    const int visible = std::min(myLayout.visibleSlots, (int)mySlots.size());

    for (int i = 0; i < visible; ++i)
    {
        auto& slot = mySlots[i];
        if (!slot) continue;

        const bool isEmpty = slot->IsEmpty();
        const bool hideEmpty = (!myLayout.alwaysShowButtons && isEmpty);

        if (hideEmpty)
        {
            // ✅ inte rendera / inte klicka: flytta offscreen
            slot->CancelDrag();
            slot->SetVisible(false);
            slot->SetPosition({ -999999.f, -999999.f });
            slot->SetDraggable(false);
            continue;
        }

        Tga::Vector2f p = GetSlotPos(i);
        if (myLayout.snapToGrid)
            p = ApplySnap(p);

        slot->SetVisible(true);  
        slot->SetPosition(p);
        slot->SetSize({ myLayout.iconSize, myLayout.iconSize });
        slot->SetIconSize(myLayout.iconSize);
        slot->SyncIconToButton();
        slot->SyncKeybindToButton();
    }

    // resterande slots som inte är inom visibleSlots: offscreen
    for (int i = visible; i < (int)mySlots.size(); ++i)
    {
        mySlots[i]->CancelDrag();
        mySlots[i]->SetVisible(false);
        mySlots[i]->SetPosition({ -999999.f, -999999.f });
        mySlots[i]->SetDraggable(false);
    }
}

void ActionBar::SetEditMode(bool on)
{
	for (auto& s : mySlots)
	{
		s->SetDraggable(on); 

		if (!on)
		{
			s->CancelDrag();
        }
	}
}

bool ActionBar::IsDragging() const
{
    const int visible = std::min(myLayout.visibleSlots, (int)mySlots.size());

    for (int i = 0; i < visible; ++i)
    {
        const auto& slot = mySlots[i];
        if (slot && slot->IsDragging())
            return true;
    }

    return false;
}

Tga::Vector2f ActionBar::GetPosition() const
{
    return myAnchor;
}

void ActionBar::SetPosition(const Tga::Vector2f& pos)
{
    myAnchor = pos;
    RebuildLayout();
}


Tga::Vector2f ActionBar::GetSlotPos(int index) const
{
    const int cols = std::max(1, myLayout.columns);
    const int x = index % cols;
    const int y = index / cols;

    const float step = myLayout.iconSize + myLayout.padding;

    // WoW känsla: väx åt höger, rader uppåt/neråt som du vill
    return {
        myAnchor.x + x * step,
        myAnchor.y - y * step
    };
}

Tga::Vector2f ActionBar::ApplySnap(const Tga::Vector2f& p) const
{
    const float g = std::max(1.f, myLayout.gridSize);
    return {
        std::round(p.x / g) * g,
        std::round(p.y / g) * g
    };
}

Tga::Vector2f ActionBar::GetSlotOffset(int index) const
{
    const int cols = std::max(1, myLayout.columns);
    const int x = index % cols;
    const int y = index / cols;

    const float step = myLayout.iconSize + myLayout.padding;

    // samma offset som GetSlotPos använder (utan anchor)
    return { x * step, -y * step };
}

void ActionBar::ReceiveEvent(const Message& msg)
{
    // Här kan du lyssna på sliders:
    // - HudGridSizeChanged => myLayout.gridSize
    // - ActionBarIconSizeChanged => myLayout.iconSize
    // - ActionBarPaddingChanged => myLayout.padding
    // - Rows/Cols changed => rebuild
    (void)msg;
}

Tga::Vector2f ActionBar::GetBoundsMin() const
{
    if (mySlots.empty()) return myAnchor;

    const int visible = std::min(myLayout.visibleSlots, (int)mySlots.size());

    Tga::Vector2f mn{ 1e9f, 1e9f };

    for (int i = 0; i < visible; ++i)
    {
        auto& s = mySlots[i];
        if (!s) continue;

        const auto p = s->GetPosition();
        const auto h = s->GetHalfSize();

        mn.x = std::min(mn.x, p.x - h.x);
        mn.y = std::min(mn.y, p.y - h.y);
    }

    return mn;
}

Tga::Vector2f ActionBar::GetBoundsMax() const
{
    if (mySlots.empty()) return myAnchor;

    const int visible = std::min(myLayout.visibleSlots, (int)mySlots.size());

    Tga::Vector2f mx{ -1e9f, -1e9f };

    for (int i = 0; i < visible; ++i)
    {
        auto& s = mySlots[i];
        if (!s) continue;

        const auto p = s->GetPosition();
        const auto h = s->GetHalfSize();

        mx.x = std::max(mx.x, p.x + h.x);
        mx.y = std::max(mx.y, p.y + h.y);
    }

    return mx;
}

void ActionBar::DebugDrawBounds(const Tga::Color& c) const
{
    auto& dd = Tga::Engine::GetInstance()->GetDebugDrawer();
    const auto mn = GetBoundsMin();
    const auto mx = GetBoundsMax();

    const Tga::Vector2f LB{ mn.x, mn.y };
    const Tga::Vector2f LT{ mn.x, mx.y };
    const Tga::Vector2f RB{ mx.x, mn.y };
    const Tga::Vector2f RT{ mx.x, mx.y };

    dd.DrawLine(LB, LT, c);
    dd.DrawLine(LT, RT, c);
    dd.DrawLine(RT, RB, c);
    dd.DrawLine(RB, LB, c);
}