﻿// ActionBar.h
#pragma once
#include <memory>
#include <vector>
#include <unordered_map>
#include <tge/math/vector2.h>
#include "../source/Events/EventManager.h"

#include "ActionBarSceneData.h"   // layout/editor-data
#include "ActionBarSpell.h"  // spell-data
#include "ActionBarSlotButton.h"

class MenuScene;
class HUD;

enum class ActionBarOrientation : uint8_t
{
    Horizontal,
    Vertical
};

struct ActionBarLayout
{
    int columns = 12;
    int rows = 1;
    float iconSize = 150.f;
    float padding = 0.f;
    bool snapToGrid = false;
    float gridSize = 50.f;
    bool alwaysShowButtons = true;
    int visibleSlots = 12;

    bool autoColumns = false;
    ActionBarOrientation orientation = ActionBarOrientation::Horizontal;
};

class ActionBar : public Observer
{
public:
    ActionBar() = default;

    void Init(HUD& hud,MenuScene& scene,int barId,int slotCount,const Tga::Vector2f& anchorPos);
    void SetLayout(const ActionBarLayout& l);
    const ActionBarLayout& GetLayout() const { return myLayout; }

    void SetAnchor(const Tga::Vector2f& p);
    const Tga::Vector2f& GetAnchor() const { return myAnchor; }

    void SetVisible(bool v) { myVisible = v; }
    bool IsVisible() const { return myVisible; }

    // spells
    void SetSpell(int slotIndex, const ActionBarSpell& spell);
    void ClearSlot(int slotIndex);

    // kallas från HudMenu/HudMainMenu update eller input tick:
    void Update(float dt);

    // Drag&Drop API
    void BeginDrag(int slotIndex);
    void UpdateDrag(const Tga::Vector2f& mouseWorld);
    void EndDrag(const Tga::Vector2f& mouseWorld, bool copy);

    int GetBarId() const { return myBarId; }

    // hit-test
    int HitTestSlot(const Tga::Vector2f& mouseWorld) const;

    // layout
    void RebuildLayout();

    // Observer (om du vill styra via events, sliders, etc)
    void ReceiveEvent(const Message& msg) override;
    Tga::Vector2f GetBoundsMin() const;
    Tga::Vector2f GetBoundsMax() const;
    void DebugDrawBounds(const Tga::Color& c) const;

    // Exponera slots (om du vill debugdrawa)
    const std::vector<std::shared_ptr<ActionBarSlotButton>>& GetSlots() const { return mySlots; }

    void SetEditMode(bool on);
    HUD* GetHud() const { return myHUD; }   

    bool IsDragging() const;
    Tga::Vector2f GetPosition() const;
    void SetPosition(const Tga::Vector2f& pos);
private:
    Tga::Vector2f GetSlotPos(int index) const;
    Tga::Vector2f ApplySnap(const Tga::Vector2f& p) const;
    Tga::Vector2f GetSlotOffset(int index) const;

private:
    MenuScene* myScene = nullptr;
    int myBarId = 0;

    bool myVisible = true;
    Tga::Vector2f myAnchor{ 400.f, 200.f };
    ActionBarLayout myLayout{};

    std::vector<std::shared_ptr<ActionBarSlotButton>> mySlots;

    // drag state
    bool myDragging = false;
    int myDragFrom = -1;
    ActionBarSpell myDragSpell{};
    bool myDragCopy = false;
    HUD* myHUD = nullptr;
    // "drag ghost" kan vara en sprite som följer musen
    // (lägg till senare när du vill)
};
