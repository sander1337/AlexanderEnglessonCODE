#pragma once
#include <memory>
#include <tge/math/vector2.h>
#include <tge/sprite/Sprite.h>
#include <tge/text/text.h>

#include "StanceBar.h"

namespace Tga { class InputManager; class SpriteDrawer; class Camera; }
class MenuScene;

class StanceBarEditPopup
{
public:
    void Init(MenuScene& scene, const std::shared_ptr<Tga::Camera>& uiCam);

    void OpenNearBar(StanceBar& bar);
    void Close();
    bool IsOpen() const { return myOpen; }

    bool Update(Tga::InputManager* im, const Tga::Vector2f& mouseWorld);
    void Render(Tga::SpriteDrawer& drawer);

private:
    bool PointInRectCenterSize(const Tga::Vector2f& p, const Tga::Vector2f& c, const Tga::Vector2f& s) const;
    float SliderValue01(const Tga::Vector2f& mouse, const Tga::Vector2f& center, const Tga::Vector2f& size) const;

    void LayoutUI();
    void ApplyToTarget();
    void RevertToOriginal();
    void DrawSlider(Tga::SpriteDrawer& drawer, const Tga::Vector2f& c, const Tga::Vector2f& s, float t01);

private:
    MenuScene* myScene = nullptr;
    std::shared_ptr<Tga::Camera> myUiCam;

    bool myOpen = false;
    StanceBar* myTarget = nullptr;

    StanceBarLayout myOriginal{};
    StanceBarLayout myEdit{};

    Tga::SpriteSharedData myBgShared{};
    Tga::Sprite2DInstanceData myBgInst{};

    Tga::SpriteSharedData myBtnShared{};
    Tga::Sprite2DInstanceData myBtnCloseInst{};
    Tga::Sprite2DInstanceData myBtnRevertInst{};

    Tga::SpriteSharedData mySliderTrackShared{};
    Tga::SpriteSharedData mySliderKnobShared{};
    Tga::Sprite2DInstanceData mySliderTrackInst{};
    Tga::Sprite2DInstanceData mySliderKnobInst{};

    Tga::Text myTitle;
    Tga::Text myLblOrientation;
    Tga::Text myLblSize;
    Tga::Text myLblPadding;

    Tga::Text myValOrientation;
    Tga::Text myValSize;
    Tga::Text myValPadding;

    Tga::Text myCloseText;
    Tga::Text myRevertText;

    Tga::Vector2f myPanelCenter{};
    Tga::Vector2f myPanelSize{ 560.f, 320.f };

    Tga::Vector2f myOrientationDropC{}, myOrientationDropS{ 220.f, 40.f };
    Tga::Vector2f mySizeSliderC{}, mySizeSliderS{ 240.f, 24.f };
    Tga::Vector2f myPaddingSliderC{}, myPaddingSliderS{ 240.f, 24.f };

    Tga::Vector2f myCloseC{}, myCloseS{ 70.f, 44.f };
    Tga::Vector2f myRevertC{}, myRevertS{ 220.f, 48.f };

    bool myDraggingPanel = false;
    Tga::Vector2f myPanelDragGrabOffset{ 0.f, 0.f };

    Tga::Vector2f myTitleBarC{};
    Tga::Vector2f myTitleBarS{ 420.f, 44.f };

    enum class DragTarget
    {
        None,
        Size,
        Padding
    };

    DragTarget myDragging = DragTarget::None;
};