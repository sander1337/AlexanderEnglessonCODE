#include "StanceBar.h"

#include "../../SceneManagement/MenuScene.h"
#include "States/Hud/HUD.h"

#include <tge/engine.h>
#include <tge/drawers/DebugDrawer.h>

void StanceBar::Init(HUD& hud, MenuScene& scene, const Tga::Vector2f& anchorPos)
{
    myHUD = &hud;
    myScene = &scene;
    myAnchor = anchorPos;

    BuildSpells();

    const char* slotFrameTex = "assets/ui/textures/ActionBarSlot.png";

    for (int i = 0; i < 3; ++i)
    {
        auto btn = std::make_shared<ActionBarSlotButton>();
        btn->InitRuntime({ 0.f, 0.f }, { myLayout.iconSize, myLayout.iconSize });
        btn->SetCamera(scene.GetCamera());
        btn->SetVisible(true);
        btn->RegisterInput();

        btn->SetIconSize(myLayout.iconSize);
        btn->SetSlotBackground(slotFrameTex);
        btn->SetSpell(mySpells[i]);
        btn->SetKeybindText("");

        btn->SetCustomLeftClickCallback([this, i]()
            {
                switch (i)
                {
                case 0: ToggleStance(MageStance::Fire);   break;
                case 1: ToggleStance(MageStance::Frost);  break;
                case 2: ToggleStance(MageStance::Arcane); break;
                default: break;
                }
            });

        mySlots[i] = btn;
        myScene->AddRuntimeButton(btn);
    }

    // optional: chain children so moving in edit mode feels like one group
    mySlots[0]->AddChild(mySlots[1].get());
    mySlots[0]->AddChild(mySlots[2].get());

    RebuildLayout();
    SetActiveStance(MageStance::Fire);
}

void StanceBar::BuildSpells()
{
    {
        ActionBarSpell s;
        s.id = 1001;
        s.name = "Fire Stance";
        s.iconTexturePath = "assets/ui/textures/Spells/spell_fire.png";
        mySpells[0] = s;
    }

    {
        ActionBarSpell s;
        s.id = 1002;
        s.name = "Frost Stance";
        s.iconTexturePath = "assets/ui/textures/Spells/spell_frost.png";
        mySpells[1] = s;
    }

    {
        ActionBarSpell s;
        s.id = 1003;
        s.name = "Arcane Stance";
        s.iconTexturePath = "assets/ui/textures/Spells/spell_arcane.png";
        mySpells[2] = s;
    }
}

void StanceBar::Update(float dt)
{
    (void)dt;

    if (!myVisible)
        return;

    // if one slot is dragged in edit mode, move the whole stance bar anchor
    for (int i = 0; i < 3; ++i)
    {
        if (mySlots[i] && mySlots[i]->IsDragging())
        {
            myAnchor = mySlots[i]->GetPosition() - Tga::Vector2f(
                i * (myLayout.iconSize + myLayout.padding),
                0.f
            );
            RebuildLayout();
            break;
        }
    }
}

void StanceBar::RebuildLayout()
{
    for (int i = 0; i < 3; ++i)
    {
        if (!mySlots[i])
            continue;

        mySlots[i]->SetVisible(myVisible);
        mySlots[i]->SetSize({ myLayout.iconSize, myLayout.iconSize });
        mySlots[i]->SetIconSize(myLayout.iconSize);
        mySlots[i]->SetPosition(GetSlotPos(i));
        mySlots[i]->SyncIconToButton();
        mySlots[i]->SyncBackgroundToButton();
        mySlots[i]->SyncCooldownToButton();
    }

    ApplyActiveVisuals();
}

void StanceBar::SetPosition(const Tga::Vector2f& pos)
{
    myAnchor = pos;
    RebuildLayout();
}

void StanceBar::SetEditMode(bool on)
{
    if (mySlots[0]) mySlots[0]->SetDraggable(on);
    if (mySlots[1]) mySlots[1]->SetDraggable(false);
    if (mySlots[2]) mySlots[2]->SetDraggable(false);

    if (!on)
    {
        for (int i = 0; i < 3; ++i)
        {
            if (mySlots[i])
                mySlots[i]->CancelDrag();
        }
    }
}

void StanceBar::SetVisible(bool visible)
{
    myVisible = visible;

    for (int i = 0; i < 3; ++i)
    {
        if (mySlots[i])
            mySlots[i]->SetVisible(visible);
    }
}

void StanceBar::SetActiveStance(MageStance stance)
{
    if (myActiveStance == stance)
        return;

    myActiveStance = stance;
    ApplyActiveVisuals();

    if (myHUD)
        myHUD->ApplyStanceBuff(stance);
}

void StanceBar::ApplyActiveVisuals()
{
    for (int i = 0; i < 3; ++i)
    {
        if (!mySlots[i])
            continue;

        mySlots[i]->ClearManualTint();
    }

    switch (myActiveStance)
    {
    case MageStance::None:
        mySlots[0]->SetManualTint({ 0.75f, 0.75f, 0.75f, 1.f });
        mySlots[1]->SetManualTint({ 0.75f, 0.75f, 0.75f, 1.f });
        mySlots[2]->SetManualTint({ 0.75f, 0.75f, 0.75f, 1.f });
        break;

    case MageStance::Fire:
        mySlots[0]->SetManualTint({ 1.25f, 1.10f, 1.10f, 1.f });
        mySlots[1]->SetManualTint({ 0.65f, 0.65f, 0.65f, 1.f });
        mySlots[2]->SetManualTint({ 0.65f, 0.65f, 0.65f, 1.f });
        break;

    case MageStance::Frost:
        mySlots[0]->SetManualTint({ 0.65f, 0.65f, 0.65f, 1.f });
        mySlots[1]->SetManualTint({ 1.10f, 1.20f, 1.30f, 1.f });
        mySlots[2]->SetManualTint({ 0.65f, 0.65f, 0.65f, 1.f });
        break;

    case MageStance::Arcane:
        mySlots[0]->SetManualTint({ 0.65f, 0.65f, 0.65f, 1.f });
        mySlots[1]->SetManualTint({ 0.65f, 0.65f, 0.65f, 1.f });
        mySlots[2]->SetManualTint({ 1.20f, 1.10f, 1.30f, 1.f });
        break;

    default:
        break;
    }
}

Tga::Vector2f StanceBar::GetSlotPos(int index) const
{
    const float step = myLayout.iconSize + myLayout.padding;

    if (myLayout.orientation == StanceBarOrientation::Horizontal)
        return { myAnchor.x + index * step, myAnchor.y };

    return { myAnchor.x, myAnchor.y - index * step };
}

Tga::Vector2f StanceBar::GetBoundsMin() const
{
    Tga::Vector2f mn{ 1e9f, 1e9f };

    for (int i = 0; i < 3; ++i)
    {
        if (!mySlots[i])
            continue;

        const auto p = mySlots[i]->GetPosition();
        const auto h = mySlots[i]->GetHalfSize();

        mn.x = std::min(mn.x, p.x - h.x);
        mn.y = std::min(mn.y, p.y - h.y);
    }

    return mn;
}

Tga::Vector2f StanceBar::GetBoundsMax() const
{
    Tga::Vector2f mx{ -1e9f, -1e9f };

    for (int i = 0; i < 3; ++i)
    {
        if (!mySlots[i])
            continue;

        const auto p = mySlots[i]->GetPosition();
        const auto h = mySlots[i]->GetHalfSize();

        mx.x = std::max(mx.x, p.x + h.x);
        mx.y = std::max(mx.y, p.y + h.y);
    }

    return mx;
}

void StanceBar::ToggleStance(MageStance stance)
{
    if (myActiveStance == stance)
        SetActiveStance(MageStance::None);
    else
        SetActiveStance(stance);
}

void StanceBar::RenderDebugBounds(const Tga::Color& c) const
{
    auto& dd = Tga::Engine::GetInstance()->GetDebugDrawer();

    const auto mn = GetBoundsMin();
    const auto mx = GetBoundsMax();

    const Tga::Vector2f LB{ mn.x, mn.y };
    const Tga::Vector2f LT{ mn.x, mx.y };
    const Tga::Vector2f RB{ mx.x, mn.y };
    const Tga::Vector2f RT{ mx.x, mx.y };

    dd.DrawLine(LB, LT, c);
    dd.DrawLine(LT, RT, c);
    dd.DrawLine(RT, RB, c);
    dd.DrawLine(RB, LB, c);
}

void StanceBar::SetLayout(const StanceBarLayout& layout)
{
    myLayout = layout;
    myLayout.iconSize = std::max(24.f, myLayout.iconSize);
    myLayout.padding = std::max(0.f, myLayout.padding);
    RebuildLayout();
}
