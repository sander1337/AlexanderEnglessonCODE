﻿#include "ActionBarKeybinds.h"

#include "UI/Button.h"                
#include "../../SceneManagement/MenuScene.h"  

#include "States/ActionBars/ActionBarSlotButton.h"
#include <tge/engine.h>
#include <tge/texture/TextureManager.h>
#include <tge/drawers/SpriteDrawer.h>

#include "Utilities/UIRectUtils.h"
#include "Utilities/UITextUtils.h"

void ActionBarKeybinds::Clear()
{
    myKeyToSlot.clear();
    mySlotToKey.clear();
}

ActionBarSlotButton* ActionBarKeybinds::GetSlotForKey(int vk) const
{
    auto it = myKeyToSlot.find(vk);
    return (it != myKeyToSlot.end()) ? it->second : nullptr;
}

void ActionBarKeybinds::Unbind(ActionBarSlotButton* slot)
{
    if (!slot) return;

    auto it = mySlotToKey.find(slot);
    if (it != mySlotToKey.end())
    {
        const int oldVk = it->second;
        myKeyToSlot.erase(oldVk);
        mySlotToKey.erase(it);
    }

    // optional: clear label
    slot->SetKeybindText("");
}

void ActionBarKeybinds::Bind(ActionBarSlotButton* slot, int vk)
{
    if (!slot) return;

    // If another slot already has this key -> unbind it
    if (auto it = myKeyToSlot.find(vk); it != myKeyToSlot.end())
    {
        ActionBarSlotButton* other = it->second;
        if (other && other != slot)
            Unbind(other);
    }

    // Remove old key for this slot
    Unbind(slot);

    // Store mapping
    myKeyToSlot[vk] = slot;
    mySlotToKey[slot] = vk;

    // Update label on slot
    slot->SetKeybindText(VkToPrettyLabel(vk));
}

std::string ActionBarKeybinds::VkToPrettyLabel(int vk)
{
    if (vk >= 'A' && vk <= 'Z') return std::string(1, char(vk));
    if (vk >= '0' && vk <= '9') return std::string(1, char(vk));

    switch (vk)
    {
    case VK_OEM_MINUS:  return "-";
    case VK_OEM_PLUS:   return "=";
    case VK_TAB:        return "Tab";
    case VK_SPACE:      return "Space";
    case VK_RETURN:     return "Enter";
    case VK_BACK:       return "Back";
    case VK_ESCAPE:     return "Esc";
    case VK_LEFT:       return "Left";
    case VK_RIGHT:      return "Right";
    case VK_UP:         return "Up";
    case VK_DOWN:       return "Down";
    case VK_PRIOR:      return "PgUp";
    case VK_NEXT:       return "PgDn";
    case VK_HOME:       return "Home";
    case VK_END:        return "End";
    case VK_INSERT:     return "Ins";
    case VK_DELETE:     return "Del";
    default: break;
    }

    if (vk >= VK_F1 && vk <= VK_F12)
        return "F" + std::to_string(vk - VK_F1 + 1);

    return "VK_" + std::to_string(vk);
}

int ActionBarKeybinds::DetectPressedVkThisFrame(Tga::InputManager* im)
{
    if (!im) return 0;

    for (int vk = 'A'; vk <= 'Z'; ++vk)
        if (im->IsKeyPressed(vk)) return vk;

    for (int vk = '0'; vk <= '9'; ++vk)
        if (im->IsKeyPressed(vk)) return vk;

    const int keys[] = {
        VK_OEM_MINUS, VK_OEM_PLUS,
        VK_TAB, VK_SPACE, VK_RETURN,
        VK_BACK, VK_ESCAPE,
        VK_LEFT, VK_RIGHT, VK_UP, VK_DOWN,
        VK_INSERT, VK_DELETE, VK_HOME, VK_END,
        VK_PRIOR, VK_NEXT
    };

    for (int vk : keys)
        if (im->IsKeyPressed(vk)) return vk;

    for (int vk = VK_F1; vk <= VK_F12; ++vk)
        if (im->IsKeyPressed(vk)) return vk;

    return 0;
}

// ------------------- popup code you already had -------------------
// keep your InitPopup/OpenPopup/ClosePopup/UpdatePopup/RenderPopup below
void ActionBarKeybinds::InitPopup(MenuScene&, const std::shared_ptr<Tga::Camera>&)
{
    auto& tm = Tga::Engine::GetInstance()->GetTextureManager();

    myPopup.bgShared.myTexture = tm.GetTexture("assets/ui/textures/spellbook_panel.png");
    myPopup.bgShared.blendState = Tga::BlendState::AlphaBlend;
    myPopup.bgShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    myPopup.bgInst.myPivot = { 0.5f, 0.5f };
    myPopup.bgInst.myColor = { 1.f, 1.f, 1.f, 0.95f };
    myPopup.bgInst.myIsHidden = true;

    myPopup.title = Tga::Text("Text/arial.ttf", Tga::FontSize_24, 1);
    myPopup.title.SetText("Rebind key");

    myPopup.currentBind = Tga::Text("Text/arial.ttf", Tga::FontSize_24, 1);

    // Simple button rectangles
    myPopup.btnShared.myTexture = tm.GetTexture("assets/ui/textures/spellbook_panel.png");
    myPopup.btnShared.blendState = Tga::BlendState::AlphaBlend;
    myPopup.btnShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    myPopup.saveInst.myPivot = { 0.5f, 0.5f };
    myPopup.cancelInst.myPivot = { 0.5f, 0.5f };


    // Colors (tint the 1x1)
    myPopup.saveEnabledColor = { 0.0f, 1.0f, 0.0f, 1.0f };
    myPopup.saveDisabledColor = { 0.4f, 0.4f, 0.4f, 0.6f }; // grey
    myPopup.saveInst.myColor = myPopup.saveDisabledColor;
    myPopup.cancelInst.myColor = { 1.0f, 0.0f, 0.0f, 1.0f };

    myPopup.saveText = Tga::Text("Text/arial.ttf", Tga::FontSize_24, 1);
    myPopup.saveText.SetText("Save");

    myPopup.cancelText = Tga::Text("Text/arial.ttf", Tga::FontSize_24, 1);
    myPopup.cancelText.SetText("Cancel");
}


void ActionBarKeybinds::OpenPopup(ActionBarSlotButton* slot)
{
    if (!slot) return;

    myPopup.open = true;
    myPopup.targetSlot = slot;
    myPopup.hasPending = false;
    myPopup.pendingVk = 0;

    const auto resI = Tga::Engine::GetInstance()->GetRenderSize();
	Tga::Vector2f center{ resI.x * 0.5f, resI.y * 0.5f };

    center.x -= 800.f;

    // --- panel ---
    myPopup.bgInst.myPosition = center;
    myPopup.bgInst.mySize = { 520.f, 260.f };
    myPopup.bgInst.myIsHidden = false;

    const float panelW = myPopup.bgInst.mySize.x;
    const float panelH = myPopup.bgInst.mySize.y;

    const float left = center.x - panelW * 0.5f;
    const float right = center.x + panelW * 0.5f;
    const float top = center.y + panelH * 0.5f;
    const float bottom = center.y - panelH * 0.5f;
    right;
    const float padX = 24.f;
    const float padY = 20.f;

    // --- Title (centered X, near top) ---
    const float titleY = top - padY - 28.f;              // tweak 28 if font differs
    UI::SetTextCenteredX(myPopup.title, center.x, titleY);

    // --- Description (wrapped inside panel) ---
    const float innerW = panelW - padX * 2.f;

    const std::string desc = "Press a key, then click Save (or Cancel).";
    const std::string wrapped = UI::WrapTextToWidth(myPopup.currentBind, desc, innerW);
    myPopup.currentBind.SetText(wrapped.c_str());

    // place desc below title with spacing
    const float descY = titleY - 44.f; // spacing down from title (tweak)
    myPopup.currentBind.SetPosition({ left + padX, descY });

    // --- Buttons row (centered, near bottom) ---
    myPopup.saveSize = { 120.f, 48.f };
    myPopup.cancelSize = { 120.f, 48.f };
    const float gap = 40.f;

    const float buttonsY = bottom + padY + myPopup.saveSize.y * 0.5f;

    myPopup.savePos = { center.x - (myPopup.saveSize.x * 0.5f + gap * 0.5f), buttonsY };
    myPopup.cancelPos = { center.x + (myPopup.cancelSize.x * 0.5f + gap * 0.5f), buttonsY };

    myPopup.saveInst.myPosition = myPopup.savePos;
    myPopup.saveInst.mySize = myPopup.saveSize;

    myPopup.cancelInst.myPosition = myPopup.cancelPos;
    myPopup.cancelInst.mySize = myPopup.cancelSize;

    // --- Button labels (centered inside each button) ---
    // Text in Tga is top-left anchored, so use button-top + padding.
    const float labelPadFromTop = 14.f;

    const float saveTop = myPopup.savePos.y - myPopup.saveSize.y * 0.5f;
    const float cancelTop = myPopup.cancelPos.y - myPopup.cancelSize.y * 0.5f;

    UI::SetTextCenteredX(myPopup.saveText, myPopup.savePos.x, saveTop + labelPadFromTop);
    UI::SetTextCenteredX(myPopup.cancelText, myPopup.cancelPos.x, cancelTop + labelPadFromTop);

    // Save starts disabled until key staged
    myPopup.saveInst.myColor = myPopup.saveDisabledColor;
}



void ActionBarKeybinds::ClosePopup()
{
    myPopup.open = false;
    myPopup.targetSlot = nullptr;
    myPopup.hasPending = false;
    myPopup.pendingVk = 0;
    myPopup.bgInst.myIsHidden = true;
}


bool ActionBarKeybinds::UpdatePopup(Tga::InputManager* im, const Tga::Vector2f& mouseWorld)
{
    if (!myPopup.open || !im)
        return false;


    // Stage key
    if (!myPopup.hasPending)
    {
        const int vk = DetectPressedVkThisFrame(im);
        if (vk != 0 && vk != VK_CONTROL && vk != VK_LCONTROL && vk != VK_RCONTROL)
        {
            myPopup.hasPending = true;
            myPopup.pendingVk = vk;

            // ✅ enable Save
            myPopup.saveInst.myColor = myPopup.saveEnabledColor;

            const std::string label = VkToPrettyLabel(vk);

            const float panelW = myPopup.bgInst.mySize.x;
            const float padX = 24.f;
            const float innerW = panelW - padX * 2.f;

            const std::string msg = "New bind: " + label + "  (click Save)";
            const std::string wrapped = UI::WrapTextToWidth(myPopup.currentBind, msg, innerW);
            myPopup.currentBind.SetText(wrapped.c_str());
        }
    }

    // Mouse click -> buttons
    if (im->IsKeyPressed(VK_LBUTTON))
    {
        if (PointInRectCenterSize(mouseWorld, myPopup.cancelPos, myPopup.cancelSize))
        {
            ClosePopup();
            return true;
        }

        if (PointInRectCenterSize(mouseWorld, myPopup.savePos, myPopup.saveSize))
        {
            if (myPopup.hasPending)
            {
                Bind(myPopup.targetSlot, myPopup.pendingVk);
                ClosePopup();
            }
            return true; // consume click either way
        }
    }

    return true; // modal
}


void ActionBarKeybinds::RenderPopup(Tga::SpriteDrawer& drawer)
{
    if (!myPopup.open) return;

    drawer.Draw(myPopup.bgShared, myPopup.bgInst);

    // buttons
	drawer.Draw(myPopup.btnShared, myPopup.saveInst);
    drawer.Draw(myPopup.btnShared, myPopup.cancelInst);

    // text
    myPopup.title.Render();
    myPopup.currentBind.Render();
	myPopup.saveText.Render();
    myPopup.cancelText.Render();
}
