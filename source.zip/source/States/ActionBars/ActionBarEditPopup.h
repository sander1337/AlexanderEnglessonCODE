// ActionBarEditPopup.h
#pragma once
#include <memory>
#include <string>

#include <tge/math/vector2.h>
#include <tge/sprite/Sprite.h>
#include <tge/text/text.h>
#include "ActionBar.h"   
#include "States/Hud/HudActionBarsController.h"


namespace Tga { class InputManager; class SpriteDrawer; class Camera; }
class MenuScene;

class ActionBarEditPopup
{
public:
    void Init(MenuScene& scene, const std::shared_ptr<Tga::Camera>& uiCam);

    void Open(ActionBar& bar);
    void Close();
    bool IsOpen() const { return myOpen; }

    // Returns true if popup is modal and consumed input this frame
    bool Update(Tga::InputManager* im, const Tga::Vector2f& mouseWorld);
    void Render(Tga::SpriteDrawer& drawer);

    void OpenNearBar(ActionBar& bar); 

    void SaveAndClose();
    bool IsPointInsidePopup(const Tga::Vector2f& p) const;
    ActionBar* GetTarget() const { return myTarget; }
private:
    // --- small UI helpers ---
    bool PointInRectCenterSize(const Tga::Vector2f& p, const Tga::Vector2f& c, const Tga::Vector2f& s) const;
    float SliderValue01(const Tga::Vector2f& mouse, const Tga::Vector2f& center, const Tga::Vector2f& size) const;

    void ApplyToTarget();      // push current edited layout into ActionBar
    void RevertToOriginal();   // reset to snapshot
    void LayoutUI();           // recompute positions of controls when opened
    bool IsOverAnyControl(const Tga::Vector2f& m) const;

    Tga::Vector2f FindPopupCenter(const Tga::Vector2f& anchor, float panelW, float panelH) const;
    Tga::Vector2f ClampPopupToScreen(Tga::Vector2f c, float panelW, float panelH) const;



private:
    MenuScene* myScene = nullptr;
    std::shared_ptr<Tga::Camera> myUiCam;
    bool myOpen = false;
    ActionBar* myTarget = nullptr;

    // Snapshot + edited values
    // (You already have ActionBarLayout in ActionBar.h)
    ActionBarLayout myOriginal{};
    ActionBarLayout myEdit{};

    // Panel visuals
    Tga::SpriteSharedData myBgShared{};
    Tga::Sprite2DInstanceData myBgInst{};

    // Generic button visuals (same texture tinted)
    Tga::SpriteSharedData myBtnShared{};
    Tga::Sprite2DInstanceData myBtnRevertInst{};
    Tga::Sprite2DInstanceData myBtnCloseInst{};

    // Slider track/knob (simple tinted sprites)
    Tga::SpriteSharedData mySliderTrackShared{};
    Tga::SpriteSharedData mySliderKnobShared{};
    Tga::Sprite2DInstanceData mySliderTrackInst{};
    Tga::Sprite2DInstanceData mySliderKnobInst{};

    // Text labels
    Tga::Text myTitle;
    Tga::Text myLblOrientation;
    Tga::Text myLblRows;
    Tga::Text myLblIcons;
    Tga::Text myLblSize;
    Tga::Text myLblPadding;
    Tga::Text myLblAlwaysShow;

    // Value texts (right side)
    Tga::Text myValOrientation;
    Tga::Text myValRows;
    Tga::Text myValIcons;
    Tga::Text myValSize;
    Tga::Text myValPadding;

    Tga::Text myRevertText;
    Tga::Text myCloseText;

    // Positions (center + size) for clickables
    Tga::Vector2f myPanelCenter{};
    Tga::Vector2f myPanelSize{ 720.f, 520.f };

    // Controls layout (store rects)
    struct SliderUI { Tga::Vector2f c{}, s{}; };
    SliderUI myRowsSlider;
    SliderUI myIconsSlider;
    SliderUI mySizeSlider;
    SliderUI myPaddingSlider;

    void DrawSlider(Tga::SpriteDrawer& drawer, const ::ActionBarEditPopup::SliderUI& ui, float t01, float knobW, float knobH);

    Tga::Vector2f myOrientationDropC{}, myOrientationDropS{ 260.f, 40.f };
    Tga::Vector2f myAlwaysCheckC{}, myAlwaysCheckS{ 40.f, 40.f };

    Tga::Vector2f myRevertC{}, myRevertS{ 260.f, 52.f };
    Tga::Vector2f myCloseC{}, myCloseS{ 80.f,  50.f };

    // dragging state
    enum class DragTarget { None, Rows, Icons, Size, Padding };
    DragTarget myDragging = DragTarget::None;

    float myValueX;

    // Drag popup
    bool myDraggingPanel = false;
    Tga::Vector2f myDragGrabOffset{ 0.f, 0.f };

    // cache panel rect (center/size)
    Tga::Vector2f myPanelC{};
    Tga::Vector2f myPanelS{ 720.f, 520.f };

    // titlebar drag rect (center/size)
    Tga::Vector2f myTitleBarC{};
    Tga::Vector2f myTitleBarS{ 0.f, 0.f };

    // Checkbox
    Tga::SpriteSharedData myCheckboxCheckedShared{};
    Tga::SpriteSharedData myCheckboxOpenShared{};
    Tga::Sprite2DInstanceData myCheckboxInst{};
};
