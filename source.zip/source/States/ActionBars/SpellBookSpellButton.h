#pragma once
#include "ActionBarSpell.h"
#include "Graphics/GameSprite.h"
#include "UI/Button.h"
#include "../Hud/HUD.h"

class HUD;

class SpellBookSpellButton : public Button
{
public:
    void SetHUD(HUD* hud);
    void SetSpell(const ActionBarSpell& s);
    void SetVisible(bool v);
    bool IsVisible() { return myVisible; }
    void Render() override;
    void Update(float dt) override;
    const ActionBarSpell& GetSpell() const { return mySpell; }

protected:
    void OnLeftClick() override;

private:
    void SyncIcon();

    HUD* myHUD = nullptr;
    ActionBarSpell mySpell{};
    bool myVisible = true;

    Tga::SpriteSharedData myIconShared{};
    Tga::Sprite2DInstanceData myIconInst{};
};

