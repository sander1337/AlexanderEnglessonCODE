﻿// ActionBarSlotButton.cpp
#include "ActionBarSlotButton.h"

#include <tge/engine.h>
#include <tge/texture/TextureManager.h>
#include <tge/graphics/GraphicsEngine.h>
#include <tge/graphics/GraphicsStateStack.h>
#include <tge/drawers/SpriteDrawer.h>

#include "ActionBar.h"
#include "GameWorld.h"
#include "../Hud/HUD.h"

void ActionBarSlotButton::SetOwner(ActionBar* owner, int index)
{
    myOwner = owner;
    myIndex = index;

    InitBindTextOnce();

    // default label (you can override later at runtime)
    SetKeybindText(std::to_string(index + 1));
}

void ActionBarSlotButton::SetSlotBackground(const char* texturePath)
{
    auto& tm = Tga::Engine::GetInstance()->GetTextureManager();
    myBgShared.myTexture = tm.GetTexture(texturePath);

    myBgShared.blendState = Tga::BlendState::AlphaBlend;
    myBgShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    myBgInst.myPivot = { 0.5f, 0.5f };
    myBgInst.myUV = { 0.f, 0.f };
    myBgInst.myUVScale = { 1.f, 1.f };
    myBgInst.myColor = { 1.f, 1.f, 1.f, 1.f };
    myBgInst.myIsHidden = (myBgShared.myTexture == nullptr);

    EnsureCooldownShader();

    SyncBackgroundToButton();
    SyncCooldownToButton();
}

void ActionBarSlotButton::SyncBackgroundToButton()
{
    myBgInst.myPosition = GetPosition();
    // matcha knappens hitbox-storlek
    const auto size = GetHalfSize() * 2.f;
    myBgInst.mySize = size;
}

void ActionBarSlotButton::SetIconSize(float px)
{
    const float scale = 0.70f;   // 90% size
    const float iconSize = px * scale;

    myIconInst.mySize = { iconSize, iconSize };
    myIconInst.myPivot = { 0.5f, 0.5f };
    myIconInst.myColor = { 1,1,1,1 };

    myIconShared.blendState = Tga::BlendState::AlphaBlend;
    myIconShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;
}

void ActionBarSlotButton::SyncIconToButton()
{
    myIconInst.myPosition = GetPosition();
}

void ActionBarSlotButton::Render()
{
    auto& engine = *Tga::Engine::GetInstance();
    auto& gss = engine.GetGraphicsEngine().GetGraphicsStateStack();
    auto& spriteDrawer = engine.GetGraphicsEngine().GetSpriteDrawer();

    SyncBackgroundToButton();
    SyncIconToButton();
    SyncCooldownToButton();

    gss.Push();
    gss.SetBlendState(Tga::BlendState::AlphaBlend);

    if (!myBgInst.myIsHidden && myBgShared.myTexture)
        spriteDrawer.Draw(myBgShared, myBgInst);

    if (HasIcon())
        spriteDrawer.Draw(myIconShared, myIconInst);

    if (IsOnCooldown() && myCooldownShared.myTexture)
    {
        gss.SetOrbValue(GetCooldownNormalized());
        spriteDrawer.Draw(myCooldownShared, myCooldownInst);
        gss.SetOrbValue(0.0f);
    }

    SyncKeybindToButton();
    myBindText.Render();

    gss.Pop();
}

void ActionBarSlotButton::Update(float aDeltaTime)
{
    Button::Update(aDeltaTime);
    UpdateCooldown(aDeltaTime);

    if (myPressFlashRemaining > 0.f)
    {
        myPressFlashRemaining -= aDeltaTime;
        if (myPressFlashRemaining < 0.f)
            myPressFlashRemaining = 0.f;
    }

    // reset base colors first
    myBgInst.myColor = { 1.f, 1.f, 1.f, 1.f };
    myIconInst.myColor = { 1.f, 1.f, 1.f, myGhosted ? 0.35f : 1.f };

    if (myUseManualTint)
    {
        myBgInst.myColor = myManualTint;
        myIconInst.myColor.r *= myManualTint.r;
        myIconInst.myColor.g *= myManualTint.g;
        myIconInst.myColor.b *= myManualTint.b;
    }

    // hover-glow bara om slot är tom
    if (myHoverGlow && IsEmpty())
    {
        myHoverGlowT += aDeltaTime;

        const float s = 0.5f + 0.5f * sinf(myHoverGlowT * 6.f);
        const float boost = 1.05f + 0.20f * s;
        const float a = 0.85f + 0.15f * s;

        myBgInst.myColor = { boost, boost, boost, a };
    }

    // press feedback flash
    if (myPressFlashRemaining > 0.f)
    {
        const float t = myPressFlashRemaining / myPressFlashDuration; // 1 -> 0
        const float boost = 1.0f + 0.35f * t; // tweak strength here

        myBgInst.myColor.r *= boost;
        myBgInst.myColor.g *= boost;
        myBgInst.myColor.b *= boost;

        myIconInst.myColor.r *= boost;
        myIconInst.myColor.g *= boost;
        myIconInst.myColor.b *= boost;
    }

    SyncBackgroundToButton();
    SyncIconToButton();
    SyncCooldownToButton();
}
void ActionBarSlotButton::TriggerPressFeedback(float duration)
{
    myPressFlashDuration = std::max(0.001f, duration);
    myPressFlashRemaining = myPressFlashDuration;
}

void ActionBarSlotButton::SetKeybindText(const std::string& s)
{
    myBindStr = s;
    myBindText.SetText(myBindStr.c_str());
    SyncKeybindToButton();
}

void ActionBarSlotButton::SyncKeybindToButton()
{
    const auto p = GetPosition();
    const auto h = GetHalfSize();

    // top-left inside the slot with padding
    const float pad = 6.f;

    Tga::Vector2f pos{
        p.x + h.x - pad - myBindText.GetWidth(),  // right side
        p.y + h.y - pad                           // top side
    };

    // adjust for baseline if needed
    pos.y -= 16.f;   // tweak if font sits too high

    myBindText.SetPosition(pos);
}

void ActionBarSlotButton::StartCooldown(float duration)
{
    myCooldownDuration = std::max(0.001f, duration);
    myCooldownRemaining = myCooldownDuration;
    myShowCooldown = true;
}

void ActionBarSlotButton::StopCooldown()
{
    myCooldownDuration = 0.f;
    myCooldownRemaining = 0.f;
    myShowCooldown = false;
}

void ActionBarSlotButton::UpdateCooldown(float dt)
{
    if (!myShowCooldown)
        return;

    myCooldownRemaining -= dt;
    if (myCooldownRemaining <= 0.f)
    {
        StopCooldown();
    }
}

float ActionBarSlotButton::GetCooldownNormalized() const
{
    if (!myShowCooldown || myCooldownDuration <= 0.f)
        return 0.f;

    float value = std::clamp(myCooldownRemaining / myCooldownDuration, 0.f, 1.f);

    return value;
}

void ActionBarSlotButton::SyncCooldownToButton()
{
    myCooldownInst.myPosition = myIconInst.myPosition;
    myCooldownInst.mySize = myIconInst.mySize;
    myCooldownInst.myPivot = { 0.5f, 0.5f };
}

void ActionBarSlotButton::EnsureCooldownShader()
{
    auto& tm = Tga::Engine::GetInstance()->GetTextureManager();

    myCooldownShared.myTexture = tm.GetTexture("assets/ui/textures/white_1x1.png");
    myCooldownShared.blendState = Tga::BlendState::AlphaBlend;
    myCooldownShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    RenderManager& renderManager = *GameWorld::GetInstance().GetRenderManager().lock();
    NCE::RenderResources& renderResources = renderManager.GetRenderResources();

    const char* pixelPath = "Shaders/CooldownRadial_PS";
    Tga::StringId shaderID = Tga::StringRegistry::RegisterOrGetString(pixelPath);

    auto shaderIt = renderResources.mySpriteShaders.find(shaderID);
    if (shaderIt == renderResources.mySpriteShaders.end())
    {
        auto shader = std::make_unique<Tga::SpriteShader>();
        shader->Init("Shaders/instanced_sprite_shader_VS", pixelPath);
        myCooldownShared.myCustomShader = shader.get();
        renderResources.mySpriteShaders.emplace(shaderID, std::move(shader));
    }
    else
    {
        myCooldownShared.myCustomShader = shaderIt->second.get();
    }

    myCooldownInst.myPivot = { 0.5f, 0.5f };
    myCooldownInst.myUV = { 0.f, 0.f };
    myCooldownInst.myUVScale = { 1.f, 1.f };
    myCooldownInst.myColor = { 0.f, 0.f, 0.f, 0.65f };
}

inline bool IsCtrlDown()
{
    if (auto* im = InputMapper::GetInstance().GetInputManager())
        return im->IsKeyHeld(VK_CONTROL);
    return false;
}

void ActionBarSlotButton::OnLeftClick()
{
    if (myCustomLeftClick)
    {
        myCustomLeftClick();
        return;
    }

    if (!myOwner) return;

    // EDIT MODE → drag/move the BAR (unchanged)
    if (IsDraggable())
    {
        Button::OnLeftClick();
        return;
    }

    auto* hud = myOwner->GetHud();
    if (!hud) return;


    // ✅ SHIFT + LMB on non-empty = start drag
    if (!IsEmpty())
    {
        auto* im = InputMapper::GetInstance().GetInputManager();
        const bool shiftDown =
            im && (im->IsKeyHeld(VK_SHIFT) || im->IsKeyHeld(VK_LSHIFT) || im->IsKeyHeld(VK_RSHIFT));

        if (shiftDown)
        {
            hud->BeginDragFromSlot(this);
            return;
        }

        // No shift: for now do nothing (later: cast spell)
        // hud->TryCastSpell(mySpell); // future
        return;
    }

    if (IsCtrlDown())
    {
        return;
    }

    hud->SetPendingBind(this);
    hud->OpenSpellBookForSlot(this);
}

void ActionBarSlotButton::OnRightClick()
{
    // TODO
}

bool ActionBarSlotButton::OnHoverEnter()
{
    myIsHovered = true;

    if (IsEmpty())
    {
        myHoverGlow = true;
        myHoverGlowT = 0.f;
        myBgInst.myColor = { 1.15f, 1.15f, 1.15f, 1.f };
    }
    else
    {
        myBgInst.myColor = { 1.f, 1.f, 1.f, 1.f };
        myIconInst.myColor = { 1.f, 1.f, 1.f, 1.f };
    }

    if (myOwner && myOwner->GetHud() && !IsEmpty())
        myOwner->GetHud()->ShowSpellTooltip(GetSpell());

    return true;
}

void ActionBarSlotButton::OnHoverExit()
{
    myIsHovered = false;
    myHoverGlow = false;

    myBgInst.myColor = { 1.f, 1.f, 1.f, 1.f };
    myIconInst.myColor = { 1.f, 1.f, 1.f, myGhosted ? 0.35f : 1.f };

    if (myOwner && myOwner->GetHud())
        myOwner->GetHud()->HideSpellTooltip();
}


void ActionBarSlotButton::ApplyVisualsFromSpell()
{
    SyncIconToButton();

    if (IsEmpty() || mySpell.iconTexturePath.empty())
    {
        myIconShared.myTexture = nullptr;
        myIconInst.myIsHidden = true;
        return;
    }

    auto& tm = Tga::Engine::GetInstance()->GetTextureManager();
    myIconShared.myTexture = tm.GetTexture(mySpell.iconTexturePath.c_str());
    myIconInst.myIsHidden = (myIconShared.myTexture == nullptr);
}

void ActionBarSlotButton::ApplyGhostAlpha()
{
    const float iconA = myGhosted ? 0.0f : 1.0f; 

    myBgInst.myColor.a = 1.0f;   // ✅ frame försvinner aldrig
    myIconInst.myColor.a = iconA; // ✅ bara spell-ikon påverkas
}

void ActionBarSlotButton::InitBindTextOnce()
{
    if (myBindInit) return;
    myBindInit = true;

    myBindText = Tga::Text("Text/arial.ttf", Tga::FontSize_24, 1);
    myBindText.SetColor({ 1.f, 1.f, 1.f, 0.95f });
}

