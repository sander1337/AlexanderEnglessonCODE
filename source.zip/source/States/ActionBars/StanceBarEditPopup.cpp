#include "StanceBarEditPopup.h"

#include <algorithm>
#include <cmath>

#include <tge/engine.h>
#include <tge/texture/TextureManager.h>
#include <tge/drawers/SpriteDrawer.h>
#include "../../SceneManagement/MenuScene.h"
#include "../../Utilities/UIRectUtils.h"


bool StanceBarEditPopup::PointInRectCenterSize(const Tga::Vector2f& p, const Tga::Vector2f& c, const Tga::Vector2f& s) const
{
    const Tga::Vector2f h = { s.x * 0.5f, s.y * 0.5f };
    return (p.x >= c.x - h.x && p.x <= c.x + h.x &&
        p.y >= c.y - h.y && p.y <= c.y + h.y);
}

float StanceBarEditPopup::SliderValue01(const Tga::Vector2f& mouse, const Tga::Vector2f& center, const Tga::Vector2f& size) const
{
    const float left = center.x - size.x * 0.5f;
    const float t = (mouse.x - left) / size.x;
   
    return Clamp01(t);
}

void StanceBarEditPopup::Init(MenuScene& scene, const std::shared_ptr<Tga::Camera>& uiCam)
{
    myScene = &scene;
    myUiCam = uiCam;

    auto& tm = Tga::Engine::GetInstance()->GetTextureManager();

    myBgShared.myTexture = tm.GetTexture("assets/ui/textures/spellbook_panel.png");
    myBgShared.blendState = Tga::BlendState::AlphaBlend;
    myBgShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    myBtnShared.myTexture = tm.GetTexture("assets/ui/textures/spellbook_panel.png");
    myBtnShared.blendState = Tga::BlendState::AlphaBlend;
    myBtnShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    mySliderTrackShared.myTexture = tm.GetTexture("assets/ui/textures/Slider_background.png");
    mySliderTrackShared.blendState = Tga::BlendState::AlphaBlend;
    mySliderTrackShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    mySliderKnobShared.myTexture = tm.GetTexture("assets/ui/textures/Slider_button.png");
    mySliderKnobShared.blendState = Tga::BlendState::AlphaBlend;
    mySliderKnobShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    myBgInst.myPivot = { 0.5f, 0.5f };
    myBgInst.myColor = { 1.f, 1.f, 1.f, 0.96f };
    myBgInst.myIsHidden = true;

    myBtnCloseInst.myPivot = { 0.5f, 0.5f };
    myBtnRevertInst.myPivot = { 0.5f, 0.5f };
    mySliderTrackInst.myPivot = { 0.5f, 0.5f };
    mySliderKnobInst.myPivot = { 0.5f, 0.5f };

    auto mkLbl = [](const char* s)
        {
            Tga::Text t("Text/arial.ttf", Tga::FontSize_24, 1);
            t.SetText(s);
            t.SetColor({ 1,1,1,0.95f });
            return t;
        };

    auto mkVal = []()
        {
            Tga::Text t("Text/arial.ttf", Tga::FontSize_24, 1);
            t.SetColor({ 1.f, 0.9f, 0.25f, 1.f });
            return t;
        };

    myTitle = mkLbl("Stance Bar");
    myLblOrientation = mkLbl("Orientation");
    myLblSize = mkLbl("Icon Size");
    myLblPadding = mkLbl("Icon Padding");

    myValOrientation = mkVal();
    myValSize = mkVal();
    myValPadding = mkVal();

    myCloseText = mkLbl("X");
    myRevertText = mkLbl("Revert");
}

void StanceBarEditPopup::OpenNearBar(StanceBar& bar)
{
    myOpen = true;
    myTarget = &bar;
    myOriginal = bar.GetLayout();
    myEdit = myOriginal;

    const Tga::Vector2f mn = bar.GetBoundsMin();
    const Tga::Vector2f mx = bar.GetBoundsMax();
    const Tga::Vector2f center = (mn + mx) * 0.5f;

    myPanelCenter = { center.x + 260.f, center.y };

    myBgInst.myPosition = myPanelCenter;
    myBgInst.mySize = myPanelSize;
    myBgInst.myIsHidden = false;

    LayoutUI();
    ApplyToTarget();
}

void StanceBarEditPopup::Close()
{
    myOpen = false;
    myTarget = nullptr;
    myDragging = DragTarget::None;
    myBgInst.myIsHidden = true;
}

void StanceBarEditPopup::LayoutUI()
{
    const float W = myPanelSize.x;
    const float H = myPanelSize.y;

    const float left = myPanelCenter.x - W * 0.5f;
    const float right = myPanelCenter.x + W * 0.5f;
    const float top = myPanelCenter.y + H * 0.5f;
    const float bottom = myPanelCenter.y - H * 0.5f;

    myTitleBarC = { myPanelCenter.x, top - 28.f };
    myTitleBarS = { W - 120.f, 44.f };

    const float padL = 40.f;
    const float padR = 40.f;
    const float padT = 40.f;
    const float padB = 40.f;

    const float innerL = left + padL;
    const float innerR = right - padR;
    const float innerT = top - padT;
    const float innerB = bottom + padB;

    const float rowH = 56.f;

    myTitle.SetPosition({ innerL, innerT });

    const float labelW = 180.f;
    const float gap = 16.f;
    const float labelX = innerL;
    const float sliderL = labelX + labelW + gap;
    const float sliderR = innerR - 20.f;
    const float sliderW = std::max(160.f, sliderR - sliderL);

    float y = innerT - 60.f;

    myLblOrientation.SetPosition({ labelX, y });
    myOrientationDropC = { sliderL + sliderW * 0.5f, y + 12.f };
    myOrientationDropS = { sliderW, 40.f };
    y -= rowH;

    myLblSize.SetPosition({ labelX, y });
    mySizeSliderC = { sliderL + sliderW * 0.5f, y + 12.f };
    mySizeSliderS = { sliderW, 24.f };
    y -= rowH;

    myLblPadding.SetPosition({ labelX, y });
    myPaddingSliderC = { sliderL + sliderW * 0.5f, y + 12.f };
    myPaddingSliderS = { sliderW, 24.f };

    myRevertC = { myPanelCenter.x, innerB };
    myCloseC = { right - 35.f, top - 35.f };

    myBtnRevertInst.myPosition = myRevertC;
    myBtnRevertInst.mySize = myRevertS;

    myBtnCloseInst.myPosition = myCloseC;
    myBtnCloseInst.mySize = myCloseS;

    myRevertText.SetPosition({ myRevertC.x - 40.f, myRevertC.y - 12.f });
    myCloseText.SetPosition({ myCloseC.x - 8.f, myCloseC.y - 12.f });
}

void StanceBarEditPopup::ApplyToTarget()
{
    if (!myTarget) return;

    myEdit.iconSize = std::max(24.f, myEdit.iconSize);
    myEdit.padding = std::max(0.f, myEdit.padding);

    myTarget->SetLayout(myEdit);

    const bool isHorizontal = (myEdit.orientation == StanceBarOrientation::Horizontal);

    myValOrientation.SetText(isHorizontal ? "Horizontal" : "Vertical");
    myValSize.SetText((std::to_string((int)std::round(myEdit.iconSize)) + "px").c_str());
    myValPadding.SetText(std::to_string((int)std::round(myEdit.padding)).c_str());

    myValOrientation.SetPosition({ myOrientationDropC.x - 45.f, myLblOrientation.GetPosition().y });
    myValSize.SetPosition({ mySizeSliderC.x + mySizeSliderS.x * 0.5f + 12.f, myLblSize.GetPosition().y });
    myValPadding.SetPosition({ myPaddingSliderC.x + myPaddingSliderS.x * 0.5f + 12.f, myLblPadding.GetPosition().y });
}

void StanceBarEditPopup::RevertToOriginal()
{
    myEdit = myOriginal;
    ApplyToTarget();
}

bool StanceBarEditPopup::Update(Tga::InputManager* im, const Tga::Vector2f& mouseWorld)
{
    if (!myOpen || !im) return false;

    if (im->IsKeyPressed(VK_ESCAPE))
    {
        Close();
        return true;
    }

    const bool lmbDown = im->IsKeyHeld(VK_LBUTTON);
    const bool lmbPressed = im->IsKeyPressed(VK_LBUTTON);
    const bool lmbReleased = im->IsKeyReleased(VK_LBUTTON);

    if (lmbPressed)
    {
        if (!PointInRectCenterSize(mouseWorld, myPanelCenter, myPanelSize))
        {
            Close();
            return true;
        }

        if (PointInRectCenterSize(mouseWorld, myCloseC, myCloseS))
        {
            Close();
            return true;
        }

        if (PointInRectCenterSize(mouseWorld, myRevertC, myRevertS))
        {
            RevertToOriginal();
            return true;
        }

        if (PointInRectCenterSize(mouseWorld, myTitleBarC, myTitleBarS))
        {
            myDraggingPanel = true;
            myPanelDragGrabOffset = mouseWorld - myPanelCenter;
            return true;
        }

        if (PointInRectCenterSize(mouseWorld, myOrientationDropC, myOrientationDropS))
        {
            myEdit.orientation =
                (myEdit.orientation == StanceBarOrientation::Horizontal)
                ? StanceBarOrientation::Vertical
                : StanceBarOrientation::Horizontal;

            ApplyToTarget();
            return true;
        }

        if (PointInRectCenterSize(mouseWorld, mySizeSliderC, mySizeSliderS))
            myDragging = DragTarget::Size;
        else if (PointInRectCenterSize(mouseWorld, myPaddingSliderC, myPaddingSliderS))
            myDragging = DragTarget::Padding;
    }

    if (lmbReleased)
    {
        myDragging = DragTarget::None;
        myDraggingPanel = false;
    }

    if (lmbDown && myDraggingPanel)
    {
        myPanelCenter = mouseWorld - myPanelDragGrabOffset;
        myBgInst.myPosition = myPanelCenter;

        LayoutUI();
        ApplyToTarget();
        return true;
    }

    if (lmbDown && myDragging != DragTarget::None)
    {
        if (myDragging == DragTarget::Size)
        {
            const float t = SliderValue01(mouseWorld, mySizeSliderC, mySizeSliderS);
            myEdit.iconSize = 40.f + t * 120.f;
        }
        else if (myDragging == DragTarget::Padding)
        {
            const float t = SliderValue01(mouseWorld, myPaddingSliderC, myPaddingSliderS);
            myEdit.padding = std::round(t * 24.f);
        }

        ApplyToTarget();
        return true;
    }

    return true;
}

void StanceBarEditPopup::DrawSlider(Tga::SpriteDrawer& drawer, const Tga::Vector2f& c, const Tga::Vector2f& s, float t01)
{
    t01 = Clamp01(t01);

    mySliderTrackInst.myPosition = c;
    mySliderTrackInst.mySize = s;
    mySliderTrackInst.myColor = { 1,1,1,1 };
    mySliderTrackInst.myIsHidden = false;
    drawer.Draw(mySliderTrackShared, mySliderTrackInst);

    const float left = c.x - s.x * 0.5f;
    const float x = left + s.x * t01;

    mySliderKnobInst.myPosition = { x, c.y };
    mySliderKnobInst.mySize = { 22.f, 22.f };
    mySliderKnobInst.myColor = { 1,1,1,1 };
    mySliderKnobInst.myIsHidden = false;
    drawer.Draw(mySliderKnobShared, mySliderKnobInst);
}

void StanceBarEditPopup::Render(Tga::SpriteDrawer& drawer)
{
    if (!myOpen) return;

    drawer.Draw(myBgShared, myBgInst);

    Tga::Sprite2DInstanceData dropInst{};
    dropInst.myPosition = myOrientationDropC;
    dropInst.mySize = myOrientationDropS;
    dropInst.myPivot = { 0.5f, 0.5f };
    dropInst.myColor = { 0.15f, 0.15f, 0.15f, 0.95f };
    drawer.Draw(myBtnShared, dropInst);

    drawer.Draw(myBtnShared, myBtnCloseInst);
    drawer.Draw(myBtnShared, myBtnRevertInst);

    const float tSize = (myEdit.iconSize - 40.f) / 120.f;
    const float tPad = myEdit.padding / 24.f;

    DrawSlider(drawer, mySizeSliderC, mySizeSliderS, tSize);
    DrawSlider(drawer, myPaddingSliderC, myPaddingSliderS, tPad);

    myTitle.Render();
    myLblOrientation.Render();
    myLblSize.Render();
    myLblPadding.Render();

    myValOrientation.Render();
    myValSize.Render();
    myValPadding.Render();

    myCloseText.Render();
    myRevertText.Render();
}