﻿#pragma once
#include <unordered_map>
#include <string>
#include <memory>

#include <tge/sprite/Sprite.h>
#include <tge/text/text.h>

namespace Tga { class InputManager; class SpriteDrawer; class Camera; }
class ActionBarSlotButton;
class MenuScene;
class Button; // ✅ forward declare YOUR Button

class ActionBarKeybinds
{
public:
    void Clear();

    void Bind(ActionBarSlotButton* slot, int vk);
    void Unbind(ActionBarSlotButton* slot);
    ActionBarSlotButton* GetSlotForKey(int vk) const;

    void InitPopup(MenuScene& scene, const std::shared_ptr<Tga::Camera>& uiCam);
    void OpenPopup(ActionBarSlotButton* slot);
    void ClosePopup();
    bool IsPopupOpen() const { return myPopup.open; }

    bool UpdatePopup(Tga::InputManager* im, const Tga::Vector2f& mouseWorld);
    void RenderPopup(Tga::SpriteDrawer& drawer);

    static std::string VkToPrettyLabel(int vk);

private:
    static int DetectPressedVkThisFrame(Tga::InputManager* im);

private:
    std::unordered_map<int, ActionBarSlotButton*> myKeyToSlot;
    std::unordered_map<ActionBarSlotButton*, int> mySlotToKey;

    struct KeybindPopup
    {
        bool open = false;

        ActionBarSlotButton* targetSlot = nullptr;

        bool hasPending = false;
        int  pendingVk = 0;

        Tga::SpriteSharedData bgShared{};
        Tga::Sprite2DInstanceData bgInst{};

        Tga::Text title;
        Tga::Text currentBind;

        // --- Save/Cancel clickable rects (center + size) ---
        Tga::Vector2f savePos{};
        Tga::Vector2f saveSize{ 160.f, 60.f };

        Tga::Vector2f cancelPos{};
        Tga::Vector2f cancelSize{ 160.f, 60.f };

        // visual buttons (simple flat)
        Tga::SpriteSharedData btnShared{};
        Tga::Sprite2DInstanceData saveInst{};
        Tga::Sprite2DInstanceData cancelInst{};

        // labels
        Tga::Text saveText;
        Tga::Text cancelText;

        Tga::Color saveEnabledColor{};
        Tga::Color saveDisabledColor{};
    };

    KeybindPopup myPopup;
};
