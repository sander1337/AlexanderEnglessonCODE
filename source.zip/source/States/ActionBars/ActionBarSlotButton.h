﻿// ActionBarSlotButton.h
#pragma once
#include "ActionBarSpell.h"
#include "../../UI/Button.h"
#include "../../Input/InputMapper.h"
#include <tge/sprite/Sprite.h>
#include <functional>
#include "tge/input/InputManager.h"

static bool IsShiftDown()
{
    auto* im = InputMapper::GetInstance().GetInputManager();
    if (!im) return false;

    return im->IsKeyHeld(VK_SHIFT) || im->IsKeyHeld(VK_LSHIFT) || im->IsKeyHeld(VK_RSHIFT);
}

class ActionBar;

class ActionBarSlotButton : public Button
{
public:
    void SetOwner(ActionBar* owner, int index);

    void SetSpell(const ActionBarSpell& s) { mySpell = s; ApplyVisualsFromSpell(); }
    const ActionBarSpell& GetSpell() const { return mySpell; }
    bool IsEmpty() const { return mySpell.id == 0; }

    void SetGhosted(bool on) { myGhosted = on; ApplyGhostAlpha(); }

    // --- Slot background API ---
    void SetSlotBackground(const char* texturePath);
    void SyncBackgroundToButton();

    // --- Icon overlay API ---
    void SetIconSize(float px);
    void SyncIconToButton();
    bool HasIcon() const { return !myIconInst.myIsHidden && myIconShared.myTexture != nullptr; }

    void Render() override;
    void Update(float aDeltaTime) override;   // ✅ lägg till

    void TriggerPressFeedback(float duration = 0.3f);

    void SetKeybindText(const std::string& s);
    void SyncKeybindToButton();

    void SetCustomLeftClickCallback(const std::function<void()>& fn) { myCustomLeftClick = fn; }
    void SetManualTint(const Tga::Color& color) { myManualTint = color; myUseManualTint = true; }
    void ClearManualTint() { myUseManualTint = false; }

    //SHADER STUFF COOLDOWN
    void StartCooldown(float duration);
    void StopCooldown();
    void UpdateCooldown(float dt);

    bool IsOnCooldown() const { return myShowCooldown && myCooldownRemaining > 0.f; }
    float GetCooldownDuration() const { return myCooldownDuration; }
    float GetCooldownRemaining() const { return myCooldownRemaining; }
    float GetCooldownNormalized() const;
    void SyncCooldownToButton();
    void EnsureCooldownShader();
protected:
    void OnLeftClick() override;
    void OnRightClick() override;
    bool OnHoverEnter() override;
    void OnHoverExit() override;

private:
    void ApplyVisualsFromSpell();
    void ApplyGhostAlpha();
    void InitBindTextOnce();
private:

    std::function<void()> myCustomLeftClick;
    bool myUseManualTint = false;
    Tga::Color myManualTint{ 1.f, 1.f, 1.f, 1.f };


    ActionBar* myOwner = nullptr;
    int myIndex = -1;

    ActionBarSpell mySpell{};
    bool myGhosted = false;

    // Background sprite (slot frame)
    Tga::SpriteSharedData myBgShared{};
    Tga::Sprite2DInstanceData myBgInst{};

    // Icon overlay sprite (spell icon)
    Tga::SpriteSharedData myIconShared{};
    Tga::Sprite2DInstanceData myIconInst{};
    bool myHoverGlow = false;
    float myHoverGlowT = 0.f;

    bool myBindInit = false;
    Tga::Text myBindText;
    std::string myBindStr;
    Tga::Vector2f myBindOffset{ -0.40f, 0.40f };

    float myPressFlashDuration = 0.f;
    float myPressFlashRemaining = 0.f;

    //SHADER STUFF COOLDOWN
    float myCooldownDuration = 0.f;
    float myCooldownRemaining = 0.f;
    bool myShowCooldown = false;
    Tga::SpriteSharedData myCooldownShared{};
    Tga::Sprite2DInstanceData myCooldownInst{};
};
