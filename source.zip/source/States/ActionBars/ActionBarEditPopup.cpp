﻿// ActionBarEditPopup.cpp
#include "ActionBarEditPopup.h"

#include <algorithm>
#include <cmath>

#include <tge/engine.h>
#include <tge/texture/TextureManager.h>
#include <tge/drawers/SpriteDrawer.h>
#include "../../SceneManagement/MenuScene.h"
#include "ActionBar.h"
#include "States/Hud/HudActionBarsController.h"
#include "Utilities/UITextUtils.h"
#include "../../Utilities/UIRectUtils.h"

static int ClampInt(int v, int lo, int hi) { return std::max(lo, std::min(v, hi)); }
static constexpr int kMaxRowsOrCols = 8;

bool ActionBarEditPopup::PointInRectCenterSize(const Tga::Vector2f& p, const Tga::Vector2f& c, const Tga::Vector2f& s) const
{
    const Tga::Vector2f h = { s.x * 0.5f, s.y * 0.5f };
    return (p.x >= c.x - h.x && p.x <= c.x + h.x &&
        p.y >= c.y - h.y && p.y <= c.y + h.y);
}

float ActionBarEditPopup::SliderValue01(const Tga::Vector2f& mouse, const Tga::Vector2f& center, const Tga::Vector2f& size) const
{
    const float left = center.x - size.x * 0.5f;
    const float t = (mouse.x - left) / size.x;
    return std::max(0.f, std::min(1.f, t));
}

void ActionBarEditPopup::Init(MenuScene& scene, const std::shared_ptr<Tga::Camera>& uiCam)
{
    myScene = &scene;
    myUiCam = uiCam;
    auto& tm = Tga::Engine::GetInstance()->GetTextureManager();

    myBgShared.myTexture = tm.GetTexture("assets/ui/textures/spellbook_panel.png"); // reuse your panel
    myBgShared.blendState = Tga::BlendState::AlphaBlend;
    myBgShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    myBgInst.myPivot = { 0.5f, 0.5f };
    myBgInst.myColor = { 1.f, 1.f, 1.f, 0.96f };
    myBgInst.myIsHidden = true;

    myBtnShared.myTexture = tm.GetTexture("assets/ui/textures/spellbook_panel.png");
    myBtnShared.blendState = Tga::BlendState::AlphaBlend;
    myBtnShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    myBtnRevertInst.myPivot = { 0.5f, 0.5f };
    myBtnCloseInst.myPivot = { 0.5f, 0.5f };

    mySliderTrackShared.myTexture = tm.GetTexture("assets/ui/textures/Slider_background.png");
    mySliderTrackShared.blendState = Tga::BlendState::AlphaBlend;
    mySliderTrackShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    mySliderKnobShared.myTexture = tm.GetTexture("assets/ui/textures/Slider_button.png");
    mySliderKnobShared.blendState = Tga::BlendState::AlphaBlend;
    mySliderKnobShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    myCheckboxCheckedShared.myTexture =tm.GetTexture("assets/ui/textures/T_UI_Checkbox_checked.dds");
    myCheckboxCheckedShared.blendState = Tga::BlendState::AlphaBlend;
    myCheckboxCheckedShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    myCheckboxOpenShared.myTexture = tm.GetTexture("assets/ui/textures/T_UI_Checkbox_open.dds");
    myCheckboxOpenShared.blendState = Tga::BlendState::AlphaBlend;
    myCheckboxOpenShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    myCheckboxInst.myPivot = { 0.5f, 0.5f };


    // pivots (knoppen och tracken ska centreras)
    mySliderTrackInst.myPivot = { 0.5f, 0.5f };
    mySliderKnobInst.myPivot = { 0.5f, 0.5f };

    myTitle = Tga::Text("Text/arial.ttf", Tga::FontSize_24, 1);

    auto mkLbl = [](const char* s) {
        Tga::Text t("Text/arial.ttf", Tga::FontSize_24, 1);
        t.SetText(s);
        t.SetColor({ 1,1,1,0.95f });
        return t;
        };
    myLblOrientation = mkLbl("Orientation");
    myLblRows = mkLbl("# of Rows");
    myLblIcons = mkLbl("# of Icons");
    myLblSize = mkLbl("Icon Size");
    myLblPadding = mkLbl("Icon Padding");
    myLblAlwaysShow = mkLbl("Always Show Buttons");

    auto mkVal = []() {
        Tga::Text t("Text/arial.ttf", Tga::FontSize_24, 1);
        t.SetColor({ 1, 0.9f, 0.25f, 1 }); // warm yellow like WoW-ish
        return t;
        };
    myValOrientation = mkVal();
    myValRows = mkVal();
    myValIcons = mkVal();
    myValSize = mkVal();
    myValPadding = mkVal();

    myRevertText = mkLbl("Revert Changes");
    myCloseText = mkLbl("X");
}

void ActionBarEditPopup::Open(ActionBar& bar)
{
    myOpen = true;
    myTarget = &bar;

    myOriginal = bar.GetLayout();
    myEdit = myOriginal;

    auto res = Tga::Engine::GetInstance()->GetRenderSize();
    myPanelCenter = { res.x * 0.5f, res.y * 0.5f };
    myPanelCenter.x -= 100.f; // tweak

    myBgInst.myPosition = myPanelCenter;
    myBgInst.mySize = myPanelSize;
    myBgInst.myIsHidden = false;

    LayoutUI();
    ApplyToTarget(); // make sure labels updated
}

void ActionBarEditPopup::Close()
{
    myOpen = false;
    myTarget = nullptr;
    myDragging = DragTarget::None;
    myBgInst.myIsHidden = true;
}

void ActionBarEditPopup::LayoutUI()
{
    const float W = myPanelSize.x;
    const float H = myPanelSize.y;

    const float left = myPanelCenter.x - W * 0.5f;
    const float right = myPanelCenter.x + W * 0.5f;
    const float top = myPanelCenter.y + H * 0.5f;
    const float bottom = myPanelCenter.y - H * 0.5f;

    // ✅ Inner padding så allt hamnar INUTI bakgrunden
    const float padL = 40.f;
    const float padR = 40.f;
    const float padT = 40.f;
    const float padB = 40.f;

    const float innerL = left + padL;
    const float innerR = right - padR;
    const float innerT = top - padT;
    const float innerB = bottom + padB;

    const float rowH = 56.f;

    // Title
    myTitle.SetText(("Action Bar " + std::to_string(myTarget ? myTarget->GetBarId() : 0)).c_str());
    myTitle.SetPosition({ innerL, innerT });

    // ✅ Lägg label+slider+value inom innerL..innerR
    const float labelW = 210.f;             // bredd för label-kolumn
    const float valueW = 120.f;             // bredd för value-kolumn (höger)
    const float gap = 16.f;

    const float labelX = innerL;
    const float valueX = innerR - valueW;  // högerkolumn
    const float sliderL = labelX + labelW + gap;
    const float sliderR = valueX - gap;
    const float sliderW = std::max(120.f, sliderR - sliderL);

    float y = innerT - 60.f; // starta under title

    myLblOrientation.SetPosition({ labelX, y });
    myOrientationDropC = { sliderL + sliderW * 0.5f, y + 12.f };
    myOrientationDropS = { sliderW, 40.f };
    y -= rowH;

    myLblRows.SetPosition({ labelX, y });
    myRowsSlider.c = { sliderL + sliderW * 0.5f, y + 12.f };
    myRowsSlider.s = { sliderW, 24.f };
    y -= rowH;

    myLblIcons.SetPosition({ labelX, y });
    myIconsSlider.c = { sliderL + sliderW * 0.5f, y + 12.f };
    myIconsSlider.s = { sliderW, 24.f };
    y -= rowH;

    myLblSize.SetPosition({ labelX, y });
    mySizeSlider.c = { sliderL + sliderW * 0.5f, y + 12.f };
    mySizeSlider.s = { sliderW, 24.f };
    y -= rowH;

    myLblPadding.SetPosition({ labelX, y });
    myPaddingSlider.c = { sliderL + sliderW * 0.5f, y + 12.f };
    myPaddingSlider.s = { sliderW, 24.f };
    y -= rowH;

    myLblAlwaysShow.SetPosition({ labelX, y });
    myAlwaysCheckC = { innerR - 275.f, y + 10.f };
    myCheckboxInst.myPosition = myAlwaysCheckC;
    myCheckboxInst.mySize = myAlwaysCheckS;

    // buttons bottom
    myRevertC = { myPanelCenter.x, innerB };
    myCloseC = { right - 35.f, top - 35.f };

    myBtnRevertInst.myPosition = myRevertC;
    myBtnRevertInst.mySize = myRevertS;

    myBtnCloseInst.myPosition = myCloseC;
    myBtnCloseInst.mySize = myCloseS;

    UI::SetTextCenteredXYApprox(myRevertText,myRevertC,24.f );
	myCloseText.SetPosition({ myCloseC.x - 8.f, myCloseC.y - 12.f });

    // ✅ Spara valueX så ApplyToTarget kan använda samma
    // (lättast: gör valueX till member: myValueX)
    myValueX = valueX;

    myTitleBarC = { myPanelCenter.x, myPanelCenter.y + myPanelSize.y * 0.5f - 35.f };
    myTitleBarS = { myPanelSize.x - 80.f, 70.f };
}

void ActionBarEditPopup::ApplyToTarget()
{
    if (!myTarget) return;

    // Clamp values hard (you can refine rules later)
    myEdit.rows = ClampInt(myEdit.rows, 1, kMaxRowsOrCols);
    myEdit.columns = ClampInt(myEdit.columns, 1, kMaxRowsOrCols);
    myEdit.padding = std::max(0.f, myEdit.padding);
    myEdit.iconSize = std::max(16.f, myEdit.iconSize);
    myEdit.visibleSlots = ClampInt(myEdit.visibleSlots, 1, 12);

    myEdit.autoColumns = (myEdit.orientation == ActionBarOrientation::Horizontal);
    myTarget->SetLayout(myEdit);

    // Update value labels
    // Orientation: if you add enum later, just flip text for now using columns/rows rule.
    const bool isHorizontal = (myEdit.orientation == ActionBarOrientation::Horizontal);

    myValOrientation.SetText(isHorizontal ? "Horizontal" : "Vertical");

    // Labeln ska bytas
    myLblRows.SetText(isHorizontal ? "# of Rows" : "# of Columns");

    // Värdet du visar vid den raden ska vara rows eller columns
    if (isHorizontal)
        myValRows.SetText(std::to_string(myEdit.rows).c_str());
    else
        myValRows.SetText(std::to_string(myEdit.columns).c_str());

    myValSize.SetText((std::to_string((int)std::round(myEdit.iconSize)) + "px").c_str());
    myValPadding.SetText(std::to_string((int)std::round(myEdit.padding)).c_str());
    myValIcons.SetText(std::to_string(myEdit.visibleSlots).c_str());

    // Place value texts on right side of controls
    const float valueX = myValueX;
    UI::SetTextCenteredXYApprox(myValOrientation,myOrientationDropC,24.f);
	myValRows.SetPosition({ valueX, myLblRows.GetPosition().y });
    myValIcons.SetPosition({ valueX, myLblIcons.GetPosition().y });
    myValSize.SetPosition({ valueX, myLblSize.GetPosition().y });
    myValPadding.SetPosition({ valueX, myLblPadding.GetPosition().y });
}

void ActionBarEditPopup::RevertToOriginal()
{
    myEdit = myOriginal;
    ApplyToTarget();
}

bool ActionBarEditPopup::Update(Tga::InputManager* im, const Tga::Vector2f& mouseWorld)
{
    if (!myOpen || !im) return false;

    // Close on ESC
    if (im->IsKeyPressed(VK_ESCAPE))
    {
        Close();
        return true;
    }

    const bool lmbDown = im->IsKeyHeld(VK_LBUTTON);
    const bool lmbPressed = im->IsKeyPressed(VK_LBUTTON);
    const bool lmbReleased = im->IsKeyReleased(VK_LBUTTON);


    if (lmbPressed)
    {
        // Klick utanför popup = save + close
        if (!IsPointInsidePopup(mouseWorld))
        {
            SaveAndClose();
            return true;
        }
    }

    // ==============================
   // PANEL DRAG (lägg här!)
   // ==============================

    if (lmbReleased)
        myDraggingPanel = false;

    if (lmbPressed)
    {
        const bool overPanel =
            PointInRectCenterSize(mouseWorld, myPanelCenter, myPanelSize);

        if (overPanel && !IsOverAnyControl(mouseWorld))
        {
            myDraggingPanel = true;
            myDragGrabOffset = mouseWorld - myPanelCenter;
            return true;
        }
    }

    if (lmbDown && myDraggingPanel && myDragging == DragTarget::None)
    {
        myPanelCenter = mouseWorld - myDragGrabOffset;
        myBgInst.myPosition = myPanelCenter;

        LayoutUI();
        ApplyToTarget();
        return true;
    }

    // Start dragging slider?
    if (lmbPressed)
    {
        if (PointInRectCenterSize(mouseWorld, myCloseC, myCloseS))
        {
            Close();
            return true;
        }

        if (PointInRectCenterSize(mouseWorld, myRevertC, myRevertS))
        {
            RevertToOriginal();
            return true;
        }

        // fake dropdown: click toggles orientation (you’ll add real enum later)
        if (PointInRectCenterSize(mouseWorld, myOrientationDropC, myOrientationDropS))
        {
            if (myEdit.orientation == ActionBarOrientation::Horizontal)
            {
                // -> Vertical
                myEdit.orientation = ActionBarOrientation::Vertical;

                // ✅ din önskan: när du swappar till vertical så ska columns vara 1
                myEdit.columns = 1;
                myEdit.rows = 1; // (kan hållas 1 för ren vertikal)
            }
            else
            {
                // -> Horizontal
                myEdit.orientation = ActionBarOrientation::Horizontal;

                // ✅ typisk default: 1 rad, 12 visibleSlots
                myEdit.rows = 1;
                // columns kommer räknas av autoColumns ändå
            }

            ApplyToTarget();
            return true;
        }

        if (PointInRectCenterSize(mouseWorld, myAlwaysCheckC, myAlwaysCheckS))
        {
            myEdit.alwaysShowButtons = !myEdit.alwaysShowButtons; // add field in layout
            ApplyToTarget();
            return true;
        }

        if (PointInRectCenterSize(mouseWorld, myRowsSlider.c, myRowsSlider.s))      myDragging = DragTarget::Rows;
        else if (PointInRectCenterSize(mouseWorld, myIconsSlider.c, myIconsSlider.s)) myDragging = DragTarget::Icons;
        else if (PointInRectCenterSize(mouseWorld, mySizeSlider.c, mySizeSlider.s))  myDragging = DragTarget::Size;
        else if (PointInRectCenterSize(mouseWorld, myPaddingSlider.c, myPaddingSlider.s)) myDragging = DragTarget::Padding;
    }

    if (lmbReleased)
        myDragging = DragTarget::None;

    // Drag update
    if (lmbDown && myDragging != DragTarget::None)
    {
        if (myDragging == DragTarget::Rows)
        {
            float t = SliderValue01(mouseWorld, myRowsSlider.c, myRowsSlider.s);

            const int v = 1 + (int)std::round(t * float(kMaxRowsOrCols - 1)); // ✅ 1..4

            if (myEdit.orientation == ActionBarOrientation::Horizontal)
                myEdit.rows = v;
            else
                myEdit.columns = v;
        }
        else if (myDragging == DragTarget::Icons)
        {
            float t = SliderValue01(mouseWorld, myIconsSlider.c, myIconsSlider.s);
            myEdit.visibleSlots = 1 + (int)std::round(t * 11.f);
        }
        else if (myDragging == DragTarget::Size)
        {
            float t = SliderValue01(mouseWorld, mySizeSlider.c, mySizeSlider.s);
            // map 50%..200% of a base (150)
            const float percent = 50.f + t * 150.f;
            myEdit.iconSize = 150.f * (percent / 100.f);
        }
        else if (myDragging == DragTarget::Padding)
        {
            float t = SliderValue01(mouseWorld, myPaddingSlider.c, myPaddingSlider.s);
            myEdit.padding = 1.f + std::round(t * 9.f);
        }

        ApplyToTarget();
        return true;
    }

    return true; // modal always while open
}

void ActionBarEditPopup::Render(Tga::SpriteDrawer& drawer)
{
    if (!myOpen) return;

    // panel
    drawer.Draw(myBgShared, myBgInst);

    // ✅ Orientation background (fake dropdown) - LÄGG HÄR
    {
        Tga::Sprite2DInstanceData dropInst{};
        dropInst.myPosition = myOrientationDropC;
        dropInst.mySize = myOrientationDropS;
        dropInst.myPivot = { 0.5f, 0.5f };
        dropInst.myColor = { 0.15f, 0.15f, 0.15f, 0.95f };

        drawer.Draw(myBtnShared, dropInst);
    }

    // Checkbox render
    myCheckboxInst.myPosition = myAlwaysCheckC;
    myCheckboxInst.mySize = myAlwaysCheckS;
    myCheckboxInst.myColor = { 1,1,1,1 };
    myCheckboxInst.myIsHidden = false;

    if (myEdit.alwaysShowButtons)
        drawer.Draw(myCheckboxCheckedShared, myCheckboxInst);
    else
        drawer.Draw(myCheckboxOpenShared, myCheckboxInst);

    // close + revert
    drawer.Draw(myBtnShared, myBtnCloseInst);
    drawer.Draw(myBtnShared, myBtnRevertInst);

    // labels + values
    myTitle.Render();
    myLblOrientation.Render(); myValOrientation.Render();
    myLblRows.Render();        myValRows.Render();
    myLblIcons.Render();       myValIcons.Render();
    myLblSize.Render();        myValSize.Render();
    myLblPadding.Render();     myValPadding.Render();
    myLblAlwaysShow.Render();

    myRevertText.Render();
    myCloseText.Render();

    // --- Slider visuals ---
    {
        const float denom = float(kMaxRowsOrCols - 1);

        const bool isHorizontal = (myEdit.orientation == ActionBarOrientation::Horizontal);

        const float tRows = (isHorizontal ? (myEdit.rows - 1) : (myEdit.columns - 1)) / denom;
    	
    	const float tIcons = (myEdit.visibleSlots - 1) / 11.f;

        // size: du mappar 50..200% av base 150
        const float percent = (myEdit.iconSize / 150.f) * 100.f;
        const float tSize = (percent - 50.f) / 150.f;

        const float tPad = (myEdit.padding - 1.f) / 9.f;

        // justera knob-storlek så den matchar din png
        const float knobW = 22.f;
        const float knobH = 22.f;

        // track-höjd kan vara större än 16 om din png är högre
        // (ui.s.y kommer från LayoutUI)
        DrawSlider(drawer, myRowsSlider, tRows, knobW, knobH);
        DrawSlider(drawer, myIconsSlider, tIcons, knobW, knobH);
        DrawSlider(drawer, mySizeSlider, tSize, knobW, knobH);
        DrawSlider(drawer, myPaddingSlider, tPad, knobW, knobH);
    }
    // (Optional) draw slider tracks/knobs later.
    // For now you can rely on text changing; then add visuals once logic works.
}

bool ActionBarEditPopup::IsOverAnyControl(const Tga::Vector2f& m) const
{
    // Close/revert
    if (PointInRectCenterSize(m, myCloseC, myCloseS)) return true;
    if (PointInRectCenterSize(m, myRevertC, myRevertS)) return true;

    // Dropdown / checkbox
    if (PointInRectCenterSize(m, myOrientationDropC, myOrientationDropS)) return true;
    if (PointInRectCenterSize(m, myAlwaysCheckC, myAlwaysCheckS)) return true;

    // Sliders
    if (PointInRectCenterSize(m, myRowsSlider.c, myRowsSlider.s)) return true;
    if (PointInRectCenterSize(m, myIconsSlider.c, myIconsSlider.s)) return true;
    if (PointInRectCenterSize(m, mySizeSlider.c, mySizeSlider.s)) return true;
    if (PointInRectCenterSize(m, myPaddingSlider.c, myPaddingSlider.s)) return true;

    return false;
}

void ActionBarEditPopup::DrawSlider(Tga::SpriteDrawer& drawer,const SliderUI& ui,float t01,float knobW,float knobH)
{
    t01 = Clamp01(t01);

    // Track
    mySliderTrackInst.myPosition = ui.c;
    mySliderTrackInst.mySize = { ui.s.x, ui.s.y };
    mySliderTrackInst.myColor = { 1,1,1,1 }; // använd texturens färg
    mySliderTrackInst.myIsHidden = false;
    drawer.Draw(mySliderTrackShared, mySliderTrackInst);

    // Knob position: vänster..höger på tracken
    const float left = ui.c.x - ui.s.x * 0.5f;
    const float x = left + ui.s.x * t01;

    mySliderKnobInst.myPosition = { x, ui.c.y };
    mySliderKnobInst.mySize = { knobW, knobH };
    mySliderKnobInst.myColor = { 1,1,1,1 };
    mySliderKnobInst.myIsHidden = false;
    drawer.Draw(mySliderKnobShared, mySliderKnobInst);
}


// ActionBar rect (center + size)
static void GetBarCenterSize(const ActionBar& bar, Tga::Vector2f& outC, Tga::Vector2f& outS)
{
    const Tga::Vector2f mn = bar.GetBoundsMin();
    const Tga::Vector2f mx = bar.GetBoundsMax();

    outC = (mn + mx) * 0.5f;
    outS = (mx - mn);
}

void ActionBarEditPopup::OpenNearBar(ActionBar& bar)
{
    myOpen = true;
    myTarget = &bar;
    myOriginal = bar.GetLayout();
    myEdit = myOriginal;

    Tga::Vector2f barC{}, barS{};
    GetBarCenterSize(bar, barC, barS);

    const float panelW = myPanelSize.x;
    const float panelH = myPanelSize.y;

    myPanelCenter = FindPopupCenter(barC, panelW, panelH);

    myBgInst.myPosition = myPanelCenter;
    myBgInst.mySize = myPanelSize;
    myBgInst.myIsHidden = false;

    LayoutUI();
    ApplyToTarget();
}

void ActionBarEditPopup::SaveAndClose()
{
    // ApplyToTarget() har redan pushat layout löpande,
    // men vi kan säkerställa en sista gång:
    ApplyToTarget();
    Close();
}

bool ActionBarEditPopup::IsPointInsidePopup(const Tga::Vector2f& p) const
{
    return PointInRectCenterSize(p, myPanelCenter, myPanelSize);
}

Tga::Vector2f ActionBarEditPopup::ClampPopupToScreen(Tga::Vector2f c, float panelW, float panelH) const
{
    if (!myUiCam) return c;

    const auto resI = Tga::Engine::GetInstance()->GetRenderSize();
    const Tga::Vector2f res{ (float)resI.x, (float)resI.y };

    const Tga::Vector2f worldBL = myUiCam->GetScreenToWorldCoordinatesVec2({ 0.f, 0.f });
    const Tga::Vector2f worldTR = myUiCam->GetScreenToWorldCoordinatesVec2({ res.x, res.y });

    const float halfW = panelW * 0.5f;
    const float halfH = panelH * 0.5f;

    c.x = std::max(worldBL.x + halfW, std::min(c.x, worldTR.x - halfW));
    c.y = std::max(worldBL.y + halfH, std::min(c.y, worldTR.y - halfH));
    return c;
}


Tga::Vector2f ActionBarEditPopup::FindPopupCenter(const Tga::Vector2f& anchor, float panelW, float panelH) const
{
    const float halfW = panelW * 0.5f;
    const float halfH = panelH * 0.5f;
    const float gap = 100.f;

    // Kandidater runt ankaret (ingen avoid/nudge)
    std::vector<Tga::Vector2f> candidates;
    candidates.push_back({ anchor.x, anchor.y + halfH + gap }); // above
    candidates.push_back({ anchor.x, anchor.y - halfH - gap }); // below
    candidates.push_back({ anchor.x + halfW + gap, anchor.y }); // right
    candidates.push_back({ anchor.x - halfW - gap, anchor.y }); // left

    // välj den som kräver minst clamp (dvs “mest onscreen”)
    Tga::Vector2f best = ClampPopupToScreen(candidates[0], panelW, panelH);
    float bestScore = 1e30f;

    for (auto c : candidates)
    {
        const Tga::Vector2f clamped = ClampPopupToScreen(c, panelW, panelH);
        const Tga::Vector2f d = clamped - c;         // hur mycket clamp flyttade den
        const float score = d.x * d.x + d.y * d.y;       // minst clamp = bäst

        if (score < bestScore)
        {
            bestScore = score;
            best = clamped;
        }
    }

    return best;
}
