﻿// ActionBarSpell.h
#pragma once
#include <string>
#include <cstdint>

enum class SpellSchool : uint8_t
{
    Arcane,
    Fire,
    Frost,
    Nature,
    Holy,
    Shadow,
    Physical
};

struct ActionBarSpell
{
    uint32_t id = 0;
    std::string name;
    std::string iconTexturePath;

    // Tooltip
    std::string rank;
    SpellSchool school = SpellSchool::Arcane;

    int manaCost = 0;
    float castTime = 0.f;    
    float cooldown = 0.f;
    int rangeYards = 0;

    // --- DAMAGE ---
    int damageMin = 0;     
    int damageMax = 0;

    float spellPowerScaling = 0.f; 

    int dotTotalDamage = 0;     
    float dotDuration = 0.f;    

    std::string description;
};