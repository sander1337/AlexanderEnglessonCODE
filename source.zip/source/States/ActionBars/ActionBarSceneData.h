// ActionBarSceneData.h
#pragma once

struct ActionBarData
{
    int barId = 0;
    int slotCount = 12;

    int columns = 12;
    int rows = 2;

    float iconSize = 200.f;
    float padding = 0.f;

    bool snapToGrid = false;
    float gridSize = 50.f;

    bool visible = true;
};