#include "stdafx.h"
#include "State.h"
#include "../source/SceneManagement/SceneID.h"
#include "../SceneManagement/RunTimeScene.h"


State::State(StateStack& aStateStack, const std::shared_ptr<SceneManager>& aSceneManager, const std::shared_ptr<RenderManager>& aRenderManager, const bool aLetThroughRender)
    :myStateStack(aStateStack),
    mySceneManager(aSceneManager),
    myRenderManager(aRenderManager),
    myCurrentSceneID(SceneID::Count),
    myLetThroughRender(aLetThroughRender)
{}

bool State::LetsThroughRender() const
{
    return myLetThroughRender;
}

bool State::LetsThroughUpdate() const
{
    return myLetThroughUpdate;
}

std::weak_ptr<RunTimeScene> State::GetScene() const
{
    return myScene;
}

const std::shared_ptr<Tga::Camera> State::GetActiveCamera() const
{
    if (myScene)
    {
        return myScene->GetActiveCamera();
    }

    return nullptr;
}

void State::SetPendingScene(SceneID aSceneID)
{
    myPendingSceneID = aSceneID;
}
