﻿#pragma once
#include "Menu.h"

class GameSprite;

class Cutscene : public Menu
{
public:
    Cutscene(StateStack& aStateStack, const std::shared_ptr<SceneManager>& aSceneManager, const std::shared_ptr<RenderManager>& aRenderManager, const bool aLetThroughRender = false);
    ~Cutscene() override = default;

    void OnEnter() override;

    void Update(float aDeltaTime) override;

    StateID GetID() override;
protected:
    void FadeIn(float aDeltaTime);
    void FadeOut(float aDeltaTime);

    float myCountDown = 3.f;
    float myCountdownMax = 3.f;
    float myCountdownCurrent = 0.f;

    float myFadeCount = 0.f;
    float myFadeTime = 0.5f;
    float myFadePerSecond = 2.f;

    bool myIsReadyToFinish = false;

    std::vector<GameSprite*> mySprites;
};