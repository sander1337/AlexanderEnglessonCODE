#include "stdafx.h"
#include "InGame.h"

#include "StateStack.h"
#include "../Render/RenderManager.h"
#include "../SceneManagement/SceneManager.h"
#include "../source/Utilities/PollingStation.h"

#include "../source/Audio/AudioManager.h"
#include "../source/SceneManagement/SceneID.h"
#include "../source/SceneManagement/GameScene.h"
#include "../Utilities/ConstantIdentifiers.h"
#include "Utilities/BlackBoard.h"
#include "../source/Objects/Actors/Player/Player.h"
#include <tge/input/InputManager.h>
#include <tge/script/ScriptManager.h>
#include <tge/script/Contexts/ScriptUpdateContext.h>

#include "GameWorld.h"


InGame::InGame(StateStack& aStateStack, const std::shared_ptr<SceneManager>& aSceneManager, const std::shared_ptr<RenderManager>& aRenderManager, const bool aLetThroughRender) :
	State(aStateStack, aSceneManager, aRenderManager, aLetThroughRender)
{}

void InGame::OnEnter()
{
	InputMapper::GetInstance().GetInputManager()->CaptureMouse();
	Tga::Engine::GetInstance()->ShowCustomCursor(false);

	if (myCurrentSceneID != myPendingSceneID)
	{
		if (!mySceneManager->IsLoaded(myPendingSceneID))
		{
			mySceneManager->LoadScene(myPendingSceneID);
		}

		myScene = std::dynamic_pointer_cast<RunTimeScene>(mySceneManager->GetScene(myPendingSceneID));
		myCurrentSceneID = myPendingSceneID;

	}

	myScene->OnEnter(*mySceneManager, myStateStack);

	// Events
	EventManager::GetInstance()->Subscribe(Event::GameOver, this);
	EventManager::GetInstance()->Subscribe(Event::PlayCutscene, this);

	if (myCurrentSceneID == SceneID::Level1 || myCurrentSceneID == SceneID::Level2)
	{
		EventManager::GetInstance()->Subscribe(Event::SwitchLevel, this);
	}

	RegisterInput();

	// Audio
	AudioManager::GetInstance()->PlaySceneAudio(myCurrentSceneID);
}

void InGame::OnExit()
{
	Tga::Engine::GetInstance()->ShowCustomCursor(true);

	GameScene* gameScene = &*std::dynamic_pointer_cast<GameScene>(myScene);
	gameScene->GetHUD()->UnsubscribeFromEvents();
	UnregisterInput();
	myScene->OnExit();

	// Events
	EventManager::GetInstance()->UnSubscribe(Event::GameOver, this);
	EventManager::GetInstance()->UnSubscribe(Event::PlayCutscene, this);
}

void InGame::Update(float aDeltaTime)
{
	if (gameOver)
	{
		auto currentSceneWeak = GameWorld::GetInstance().GetCurrentScene();
		std::shared_ptr<RunTimeScene> baseScene = currentSceneWeak.lock();
		std::shared_ptr<GameScene> gameScene = std::dynamic_pointer_cast<GameScene>(baseScene);

		if (gameScene)
		{
			std::shared_ptr<Player> player = gameScene->GetPlayer().lock();

			player->ResetPlayer(AI::PollingStation3D::Get().GetCurrentSceneID());
		}

		// TODO :: reset all enemies

		//ForceSwitchLevel(myCurrentSceneID);
		//myStateStack.Pop();
		//myStateStack.Push(StateID::InGame, SceneID::Count);

		gameOver = false;
	}

	else
	{
		static int frame = 0;
		Tga::ScriptUpdateContext context{};
		context.deltaTime = aDeltaTime;
		context.frame = frame;
		Tga::ScriptManager::GetInstance()->Update(context);

		myScene->Update(aDeltaTime);

		AI::PollingStation3D::Get().UpdateCurrentSceneID(myCurrentSceneID);
		frame++;
	}
}

void InGame::Render()
{
	std::shared_ptr<GameScene> scene = std::dynamic_pointer_cast<GameScene>(myScene);

	bool showHudEditGrid = false;

	if (State* current = myStateStack.GetCurrentState())
	{
		if (current->GetID() == StateID::HUD)
		{
			showHudEditGrid = true;
		}
	}

	myRenderManager->RenderScene(*scene, showHudEditGrid);
}

void InGame::SwitchLevel(SceneID aSceneID)
{
	if (myCurrentSceneID == aSceneID)
	{
		return;
	}

	if (!mySceneManager->IsLoaded(aSceneID))
	{
		mySceneManager->LoadScene(aSceneID);
	}

	myPendingSceneID = aSceneID;

	AudioManager::GetInstance()->PlaySceneAudio(aSceneID);
}

void InGame::RegisterInput()
{
	RegisterToMapper(InputEvent::Pause);
	RegisterToMapper(InputEvent::CaptureMouse);
}

void InGame::UnregisterInput()
{
	UnRegisterToMapper(InputEvent::Pause);
	UnRegisterToMapper(InputEvent::CaptureMouse);
}

void InGame::ReceiveInput(InputEvent aGameEvent, const std::any& someData)
{
	UNREFERENCED_PARAMETER(someData);

	switch (aGameEvent)
	{
		case InputEvent::Pause:
		{
			//if (myStateStack.GetCurrentState()->GetID() == StateID::Cutscene)
			//{
			//    SceneID sceneID = myStateStack.GetCurrentState()->GetCurrentSceneID();
			//    myStateStack.Pop();
			//    myStateStack.QueueState(StateID::Cutscene, sceneID);
			//}
			myStateStack.Push(StateID::Pause, SceneID::Pause);
			break;
		}
		case InputEvent::CaptureMouse:
		{
			Tga::InputManager* input = InputMapper::GetInstance().GetInputManager();
			mouseLocked = !mouseLocked;

			if (mouseLocked)
			{
				input->CaptureMouse();
			}
			else
			{
				input->ReleaseMouse();
			}
		}

	}
}

void InGame::ReceiveEvent(const Message& aMessage)
{
	switch (aMessage.eventType)
	{
		case Event::SwitchLevel:
		{
			SceneID nextLevel = std::get<SceneID>(aMessage.data);
			if (nextLevel == SceneID::Count)
			{
				nextLevel = static_cast<SceneID>(static_cast<int>(myCurrentSceneID) + 1);
			}

			if (nextLevel != SceneID::EndScreen)
			{
				SwitchLevel(nextLevel);
				myStateStack.Pop();
				myStateStack.Push(StateID::InGame, SceneID::Count);
			}
			else
			{
				myScene = std::dynamic_pointer_cast<RunTimeScene>(mySceneManager->GetScene(myPendingSceneID));
				GameScene* gameScene = &*std::dynamic_pointer_cast<GameScene>(myScene);
				auto player = gameScene->GetPlayer().lock();
				player->SetIsRestarting(true);

				myStateStack.Pop();
				myStateStack.Push(StateID::EndScreen, nextLevel);
				Tga::Engine::GetInstance()->ShowCustomCursor(false);
			}
			break;
		}
		case Event::GameOver:
		{
			gameOver = true;
			break;
		}
		case Event::PlayCutscene:
		{
			int playerLevel = Blackboard::GetInstance()->GetInt("playerLevel");

			if (playerLevel <= 4)
			{
				SceneID cutscene = std::get<SceneID>(aMessage.data);
				if (myStateStack.GetCurrentState()->GetID() == StateID::Cutscene)
				{
					myStateStack.QueueState(StateID::Cutscene, cutscene);
				}
				else
				{
					myStateStack.Push(StateID::Cutscene, cutscene);
				}
			}
			break;
		}
		default:
		{
			break;
		}
	}
}

StateID InGame::GetID()
{
	return StateID::InGame;
}