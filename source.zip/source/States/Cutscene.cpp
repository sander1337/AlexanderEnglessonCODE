#include "Cutscene.h"
#include "StateStack.h"
#include "../SceneManagement/SceneManager.h"
#include <tge/scene/Scene.h>
#include "../SceneManagement/MenuScene.h"
#include "../Utilities/BlackBoard.h"

Cutscene::Cutscene(StateStack& aStateStack, const std::shared_ptr<SceneManager>& aSceneManager, const std::shared_ptr<RenderManager>& aRenderManager, const bool aLetThroughRender)
	:Menu(aStateStack, aSceneManager, aRenderManager, aLetThroughRender)
{
	myLetThroughRender = true;
	myLetThroughUpdate = true;
}

void Cutscene::OnEnter()
{
	Menu::OnEnter();
	std::shared_ptr<MenuScene> scene = std::dynamic_pointer_cast<MenuScene>(myScene);
	Tga::Color color;

	std::string property = "Cutscene_LifeTime_" + std::to_string(static_cast<int>(myCurrentSceneID));
	myCountdownMax = Blackboard::GetInstance()->GetFloat(property);
	
	property = "Cutscene_FadeTime_" + std::to_string(static_cast<int>(myCurrentSceneID));
	myFadeTime = Blackboard::GetInstance()->GetFloat(property);

	if (myCountdownMax <= 0.f)
	{
		myCountdownMax = 3.f;
	}
	myCountdownCurrent = myCountdownMax;
	myFadeCount = 0.f;

	if (myFadeTime > 0.f)
	{
		myFadePerSecond = 1.f / myFadeTime;
	}
	mySprites.clear();
	GameSprite* spritePtr = nullptr;
	for (auto& sprite : scene->GetSprites())
	{
		spritePtr = sprite.get();
		mySprites.emplace_back(spritePtr);
		color = mySprites.back()->GetColor();
		color.a = (myFadeTime > 0.f) ? 0.f : 1.f;
		mySprites.back()->SetColor(color);
	}
	myIsReadyToFinish = false;
}

void Cutscene::Update(float aDeltaTime)
{
	if (myIsReadyToFinish)
	{
		myStateStack.Pop();
		return;
	}

	if (myFadeCount < myFadeTime)
	{
		myFadeCount += aDeltaTime;
		if (myCountdownCurrent > 0.f)
		{
			FadeIn(aDeltaTime);
		}
		else
		{
			FadeOut(aDeltaTime);
		}
	}
	else
	{
		if (myCountdownCurrent > 0.f)
		{
			myCountdownCurrent -= aDeltaTime;
		}
		if (myCountdownCurrent <= 0.f)
		{
			myFadeCount = 0.f;
		}
	}

	if (myCountdownCurrent <= 0.f && myFadeCount >= myFadeTime)
	{
		myIsReadyToFinish = true;
	}
}

StateID Cutscene::GetID()
{
	return StateID::Cutscene;
}

void Cutscene::FadeIn(float aDeltaTime)
{
	for (auto& sprite : mySprites)
	{
		Tga::Color color;
		color = sprite->GetColor();
		color.a += myFadePerSecond * aDeltaTime;
		color.a = std::clamp(color.a, 0.f, 1.f);
		mySprites.back()->SetColor(color);
	}
}

void Cutscene::FadeOut(float aDeltaTime)
{
	for (auto& sprite : mySprites)
	{
		Tga::Color color;
		color = sprite->GetColor();
		color.a -= myFadePerSecond * aDeltaTime;
		color.a = std::clamp(color.a, 0.f, 1.f);
		mySprites.back()->SetColor(color);
	}
}
