#include "stdafx.h"
#include "Menu.h"
#include <tge/engine.h>
#include "StateStack.h"
#include "../Audio/AudioManager.h"
#include "../source/Utilities/PollingStation.h"
#include "../SceneManagement/SceneManager.h"
#include "../SceneManagement/RunTimeScene.h"
#include "../SceneManagement/MenuScene.h"
#include "../Render/RenderManager.h"
#include "../SceneManagement/SceneID.h"
#include "../Input/InputMapper.h"
#include <tge/input/InputManager.h>

using namespace Tga;
Menu::Menu(StateStack& aStateStack, const std::shared_ptr<SceneManager>& aSceneManager, const std::shared_ptr<RenderManager>& aRenderManager, const bool aLetThroughRender)
	:State(aStateStack, aSceneManager, aRenderManager, aLetThroughRender)
{}

void Menu::OnEnter()
{
    InputMapper::GetInstance().GetInputManager()->ReleaseMouse();

    if (!mySceneManager->IsLoaded(myPendingSceneID))
        mySceneManager->LoadScene(myPendingSceneID, SceneType::MenuScene);

    auto menuScene = std::dynamic_pointer_cast<MenuScene>(mySceneManager->GetScene(myPendingSceneID));
    if (!menuScene)
    {
        std::cout << "[Menu] ERROR: SceneID " << (int)myPendingSceneID << " is not a MenuScene or failed to load\n";
        return;
    }

    myScene = menuScene;              // <-- myScene b�r vara std::shared_ptr<MenuScene> i Menu om m�jligt
    menuScene->OnEnter(*mySceneManager, myStateStack);

    if (myCurrentSceneID == myPendingSceneID)
        return;

    myCurrentSceneID = myPendingSceneID;

    for (auto& [id, btn] : menuScene->GetButtons())
        if (btn) btn->SetStateStack(&myStateStack);
}


void Menu::OnExit()
{
	myScene->OnExit();
}

void Menu::Update(float aDeltaTime)
{
	aDeltaTime;
	AI::PollingStation3D::Get().UpdateCurrentSceneID(myCurrentSceneID);

	TickSelectCooldown();
}

void Menu::Render()
{
	std::shared_ptr<MenuScene> scene = std::dynamic_pointer_cast<MenuScene>(myScene);
	myRenderManager->RenderScene(*scene);
}

void Menu::ReceiveEvent(const Message& aMessage)
{
	aMessage;
}

StateID Menu::GetID()
{
	return StateID();
}

void Menu::TickSelectCooldown()
{
	if (mySelectCooldown > 0.f)
	{
		mySelectCooldown -= Tga::Engine::GetInstance()->GetDeltaTime();
	}
}
