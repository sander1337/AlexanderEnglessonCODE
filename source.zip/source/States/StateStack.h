#pragma once
//#pragma message(__FILE__" was compiled")
#include "StateID.h"
#include <map>
#include <memory>
#include <vector>
#include "../source/SceneManagement/SceneID.h"

class State;
enum class SceneID : std::uint8_t;
class RenderManager;
class SceneManager;


class StateStack
{
public:
    StateStack() = default;
    ~StateStack() = default;

    void Init(SceneID aSceneID, const std::shared_ptr<SceneManager>& aSceneManager, const std::shared_ptr<RenderManager>& aRenderManager);
    void Update(float aDeltaTime);
    void Render(int anIndex = -10);

    void Push(StateID aStateID, SceneID aSceneID = SceneID::Count);
    void Pop();
    void EnterState(int anIndex = -10);
    void ExitState(int anIndex = -10);
    void QueueState(StateID aStateID, SceneID aSceneID);
    void Clear();
    bool empty() { return myStack.empty(); };

    State* GetCurrentState() const;
    State* GetState(StateID aStateID) const;
    State* GetBelowCurrentState() const;


private:
    std::map<StateID, std::shared_ptr<State>> myCachedStates;
    std::vector<State*> myStack;
    std::vector<std::pair<StateID, SceneID>> myQueue;
};