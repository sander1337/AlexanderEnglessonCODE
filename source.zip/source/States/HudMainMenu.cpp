﻿#include "HudMainMenu.h"

#include "stdafx.h"
#include "OtherMenus.h"
#include "HudMenu.h"// where HudMenu lives
#include "../SceneManagement/MenuScene.h"
#include "../Input/InputMapper.h"

#include <imgui/imgui_impl_dx11.h>
#include <tge/graphics/GraphicsEngine.h>
#include <tge/graphics/GraphicsStateStack.h>
#include <tge/input/InputManager.h>


void HudMainMenu::OnEnter()
{
    Menu::OnEnter();

    auto menuScene = std::dynamic_pointer_cast<MenuScene>(myScene);
    if (menuScene)
    {
        menuScene->BringToFront(Tga::ButtonType::Save);
        menuScene->BringToFront(Tga::ButtonType::Back2x);
    }

    if (auto* im = InputMapper::GetInstance().GetInputManager())
        im->ReleaseMouse();

    // Wire parent/children (din kod)
    if (menuScene)
    {
        auto& btns = menuScene->GetButtons();
        Button* parent = nullptr;
        Button* save = nullptr;
        Button* back = nullptr;

        if (auto it = btns.find(Tga::ButtonType::MoveAllButtonsInMySize); it != btns.end())
            parent = it->second.get();

        if (auto it = btns.find(Tga::ButtonType::Save); it != btns.end())
            save = it->second.get();

        if (auto it = btns.find(Tga::ButtonType::Back2x); it != btns.end())
            back = it->second.get();

        if (parent)
        {
            if (save) parent->AddChild(save);
            if (back) parent->AddChild(back);

            if (save) save->SetDraggable(false);
            if (back) back->SetDraggable(false);
        }
    }

    Message c;
    c.eventType = Event::CloseSpellBook;
    c.data = 0; // unused
    EventManager::GetInstance()->SendEventMessage(c);
    SetHudEditMode(true);
}

void HudMainMenu::OnExit()
{
    SetHudEditMode(false);
    Menu::OnExit();
}

void HudMainMenu::Render()
{
    Menu::Render();

    auto& engine = *Tga::Engine::GetInstance();
    auto& gss = engine.GetGraphicsEngine().GetGraphicsStateStack();

    gss.Push();
    // Option 1: use the menu scene camera (UI camera)
    gss.SetCamera(*GetActiveCamera()); // if Menu/State has GetActiveCamera()

    // Option 2: create a dedicated orthographic camera for UI and set it here

    auto menuScene = std::dynamic_pointer_cast<MenuScene>(myScene);
    if (menuScene)
    {
        for (auto& s : menuScene->GetSprites()) s->UpdateAndRender();

        // --- Actionbar / runtime buttons ---
        for (auto& b : menuScene->GetRuntimeButtons())
            if (b) b->Render();

        // --- Vanliga meny-knappar (Save/Back osv) ---
        for (auto id : menuScene->GetButtonDrawOrder())
        {
            auto it = menuScene->GetButtons().find(id);
            if (it == menuScene->GetButtons().end()) continue;
            if (!it->second) continue;
            it->second->Render();
        }
        auto it = menuScene->GetButtons().find(Tga::ButtonType::MoveAllButtonsInMySize);
        if (it != menuScene->GetButtons().end() && it->second)
        {
            Button* b = it->second.get();
            // Subtle red when idle
            const Tga::Color idle = { 1.0f, 0.0f, 0.0f, 0.25f };
            // Bright / “glow” red when hovering or dragging
            const Tga::Color hot = { 1.0f, 0.15f, 0.15f, 0.90f };

            const bool active = b->IsHovered() || b->IsDragging();
            b->DebugDrawBounds(active ? hot : idle);
        }
    }

    gss.Pop();
}

void HudMainMenu::Update(float aDeltaTime)
{
    Menu::Update(aDeltaTime);

    auto menuScene = std::dynamic_pointer_cast<MenuScene>(myScene);
    if (!menuScene) return;

    for (auto& b : menuScene->GetRuntimeButtons())
        if (b) b->Update(aDeltaTime);

    for (auto& bar : menuScene->GetActionBars())
        if (bar) bar->Update(aDeltaTime);
}

void HudMainMenu::SetHudEditMode(bool on)
{
    auto menuScene = std::dynamic_pointer_cast<MenuScene>(myScene);
    if (!menuScene) return;

    for (auto& [id, btn] : menuScene->GetButtons())
    {
        if (!btn) continue;

        const bool isParent = (id == Tga::ButtonType::MoveAllButtonsInMySize);
        const bool isChild = (id == Tga::ButtonType::Save || id == Tga::ButtonType::Back2x);

        if (isParent)
        {
            btn->SetDraggable(on);
            if (!on) btn->CancelDrag();
        }
        else if (isChild)
        {
            btn->SetDraggable(false); // barn dras via parent
            btn->CancelDrag();
        }
    }
}
