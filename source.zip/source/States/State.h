#pragma once
//#pragma message(__FILE__" was compiled")
#include "StateID.h"
#include "../Events/EventManager.h"

#include <memory>

namespace Tga
{
	class Camera;
}

class RunTimeScene;
class RenderManager;
class SceneManager;
class StateStack;

class State : public Observer
{
public:
    State(StateStack& aStateStack, const std::shared_ptr<SceneManager>& aSceneManager, const std::shared_ptr<RenderManager>& aRenderManager, const bool aLetThroughRender = false);
    virtual ~State() = default;

    virtual void OnEnter() = 0;
    virtual void OnExit() = 0;
    virtual void Update(float aDeltaTime) = 0;
    virtual void Render() = 0;

    virtual bool LetsThroughRender() const;
    virtual bool LetsThroughUpdate() const;

    virtual StateID GetID() = 0;

    std::weak_ptr<RunTimeScene> GetScene() const;
    SceneID GetCurrentSceneID() const { return myCurrentSceneID; }
    virtual const std::shared_ptr<Tga::Camera> GetActiveCamera() const;

    virtual void SetPendingScene(SceneID aSceneID);

    void ReceiveEvent(const Message& aMessage) { aMessage; };
    virtual void SetHasExited(bool aStatus) { myHasExited = aStatus; }
    virtual bool GetHasExited() { return myHasExited; }

protected:
    StateStack& myStateStack;
    std::shared_ptr<SceneManager>  mySceneManager;
    std::shared_ptr<RenderManager> myRenderManager;
    std::shared_ptr<RunTimeScene> myScene;
    bool myHasBeenInitialized = false;

    bool myHasExited = true;

    SceneID myPendingSceneID;
    SceneID myCurrentSceneID;

    bool myLetThroughRender = false;
    bool myLetThroughUpdate = false;
};
