#include "stdafx.h"
#include "OtherMenus.h"
#include "StateStack.h"

// MAIN MENU
#pragma region MainMenu
MainMenu::MainMenu(StateStack& aStateStack, const std::shared_ptr<SceneManager>& aSceneManager, const std::shared_ptr<RenderManager>& aRenderManager, const bool aLetThroughRender)
	:Menu(aStateStack, aSceneManager, aRenderManager, aLetThroughRender) 
{
}

StateID MainMenu::GetID()
{
	return StateID::MainMenu;
}
#pragma endregion

// OPTIONS
#pragma region Options
OptionsMenu::OptionsMenu(StateStack& aStateStack, const std::shared_ptr<SceneManager>& aSceneManager, const std::shared_ptr<RenderManager>& aRenderManager, const bool aLetThroughRender)
	:Menu(aStateStack, aSceneManager, aRenderManager, aLetThroughRender)
{

}
StateID OptionsMenu::GetID()
{
	return StateID::Options;
}
#pragma endregion

// CREDITS
#pragma region Credits
CreditsMenu::CreditsMenu(StateStack& aStateStack, const std::shared_ptr<SceneManager>& aSceneManager, const std::shared_ptr<RenderManager>& aRenderManager, const bool aLetThroughRender)
	:Menu(aStateStack, aSceneManager, aRenderManager, aLetThroughRender)
{}

void CreditsMenu::OnEnter()
{
	Menu::OnEnter();
	Tga::Engine::GetInstance()->ShowCustomCursor(true);
}

StateID CreditsMenu::GetID()
{
	return StateID::Credits;
}
#pragma endregion

// LEVEL SELECT
#pragma region LevelSelect
LevelSelectMenu::LevelSelectMenu(StateStack& aStateStack, const std::shared_ptr<SceneManager>& aSceneManager, const std::shared_ptr<RenderManager>& aRenderManager, const bool aLetThroughRender)
	:Menu(aStateStack, aSceneManager, aRenderManager, aLetThroughRender)
{

}

StateID LevelSelectMenu::GetID()
{
	return StateID::LevelSelect;
}
#pragma endregion

// PAUSE
#pragma region Pause
PauseMenu::PauseMenu(StateStack& aStateStack, const std::shared_ptr<SceneManager>& aSceneManager, const std::shared_ptr<RenderManager>& aRenderManager, const bool aLetThroughRender)
	:Menu(aStateStack, aSceneManager, aRenderManager, aLetThroughRender)
{
	myLetThroughRender = true;
}

StateID PauseMenu::GetID()
{
	return StateID::Pause;
}
#pragma endregion