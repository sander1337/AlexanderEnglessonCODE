#pragma once
//#pragma message(__FILE__" was compiled")
#include <cstdint>

enum class StateID : uint8_t
{
	InGame,
	MainMenu,
	Options,
	LevelSelect,
	Credits,
	Pause,
	Cutscene,
	SplashScreen,
	EndScreen,
	HUD,
	EditHud,
	HudMainMenu,
	Count
};