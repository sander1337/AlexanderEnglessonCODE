#pragma once
#include "Menu.h"
#include "ActionBars/ActionBar.h"

class HudMainMenu : public Menu
{
public:
	HudMainMenu(StateStack& aStateStack,
        const std::shared_ptr<SceneManager>& aSceneManager,
        const std::shared_ptr<RenderManager>& aRenderManager,
        const bool aLetThroughRender = false)
        : Menu(aStateStack, aSceneManager, aRenderManager, aLetThroughRender)
    {
        myLetThroughRender = true; // see game behind while editing (like pause)
        myLetThroughUpdate = true;
    }

    void OnEnter() override;
    void OnExit() override;
    void Render() override;
    void Update(float aDeltaTime) override;

    StateID GetID() override { return StateID::HudMainMenu; }

private:
    void SetHudEditMode(bool on);

    // outline color
    Tga::Color myEditOutlineColor = { 1.0f, 0.0f, 0.0f, 1.0f };
};

