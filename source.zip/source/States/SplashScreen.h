#pragma once
#include "State.h"
#include <tge/sprite/sprite.h>

class SplashScreen : public State
{
public:
    SplashScreen(StateStack& aStateStack, const std::shared_ptr<SceneManager>& aSceneManager, const std::shared_ptr<RenderManager>& aRenderManager, const bool aLetThroughRender = false);
    ~SplashScreen() override = default;

    void Init();
    void OnEnter() override;
    void OnExit() override;

    void Update(float aDeltaTime) override;
    void Render() override;

    StateID GetID() override;
private:
    void FadeIn(float aDeltaTime);
    void FadeOut(float aDeltaTime);

    float myCountdownMax = 3.f;
    float myCountdownCurrent = 0.f;

    float myFadeCount = 0.f;
    float myFadeTime = 0.5f;
    float myFadePerSecond = 2.f;

    float myPauseCount = 0.f;
    float myPauseTime = 0.5f;

    bool myIsReadyToSwitch = false;

    int mySplashScreenMax = 0;
    int mySplashScreenCurrent = 0;

    Tga::Sprite2DInstanceData mySpriteInstance;
    Tga::Sprite3DInstanceData mySpriteInstance3D;
    std::vector<Tga::SpriteSharedData> mySprites;
    std::shared_ptr<Tga::Camera> myCamera;
};

