#pragma once
//#pragma message(__FILE__" was compiled")
#include "Menu.h"

class MainMenu : public Menu
{
public:
    MainMenu(StateStack& aStateStack, const std::shared_ptr<SceneManager>& aSceneManager, const std::shared_ptr<RenderManager>& aRenderManager, const bool aLetThroughRender = false);
    ~MainMenu() override = default;

    StateID GetID() override;
};

class OptionsMenu : public Menu
{
public:
    OptionsMenu(StateStack& aStateStack, const std::shared_ptr<SceneManager>& aSceneManager, const std::shared_ptr<RenderManager>& aRenderManager, const bool aLetThroughRender = false);
    ~OptionsMenu() override = default;

    StateID GetID() override;
};

class CreditsMenu : public Menu
{
public:
    CreditsMenu(StateStack& aStateStack, const std::shared_ptr<SceneManager>& aSceneManager, const std::shared_ptr<RenderManager>& aRenderManager, const bool aLetThroughRender = false);
    ~CreditsMenu() override = default;

    void OnEnter() override;

    StateID GetID() override;

private:
};

class LevelSelectMenu : public Menu
{
public:
    LevelSelectMenu(StateStack& aStateStack, const std::shared_ptr<SceneManager>& aSceneManager, const std::shared_ptr<RenderManager>& aRenderManager, const bool aLetThroughRender = false);
    ~LevelSelectMenu() override = default;

    StateID GetID() override;

private:
};

class PauseMenu : public Menu
{
public:
    PauseMenu(StateStack& aStateStack, const std::shared_ptr<SceneManager>& aSceneManager, const std::shared_ptr<RenderManager>& aRenderManager, const bool aLetThroughRender = false);
    ~PauseMenu() override = default;

    StateID GetID() override;
};

