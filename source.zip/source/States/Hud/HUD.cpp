﻿#include "HUD.h"
#include "stdafx.h"

#include <algorithm>
#include <unordered_map>
#include <vector>
#include <iostream>

#include <tge/engine.h>
#include <tge/drawers/SpriteDrawer.h>
#include <tge/graphics/GraphicsEngine.h>
#include <tge/graphics/GraphicsStateStack.h>
#include <tge/input/InputManager.h>
#include <tge/texture/TextureManager.h>
#include <tge/drawers/DebugDrawer.h>
#include <tge/graphics/DX11.h>

#include "../../SceneManagement/SceneManager.h"
#include "../../SceneManagement/MenuScene.h"
#include "../source/SceneManagement/SceneID.h"
#include "../source/Events/EventManager.h"
#include "../source/Utilities/PollingStation.h"

#include "States/ActionBars/SpellBookSpellButton.h"
#include "States/ActionBars/ActionBarSlotButton.h"
#include "States/Hud/HudSpellBook.h"

static void TryActivateBuffFromSpell(HUD* hud, const ActionBarSpell& spell)
{
    if (!hud) return;

    switch (spell.id)
    {
    case 9: // Arcane Intellect
        hud->AddBuff(
            spell.id,
            spell.name,
            spell.iconTexturePath,
            1800.f); // 30 min
        break;

    case 10: // Dampen Magic
        hud->AddBuff(
            spell.id,
            spell.name,
            spell.iconTexturePath,
            600.f); // 10 min
        break;

    case 11: // Amplify Magic
        hud->AddBuff(
            spell.id,
            spell.name,
            spell.iconTexturePath,
            600.f); // 10 min
        break;
    case 12: // Blink
    {
        if (hud->HasDebuff(static_cast<int>(spell.id)))
            break; // still on cooldown, do nothing

        hud->AddDebuff(
            spell.id,
            "Blink Cooldown",
            spell.iconTexturePath,
            spell.cooldown);

        Message msg{};
        msg.eventType = Event::PlayerBlink;
        EventManager::GetInstance()->SendEventMessage(msg);
        break;
    }
    default:
        break;
    }
}

void HUD::Init(SceneManager* aSceneManager, StateStack* aStateStack, Tga::Camera& aSceneCamera)
{
    myCamera.Init(Tga::Camera::ProjectionType::Ortoraphic);
    mySceneCamera = &aSceneCamera;

    myScene = std::dynamic_pointer_cast<MenuScene>(aSceneManager->GetScene(SceneID::HUD));
    myScene->OnEnter(*aSceneManager, *aStateStack);
    auto uiCam = myScene->GetCamera();



    // Keybind popup
    myKeybindPopup.Init(myScene);

    // Dragdrop: only between actionbars (spellbook drag blocked in BeginDragFromSpell)
    myDragDrop.Init(*myScene);

    myDragDrop.SetCopyModifier([](Tga::InputManager* im)
        {
            return im && im->IsKeyHeld(VK_CONTROL);
        });

    // If something still calls drop-from-spell, keep safe behavior:
    myDragDrop.SetOnDropFromSpell([this](const ActionBarSpell& spell, ActionBarSlotButton* toSlot)
        {
            if (myPendingBind.active && myPendingBind.targetSlot)
            {
                myPendingBind.targetSlot->SetSpell(spell);
                myPendingBind.active = false;
                myPendingBind.targetSlot = nullptr;
                mySpellBooks.Close();
                return;
            }

            if (toSlot)
                toSlot->SetSpell(spell);
        });

    // Tooltip
    myTooltip.Init(Tga::Engine::GetInstance()->GetTextureManager());


    // Spellbook + actionbars
    mySpellBooks.Init(*this, *myScene, myScene->GetCamera());
    myActionBars.EnsureDefaultBars(*this, *myScene);

    //Castbar
    myCastBarFrame = std::make_shared<CastBarFrame>();
    myCastBarFrame->InitRuntimeFrame(this, uiCam, { 0.f, -420.f }, { 420.f, 36.f });
    myScene->AddRuntimeButton(myCastBarFrame);
    myCastBarFrame->RegisterInput();

    // Buff frame
    myBuffFrame = std::make_shared<BuffFrame>();
    myBuffFrame->InitRuntimeFrame(this, uiCam, { 920.f, 750.f }, { 710.f, 194.f });
    myBuffFrame->SetGrid(10, 2);
    myScene->AddRuntimeButton(myBuffFrame);
    myBuffFrame->RegisterInput();

    AddBuff(9, "Arcane Intellect", "assets/ui/textures/Spells/Arcane_Intellect.jpg", 1800.f);
    AddBuff(10, "Dampen Magic", "assets/ui/textures/Spells/Dampen_Magic.jpg", 600.f);

    // Debuff frame
    myDebuffFrame = std::make_shared<BuffFrame>();
    myDebuffFrame->InitRuntimeFrame(this, uiCam, { 920.f, 640.f }, { 710.f, 98.f });
    myDebuffFrame->SetGrid(10, 1);
    myScene->AddRuntimeButton(myDebuffFrame);
    myDebuffFrame->RegisterInput();

    //BUFF/DEBUFF OVERLAP SAFETY
    ResolveBuffDebuffOverlap(10.f);

    //STANCE BAR
    myStanceBar = std::make_shared<StanceBar>();
    myStanceBar->Init(*this, *myScene, { -220.f, -520.f });

    // Player frame
    myPlayerFrame = std::make_shared<PlayerFrame>();
    myPlayerFrame->InitRuntimeFrame(this, uiCam, { -450, -160.f }, { 420.f, 140.f });
    myScene->AddRuntimeButton(myPlayerFrame);
    myPlayerFrame->RegisterInput();

    myPlayerFrame->SetName("Sander");
    myPlayerFrame->SetHealth(4585, 4585);
    myPlayerFrame->SetMana(2315, 5571);
    myPlayerSnap = { "Sander", 4585, 4585, 2315, 5571 };

    // Target frame
    myTargetFrame = std::make_shared<TargetFrame>();
    myTargetFrame->InitRuntimeFrame(this, uiCam, { 450, -160.f }, { 420.f, 140.f });
    myScene->AddRuntimeButton(myTargetFrame);
    myTargetFrame->RegisterInput();
    myTargetFrame->ClearTarget();

    // Party frames (5)
    {
        const Tga::Vector2f partySize = { 420.f, 140.f };  // same as player frame size
        const Tga::Vector2f partyAnchor = { -1400.f, 520.f }; // 👈 more left

        for (int i = 0; i < 5; ++i)
        {
            auto pf = std::make_shared<PartyFrame>();
            pf->InitRuntimeFrame(this, uiCam, partyAnchor, partySize, i);

            pf->SetName(("Party " + std::to_string(i + 1)).c_str());
            pf->SetHealth(2500 + i * 100, 3000);
            pf->SetMana(1200 + i * 50, 2000);
            myPartySnaps[i] =
            {
                "Party " + std::to_string(i + 1),
                2500 + i * 100, 3000,
                1200 + i * 50,  2000
            };
            myScene->AddRuntimeButton(pf);
            pf->RegisterInput();

            myPartyFrames[i] = pf;
        }
    }



    // Buttons state stack
    for (auto& [id, btn] : myScene->GetButtons())
        if (btn) btn->SetStateStack(aStateStack);

    SubscribeToEvents();

    // Enemy healthbar textures (3D)
    auto& tm = Tga::Engine::GetInstance()->GetTextureManager();
    myEnemyEmptyBar.myTexture = tm.GetTexture("assets/UI/hud/textures/T_UI_Enemy_HealthBar_Empty_Small.dds");
    myEnemyFullBar.myTexture = tm.GetTexture("assets/UI/hud/textures/T_UI_Enemy_HealthBar_Full_Small.dds");

    // Boss HUD (2D)
    {
        const Tga::Vector2f resolution = { 1140.f, 900.f };
        myBossSpriteInstance.mySize = myEnemyEmptyBar.myTexture->CalculateTextureSize();
        myBossSpriteInstance.mySize.y *= 0.5f;
        myBossSpriteInstance.myPivot = { 0.f, 0.5f };
        myBossSpriteInstance.myPosition = { resolution.x * 0.5f, resolution.y * 0.8f };
        myBossSpriteInstance.myPosition.x -= myBossSpriteInstance.mySize.x;

        myBossName = Tga::Text{ "text/nexa-rust.handmade-extended.ttf", Tga::FontSize_36 };
        myBossName.SetText("Lind Wurm");
        myBossName.SetColor({ 1.f, 0.690f, 0.564f, 1.f });

        Tga::Vector2f textPos = myBossSpriteInstance.myPosition;
        textPos.x += myBossSpriteInstance.mySize.x * 0.5f;
        textPos.x -= myBossName.GetWidth() * 0.5f;
        textPos.y += myBossSpriteInstance.mySize.y * 0.25f;
        myBossName.SetPosition(textPos);

        myBossSpriteInstance.myTextureRect.myEndX = 0.f;
    }
    ApplyHudEditSettings();
}

void HUD::Render()
{
    if (!myScene)
        return;

    auto& engine = *Tga::Engine::GetInstance();
    auto& gss = engine.GetGraphicsEngine().GetGraphicsStateStack();
    auto& spriteDrawer = engine.GetGraphicsEngine().GetSpriteDrawer();

    gss.Push();
    gss.SetBlendState(Tga::BlendState::AlphaBlend);
    gss.SetSamplerState(Tga::SamplerFilter::Trilinear, Tga::SamplerAddressMode::Clamp);
    gss.SetAlphaTestThreshold(0.7f);

    // -------------------------
    // 3D enemy bars (world cam)
    // -------------------------
    gss.SetCamera(*mySceneCamera);

    auto hurtActors = AI::PollingStation3D::Get().GetHurtActors();
    if (mySceneCamera != nullptr)
    {
        std::vector<Tga::Sprite3DInstanceData> emptyBars;
        std::vector<Tga::Sprite3DInstanceData> fullBars;

        emptyBars.reserve(hurtActors.size());
        fullBars.reserve(hurtActors.size());

        for (auto& [actor, info] : hurtActors)
        {
            Tga::Sprite3DInstanceData emptyBar;
            Tga::Sprite3DInstanceData fullBar;

            Tga::Matrix4x4f transform = info.transform;
            transform.Translate(Tga::Vector3f::Up * 300.f);

            const Tga::Vector2ui size = myEnemyEmptyBar.myTexture[0].CalculateTextureSize();
            Tga::Vector2f floatSize{ (float)size.x, (float)size.y };
            floatSize *= 0.15f;

            Tga::Vector2f pivot = floatSize;

            SetTransformFor3DSprite(emptyBar, transform, floatSize, pivot);

            fullBar.myTextureRect = { 0.f, 0.f, (float)info.health / (float)info.maxHealth, 1.f };
            floatSize.x *= fullBar.myTextureRect.myEndX;
            SetTransformFor3DSprite(fullBar, transform, floatSize, pivot);

            emptyBars.push_back(emptyBar);
            fullBars.push_back(fullBar);
        }

        for (size_t i = 0; i < emptyBars.size(); ++i)
        {
            spriteDrawer.Draw(myEnemyEmptyBar, emptyBars[i]);
            spriteDrawer.Draw(myEnemyFullBar, fullBars[i]);
        }
    }

    // -------------------------
    // UI (UI cam)
    // -------------------------
    gss.SetCamera(*myScene->GetCamera());

    if (myEditMode)
    {
        const Tga::Color purple{ 0.8f, 0.2f, 1.0f, 1.0f };

        // Scene buttons
        for (auto& [id, btn] : myScene->GetButtons())
            if (btn) btn->DebugDrawBounds(purple);

        // ✅ Runtime buttons (ActionBar slots + PlayerFrame + TargetFrame)
        for (auto& b : myScene->GetRuntimeButtons())
            if (b && b->IsVisible()) b->DebugDrawBounds(purple);
    }

    // Draw normal UI first
    for (auto& sprite : myScene->GetSprites())
        sprite->UpdateAndRender();

    for (auto& [id, btn] : myScene->GetButtons())
        if (btn) btn->Render();

    // Draw normal runtime (frames, actionbars, etc)
    for (auto& b : myScene->GetRuntimeButtons())
        if (b && b->IsVisible()) b->Render();

    
	// If spellbook open: draw overlay panel ON TOP of frames
	mySpellBooks.RenderBackdrop(spriteDrawer);
	

    // Draw modal runtime (spell buttons) ON TOP of the panel
    for (auto& b : myScene->GetModalRuntimeButtons())
        if (b) b->Render();

    myDragDrop.Render(spriteDrawer);
    myTooltip.Render(spriteDrawer);
    myKeybindPopup.Render(spriteDrawer);

    gss.Pop();
}

void HUD::Update(float aDeltaTime)
{
    if (!myScene)
        return;

    auto* im = InputMapper::GetInstance().GetInputManager();
    if (!im) return;

    for (auto& b : myScene->GetRuntimeButtons())
        if (b && b->IsVisible()) b->Update(aDeltaTime);

    for (auto& b : myScene->GetModalRuntimeButtons())
        if (b) b->Update(aDeltaTime);

    if (myPendingCastActive && myCastBarFrame && !myCastBarFrame->IsCasting())
    {
        TryActivateBuffFromSpell(this, myPendingCastSpell);
        myPendingCastActive = false;
        myPendingCastSpell = {};
    }

    // Mouse -> UI world
    const auto resI = Tga::Engine::GetInstance()->GetRenderSize();
    const float H = (float)resI.y;

    const Tga::Vector2f mouseScreen{ im->GetMousePosition().x, H - im->GetMousePosition().y };
    auto* uiCam = myScene->GetCamera().get();
    const Tga::Vector2f mouseWorld = uiCam->GetScreenToWorldCoordinatesVec2(mouseScreen);

    if (!myEditMode && im->IsKeyPressed(VK_RBUTTON))
    {
        if (RemoveBuffAtMouse(mouseWorld))
            return;
    }

    // Update actionbars
    myActionBars.Update(*myScene, aDeltaTime);

    

    if (!myEditMode && im->IsKeyPressed(VK_LBUTTON))
    {
        bool clickedUnitFrame = false;

        if (!clickedUnitFrame && myTargetFrame)
        {
            if (PointInRectCenterSize(
                mouseWorld,
                myTargetFrame->GetPosition(),
                myTargetFrame->GetHalfSize() * 2.f))   // size = full size
            {
                return; // don't clear or reset
            }
        }
        // Party click -> set target
        for (int i = 0; i < 5; ++i)
        {
            auto& pf = myPartyFrames[i];
            if (!pf) continue;

            const auto p = pf->GetPosition();
            const auto hs = pf->GetHalfSize();

            if (mouseWorld.x >= p.x - hs.x && mouseWorld.x <= p.x + hs.x &&
                mouseWorld.y >= p.y - hs.y && mouseWorld.y <= p.y + hs.y)
            {
                clickedUnitFrame = true;
                if (myTargetFrame) myTargetFrame->SetTarget(myPartySnaps[i]);
                break;
            }
        }

        // PlayerFrame click -> set target
        if (!clickedUnitFrame && myPlayerFrame && myPlayerFrame->IsVisible())
        {
            const auto p = myPlayerFrame->GetPosition();
            const auto hs = myPlayerFrame->GetHalfSize();

            if (mouseWorld.x >= p.x - hs.x && mouseWorld.x <= p.x + hs.x &&
                mouseWorld.y >= p.y - hs.y && mouseWorld.y <= p.y + hs.y)
            {
                clickedUnitFrame = true;
                if (myTargetFrame) myTargetFrame->SetTarget(myPlayerSnap);
            }
        }

        // Clicked nowhere -> clear target (hide frame)
        if (!clickedUnitFrame)
        {
            if (myTargetFrame) myTargetFrame->ClearTarget();
        }

        // Optional: stop further click handling if this is “targeting click”
        // return;
    }

    // Modal popup eats input
    if (myKeybindPopup.Update(im, mouseWorld))
        return;

    // Ctrl+click opens keybind popup
    if (!mySpellBooks.IsOpen() && !myDragDrop.IsDragging() &&
        im->IsKeyHeld(VK_CONTROL) && im->IsKeyPressed(VK_LBUTTON))
    {
        if (auto* slot = myActionBars.HitTestSlot(*myScene, mouseWorld))
        {
            myKeybindPopup.TryOpenPopupOnCtrlClick(im, slot);
            return;
        }
    }

    // =========================================================
    // SPELLBOOK OPEN: click-to-assign only + tooltip + close
    // =========================================================
    if (mySpellBooks.IsOpen())
    {
        // 1) Click spell -> assign -> close
        if (im->IsKeyPressed(VK_LBUTTON))
        {
            if (auto* clicked = mySpellBooks.HitTest(mouseWorld))
            {
                const ActionBarSpell s = clicked->GetSpell();

                if (myPendingBind.active && myPendingBind.targetSlot)
                {
                    if (s.id == HudSpellBook::kDontSetSpellId)
                        myPendingBind.targetSlot->SetSpell(ActionBarSpell{});
                    else
                        myPendingBind.targetSlot->SetSpell(s);
                }

                myPendingBind.active = false;
                myPendingBind.targetSlot = nullptr;

                mySpellBooks.Close();
                myIgnoreOutsideClick = true;
                HideSpellTooltip();
                return; // IMPORTANT: no dragdrop while open
            }
        }

        // 2) Close on outside click
        if (im->IsKeyPressed(VK_LBUTTON))
        {
            if (myIgnoreOutsideClick) myIgnoreOutsideClick = false;
            else if (!mySpellBooks.IsMouseInside(mouseWorld))
            {
                mySpellBooks.Close();
                HideSpellTooltip();
                return;
            }
        }

        // 3) Hover tooltip for spellbook
        SpellBookSpellButton* spellHover = mySpellBooks.HitTest(mouseWorld);
        if (spellHover != myPrevHoverSpell)
        {
            if (spellHover) ShowSpellTooltip(spellHover->GetSpell());
            else HideSpellTooltip();
            myPrevHoverSpell = spellHover;
        }

        myPrevHoverSlot = nullptr;

        // ❌ No dragdrop update while spellbook open
        return;
    }

    // =========================================================
    // SPELLBOOK CLOSED: normal hover + drag between actionbars
    // =========================================================

    // Hover tooltip for actionbar slots
    ActionBarSlotButton* hover = myActionBars.HitTestSlot(*myScene, mouseWorld);
    if (hover != myPrevHoverSlot)
    {
        if (hover && !hover->IsEmpty()) ShowSpellTooltip(hover->GetSpell());
        else HideSpellTooltip();
        myPrevHoverSlot = hover;
    }
    myPrevHoverSpell = nullptr;

    // Drag between actionbars
    myDragDrop.Update(mouseWorld, im, myActionBars);
}

void HUD::SetSceneCamera(Tga::Camera* aCamera)
{
    mySceneCamera = aCamera;
    if (!myScene) return;

    auto uiCam = myScene->GetCamera();
    for (auto& b : myScene->GetRuntimeButtons())
        if (b) b->SetCamera(uiCam);
}

void HUD::SetSceneToNull()
{
    myScene = nullptr;
    myPrevHoverSlot = nullptr;
    myPrevHoverSpell = nullptr;
}

void HUD::SubscribeToEvents()
{
    if (!myScene)
        return;

    if (myIsSubscribedToEvents)
        return;

    for (auto& [id, btn] : myScene->GetButtons())
        if (btn) btn->RegisterInput();

    for (auto& b : myScene->GetRuntimeButtons())
        if (b) b->RegisterInput();

    for (auto& b : myScene->GetModalRuntimeButtons())
        if (b) b->RegisterInput();

    EventManager::GetInstance()->Subscribe(Event::ToggleHudEditMode, this);
    EventManager::GetInstance()->Subscribe(Event::CloseSpellBook, this);
    myIsSubscribedToEvents = true;
}

void HUD::UnsubscribeFromEvents()
{
    if (!myIsSubscribedToEvents)
        return;

    if (myScene)
    {
        for (auto& [id, btn] : myScene->GetButtons())
            if (btn) btn->UnregisterInput();

        for (auto& b : myScene->GetRuntimeButtons())
            if (b) b->UnregisterInput();
    }

    EventManager::GetInstance()->UnSubscribe(Event::ToggleHudEditMode, this);
    EventManager::GetInstance()->UnSubscribe(Event::CloseSpellBook, this);
    myIsSubscribedToEvents = false;
}

void HUD::SetPartyAnchor(const Tga::Vector2f& p)
{
    myPartyAnchor = p;

    for (auto& frame : myPartyFrames)
    {
        if (!frame)
            continue;

        frame->SetAnchorPosition(myPartyAnchor);
    }
}

void HUD::StartCastBar(const ActionBarSpell& spell)
{
    if (!myCastBarFrame || spell.castTime <= 0.f)
        return;

    myPendingCastActive = true;
    myPendingCastSpell = spell;
    myCastBarFrame->StartCast(spell);
}

void HUD::StopCastBar()
{
    if (myCastBarFrame)
        myCastBarFrame->StopCast();
}

bool HUD::IsCastingSpell() const
{
    return myCastBarFrame && myCastBarFrame->IsCasting();
}

void HUD::AddBuff(int id, const std::string& name, const std::string& iconPath, float duration)
{
    if (myBuffFrame)
        myBuffFrame->AddOrRefreshBuff(id, name, iconPath, duration);
}

void HUD::RemoveBuff(int id)
{
    if (myBuffFrame)
        myBuffFrame->RemoveBuff(id);
}

bool HUD::RemoveBuffAtMouse(const Tga::Vector2f& mouseWorld)
{
    if (!myBuffFrame || !myBuffFrame->IsVisible())
        return false;

    return myBuffFrame->RemoveBuffAtMouse(mouseWorld);
}

void HUD::ApplyStanceBuff(MageStance stance)
{
    // remove all stance buffs first
    RemoveBuff(1001);
    RemoveBuff(1002);
    RemoveBuff(1003);

    switch (stance)
    {
    case MageStance::Fire:
        AddBuff(
            1001,
            "Fire Stance",
            "assets/ui/textures/Spells/spell_fire.png",
            -1.f);
        break;

    case MageStance::Frost:
        AddBuff(
            1002,
            "Frost Stance",
            "assets/ui/textures/Spells/spell_frost.png",
            -1.f);
        break;

    case MageStance::Arcane:
        AddBuff(
            1003,
            "Arcane Stance",
            "assets/ui/textures/Spells/spell_arcane.png",
            -1.f);
        break;

    case MageStance::None:
    default:
        break;
    }
}

void HUD::AddDebuff(int id, const std::string& name, const std::string& iconPath, float duration)
{
    if (myDebuffFrame)
        myDebuffFrame->AddOrRefreshBuff(id, name, iconPath, duration);
}

void HUD::RemoveDebuff(int id)
{
    if (myDebuffFrame)
        myDebuffFrame->RemoveBuff(id);
}

bool HUD::HasDebuff(int id) const
{
    if (!myDebuffFrame)
        return false;

    return myDebuffFrame->HasBuff(id);
}

void HUD::ResolveBuffDebuffOverlap(float gap)
{
    if (!myBuffFrame || !myDebuffFrame)
        return;

    const Tga::Vector2f buffPos = myBuffFrame->GetPosition();
    const Tga::Vector2f buffHalf = myBuffFrame->GetHalfSize();

    const Tga::Vector2f debuffPos = myDebuffFrame->GetPosition();
    const Tga::Vector2f debuffHalf = myDebuffFrame->GetHalfSize();

    const float buffLeft = buffPos.x - buffHalf.x;
    const float buffRight = buffPos.x + buffHalf.x;
    const float buffBottom = buffPos.y - buffHalf.y;
    const float buffTop = buffPos.y + buffHalf.y;

    const float debuffLeft = debuffPos.x - debuffHalf.x;
    const float debuffRight = debuffPos.x + debuffHalf.x;
    const float debuffBottom = debuffPos.y - debuffHalf.y;
    const float debuffTop = debuffPos.y + debuffHalf.y;

    // No overlap => do nothing
    if (debuffRight <= buffLeft ||
        debuffLeft >= buffRight ||
        debuffTop <= buffBottom ||
        debuffBottom >= buffTop)
    {
        return;
    }

    // Amount needed to move debuff fully outside on each side
    const float moveLeft = (debuffRight - buffLeft) + gap;   // push debuff left
    const float moveRight = (buffRight - debuffLeft) + gap;   // push debuff right
    const float moveDown = (debuffTop - buffBottom) + gap;   // push debuff down
    const float moveUp = (buffTop - debuffBottom) + gap;   // push debuff up

    // Pick the smallest move
    float smallest = moveLeft;
    enum class ResolveDir { Left, Right, Down, Up };
    ResolveDir dir = ResolveDir::Left;

    if (moveRight < smallest)
    {
        smallest = moveRight;
        dir = ResolveDir::Right;
    }

    if (moveDown < smallest)
    {
        smallest = moveDown;
        dir = ResolveDir::Down;
    }

    if (moveUp < smallest)
    {
        smallest = moveUp;
        dir = ResolveDir::Up;
    }

    Tga::Vector2f newPos = debuffPos;

    switch (dir)
    {
    case ResolveDir::Left:
        newPos.x -= moveLeft;
        break;

    case ResolveDir::Right:
        newPos.x += moveRight;
        break;

    case ResolveDir::Down:
        newPos.y -= moveDown;
        break;

    case ResolveDir::Up:
        newPos.y += moveUp;
        break;
    }

    myDebuffFrame->SetPosition(newPos);
}

void HUD::RenderEditGrid(bool aShowGrid)
{
    if (!myScene)
        return;

    if (!aShowGrid)
        return;

    const auto& s = myHudEditSettings;
    if (!s.showGrid)
        return;

    auto uiCam = myScene->GetCamera();
    if (!uiCam)
        return;

    auto& engine = *Tga::Engine::GetInstance();
    auto& gss = engine.GetGraphicsEngine().GetGraphicsStateStack();

    Tga::DX11::BackBuffer->SetAsActiveTarget(Tga::DX11::DepthBuffer);

    gss.Push();
    gss.SetCamera(*uiCam);
    gss.SetBlendState(Tga::BlendState::AlphaBlend);

    const float grid = std::max(5.f, s.gridSize);

    const auto res = Tga::Engine::GetInstance()->GetRenderSize();

    const Tga::Vector2f worldBL = uiCam->GetScreenToWorldCoordinatesVec2({ 0.f, 0.f });
    const Tga::Vector2f worldTR = uiCam->GetScreenToWorldCoordinatesVec2({ (float)res.x, (float)res.y });

    const float left = std::min(worldBL.x, worldTR.x);
    const float right = std::max(worldBL.x, worldTR.x);
    const float bottom = std::min(worldBL.y, worldTR.y);
    const float top = std::max(worldBL.y, worldTR.y);

    auto& dd = Tga::Engine::GetInstance()->GetDebugDrawer();

    const Tga::Color minorColor = { 0.55f, 0.25f, 0.8f, 0.20f };
    const Tga::Color majorColor = { 0.80f, 0.35f, 1.0f, 0.45f };

    // Anchor grid around world origin
    const float centerX = 0.f;
    const float centerY = 0.f;

    // ----- Vertical lines -----
    {
        // Draw center line first
        dd.DrawLine(
            { centerX, bottom, 0.f },
            { centerX, top, 0.f },
            majorColor);

        // Draw to the right
        int step = 1;
        for (float x = centerX + grid; x <= right; x += grid, ++step)
        {
            const bool major = (step % 5) == 0;
            dd.DrawLine(
                { x, bottom, 0.f },
                { x, top, 0.f },
                major ? majorColor : minorColor);
        }

        // Draw to the left
        step = 1;
        for (float x = centerX - grid; x >= left; x -= grid, ++step)
        {
            const bool major = (step % 5) == 0;
            dd.DrawLine(
                { x, bottom, 0.f },
                { x, top, 0.f },
                major ? majorColor : minorColor);
        }
    }

    // ----- Horizontal lines -----
    {
        // Draw center line first
        dd.DrawLine(
            { left, centerY, 0.f },
            { right, centerY, 0.f },
            majorColor);

        // Draw upward
        int step = 1;
        for (float y = centerY + grid; y <= top; y += grid, ++step)
        {
            const bool major = (step % 5) == 0;
            dd.DrawLine(
                { left, y, 0.f },
                { right, y, 0.f },
                major ? majorColor : minorColor);
        }

        // Draw downward
        step = 1;
        for (float y = centerY - grid; y >= bottom; y -= grid, ++step)
        {
            const bool major = (step % 5) == 0;
            dd.DrawLine(
                { left, y, 0.f },
                { right, y, 0.f },
                major ? majorColor : minorColor);
        }
    }

    gss.Pop();
}

void HUD::SetEditMode(bool aEnabled)
{
    myEditMode = aEnabled;
    if (!myScene) return;

    if (myEditMode)
    {
        // hard-disable spellbook while editing
        if (mySpellBooks.IsOpen())
            mySpellBooks.Close();

        myIgnoreOutsideClick = false;
        myPendingBind.active = false;
        myPendingBind.targetSlot = nullptr;

        HideSpellTooltip();
        myPrevHoverSpell = nullptr;
        myPrevHoverSlot = nullptr;
    }

    for (auto& [type, btn] : myScene->GetButtons())
    {
        if (!btn) continue;
        btn->SetDraggable(myEditMode);
        if (!myEditMode) btn->CancelDrag();
    }

    myActionBars.SetEditMode(*myScene, myEditMode);

    if (myCastBarFrame) myCastBarFrame->SetEditMode(myEditMode);
    if (myPlayerFrame) myPlayerFrame->SetEditMode(myEditMode);
    if (myTargetFrame) myTargetFrame->SetEditMode(myEditMode);
    if (myBuffFrame) myBuffFrame->SetEditMode(myEditMode);
    if (myDebuffFrame) myDebuffFrame->SetEditMode(myEditMode);
    if (myStanceBar) myStanceBar->SetEditMode(myEditMode);

    for (int i = 0; i < 5; ++i)
    {
        if (myPartyFrames[i])
            myPartyFrames[i]->SetEditMode(myEditMode); // all draggable in editmode
    }
    ApplyHudEditSettings();
}

void HUD::ReceiveEvent(const Message& aMessage)
{
    if (aMessage.eventType == Event::CloseSpellBook)
    {
        if (mySpellBooks.IsOpen())
        {
            mySpellBooks.Close();
            myIgnoreOutsideClick = false;
        }

        myPendingBind.active = false;
        myPendingBind.targetSlot = nullptr;

        HideSpellTooltip();
        myPrevHoverSpell = nullptr;
        myPrevHoverSlot = nullptr;

        // if you have it:
        // myDragDrop.Cancel();
        return;
    }

    if (aMessage.eventType != Event::ToggleHudEditMode)
        return;

    const int enabledInt = std::get<int>(aMessage.data);
    SetEditMode(enabledInt != 0);
}




void HUD::ReceiveInput(InputEvent e, const std::any& data)
{
    switch (e)
    {
    case InputEvent::ToggleSpellBook:
    {
        if (myEditMode) // 🚫 do nothing while editing
            return;

        mySpellBooks.Toggle();
        myIgnoreOutsideClick = true;
        break;
    }
    case InputEvent::ActionKeyPressed:
    {
        const int key = std::any_cast<int>(data);
        if (myEditMode || mySpellBooks.IsOpen() || myDragDrop.IsDragging())
            return;

        // block all new spell casts while currently casting
        if (IsCastingSpell())
            return;

        if (auto* slot = myActionBars.GetSlotForActionKey(*myScene, key))
        {
            if (!slot->IsEmpty())
            {
                slot->TriggerPressFeedback();

                const ActionBarSpell& spell = slot->GetSpell();

                if (slot->IsOnCooldown())
                    return;

                if (spell.castTime > 0.f)
                {
                    StartCastBar(spell);
                }
                else
                {
                    TryActivateBuffFromSpell(this, spell);

                    if (spell.cooldown > 0.f)
                        slot->StartCooldown(spell.cooldown);
                }
            }
        }
        break;
    }

    default:
        break;
    }
}

void HUD::RegisterInput()
{
    if (myInputRegistered) return;

    RegisterToMapper({
        InputEvent::ToggleSpellBook,
        InputEvent::ActionKeyPressed
        });

    myInputRegistered = true;
}

void HUD::UnregisterInput()
{
    if (!myInputRegistered) return;

    UnRegisterToMapper({
        InputEvent::ToggleSpellBook,
        InputEvent::ActionKeyPressed
        });

    myInputRegistered = false;
}

void HUD::SetPendingBind(ActionBarSlotButton* slot)
{
    myPendingBind.active = (slot != nullptr);
    myPendingBind.targetSlot = slot;
}

void HUD::OpenSpellBookForSlot(ActionBarSlotButton* slot)
{
    if (!slot) return;
    if (myEditMode) return; // 🚫

    SetPendingBind(slot);
    mySpellBooks.OpenForSlot(slot, &myActionBars);
    myIgnoreOutsideClick = true;
}

void HUD::CloseSpellBook()
{
    if (mySpellBooks.IsOpen())
    {
        mySpellBooks.Close();
        myIgnoreOutsideClick = false;
        myPendingBind.active = false;
        myPendingBind.targetSlot = nullptr;
        HideSpellTooltip();
        myPrevHoverSpell = nullptr;
        myPrevHoverSlot = nullptr;
    }
}

bool HUD::IsSpellBookOpen() const
{
    return mySpellBooks.IsOpen();
}

void HUD::BeginDragFromSlot(ActionBarSlotButton* from)
{
    myDragDrop.BeginFromSlot(from);
}

void HUD::BeginDragFromSpell(const ActionBarSpell& spell)
{
    // Spellbook drag disabled (click-to-assign only)
    if (mySpellBooks.IsOpen())
        return;

    myDragDrop.BeginFromSpell(spell);
}

// ------------------------------------------------------
// 3D Helpers (unchanged logic)
// ------------------------------------------------------

void HUD::SetTransformFor3DSprite(Tga::Sprite3DInstanceData& aSprite,
    Tga::Matrix4x4f aTransform,
    Tga::Vector2f aSpriteSize,
    Tga::Vector2f aPivot)
{
    Tga::Matrix4x4f transform = Tga::Matrix4x4f::CreateFromTranslation(aTransform.GetPosition());
    transform.Translate(mySceneCamera->GetTransform().GetRight() * (Tga::Vector3f{ aPivot.x, aPivot.y, 1.f } *-0.5f));
    transform = Tga::Matrix4x4f::CreateFromRotation(mySceneCamera->GetTransform().GetRotationAsQuaternion()) *= transform;
    transform = Tga::Matrix4x4f::CreateFromScale(Tga::Vector3f{ aSpriteSize.x, aSpriteSize.y, 1.f }) * transform;
    aSprite.myTransform = transform;
}

Tga::Matrix4x4f HUD::CreateBillboardMatrix(const Tga::Vector3f& aPosition,
    const Tga::Vector3f& aTargetPosition,
    const Tga::Vector3f aScale)
{
    Tga::Vector3f direction = aPosition - aTargetPosition;
    direction.Normalize();

    Tga::Vector3f up = mySceneCamera->GetTransform().GetUp();
    Tga::Vector3f right = mySceneCamera->GetTransform().GetRight();

    Tga::Matrix4x4f billboard = Tga::Matrix4x4f::CreateIdentityMatrix();
    billboard.SetRight(right);
    billboard.SetUp(up);
    billboard.SetForward(direction);
    billboard.Scale(aScale);
    billboard.SetPosition(aPosition);
    return billboard;
}

void HUD::UpdateDockedHealthBar(int aCurrentHealth, int aMaxHealth)
{
    myBossSpriteInstance.myTextureRect.myEndX =
        static_cast<float>(aCurrentHealth) / static_cast<float>(aMaxHealth);
}

void HUD::ApplyHudEditSettings()
{
    const auto& s = myHudEditSettings;
    if (myPlayerFrame)
    {
        myPlayerFrame->SetVisible(s.playerFrame);
        if (!s.playerFrame)
            myPlayerFrame->CancelDrag();
    }

    if (myTargetFrame)
    {
        myTargetFrame->SetVisible(s.targetAndFocus);
        if (!s.targetAndFocus)
            myTargetFrame->CancelDrag();
    }

    for (int i = 0; i < 5; ++i)
    {
        if (myPartyFrames[i])
        {
            myPartyFrames[i]->SetVisible(s.partyFrames);
            if (!s.partyFrames)
                myPartyFrames[i]->CancelDrag();
        }
    }

    if (myBuffFrame)
    {
        myBuffFrame->SetVisible(s.buffsDebuffs);
        if (!s.buffsDebuffs)
            myBuffFrame->CancelDrag();
    }

    if (myDebuffFrame)
    {
        myDebuffFrame->SetVisible(s.buffsDebuffs);
        if (!s.buffsDebuffs)
            myDebuffFrame->CancelDrag();
    }

    if (myCastBarFrame)
    {
        const bool showCastBarInEdit = myEditMode && s.castBar;
        const bool showCastBarInGame = !myEditMode && s.castBar && myCastBarFrame->IsCasting();

        myCastBarFrame->SetVisible(showCastBarInEdit || showCastBarInGame);

        if (!s.castBar)
            myCastBarFrame->CancelDrag();
    }

    if (myStanceBar)
    {
        myStanceBar->SetVisible(s.stanceBar);
    }

}

void HUD::ApplyPartyFrameSettings()
{
    for (int i = 0; i < 5; ++i)
    {
        if (!myPartyFrames[i])
            continue;

        myPartyFrames[i]->SetUseRaidStyle(myPartyFrameSettings.useRaidStyle);
        myPartyFrames[i]->SetUseHorizontalLayout(myPartyFrameSettings.useHorizontal);
        myPartyFrames[i]->SetFrameScale(myPartyFrameSettings.frameScale);
        myPartyFrames[i]->SetRaidFrameWidth(myPartyFrameSettings.raidWidth);
        myPartyFrames[i]->SetRaidFrameHeight(myPartyFrameSettings.raidHeight);

        myPartyFrames[i]->RefreshLayout();
    }
}

Tga::Vector2f HUD::GetPartyFrameSettingsPopupPos() const
{
    float rightMost = -100000.f;
    float topMost = -100000.f;
    bool found = false;

    for (const auto& frame : myPartyFrames)
    {
        if (!frame || !frame->IsVisible())
            continue;

        const Tga::Vector2f pos = frame->GetPosition();
        const Tga::Vector2f half = frame->GetHalfSize();

        rightMost = std::max(rightMost, pos.x + half.x);
        topMost = std::max(topMost, pos.y + half.y);
        found = true;
    }

    if (!found || !myScene || !myScene->GetCamera())
        return { 0.f, 0.f };

    const Tga::Vector2f popupSize =
        myPartyFrameSettings.useRaidStyle
        ? Tga::Vector2f{ 520.f, 460.f }
    : Tga::Vector2f{ 520.f, 220.f };

    const float margin = 20.f;

    // Preferred position: to the right of the party frames
    Tga::Vector2f preferred =
    {
        rightMost + margin + popupSize.x * 0.5f,
        topMost - popupSize.y * 0.5f
    };

    // Screen bounds in UI world space
    const auto res = Tga::Engine::GetInstance()->GetRenderSize();
    const float screenW = static_cast<float>(res.x);
    const float screenH = static_cast<float>(res.y);

    const auto uiCam = myScene->GetCamera();

    const Tga::Vector2f worldBL = uiCam->GetScreenToWorldCoordinatesVec2({ 0.f, 0.f });
    const Tga::Vector2f worldTR = uiCam->GetScreenToWorldCoordinatesVec2({ screenW, screenH });

    const float popupHalfW = popupSize.x * 0.5f;
    const float popupHalfH = popupSize.y * 0.5f;

    const bool outsideRight = preferred.x + popupHalfW > worldTR.x;
    const bool outsideLeft = preferred.x - popupHalfW < worldBL.x;
    const bool outsideTop = preferred.y + popupHalfH > worldTR.y;
    const bool outsideBottom = preferred.y - popupHalfH < worldBL.y;

    // If popup would be outside even a little -> center it
    if (outsideRight || outsideLeft || outsideTop || outsideBottom)
    {
        return (worldBL + worldTR) * 0.5f;
    }

    return preferred;
}
