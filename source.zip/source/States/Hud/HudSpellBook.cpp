﻿#include "HudSpellBook.h"

#include <tge/engine.h>
#include <tge/texture/TextureManager.h>
#include <tge/drawers/SpriteDrawer.h>

#include "../../SceneManagement/MenuScene.h"
#include "../../States/ActionBars/SpellBookSpellButton.h"
#include "../../States/ActionBars/ActionBarSlotButton.h" 
#include "HUD.h"
#include "HudActionBarsController.h"
#include "States/ActionBars/SpellBookSpellButton.h"

#include "Utilities/UITextUtils.h" 

void HudSpellBook::Init(HUD& hud, MenuScene& scene, std::shared_ptr<Tga::Camera> uiCam)
{
    myHUD = &hud;
    myScene = &scene;
    myUiCam = std::move(uiCam);

    // init textures once
    auto& tm = Tga::Engine::GetInstance()->GetTextureManager();

    myDimShared.myTexture = tm.GetTexture("assets/ui/textures/black_overlay.png");
    myDimShared.blendState = Tga::BlendState::AlphaBlend;
    myDimShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;
    myDimInst.myPivot = { 0.5f, 0.5f };
    myDimInst.myIsHidden = false;
    myDimInst.myColor = { 1.f, 1.f, 1.f, 0.90f };

    myBgShared.myTexture = tm.GetTexture("assets/ui/textures/spellbook_panel.png");
    myBgShared.blendState = Tga::BlendState::AlphaBlend;
    myBgShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;
    myBgInst.myPivot = { 0.5f, 0.5f };
    myBgInst.myIsHidden = false;
    myBgInst.myColor = { 1.f, 1.f, 1.f, 0.90f };

    myBgInit = true;
}

void HudSpellBook::Toggle()
{
    if (myOpen) Close();
    else Open(nullptr);
}

void HudSpellBook::Open(const HudActionBarsController* bars)
{
    if (!myScene) return;

    myOpen = true;

    EnsureLoadedSpells();
    LayoutAndApply(bars);
}

void HudSpellBook::Close()
{
    myOpen = false;
    myHasAnchor = false;
    myCachedHover = nullptr;

    // hide buttons
    for (auto& b : myButtons)
    {
        auto sb = std::dynamic_pointer_cast<SpellBookSpellButton>(b);
        if (sb)
        {
            sb->CancelDrag();
            sb->SetVisible(false);
            sb->SetPosition({ -999999.f, -999999.f });
            sb->SetDraggable(false);
        }
    }

    if (auto sb = std::dynamic_pointer_cast<SpellBookSpellButton>(myDontSetButton))
    {
        sb->CancelDrag();
        sb->SetVisible(false);
        sb->SetPosition({ -999999.f, -999999.f });
        sb->SetDraggable(false);
    }
       
}

void HudSpellBook::RenderBackdrop(Tga::SpriteDrawer& spriteDrawer)
{
    if (!myOpen || !myBgInit ) return;

    spriteDrawer.Draw(myDimShared, myDimInst);
    spriteDrawer.Draw(myBgShared, myBgInst);
}

bool HudSpellBook::IsMouseInside(const Tga::Vector2f& mouseWorld) const
{
    if (!myOpen) return false;

    if (myBgInit && PointInRectCenterSize(mouseWorld, myBgInst.myPosition, myBgInst.mySize))
        return true;

    // allow buttons outside panel
    if (HitTestButtonsInternal(mouseWorld))
        return true;

    return false;
}

SpellBookSpellButton* HudSpellBook::HitTest(const Tga::Vector2f& mouseWorld)
{
    if (!myOpen) return nullptr;
    return HitTestButtonsInternal(mouseWorld);
}

const ActionBarSpell* HudSpellBook::GetHoverSpell(const Tga::Vector2f& mouseWorld)
{
    SpellBookSpellButton* b = HitTest(mouseWorld);
    if (!b) return nullptr;
    return &b->GetSpell();
}

void HudSpellBook::OpenForSlot(ActionBarSlotButton* slot, const HudActionBarsController* bars)
{
    if (!slot) return;

    const float lift = 18.f;
    myAnchorWorld = slot->GetPosition() + Tga::Vector2f{ 0.f, slot->GetHalfSize().y + lift };
    myAnchorHalf = slot->GetHalfSize();
    myHasAnchor = true;

    Open(bars);
}

void HudSpellBook::EnsureLoadedSpells()
{
   
    if (myAllSpells.empty())
    {
        myAllSpells.push_back({ 1,"Frostbolt",
            "assets/ui/textures/Spells/Frostbolt.png",
            "Rank 1",
            SpellSchool::Frost,
            20,                      // 2% base mana (fake example value)
            1.75f,                   // cast time
            0.f,                     // cooldown
            40,                      // range
            0, 0,                    // no flat base damage
            2.72f,                   // 272% spell power scaling
            0, 0.f,                  // no DoT
            "Launches a bolt of frost at the enemy, causing (272% of Spell Power) Frost damage and slowing movement speed by 50% for 8 sec."
            });

        myAllSpells.push_back({ 2,"Fireball",
            "assets/ui/textures/Spells/Fireball.jpg",
            "Level 60",
            SpellSchool::Fire,
            30,                      // mana
            1.5f,                    // cast time
            0.f,                     // cooldown
            35,                      // range
            16, 25,                  // base damage
            0.f,                     // spell power scaling (not provided)
            2, 4.f,                  // DoT: 2 damage over 4 sec
            "Hurls a fiery ball that causes 16 to 25 Fire damage and an additional 2 Fire damage over 4 sec."
            });

        myAllSpells.push_back({ 3,"Cone of Cold",
            "assets/ui/textures/Spells/Cone_of_Cold.jpg",
            "",
            SpellSchool::Frost,
            0,                       // mana
            0.f,                     // instant
            0.f,                     // cooldown 
            0,                       // range 
            0, 0,          // base damage
            0.f,                     // spell power scaling (not provided)
            0, 0.f,    // none
            "Inflicts Frost damage to enemies in a cone in front of the caster, reducing their movement speed for 8 sec."
            });

        myAllSpells.push_back({ 4,"Blizzard",
            "assets/ui/textures/Spells/Blizzard.jpg",
            "Level 60",
            SpellSchool::Frost,
            520,                     // mana
            8.f,                     // channeled 8 sec
            0.f,                     // cooldown not provided
            30,                      // range
            0, 0,                    // not provided as min/max here (total given)
            0.f,                     // not provided
            0, 0.f,                  // none
            "Ice shards pelt the target area doing 360 Frost damage over 8 sec."
            });

        myAllSpells.push_back({ 5,"Fire Blast",
            "assets/ui/textures/Spells/Fire_Blast.jpg",
            "Level 60",
            SpellSchool::Fire,
            340,                     // mana
            0.f,                     // instant
            8.f,                     // cooldown
            20,                      // range
            446, 524,                // damage
            0.f,                     // not provided
            0, 0.f,                  // none
            "Blasts the enemy for 446 to 524 Fire damage."
            });

        myAllSpells.push_back({ 6,"Flamestrike",
            "assets/ui/textures/Spells/Flamestrike.jpg",
            "Talent",
            SpellSchool::Fire,
            15,                      // 1.5% base mana -> store as 15 (you can interpret as % in UI)
            3.5f,                    // cast time
            0.f,                     // cooldown not provided
            40,                      // range
            0, 0,                    // not provided as flat min/max
            3.00f,                   // 300% spell power
            0, 0.f,                  // none
            "Calls down a pillar of fire, burning all enemies within the area for (300% of Spell Power) Fire damage. Deals reduced damage beyond 8 targets."
            });

        myAllSpells.push_back({ 7,"Frost Nova",
            "assets/ui/textures/Spells/Frost_Nova.jpg",
            "Level 60",
            SpellSchool::Frost,
            145,                     // mana
            0.f,                     // instant
            25.f,                    // cooldown
            0,                       // range not provided
            71, 79,                  // damage
            0.f,                     // not provided
            0, 0.f,                  // none
            "Blasts enemies near the caster for 71 to 79 Frost damage and freezes them in place for up to 8 sec. Damage caused may interrupt the effect."
            });

        myAllSpells.push_back({ 8,"Arcane Explosion",
            "assets/ui/textures/Spells/Arcane_Explosion.jpg",
            "Level 60",
            SpellSchool::Arcane,
            75,                      // mana
            0.f,                     // instant
            0.f,                     // cooldown not provided
            0,                       // self/aoe radius given instead
            34, 38,                  // damage
            0.f,                     // not provided
            0, 0.f,                  // none
            "Causes an explosion of arcane magic around the caster, causing 34 to 38 Arcane damage to all targets within 10 yards."
            });

        myAllSpells.push_back({ 9,"Arcane Intellect",
            "assets/ui/textures/Spells/Arcane_Intellect.jpg",
            "",
            SpellSchool::Arcane,
            60,                      // mana
            0.f,                     // instant
            0.f,                     // cooldown not provided
            30,                      // range
            0, 0,                    // none
            0.f,                     // none
            0, 0.f,                  // none
            "Increases the target's Intellect by 2 for 30 min."
            });

        myAllSpells.push_back({ 10,"Dampen Magic",
            "assets/ui/textures/Spells/Dampen_Magic.jpg",
            "",
            SpellSchool::Arcane,
            100,                     // mana
            0.f,                     // instant
            0.f,                     // cooldown not provided
            30,                      // range
            0, 0,                    // none
            0.f,                     // none
            0, 0.f,                  // none
            "Dampens magic used against the targeted party member, decreasing damage taken from spells by up to 10 and healing spells by up to 20. Lasts 10 min."
            });

        myAllSpells.push_back({ 11,"Amplify Magic",
            "assets/ui/textures/Spells/Amplify_Magic.jpg",
            "",
            SpellSchool::Arcane,
            450,                     // mana
            0.f,                     // instant
            0.f,                     // cooldown not provided
            30,                      // range
            0, 0,                    // none
            0.f,                     // none
            0, 0.f,                  // none
            "Amplifies magic used against the targeted party member, increasing damage taken from spells by up to 75 and healing spells by up to 150. Lasts 10 min."
            });

        myAllSpells.push_back({ 12,"Blink",
            "assets/ui/textures/Spells/Blink.jpg",
            "",
            SpellSchool::Arcane,
            35,                      // 35% of base mana -> store as 35 (interpret as % in UI)
            0.f,                     // instant
            15.f,                    // cooldown
            0,                       // range n/a (movement)
            0, 0,                    // none
            0.f,                     // none
            0, 0.f,                  // none
            "Teleports the caster 20 yards forward, unless something is in the way. Also frees the caster from stuns and bonds."
            });
    }
}

void HudSpellBook::EnsureButtons(int count)
{
    while ((int)myButtons.size() < count)
    {
        auto b = std::make_shared<SpellBookSpellButton>();
        b->InitRuntime({ 0,0 }, { 100.f, 100.f }); // will be resized in layout
        b->SetHUD(myHUD);

        myScene->AddModalRuntimeButton(b);
    	b->SetCamera(myUiCam);
        b->RegisterInput();

        myButtons.push_back(b);
    }

    if (!myDontSetButton)
    {
        auto b = std::make_shared<SpellBookSpellButton>();
        b->InitRuntime({ 0,0 }, { 100.f, 100.f });
        b->SetHUD(myHUD);

        myScene->AddModalRuntimeButton(b); 
    	b->SetCamera(myUiCam);
        b->RegisterInput();

        myDontSetButton = b;
    }
}

void HudSpellBook::LayoutAndApply(const HudActionBarsController* bars)
{
    const float baseSlotSize = 100.f;
    const float basePad = 10.f;
    const int   cols = 5;
    const float cancelScale = 1.5f;
    const float cancelRowScale = cancelScale;
    const float basePaddingAroundGrid = 25.f;

    const int count = (int)myAllSpells.size();
    const int rowsSpells = (count + cols - 1) / cols;

    const float slotSizeX = baseSlotSize * myPanelScale.x;
    const float slotSizeY = baseSlotSize * myPanelScale.y;

    const float padX = basePad * myPanelScale.x;
    const float padY = basePad * myPanelScale.y;

    const float extraX = basePaddingAroundGrid * myPanelScale.x;
    const float extraY = basePaddingAroundGrid * myPanelScale.y;

    const float gridW = cols * slotSizeX + (cols - 1) * padX;
    const float normalRowH = slotSizeY;
    const float normalGapY = padY;

    const float cancelRowH = slotSizeY * cancelRowScale;

    const float gridH =
        cancelRowH + normalGapY +
        (rowsSpells * normalRowH) +
        ((rowsSpells - 1) * normalGapY);

    float panelW = gridW + extraX * 2.f;
    float panelH = gridH + extraY * 2.f;

    if (panelW < myPanelMinW) panelW = myPanelMinW;
    if (panelH < myPanelMinH) panelH = myPanelMinH;

    const auto resI = Tga::Engine::GetInstance()->GetRenderSize();
    const Tga::Vector2f res{ (float)resI.x, (float)resI.y };
    const Tga::Vector2f screenCenter{ res.x * 0.5f, res.y * 0.5f };

    // ✅ compute clamp space ONCE (needs camera)
    const Tga::Vector2f worldBL = myUiCam->GetScreenToWorldCoordinatesVec2({ 0.f, 0.f });
    const Tga::Vector2f worldTR = myUiCam->GetScreenToWorldCoordinatesVec2({ res.x, res.y });

    const float halfW = panelW * 0.5f;
    const float halfH = panelH * 0.5f;

    auto clampToScreen = [&](Tga::Vector2f c)
        {
            c.x = std::max(worldBL.x + halfW, std::min(c.x, worldTR.x - halfW));
            c.y = std::max(worldBL.y + halfH, std::min(c.y, worldTR.y - halfH));
            return c;
        };

    // --- pick initial center ---
    Tga::Vector2f panelCenter = screenCenter + myPanelPos;

    if (myHasAnchor)
        panelCenter = FindSpellBookCenterAvoidingBars(bars, myAnchorWorld, panelW, panelH);

    // ✅ clamp -> nudge -> clamp (after nudge)
    panelCenter = clampToScreen(panelCenter);
    panelCenter = NudgeRectOutOfBars(bars, panelCenter, panelW, panelH);
    panelCenter = clampToScreen(panelCenter);

    // apply bg (panel)
    myBgInst.myPosition = panelCenter;
    myBgInst.mySize = { panelW, panelH };

    // ✅ dim overlay should match panel (slightly bigger)
    const float pad = 20.f; // tweak
    myDimInst.myPosition = panelCenter;
    myDimInst.mySize = { panelW + pad * 2.f, panelH + pad * 2.f };
    myDimInst.myPivot = { 0.5f, 0.5f };
    myDimInst.myIsHidden = false;

    EnsureButtons(count);

    // start position (cancel row)
    const Tga::Vector2f start{
        panelCenter.x - halfW + extraX + slotSizeX * 0.5f,
        panelCenter.y + halfH - extraY - cancelRowH * 0.5f
    };

    const float spellsStartY = start.y - (cancelRowH * 0.5f + normalGapY + normalRowH * 0.5f);

    // cancel button
    if (auto dontSet = std::dynamic_pointer_cast<SpellBookSpellButton>(myDontSetButton))
    {
        ActionBarSpell s{};
        s.id = kDontSetSpellId;
        s.name = "Cancel";
        s.iconTexturePath = "assets/ui/textures/ActionBarSlotDontSetSpell.png";
        dontSet->SetSpell(s);

        dontSet->SetSize({ slotSizeX * cancelScale, slotSizeY * cancelScale });

        const int centerCol = cols / 2;
        dontSet->SetPosition({ start.x + centerCol * (slotSizeX + padX), start.y });
        dontSet->SetVisible(true);
    }

    // normal spell buttons
    for (int i = 0; i < (int)myButtons.size(); ++i)
    {
        auto sb = std::dynamic_pointer_cast<SpellBookSpellButton>(myButtons[i]);
        if (!sb) continue;

        if (i < count)
        {
            sb->SetSpell(myAllSpells[i]);
            sb->SetSize({ slotSizeX, slotSizeY });

            const int x = i % cols;
            const int y = i / cols;

            sb->SetPosition({
                start.x + x * (slotSizeX + padX),
                spellsStartY - y * (normalRowH + normalGapY)
                });

            sb->SetVisible(true);
        }
        else
        {
            sb->SetVisible(false);
        }
    }
}




SpellBookSpellButton* HudSpellBook::HitTestButtonsInternal(const Tga::Vector2f& mouseWorld) const
{
    // normal spell buttons
    for (auto& b : myButtons)
    {
        auto sb = std::dynamic_pointer_cast<SpellBookSpellButton>(b);
        if (!sb || !sb->IsVisible()) continue;

        const auto p = sb->GetPosition();
        const auto h = sb->GetHalfSize();

        const bool inside =
            mouseWorld.x >= p.x - h.x && mouseWorld.x <= p.x + h.x &&
            mouseWorld.y >= p.y - h.y && mouseWorld.y <= p.y + h.y;

        if (inside) return sb.get();
    }

    // cancel
    if (auto sb = std::dynamic_pointer_cast<SpellBookSpellButton>(myDontSetButton))
    {
        if (sb->IsVisible())
        {
            const auto p = sb->GetPosition();
            const auto h = sb->GetHalfSize();

            const bool inside =
                mouseWorld.x >= p.x - h.x && mouseWorld.x <= p.x + h.x &&
                mouseWorld.y >= p.y - h.y && mouseWorld.y <= p.y + h.y;

            if (inside) return sb.get();
        }
    }

    return nullptr;
}

std::vector<Rect> HudSpellBook::GetActionBarRects(const HudActionBarsController* bars, float pad) const
{
    if (!bars || !myScene)
        return {};

    return bars->GetBarRects(*myScene, pad);
}

Tga::Vector2f HudSpellBook::NudgeRectOutOfBars(const HudActionBarsController* bars,
    Tga::Vector2f center, float w, float h) const
{
    if (!bars || !myScene) return center;

    const auto avoid = bars->GetBarRects(*myScene, 12.f);
    if (avoid.empty()) return center;

    const auto resI = Tga::Engine::GetInstance()->GetRenderSize();
    const Tga::Vector2f res{ (float)resI.x, (float)resI.y };

    const Tga::Vector2f worldBL = myUiCam->GetScreenToWorldCoordinatesVec2({ 0.f, 0.f });
    const Tga::Vector2f worldTR = myUiCam->GetScreenToWorldCoordinatesVec2({ res.x, res.y });

    const float halfW = w * 0.5f;
    const float halfH = h * 0.5f;

    auto clamp = [&](Tga::Vector2f c)
        {
            c.x = std::max(worldBL.x + halfW, std::min(c.x, worldTR.x - halfW));
            c.y = std::max(worldBL.y + halfH, std::min(c.y, worldTR.y - halfH));
            return c;
        };

    for (int it = 0; it < 12; ++it)
    {
        Rect r = MakeRectCenterSize(center, w, h);
        bool moved = false;

        for (const auto& a : avoid)
        {
            if (!Overlaps(r, a)) continue;

            const float pushLeft = (r.max.x - a.min.x);
            const float pushRight = (a.max.x - r.min.x);
            const float pushDown = (r.max.y - a.min.y);
            const float pushUp = (a.max.y - r.min.y);

            float best = pushLeft;
            Tga::Vector2f delta{ -pushLeft, 0.f };

            if (pushRight < best) { best = pushRight; delta = { pushRight, 0.f }; }
            if (pushDown < best) { best = pushDown;  delta = { 0.f, -pushDown }; }
            if (pushUp < best) { best = pushUp;    delta = { 0.f,  pushUp }; }

            // small gap
            delta.x += (delta.x < 0 ? -10.f : (delta.x > 0 ? 10.f : 0.f));
            delta.y += (delta.y < 0 ? -10.f : (delta.y > 0 ? 10.f : 0.f));

            center = clamp(center + delta);
            moved = true;
            break;
        }

        if (!moved) break;
    }

    return center;
}

Tga::Vector2f HudSpellBook::FindSpellBookCenterAvoidingBars(const HudActionBarsController* bars,
    const Tga::Vector2f& anchor, float panelW, float panelH) const
{
    const auto resI = Tga::Engine::GetInstance()->GetRenderSize();
    const Tga::Vector2f res{ (float)resI.x, (float)resI.y };

    const Tga::Vector2f worldBL = myUiCam->GetScreenToWorldCoordinatesVec2({ 0.f, 0.f });
    const Tga::Vector2f worldTR = myUiCam->GetScreenToWorldCoordinatesVec2({ res.x, res.y });

    const float halfW = panelW * 0.5f;
    const float halfH = panelH * 0.5f;

    auto clampToScreen = [&](Tga::Vector2f c)
        {
            c.x = std::max(worldBL.x + halfW, std::min(c.x, worldTR.x - halfW));
            c.y = std::max(worldBL.y + halfH, std::min(c.y, worldTR.y - halfH));
            return c;
        };

    const auto avoid = (bars && myScene) ? bars->GetBarRects(*myScene, 12.f) : std::vector<Rect>{};

    const float gap = 18.f;
    const float screenMidX = (worldBL.x + worldTR.x) * 0.5f;
    const bool preferLeft = anchor.x > screenMidX;

    std::vector<Tga::Vector2f> candidates;

    candidates.push_back({ anchor.x, anchor.y + halfH + gap }); // above
    candidates.push_back({ anchor.x, anchor.y - halfH - gap }); // below

    if (preferLeft) 
    {
        candidates.push_back({ anchor.x - halfW - gap, anchor.y });
        candidates.push_back({ anchor.x + halfW + gap, anchor.y });
    }
    else 
    {
        candidates.push_back({ anchor.x + halfW + gap, anchor.y });
        candidates.push_back({ anchor.x - halfW - gap, anchor.y });
    }

    candidates.push_back({ anchor.x + halfW + gap, anchor.y + halfH + gap });
    candidates.push_back({ anchor.x - halfW - gap, anchor.y + halfH + gap });
    candidates.push_back({ anchor.x + halfW + gap, anchor.y - halfH - gap });
    candidates.push_back({ anchor.x - halfW - gap, anchor.y - halfH - gap });

    Tga::Vector2f best = clampToScreen(candidates[0]);
    float bestScore = 1e30f;

    for (auto c : candidates)
    {
        c = clampToScreen(c);
        Rect r = MakeRectCenterSize(c, panelW, panelH);

        int overlaps = 0;
        for (auto& a : avoid) if (Overlaps(r, a)) overlaps++;

        float score = overlaps * 1000000.f;

        const Tga::Vector2f d = c - anchor;
        score += d.x * d.x + d.y * d.y;

        if (score < bestScore)
        {
            bestScore = score;
            best = c;
        }
    }

    return best;
}



