#include "HudKeybindPopupController.h"
#include "../../SceneManagement/MenuScene.h"
#include <tge/drawers/SpriteDrawer.h>
#include <tge/input/InputManager.h>

void HudKeybindPopupController::Init(std::shared_ptr<MenuScene> scene)
{
    myScene = std::move(scene);
    if (!myScene) return;

    myKeybinds.InitPopup(*myScene, myScene->GetCamera());
}

bool HudKeybindPopupController::Update(Tga::InputManager* im, const Tga::Vector2f& mouseWorld)
{
    // modal update: return true if it ate input
    return myKeybinds.UpdatePopup(im, mouseWorld);
}

void HudKeybindPopupController::Render(Tga::SpriteDrawer& drawer)
{
    myKeybinds.RenderPopup(drawer);
}

void HudKeybindPopupController::TryOpenPopupOnCtrlClick(Tga::InputManager* im, ActionBarSlotButton* slot)
{
    if (!im || !slot) return;
    if (im->IsKeyHeld(VK_CONTROL) && im->IsKeyPressed(VK_LBUTTON))
    {
        myKeybinds.OpenPopup(slot);
    }
}
