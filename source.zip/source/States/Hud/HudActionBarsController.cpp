#include "HudActionBarsController.h"
#include "../../SceneManagement/MenuScene.h"
#include "States/ActionBars/ActionBar.h"
#include "States/ActionBars/ActionBarSlotButton.h" // if you have it; otherwise forward-declare + include where needed
#include "HUD.h"

#include <tge/Engine.h>


void HudActionBarsController::EnsureDefaultBars(HUD& hud, MenuScene& scene)
{
    (void)hud;

    if (!scene.GetActionBars().empty())
        return;

    // Bar 1 (bottom-left)
    {
        auto bar = std::make_shared<ActionBar>();
        auto l = bar->GetLayout();
        bar->Init(hud, scene, 1, 12, { -750.f, -820.f });
        bar->SetLayout({
            .columns = 12,
            .rows = 1,
            .iconSize = l.iconSize,
            .padding = 1.f,
            .snapToGrid = false,
            .gridSize = l.gridSize,
            .visibleSlots = 12,
            .autoColumns = false
            });
        const char* binds[12] = { "1","2","3","4","5","6","7","8","9","0","-","=" };
        const auto& slots = bar->GetSlots();
        for (int i = 0; i < 12 && i < (int)slots.size(); ++i)
            slots[i]->SetKeybindText(binds[i]);

        scene.AddActionBar(bar);
    }

    // Bar 2 (above bar 1)
    {
        auto bar = std::make_shared<ActionBar>();
        auto l = bar->GetLayout();
        bar->Init(hud, scene, 2, 12, { -750.f, -670.f });
        bar->SetLayout({
            .columns = 12,
            .rows = 1,
            .iconSize = l.iconSize,
            .padding = 1.f,
            .snapToGrid = false,
            .gridSize = l.gridSize,
            .visibleSlots = 12,
            .autoColumns = false
            });

        const char* binds[12] = { "S-1","S-2","S-3","S-4","S-5","S-6","S-7","S-8","S-9","S-0","S--","S-=" };
        const auto& slots = bar->GetSlots();
        for (int i = 0; i < 12 && i < (int)slots.size(); ++i)
            slots[i]->SetKeybindText(binds[i]);

        scene.AddActionBar(bar);
    }

    // Right vertical bar 1
    {
        auto bar = std::make_shared<ActionBar>();
        bar->Init(hud, scene, 3, 8, { 1550.f, 500.f });
        ActionBarLayout l{};
        l.columns = 1;
        l.rows = 8;              


        l.visibleSlots = 8;
        l.iconSize = 100.f;
        l.padding = 1.f;
        l.snapToGrid = false;
        l.gridSize = 50.f;
        l.autoColumns = false;
        bar->SetLayout(l);

        scene.AddActionBar(bar);
    }

    // Right vertical bar 2
    {
        auto bar = std::make_shared<ActionBar>();
        bar->Init(hud, scene, 4, 8, { 1450.f, 500.f });
        ActionBarLayout l{};
        l.columns = 1;
        l.rows = 8;              
        l.visibleSlots = 8;
        l.iconSize = 100.f;
        l.padding = 1.f;
        l.snapToGrid = false;
        l.gridSize = 50.f;
        l.autoColumns = false;
        bar->SetLayout(l);

        scene.AddActionBar(bar);
    }
}

void HudActionBarsController::SetEditMode(MenuScene& scene, bool enabled)
{
    for (auto& bar : scene.GetActionBars())
        if (bar) bar->SetEditMode(enabled);
}

void HudActionBarsController::Update(MenuScene& scene, float dt)
{
    for (auto& bar : scene.GetActionBars())
        if (bar) bar->Update(dt);
}

void HudActionBarsController::RenderDebug(MenuScene& scene)
{
    (void)scene;
    // optional for later (bounds, ids, etc.)
}

ActionBarSlotButton* HudActionBarsController::HitTestSlot(MenuScene& scene, const Tga::Vector2f& mouseWorld)
{
    for (auto& bar : scene.GetActionBars())
    {
        if (!bar || !bar->IsVisible()) continue;

        for (auto& s : bar->GetSlots())
        {
            auto* slot = s.get();
            if (!slot) continue;

            const auto p = slot->GetPosition();
            const auto h = slot->GetHalfSize();

            const bool inside =
                mouseWorld.x >= p.x - h.x && mouseWorld.x <= p.x + h.x &&
                mouseWorld.y >= p.y - h.y && mouseWorld.y <= p.y + h.y;

            if (inside)
                return slot;
        }
    }
    return nullptr;
}

ActionBarSlotButton* HudActionBarsController::GetSlotForActionKey(MenuScene& scene, int actionKey)
{
    const int idx = actionKey - 1;
    if (idx < 0) return nullptr;

    for (auto& bar : scene.GetActionBars())
    {
        if (!bar || !bar->IsVisible()) continue;

        const auto& slots = bar->GetSlots();
        if (idx >= 0 && idx < (int)slots.size())
            return slots[idx].get();
    }
    return nullptr;
}

std::vector<Rect> HudActionBarsController::GetBarRects(MenuScene& scene, float pad) const
{
    std::vector<Rect> out;

    for (auto& bar : scene.GetActionBars())
    {
        if (!bar || !bar->IsVisible()) continue;

        Tga::Vector2f mn = bar->GetBoundsMin();
        Tga::Vector2f mx = bar->GetBoundsMax();

        if (mn.x > mx.x) std::swap(mn.x, mx.x);
        if (mn.y > mx.y) std::swap(mn.y, mx.y);

        mn.x -= pad; mn.y -= pad;
        mx.x += pad; mx.y += pad;

        out.push_back({ mn, mx });
    }

    return out;
}