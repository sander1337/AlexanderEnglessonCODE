#include "PartyFrame.h"
#include <tge/engine.h>
#include <tge/texture/TextureManager.h>
#include <tge/drawers/SpriteDrawer.h>
#include <tge/graphics/GraphicsEngine.h>
#include <tge/graphics/GraphicsStateStack.h>
#include <tge/drawers/DebugDrawer.h>
#include "States/Hud/HUD.h"

void PartyFrame::InitRuntimeFrame(HUD* hud,
    const std::shared_ptr<Tga::Camera>& uiCam,
    const Tga::Vector2f& anchorPos,
    const Tga::Vector2f& size,
    int partyIndex)
{
    myHUD = hud;
    myAnchorPos = anchorPos;
    myPartyIndex = partyIndex;
    myNormalFrameSize = size;

    // Button base
    InitRuntime(anchorPos, size);   // temp, we immediately SyncAutoPosition
    SetCamera(uiCam);
    SetVisible(true);

    auto& tm = Tga::Engine::GetInstance()->GetTextureManager();

    // Textures (same as PlayerFrame)
    myFrameShared.myTexture = tm.GetTexture("assets/ui/textures/frames/player_frame.png");
    myFrameShared.blendState = Tga::BlendState::AlphaBlend;
    myFrameShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    myFrameInst.myPivot = { 0.5f, 0.5f };
    myFrameInst.myIsHidden = (myFrameShared.myTexture == nullptr);
    myFrameInst.myColor = { 1,1,1,1 };

    myPortraitShared.myTexture = tm.GetTexture("assets/ui/textures/frames/player_portrait_circle.png");
    myPortraitShared.blendState = Tga::BlendState::AlphaBlend;
    myPortraitShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    myPortraitInst.myPivot = { 0.5f, 0.5f };
    myPortraitInst.myIsHidden = (myPortraitShared.myTexture == nullptr);
    myPortraitInst.myColor = { 1,1,1,1 };

    auto white = tm.GetTexture("assets/ui/textures/white_1x1.png");

    myRaidBgShared.myTexture = white;
    myRaidBgShared.blendState = Tga::BlendState::AlphaBlend;
    myRaidBgShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    myRaidBgInst.myPivot = { 0.5f, 0.5f };
    myRaidBgInst.myColor = { 0.2f, 0.2f, 0.2f, 1.f };
    myRaidBgInst.myIsHidden = false;

    myNameBgShared.myTexture = white;
    myNameBgShared.blendState = Tga::BlendState::AlphaBlend;
    myNameBgShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;
    myNameBgInst.myPivot = { 0.5f, 0.5f };
    myNameBgInst.myIsHidden = (myNameBgShared.myTexture == nullptr);
    myNameBgInst.myColor = { 0.05f, 0.05f, 0.05f, 0.85f };

    myHpBgShared.myTexture = white;
    myHpBgShared.blendState = Tga::BlendState::AlphaBlend;
    myHpBgShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;
    myHpBgInst.myPivot = { 0.5f, 0.5f };
    myHpBgInst.myIsHidden = (myHpBgShared.myTexture == nullptr);
    myHpBgInst.myColor = { 0.05f, 0.05f, 0.05f, 0.85f };

    myHpFillShared.myTexture = white;
    myHpFillShared.blendState = Tga::BlendState::AlphaBlend;
    myHpFillShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;
    myHpFillInst.myPivot = { 0.5f, 0.5f };
    myHpFillInst.myIsHidden = (myHpFillShared.myTexture == nullptr);
    myHpFillInst.myColor = { 0.1f, 0.9f, 0.1f, 1.0f };

    myManaBgShared.myTexture = white;
    myManaBgShared.blendState = Tga::BlendState::AlphaBlend;
    myManaBgShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;
    myManaBgInst.myPivot = { 0.5f, 0.5f };
    myManaBgInst.myIsHidden = (myManaBgShared.myTexture == nullptr);
    myManaBgInst.myColor = { 0.05f, 0.05f, 0.05f, 0.85f };

    myManaFillShared.myTexture = white;
    myManaFillShared.blendState = Tga::BlendState::AlphaBlend;
    myManaFillShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;
    myManaFillInst.myPivot = { 0.5f, 0.5f };
    myManaFillInst.myIsHidden = (myManaFillShared.myTexture == nullptr);
    myManaFillInst.myColor = { 0.25f, 0.45f, 1.0f, 1.0f };

    myNameText = Tga::Text("Text/arial.ttf", Tga::FontSize_14, 1);
    myNameText.SetColor({ 1,1,1,1 });
    myNameText.SetText("Party");

    myHpText = Tga::Text("Text/arial.ttf", Tga::FontSize_14, 1);
    myHpText.SetColor({ 1,1,1,0.9f });
    myHpText.SetText("1 / 1");

    myManaText = Tga::Text("Text/arial.ttf", Tga::FontSize_14, 1);
    myManaText.SetColor({ 1,1,1,0.9f });
    myManaText.SetText("0 / 0");

    // Place based on index
    SyncAutoPosition();
    SyncVisuals();
}

void PartyFrame::SetEditMode(bool on)
{
    myEditMode = on;
    SetDraggable(on);
    if (!on) CancelDrag();
}

void PartyFrame::SetPartyIndex(int idx)
{
    myPartyIndex = std::max(0, idx);
    SyncAutoPosition();
}

void PartyFrame::SetAnchorPosition(const Tga::Vector2f& anchorPos)
{
    myAnchorPos = anchorPos;

    // Don't snap while user is dragging this frame
    if (IsDraggable() && IsDragging())
        return;

    SyncAutoPosition();
}

void PartyFrame::SetName(const char* name)
{
    myNameString = name ? name : "Party";
    myNameText.SetText(myNameString.c_str());
}

void PartyFrame::SetHealth(int hp, int maxHp)
{
    myHp = std::max(0, hp);
    myMaxHp = std::max(1, maxHp);

    myHpString = std::to_string(myHp) + " / " + std::to_string(myMaxHp);
    myHpText.SetText(myHpString.c_str());
}

void PartyFrame::SetMana(int mana, int maxMana)
{
    myMana = std::max(0, mana);
    myMaxMana = std::max(1, maxMana);

    myManaString = std::to_string(myMana) + " / " + std::to_string(myMaxMana);
    myManaText.SetText(myManaString.c_str());
}

Tga::FontSize PartyFrame::CalcNameFontSize() const
{
    const Tga::Vector2f size = GetHalfSize() * 2.f;
    const float w = size.x;
    const float h = size.y;

    int desiredPx = 14;

    if (myUseRaidStyle)
    {
        desiredPx = (int)std::min(h * 0.20f, w * 0.07f);
    }
    else
    {
        desiredPx = (int)std::min(h * 0.12f, w * 0.05f);
    }

    desiredPx = std::clamp(desiredPx, 8, 36);
    return PickClosestFontSize(desiredPx);
}

Tga::FontSize PartyFrame::CalcValueFontSize() const
{
    const Tga::Vector2f size = GetHalfSize() * 2.f;
    const float w = size.x;
    const float h = size.y;

    int desiredPx = 12;

    if (myUseRaidStyle)
    {
        desiredPx = (int)std::min(h * 0.16f, w * 0.06f);
    }
    else
    {
        desiredPx = (int)std::min(h * 0.10f, w * 0.045f);
    }

    desiredPx = std::clamp(desiredPx, 8, 30);
    return PickClosestFontSize(desiredPx);
}
Tga::FontSize PartyFrame::PickClosestFontSize(int px)
{
    using namespace Tga;

    if (px <= 7)  return FontSize_6;
    if (px <= 8)  return FontSize_8;
    if (px <= 9)  return FontSize_9;
    if (px <= 10) return FontSize_10;
    if (px <= 11) return FontSize_11;
    if (px <= 13) return FontSize_12;
    if (px <= 16) return FontSize_14;
    if (px <= 21) return FontSize_18;
    if (px <= 27) return FontSize_24;
    if (px <= 33) return FontSize_30;
    if (px <= 42) return FontSize_36;
    if (px <= 54) return FontSize_48;
    if (px <= 66) return FontSize_60;
    return FontSize_72;
}

void PartyFrame::UpdateTextSizes()
{
    const Tga::FontSize newNameSize = CalcNameFontSize();
    const Tga::FontSize newValueSize = CalcValueFontSize();

    if (newNameSize != myCurrentNameFontSize)
    {
        myCurrentNameFontSize = newNameSize;

        myNameText = Tga::Text("Text/arial.ttf", newNameSize, 1);
        myNameText.SetColor({ 1,1,1,1 });
        myNameText.SetText(myNameString.c_str());
    }

    if (newValueSize != myCurrentValueFontSize)
    {
        myCurrentValueFontSize = newValueSize;

        myHpText = Tga::Text("Text/arial.ttf", newValueSize, 1);
        myHpText.SetColor({ 1,1,1,0.9f });
        myHpText.SetText(myHpString.c_str());

        myManaText = Tga::Text("Text/arial.ttf", newValueSize, 1);
        myManaText.SetColor({ 1,1,1,0.9f });
        myManaText.SetText(myManaString.c_str());
    }
}

void PartyFrame::Update(float dt)
{
    if (!IsVisible()) return;

    Button::Update(dt);

    if (IsDraggable() && IsDragging())
    {
        const Tga::Vector2f fullSize = GetHalfSize() * 2.f;
        const auto cur = GetPosition();

        Tga::Vector2f newAnchor{};

        if (myUseHorizontalLayout)
        {
            const float stepX = fullSize.x + myVerticalSpacing;
            newAnchor = { cur.x - stepX * (float)myPartyIndex, cur.y };
        }
        else
        {
            const float stepY = fullSize.y + myVerticalSpacing;
            newAnchor = { cur.x, cur.y + stepY * (float)myPartyIndex };
        }

        if (myHUD)
            myHUD->SetPartyAnchor(newAnchor);

        return;
    }

    SyncAutoPosition();
    SyncVisuals();
}

void PartyFrame::SetFrameScale(float s)
{
	myFrameScale = s; 
	RefreshLayout(); 
}

void PartyFrame::SetUseRaidStyle(bool on)
{
    myUseRaidStyle = on;
    RefreshLayout();
}

void PartyFrame::SetUseHorizontalLayout(bool on)
{
    myUseHorizontalLayout = on;
    RefreshLayout();
}

void PartyFrame::SetRaidFrameWidth(float w)
{
    myRaidFrameWidth = w;
    RefreshLayout();
}

void PartyFrame::SetRaidFrameHeight(float h)
{
    myRaidFrameHeight = h;
    RefreshLayout();
}

void PartyFrame::RefreshLayout()
{
    if (myUseRaidStyle)
    {
        SetHalfSize({
            myRaidFrameWidth * myFrameScale * 0.5f,
            myRaidFrameHeight * myFrameScale * 0.5f
            });
    }
    else
    {
        SetHalfSize({
            myNormalFrameSize.x * myFrameScale * 0.5f,
            myNormalFrameSize.y * myFrameScale * 0.5f
            });
    }

    SyncAutoPosition();
    SyncVisuals();
}

void PartyFrame::Render()
{
    if (!IsVisible()) return;

    auto& engine = *Tga::Engine::GetInstance();
    auto& gss = engine.GetGraphicsEngine().GetGraphicsStateStack();
    auto& drawer = engine.GetGraphicsEngine().GetSpriteDrawer();

    SyncVisuals();

    gss.Push();
    gss.SetBlendState(Tga::BlendState::AlphaBlend);

    if (myPortraitShared.myTexture && !myPortraitInst.myIsHidden)
        drawer.Draw(myPortraitShared, myPortraitInst);

    if (myUseRaidStyle)
    {
        drawer.Draw(myRaidBgShared, myRaidBgInst);
    }
    else
    {
        if (myFrameShared.myTexture && !myFrameInst.myIsHidden)
            drawer.Draw(myFrameShared, myFrameInst);
    }

    if (myNameBgShared.myTexture && !myNameBgInst.myIsHidden)
        drawer.Draw(myNameBgShared, myNameBgInst);

    if (myHpBgShared.myTexture && !myHpBgInst.myIsHidden)
        drawer.Draw(myHpBgShared, myHpBgInst);
    if (myHpFillShared.myTexture && !myHpFillInst.myIsHidden)
        drawer.Draw(myHpFillShared, myHpFillInst);

    if (myManaBgShared.myTexture && !myManaBgInst.myIsHidden)
        drawer.Draw(myManaBgShared, myManaBgInst);
    if (myManaFillShared.myTexture && !myManaFillInst.myIsHidden)
        drawer.Draw(myManaFillShared, myManaFillInst);

    myNameText.Render();
    myHpText.Render();
    myManaText.Render();

    gss.Pop();


    if (myEditMode)
    {
        if (myUseRaidStyle)
            DrawDebugRect(myRaidBgInst.myPosition, myRaidBgInst.mySize);
        else
            DrawDebugRect(myFrameInst.myPosition, myFrameInst.mySize);
    }
}

void PartyFrame::SyncAutoPosition()
{
    const Tga::Vector2f fullSize = GetHalfSize() * 2.f;

    if (myUseHorizontalLayout)
    {
        const float stepX = fullSize.x + myVerticalSpacing;

        const Tga::Vector2f pos =
        {
            myAnchorPos.x + stepX * (float)myPartyIndex,
            myAnchorPos.y
        };

        SetPosition(pos);
    }
    else
    {
        const float stepY = fullSize.y + myVerticalSpacing;

        const Tga::Vector2f pos =
        {
            myAnchorPos.x,
            myAnchorPos.y - stepY * (float)myPartyIndex
        };

        SetPosition(pos);
    }
}

void PartyFrame::SyncNormalVisuals()
{
    const Tga::Vector2f p = GetPosition();
    const Tga::Vector2f size = GetHalfSize() * 2.f;
	const float w = size.x;
    const float h = size.y;

    myFrameInst.myPosition = p;
    myFrameInst.mySize = size;

    const float innerL = 0.385f;
    const float innerR = 0.05f;
    const float innerT = 0.44f;
    const float innerB = 0.15f;

    const float portraitCX = 0.20f;
    const float portraitCY = 0.50f;
    const float portraitD = 0.78f;

    const float rowGapN = 0.06f;
    const float hpHN = 0.38f;
    const float manaHN = 0.26f;

    const float padXn = 0.03f;
    const float padYn = 0.06f;

    const float x0 = p.x - w * 0.5f;
    const float y0 = p.y - h * 0.5f;

    const float innerX0 = x0 + w * innerL;
    const float innerX1 = x0 + w * (1.f - innerR);
    const float innerY1 = y0 + h * (1.f - innerT);
    const float innerY0 = y0 + h * innerB;

    const float innerW = std::max(10.f, innerX1 - innerX0);
    const float innerH = std::max(10.f, innerY1 - innerY0);

    const float padX = innerW * padXn;
    const float padY = innerH * padYn;

    const float pd = h * portraitD;
    myPortraitInst.mySize = { pd, pd };
    myPortraitInst.myPosition =
    {
        x0 + w * portraitCX,
        y0 + h * portraitCY
    };

    const float usableW = innerW - padX * 2.f;

    const float gap = innerH * rowGapN;
    const float hpH = innerH * hpHN;
    const float manaH = innerH * manaHN;

    float y = innerY1 - padY;

    const float hpY = y - hpH * 0.5f; y -= hpH + gap;
    const float manaY = y - manaH * 0.5f;

    const float cx = innerX0 + padX + usableW * 0.5f;
    const float left = innerX0 + padX;

    const float tabCenterX = x0 + w * 0.44f;
    const float tabCenterY = y0 + h * 0.62f;

    myHpBgInst.myPosition = { cx, hpY };
    myHpBgInst.mySize = { usableW, hpH };

    const float hp01 = (float)myHp / (float)std::max(1, myMaxHp);
    const float hpFillW = usableW * std::clamp(hp01, 0.f, 1.f);
    myHpFillInst.mySize = { hpFillW, hpH };
    myHpFillInst.myPosition = { left + hpFillW * 0.5f, hpY };

    myManaBgInst.myPosition = { cx, manaY };
    myManaBgInst.mySize = { usableW, manaH };

    const float mana01 = (float)myMana / (float)std::max(1, myMaxMana);
    const float manaFillW = usableW * std::clamp(mana01, 0.f, 1.f);
    myManaFillInst.mySize = { manaFillW, manaH };
    myManaFillInst.myPosition = { left + manaFillW * 0.5f, manaY };

    myNameText.SetPosition({ tabCenterX - myNameText.GetWidth() * 0.5f, tabCenterY });
    myHpText.SetPosition({ left + usableW * 0.03f, hpY - hpH * 0.4f });
    myManaText.SetPosition({ left + usableW * 0.03f, manaY - manaH * 0.4f });

    myPortraitInst.myIsHidden = false;
}

void PartyFrame::SyncRaidVisuals()
{
    const Tga::Vector2f p = GetPosition();

    const float w = myRaidFrameWidth * myFrameScale;
    const float h = myRaidFrameHeight * myFrameScale;

    // make actual clickable/rendered frame use raid size
    myRaidBgInst.myPosition = p;
    myRaidBgInst.mySize = { w, h };
    myRaidBgInst.myColor = { 0.35f, 0.35f, 0.35f, 1.f };

    // hide big portrait in raid mode
    myPortraitInst.myIsHidden = true;

    const float x0 = p.x - w * 0.5f;
    const float y0 = p.y - h * 0.5f;
    const float x1 = p.x + w * 0.5f;
    const float y1 = p.y + h * 0.5f;
    x1;
    // class-color-ish/tinted background look
    myFrameInst.myColor = { 0.35f, 0.35f, 0.35f, 1.f }; // neutral for now

    // top name strip
    const float nameH = h * 0.28f;
    myNameBgInst.myIsHidden = false;
    myNameBgInst.myPosition = { p.x, y1 - nameH * 0.5f };
    myNameBgInst.mySize = { w, nameH };
    myNameBgInst.myColor = { 0.12f, 0.12f, 0.12f, 0.65f };

    // health area
    const float manaH = std::max(4.f, h * 0.14f);
    const float hpH = h - nameH - manaH;
    const float hpCenterY = y0 + manaH + hpH * 0.5f;
    const float manaCenterY = y0 + manaH * 0.5f;

    myHpBgInst.myIsHidden = false;
    myHpBgInst.myPosition = { p.x, hpCenterY };
    myHpBgInst.mySize = { w, hpH };
    myHpBgInst.myColor = { 0.06f, 0.06f, 0.06f, 0.75f };

    const float hp01 = (float)myHp / (float)std::max(1, myMaxHp);
    const float hpFillW = w * std::clamp(hp01, 0.f, 1.f);
    myHpFillInst.myIsHidden = false;
    myHpFillInst.mySize = { hpFillW, hpH };
    myHpFillInst.myPosition = { x0 + hpFillW * 0.5f, hpCenterY };
    myHpFillInst.myColor = { 0.1f, 0.8f, 0.1f, 0.9f };

    myManaBgInst.myIsHidden = false;
    myManaBgInst.myPosition = { p.x, manaCenterY };
    myManaBgInst.mySize = { w, manaH };
    myManaBgInst.myColor = { 0.05f, 0.05f, 0.05f, 0.9f };

    const float mana01 = (float)myMana / (float)std::max(1, myMaxMana);
    const float manaFillW = w * std::clamp(mana01, 0.f, 1.f);
    myManaFillInst.myIsHidden = false;
    myManaFillInst.mySize = { manaFillW, manaH };
    myManaFillInst.myPosition = { x0 + manaFillW * 0.5f, manaCenterY };
    myManaFillInst.myColor = { 0.2f, 0.4f, 1.f, 1.f };

    // name top-left
    myNameText.SetPosition({ x0 + 6.f, y1 - nameH + 2.f });

    // hide number texts or keep very small
    myHpText.SetPosition({ x0 + 4.f, hpCenterY - 8.f });
    myManaText.SetPosition({ x0 + 4.f, manaCenterY - 8.f });
}

void PartyFrame::DrawDebugRect(const Tga::Vector2f& center, const Tga::Vector2f& size)
{
    const float halfW = size.x * 0.5f;
    const float halfH = size.y * 0.5f;

    const Tga::Vector3f tl{ center.x - halfW, center.y - halfH, 0.f };
    const Tga::Vector3f tr{ center.x + halfW, center.y - halfH, 0.f };
    const Tga::Vector3f br{ center.x + halfW, center.y + halfH, 0.f };
    const Tga::Vector3f bl{ center.x - halfW, center.y + halfH, 0.f };

    auto& dbg = Tga::Engine::GetInstance()->GetDebugDrawer();

    dbg.DrawLine(tl, tr, { 1.f, 1.f, 1.f, 1.f });
    dbg.DrawLine(tr, br, { 1.f, 1.f, 1.f, 1.f });
    dbg.DrawLine(br, bl, { 1.f, 1.f, 1.f, 1.f });
    dbg.DrawLine(bl, tl, { 1.f, 1.f, 1.f, 1.f });
}

void PartyFrame::SyncVisuals()
{
    UpdateTextSizes();

    if (myUseRaidStyle)
        SyncRaidVisuals();
    else
        SyncNormalVisuals();
}

