#pragma once

#include <memory>
#include <tge/math/Vector2.h>
#include <tge/sprite/Sprite.h>
#include <tge/text/text.h>

namespace Tga
{
    class Camera;
    class InputManager;
    class SpriteDrawer;
}

class HUD;

class PartyFrameSettingsPopup
{
public:
    void Init(HUD* hud, const std::shared_ptr<Tga::Camera>& uiCam);

    void Open(const Tga::Vector2f& centerPos);
    void Close();
    bool IsOpen() const { return myIsOpen; }

    bool Update(Tga::InputManager* im, const Tga::Vector2f& mouseWorld);
    void Render(Tga::SpriteDrawer& drawer);

private:
    struct RectUI
    {
        Tga::Vector2f c{};
        Tga::Vector2f s{};
    };

private:
    void LayoutUI();
    void PullFromHUD();
    void PushToHUD();

    bool PointInRect(const Tga::Vector2f& p, const Tga::Vector2f& c, const Tga::Vector2f& s) const;
    bool IsInsidePopup(const Tga::Vector2f& p) const;
    float Slider01(const Tga::Vector2f& mouse, const RectUI& r) const;

    float To01(float v, float minV, float maxV) const;
    float From01(float t, float minV, float maxV) const;

    void DrawSlider(Tga::SpriteDrawer& drawer, const RectUI& r, float t01);

private:
    HUD* myHUD = nullptr;
    std::shared_ptr<Tga::Camera> myUiCam;

    bool myIsOpen = false;
    bool myDraggingPanel = false;
    bool myDraggingScale = false;
    bool myDraggingWidth = false;
    bool myDraggingHeight = false;

    Tga::Vector2f myPanelCenter{ 0.f, 0.f };
    Tga::Vector2f myPanelSize{ 520.f, 360.f };
    Tga::Vector2f myDragOffset{};

    void ApplySizeForMode();

    Tga::Vector2f myCompactSize{ 520.f, 220.f };
    Tga::Vector2f myExpandedSize{ 520.f, 460.f };

    // local editable state
    bool myUseRaidStyle = false;
    bool myUseHorizontal = false;
    float myFrameScale = 1.f;
    float myRaidWidth = 260.f;
    float myRaidHeight = 70.f;

    float myMinScale = 0.75f;
    float myMaxScale = 1.50f;
    float myMinWidth = 140.f;
    float myMaxWidth = 400.f;
    float myMinHeight = 100.f;
    float myMaxHeight = 200.f;

    RectUI myTitleBar{};
    RectUI myCloseButton{};
    RectUI myRaidStyleButton{};
    RectUI myHorizontalButton{};
    RectUI myScaleSlider{};
    RectUI myWidthSlider{};
    RectUI myHeightSlider{};

    Tga::SpriteSharedData myBgShared{};
    Tga::Sprite2DInstanceData myBgInst{};

    Tga::SpriteSharedData myCloseBtnShared{};
    Tga::Sprite2DInstanceData myCloseInst{};

    Tga::SpriteSharedData myCheckboxCheckedShared{};
    Tga::SpriteSharedData myCheckboxOpenShared{};
    Tga::Sprite2DInstanceData myRaidStyleInst{};
    Tga::Sprite2DInstanceData myHorizontalInst{};

    Tga::SpriteSharedData mySliderTrackShared{};
    Tga::SpriteSharedData mySliderKnobShared{};
    Tga::Sprite2DInstanceData mySliderTrackInst{};
    Tga::Sprite2DInstanceData mySliderKnobInst{};

    Tga::Text myTitle;
    Tga::Text myCloseText;
    Tga::Text myRaidStyleText;
    Tga::Text myScaleLabel;
    Tga::Text myScaleValue;
    Tga::Text myWidthLabel;
    Tga::Text myWidthValue;
    Tga::Text myHeightLabel;
    Tga::Text myHeightValue;
    Tga::Text myHorizontalText;
};