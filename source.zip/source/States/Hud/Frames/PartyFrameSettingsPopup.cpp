#include "PartyFrameSettingsPopup.h"
#include "../HUD.h"

#include <tge/Engine.h>
#include <tge/input/InputManager.h>
#include <tge/texture/TextureManager.h>
#include <tge/drawers/SpriteDrawer.h>
#include <tge/graphics/GraphicsEngine.h>
#include <tge/graphics/GraphicsStateStack.h>

#include <algorithm>
#include <string>

void PartyFrameSettingsPopup::Init(HUD* hud, const std::shared_ptr<Tga::Camera>& uiCam)
{
    myHUD = hud;
    myUiCam = uiCam;

    auto& tm = Tga::Engine::GetInstance()->GetTextureManager();

    // Background panel
    myBgShared.myTexture = tm.GetTexture("assets/ui/textures/spellbook_panel.png");
    myBgShared.blendState = Tga::BlendState::AlphaBlend;
    myBgShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    myBgInst.myPivot = { 0.5f, 0.5f };
    myBgInst.myColor = { 1,1,1,0.96f };
    myBgInst.myIsHidden = false;

    // Close button uses same panel texture style
    myCloseBtnShared.myTexture = tm.GetTexture("assets/ui/textures/spellbook_panel.png");
    myCloseBtnShared.blendState = Tga::BlendState::AlphaBlend;
    myCloseBtnShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    myCloseInst.myPivot = { 0.5f, 0.5f };
    myCloseInst.myColor = { 1,1,1,1 };
    myCloseInst.myIsHidden = false;

    // Checkbox textures
    myCheckboxCheckedShared.myTexture = tm.GetTexture("assets/ui/textures/T_UI_Checkbox_checked.dds");
    myCheckboxCheckedShared.blendState = Tga::BlendState::AlphaBlend;
    myCheckboxCheckedShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    myCheckboxOpenShared.myTexture = tm.GetTexture("assets/ui/textures/T_UI_Checkbox_open.dds");
    myCheckboxOpenShared.blendState = Tga::BlendState::AlphaBlend;
    myCheckboxOpenShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    myRaidStyleInst.myPivot = { 0.5f, 0.5f };
    myRaidStyleInst.myColor = { 1,1,1,1 };
    myRaidStyleInst.myIsHidden = false;

    myHorizontalInst.myPivot = { 0.5f, 0.5f };
    myHorizontalInst.myColor = { 1,1,1,1 };
    myHorizontalInst.myIsHidden = false;

    // Slider textures
    mySliderTrackShared.myTexture = tm.GetTexture("assets/ui/textures/Slider_background.png");
    mySliderTrackShared.blendState = Tga::BlendState::AlphaBlend;
    mySliderTrackShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    mySliderKnobShared.myTexture = tm.GetTexture("assets/ui/textures/Slider_button.png");
    mySliderKnobShared.blendState = Tga::BlendState::AlphaBlend;
    mySliderKnobShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    mySliderTrackInst.myPivot = { 0.5f, 0.5f };
    mySliderKnobInst.myPivot = { 0.5f, 0.5f };

    myTitle = Tga::Text("Text/arial.ttf", Tga::FontSize_18, 1);
    myTitle.SetText("Party Frame Settings");
    myTitle.SetColor({ 1,1,1,1 });

    myCloseText = Tga::Text("Text/arial.ttf", Tga::FontSize_18, 1);
    myCloseText.SetText("X");
    myCloseText.SetColor({ 1,1,1,1 });

    myRaidStyleText = Tga::Text("Text/arial.ttf", Tga::FontSize_18, 1);
    myRaidStyleText.SetText("Use raid-style party frames");
    myRaidStyleText.SetColor({ 1,1,1,1 });

    myScaleLabel = Tga::Text("Text/arial.ttf", Tga::FontSize_18, 1);
    myScaleLabel.SetText("Frame size");
    myScaleLabel.SetColor({ 1,1,1,1 });

    myScaleValue = Tga::Text("Text/arial.ttf", Tga::FontSize_18, 1);
    myScaleValue.SetColor({ 1,1,1,1 });

    myWidthLabel = Tga::Text("Text/arial.ttf", Tga::FontSize_18, 1);
    myWidthLabel.SetText("Frame width");
    myWidthLabel.SetColor({ 1,1,1,1 });

    myWidthValue = Tga::Text("Text/arial.ttf", Tga::FontSize_18, 1);
    myWidthValue.SetColor({ 1,1,1,1 });

    myHeightLabel = Tga::Text("Text/arial.ttf", Tga::FontSize_18, 1);
    myHeightLabel.SetText("Frame height");
    myHeightLabel.SetColor({ 1,1,1,1 });

    myHeightValue = Tga::Text("Text/arial.ttf", Tga::FontSize_18, 1);
    myHeightValue.SetColor({ 1,1,1,1 });

    myHorizontalText = Tga::Text("Text/arial.ttf", Tga::FontSize_18, 1);
    myHorizontalText.SetText("Use horizontal layout");
    myHorizontalText.SetColor({ 1,1,1,1 });
}

void PartyFrameSettingsPopup::Open(const Tga::Vector2f& centerPos)
{
    PullFromHUD();
    myPanelCenter = centerPos;
    ApplySizeForMode();
    myIsOpen = true;
}

void PartyFrameSettingsPopup::Close()
{
    myIsOpen = false;
    myDraggingPanel = false;
    myDraggingScale = false;
    myDraggingWidth = false;
    myDraggingHeight = false;
}

void PartyFrameSettingsPopup::PullFromHUD()
{
    if (!myHUD) return;
    const auto& s = myHUD->GetPartyFrameSettings();
    myUseRaidStyle = s.useRaidStyle;
    myUseHorizontal = s.useHorizontal;
    myFrameScale = s.frameScale;
    myRaidWidth = s.raidWidth;
    myRaidHeight = s.raidHeight;
}

void PartyFrameSettingsPopup::PushToHUD()
{
    if (!myHUD) return;
    auto& s = myHUD->GetPartyFrameSettings();
    s.useRaidStyle = myUseRaidStyle;
    s.useHorizontal = myUseHorizontal;
    s.frameScale = myFrameScale;
    s.raidWidth = myRaidWidth;
    s.raidHeight = myRaidHeight;
    myHUD->ApplyPartyFrameSettings();
}

bool PartyFrameSettingsPopup::PointInRect(const Tga::Vector2f& p, const Tga::Vector2f& c, const Tga::Vector2f& s) const
{
    const Tga::Vector2f h = s * 0.5f;
    return
        p.x >= c.x - h.x && p.x <= c.x + h.x &&
        p.y >= c.y - h.y && p.y <= c.y + h.y;
}

bool PartyFrameSettingsPopup::IsInsidePopup(const Tga::Vector2f& p) const
{
    return PointInRect(p, myPanelCenter, myPanelSize);
}

float PartyFrameSettingsPopup::Slider01(const Tga::Vector2f& mouse, const RectUI& r) const
{
    const float left = r.c.x - r.s.x * 0.5f;
    return std::clamp((mouse.x - left) / r.s.x, 0.f, 1.f);
}

float PartyFrameSettingsPopup::To01(float v, float minV, float maxV) const
{
    if (maxV <= minV) return 0.f;
    return std::clamp((v - minV) / (maxV - minV), 0.f, 1.f);
}

float PartyFrameSettingsPopup::From01(float t, float minV, float maxV) const
{
    return minV + std::clamp(t, 0.f, 1.f) * (maxV - minV);
}

void PartyFrameSettingsPopup::LayoutUI()
{
    const float checkboxOffsetX = 24.f;

    const float left = myPanelCenter.x - myPanelSize.x * 0.5f;
    const float top = myPanelCenter.y + myPanelSize.y * 0.5f;

    myBgInst.myPosition = myPanelCenter;
    myBgInst.mySize = myPanelSize;
    myBgInst.myColor = { 1,1,1,0.96f };

    myTitleBar.c = { myPanelCenter.x, top - 28.f };
    myTitleBar.s = { myPanelSize.x - 20.f, 44.f };

    myCloseButton.c = { left + myPanelSize.x - 30.f, top - 28.f };
    myCloseButton.s = { 36.f, 36.f };

    float y = top - 90.f;
    const float contentW = myPanelSize.x - 40.f;

    myRaidStyleButton.c = { left + 34.f + checkboxOffsetX, y };
	myRaidStyleButton.s = { 30.f, 30.f };

    y -= 76.f;
    myScaleSlider.c = { myPanelCenter.x, y };
    myScaleSlider.s = { contentW - 120.f, 36.f };

    if (myUseRaidStyle)
    {
        y -= 82.f;
        myWidthSlider.c = { myPanelCenter.x, y };
        myWidthSlider.s = { contentW - 120.f, 36.f };

        y -= 82.f;
        myHeightSlider.c = { myPanelCenter.x, y };
        myHeightSlider.s = { contentW - 120.f, 36.f };

        y -= 76.f;
        myHorizontalButton.c = { left + 34.f + checkboxOffsetX, y };
    	myHorizontalButton.s = { 30.f, 30.f };
    }

    myTitle.SetPosition({ left + 18.f, top - 38.f });
    myCloseText.SetPosition({ myCloseButton.c.x - 6.f, myCloseButton.c.y - 10.f });

    myRaidStyleText.SetPosition({
     myRaidStyleButton.c.x + 28.f,
     myRaidStyleButton.c.y - 10.f
        });

    myScaleLabel.SetPosition({
        myScaleSlider.c.x - myScaleSlider.s.x * 0.5f,
        myScaleSlider.c.y + 22.f
        });

    {
        std::string txt = std::to_string((int)(myFrameScale * 100.f)) + "%";
        myScaleValue.SetText(txt.c_str());
        myScaleValue.SetPosition({
            myScaleSlider.c.x + myScaleSlider.s.x * 0.5f + 16.f,
            myScaleSlider.c.y - 10.f
            });
    }

    if (myUseRaidStyle)
    {
        myWidthLabel.SetPosition({
            myWidthSlider.c.x - myWidthSlider.s.x * 0.5f,
            myWidthSlider.c.y + 22.f
            });

        {
            std::string txt = std::to_string((int)myRaidWidth);
            myWidthValue.SetText(txt.c_str());
            myWidthValue.SetPosition({
                myWidthSlider.c.x + myWidthSlider.s.x * 0.5f + 16.f,
                myWidthSlider.c.y - 10.f
                });
        }

        myHeightLabel.SetPosition({
            myHeightSlider.c.x - myHeightSlider.s.x * 0.5f,
            myHeightSlider.c.y + 22.f
            });

        {
            std::string txt = std::to_string((int)myRaidHeight);
            myHeightValue.SetText(txt.c_str());
            myHeightValue.SetPosition({
                myHeightSlider.c.x + myHeightSlider.s.x * 0.5f + 16.f,
                myHeightSlider.c.y - 10.f
                });
        }

        myHorizontalText.SetPosition({
    myHorizontalButton.c.x + 28.f,
    myHorizontalButton.c.y - 10.f
            });
    }
}

bool PartyFrameSettingsPopup::Update(Tga::InputManager* im, const Tga::Vector2f& mouseWorld)
{
    if (!myIsOpen || !im)
        return false;

    LayoutUI();

    const bool pressed = im->IsKeyPressed(VK_LBUTTON);
    const bool down = im->IsKeyHeld(VK_LBUTTON);
    const bool released = im->IsKeyReleased(VK_LBUTTON);

    if (pressed)
    {
        if (PointInRect(mouseWorld, myCloseButton.c, myCloseButton.s))
        {
            Close();
            return true;
        }

        if (PointInRect(mouseWorld, myRaidStyleButton.c, myRaidStyleButton.s))
        {
            myUseRaidStyle = !myUseRaidStyle;
            ApplySizeForMode();
            PushToHUD();
            return true;
        }

        if (myUseRaidStyle && PointInRect(mouseWorld, myHorizontalButton.c, myHorizontalButton.s))
        {
            myUseHorizontal = !myUseHorizontal;
            PushToHUD();
            LayoutUI();
            return true;
        }

        if (PointInRect(mouseWorld, myScaleSlider.c, myScaleSlider.s))
        {
            myDraggingScale = true;
            return true;
        }

        if (myUseRaidStyle && PointInRect(mouseWorld, myWidthSlider.c, myWidthSlider.s))
        {
            myDraggingWidth = true;
            return true;
        }

        if (myUseRaidStyle && PointInRect(mouseWorld, myHeightSlider.c, myHeightSlider.s))
        {
            myDraggingHeight = true;
            return true;
        }

        if (PointInRect(mouseWorld, myTitleBar.c, myTitleBar.s))
        {
            myDraggingPanel = true;
            myDragOffset = myPanelCenter - mouseWorld;
            return true;
        }

        if (!IsInsidePopup(mouseWorld))
        {
            Close();
            return false;
        }
    }

    if (myDraggingPanel && down)
    {
        myPanelCenter = mouseWorld + myDragOffset;
        LayoutUI();
        return true;
    }

    if (myDraggingScale && down)
    {
        myFrameScale = From01(Slider01(mouseWorld, myScaleSlider), myMinScale, myMaxScale);
        PushToHUD();
        LayoutUI();
        return true;
    }

    if (myDraggingWidth && down)
    {
        myRaidWidth = From01(Slider01(mouseWorld, myWidthSlider), myMinWidth, myMaxWidth);
        PushToHUD();
        LayoutUI();
        return true;
    }

    if (myDraggingHeight && down)
    {
        myRaidHeight = From01(Slider01(mouseWorld, myHeightSlider), myMinHeight, myMaxHeight);
        PushToHUD();
        LayoutUI();
        return true;
    }

    if (released)
    {
        myDraggingPanel = false;
        myDraggingScale = false;
        myDraggingWidth = false;
        myDraggingHeight = false;
    }

    return IsInsidePopup(mouseWorld);
}

void PartyFrameSettingsPopup::DrawSlider(Tga::SpriteDrawer& drawer, const RectUI& r, float t01)
{
    t01 = std::max(0.f, std::min(1.f, t01));

    mySliderTrackInst.myPosition = r.c;
    mySliderTrackInst.mySize = r.s;
    mySliderTrackInst.myColor = { 1,1,1,1 };
    mySliderTrackInst.myIsHidden = false;
    drawer.Draw(mySliderTrackShared, mySliderTrackInst);

    const float left = r.c.x - r.s.x * 0.5f;
    const float knobX = left + r.s.x * t01;

    mySliderKnobInst.myPosition = { knobX, r.c.y };
    mySliderKnobInst.mySize = { 22.f, 22.f };
    mySliderKnobInst.myColor = { 1,1,1,1 };
    mySliderKnobInst.myIsHidden = false;
    drawer.Draw(mySliderKnobShared, mySliderKnobInst);
}

void PartyFrameSettingsPopup::ApplySizeForMode()
{
    const float oldTop = myPanelCenter.y + myPanelSize.y * 0.5f;

    myPanelSize = myUseRaidStyle ? myExpandedSize : myCompactSize;

    // Keep top edge fixed, expand downward
    myPanelCenter.y = oldTop - myPanelSize.y * 0.5f;

    myBgInst.myPosition = myPanelCenter;
    myBgInst.mySize = myPanelSize;

    LayoutUI();
}

void PartyFrameSettingsPopup::Render(Tga::SpriteDrawer& drawer)
{
    if (!myIsOpen)
        return;

    auto& engine = *Tga::Engine::GetInstance();
    auto& gss = engine.GetGraphicsEngine().GetGraphicsStateStack();

    gss.Push();
    gss.SetBlendState(Tga::BlendState::AlphaBlend);

    drawer.Draw(myBgShared, myBgInst);

    myCloseInst.myPosition = myCloseButton.c;
    myCloseInst.mySize = myCloseButton.s;
    myCloseInst.myColor = { 1,1,1,1 };
    drawer.Draw(myCloseBtnShared, myCloseInst);

    myRaidStyleInst.myPosition = myRaidStyleButton.c;
    myRaidStyleInst.mySize = myRaidStyleButton.s;
    myRaidStyleInst.myColor = { 1,1,1,1 };

    if (myUseRaidStyle)
        drawer.Draw(myCheckboxCheckedShared, myRaidStyleInst);
    else
        drawer.Draw(myCheckboxOpenShared, myRaidStyleInst);

    DrawSlider(drawer, myScaleSlider, To01(myFrameScale, myMinScale, myMaxScale));

    if (myUseRaidStyle)
    {
        DrawSlider(drawer, myWidthSlider, To01(myRaidWidth, myMinWidth, myMaxWidth));
        DrawSlider(drawer, myHeightSlider, To01(myRaidHeight, myMinHeight, myMaxHeight));

        myHorizontalInst.myPosition = myHorizontalButton.c;
        myHorizontalInst.mySize = myHorizontalButton.s;
        myHorizontalInst.myColor = { 1,1,1,1 };

        if (myUseHorizontal)
            drawer.Draw(myCheckboxCheckedShared, myHorizontalInst);
        else
            drawer.Draw(myCheckboxOpenShared, myHorizontalInst);
    }

    myTitle.Render();
    myCloseText.Render();
    myRaidStyleText.Render();
    myScaleLabel.Render();
    myScaleValue.Render();

    if (myUseRaidStyle)
    {
        myWidthLabel.Render();
        myWidthValue.Render();
        myHeightLabel.Render();
        myHeightValue.Render();
        myHorizontalText.Render();
    }

    gss.Pop();
}

