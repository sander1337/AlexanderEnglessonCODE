#include "BuffFrame.h"
#include <tge/engine.h>
#include <tge/texture/TextureManager.h>
#include <tge/drawers/SpriteDrawer.h>
#include <tge/graphics/GraphicsEngine.h>
#include <tge/graphics/GraphicsStateStack.h>
#include <tge/drawers/DebugDrawer.h>

#include "States/Hud/HUD.h"

#include <algorithm>
#include <iostream>

void BuffFrame::InitRuntimeFrame(HUD* hud,
    const std::shared_ptr<Tga::Camera>& uiCam,
    const Tga::Vector2f& pos,
    const Tga::Vector2f& size)
{
    myHUD = hud;

    InitRuntime(pos, size);
    SetCamera(uiCam);
    SetVisible(true);

    auto& tm = Tga::Engine::GetInstance()->GetTextureManager();

    auto white = tm.GetTexture("assets/ui/textures/white_1x1.png");
    myBgShared.myTexture = white;
    myBgShared.blendState = Tga::BlendState::AlphaBlend;
    myBgShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    myBgInst.myPivot = { 0.5f, 0.5f };
    myBgInst.myColor = { 0.05f, 0.05f, 0.05f, 0.45f };
    myBgInst.myIsHidden = false;

    SyncVisuals();
}

void BuffFrame::SetEditMode(bool on)
{
    myEditMode = on;

    if (myEditMode)
        EnsurePreviewBuffs();
    else
        ClearPreviewBuffs();

    SetDraggable(on);
    if (!on)
        CancelDrag();

    SyncVisuals();
}

void BuffFrame::ReceiveInput(InputEvent e, const std::any& data)
{
    if (!IsVisible())
        return;

    Button::ReceiveInput(e, data);
}

void BuffFrame::AddOrRefreshBuff(int id, const std::string& name, const std::string& iconPath, float duration)
{
    auto& tm = Tga::Engine::GetInstance()->GetTextureManager();

    for (auto& buff : myBuffs)
    {
        if (buff.id == id)
        {
            buff.name = name;
            buff.iconPath = iconPath;
            buff.duration = duration;
            buff.timeLeft = duration;
            buff.active = true;
            buff.timeText.SetColor({ 1.f,1.f,1.f,1.f });
            buff.nameText.SetColor({ 1.f,1.f,1.f,1.f });
            buff.nameText.SetText(name.c_str());
            return;
        }
    }

    BuffEntry entry;
    entry.id = id;
    entry.name = name;
    entry.iconPath = iconPath;
    entry.duration = duration;
    entry.timeLeft = duration;
    entry.active = true;

    entry.iconShared.myTexture = tm.GetTexture(iconPath.c_str());
    entry.iconShared.blendState = Tga::BlendState::AlphaBlend;
    entry.iconShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    entry.iconInst.myPivot = { 0.5f, 0.5f };
    entry.iconInst.myColor = { 1.f,1.f,1.f,1.f };
    entry.iconInst.myIsHidden = (entry.iconShared.myTexture == nullptr);

    entry.timeText.SetColor({ 1.f,1.f,1.f,1.f });
    entry.nameText.SetColor({ 1.f,1.f,1.f,1.f });
    entry.nameText.SetText(name.c_str());

    myBuffs.push_back(std::move(entry));
    SyncVisuals();
}

void BuffFrame::RemoveBuff(int id)
{
    myBuffs.erase(
        std::remove_if(myBuffs.begin(), myBuffs.end(),
            [id](const BuffEntry& b) { return b.id == id; }),
        myBuffs.end());

    SyncVisuals();
}

void BuffFrame::ClearBuffs()
{
    myBuffs.clear();
    SyncVisuals();
}

bool BuffFrame::HasBuff(int id) const
{
    for (const auto& b : myBuffs)
    {
        if (b.id == id)
            return true;
    }
    return false;
}

void BuffFrame::Update(float dt)
{
    if (!IsVisible())
        return;

    myHUD->ResolveBuffDebuffOverlap(0.f);
    Button::Update(dt);

    bool changed = false;

    for (auto& buff : myBuffs)
    {
        if (!buff.active)
            continue;

        if (buff.duration > 0.f)
        {
            buff.timeLeft -= dt;
            if (buff.timeLeft <= 0.f)
            {
                buff.timeLeft = 0.f;
                buff.active = false;
                changed = true;
            }
        }
    }

    myBuffs.erase(
        std::remove_if(myBuffs.begin(), myBuffs.end(),
            [](const BuffEntry& b) { return !b.active; }),
        myBuffs.end());

    if (changed)
        SyncVisuals();

    SyncVisuals();
}

void BuffFrame::Render()
{
    if (!IsVisible())
        return;

    auto& engine = *Tga::Engine::GetInstance();
    auto& gss = engine.GetGraphicsEngine().GetGraphicsStateStack();
    auto& drawer = engine.GetGraphicsEngine().GetSpriteDrawer();

    SyncVisuals();

    gss.Push();
    gss.SetBlendState(Tga::BlendState::AlphaBlend);

    if (myEditMode && myBgShared.myTexture)
        drawer.Draw(myBgShared, myBgInst);

    auto& buffs = GetDisplayBuffsMutable();
    const int count = std::min((int)buffs.size(), myMaxVisibleBuffs);

    for (int i = 0; i < count; ++i)
    {
        auto& buff = buffs[i];

        if (buff.iconShared.myTexture && !buff.iconInst.myIsHidden)
            drawer.Draw(buff.iconShared, buff.iconInst);

        if (buff.duration > 0.f)
            buff.timeText.Render();
    }

    gss.Pop();

    if (myEditMode)
        DrawDebugLayout();
}

int BuffFrame::HitTestBuffIndex(const Tga::Vector2f& mouseWorld) const
{
    const auto& buffs = GetDisplayBuffs();
    const int count = std::min((int)buffs.size(), myMaxVisibleBuffs);

    for (int i = 0; i < count; ++i)
    {
        const auto& buff = buffs[i];
        const Tga::Vector2f p = buff.iconInst.myPosition;
        const Tga::Vector2f s = buff.iconInst.mySize;
        const Tga::Vector2f h = s * 0.5f;

        if (mouseWorld.x >= p.x - h.x && mouseWorld.x <= p.x + h.x &&
            mouseWorld.y >= p.y - h.y && mouseWorld.y <= p.y + h.y)
        {
            return i;
        }
    }

    return -1;
}

bool BuffFrame::RemoveBuffAtMouse(const Tga::Vector2f& mouseWorld)
{
    if (myBuffs.empty())
        return false; // don't remove preview buffs

    const int idx = HitTestBuffIndex(mouseWorld);
    if (idx < 0)
        return false;

    if (idx >= (int)myBuffs.size())
        return false;

    myBuffs.erase(myBuffs.begin() + idx);
    SyncVisuals();
    return true;
}

Tga::Vector2f BuffFrame::GetRecommendedSize() const
{
    const float iconSize = myIconSize * myFrameScale;
    const float padX = myPaddingX * myFrameScale;
    const float padY = myPaddingY * myFrameScale;
    const float colGap = myColumnGap * myFrameScale;
    const float rowGap = myRowGap * myFrameScale;
    const float timerHeight = 18.f * myFrameScale;

    const float width =
        padX * 2.f +
        myColumns * iconSize +
        (myColumns - 1) * colGap;

    const float height =
        padY * 2.f +
        myRows * iconSize +
        myRows * timerHeight +
        (myRows - 1) * rowGap;

    return { width, height };
}

void BuffFrame::SyncVisuals()
{
    const Tga::Vector2f p = GetPosition();
    const Tga::Vector2f size = (GetHalfSize() * 2.f) * myFrameScale;
    const float w = size.x;
    const float h = size.y;

    myBgInst.myPosition = p;
    myBgInst.mySize = size;

    const float x0 = p.x - w * 0.5f;
    const float yTop = p.y + h * 0.5f;

    const float iconSize = myIconSize * myFrameScale;
    const float padX = myPaddingX * myFrameScale;
    const float padY = myPaddingY * myFrameScale;
    const float colGap = myColumnGap * myFrameScale;
    const float rowGap = myRowGap * myFrameScale;

    auto& buffs = GetDisplayBuffsMutable();
    const int count = std::min((int)buffs.size(), myMaxVisibleBuffs);

    const float cellW = iconSize + colGap;
    const float cellH = iconSize + 18.f * myFrameScale + rowGap; // icon + timer text + gap

    for (int i = 0; i < count; ++i)
    {
        auto& buff = buffs[i];

        const int col = i % myColumns;
        const int row = i / myColumns;

        if (row >= myRows)
            break;

        const float rightX = x0 + w - padX - iconSize * 0.5f;
        const float iconCenterX = rightX - col * cellW;
        const float iconCenterY = yTop - padY - iconSize * 0.5f - row * cellH;

        buff.iconInst.mySize = { iconSize, iconSize };
        buff.iconInst.myPosition = { iconCenterX, iconCenterY };

        const std::string txt = FormatTime(buff.timeLeft);
        buff.timeText.SetText(txt.c_str());
        buff.timeText.SetPosition({
            iconCenterX - buff.timeText.GetWidth() * 0.5f,
            iconCenterY - iconSize * 0.5f - 16.f * myFrameScale
            });

        buff.nameText.SetPosition({ -100000.f, -100000.f });
    }
}

std::string BuffFrame::FormatTime(float seconds) const
{
    if (seconds <= 0.f)
        return "0s";

    const int total = static_cast<int>(seconds);

    if (total >= 60)
    {
        const int mins = total / 60;
        return std::to_string(mins) + "m";
    }

    return std::to_string(total) + "s";
}

const std::vector<BuffFrame::BuffEntry>& BuffFrame::GetDisplayBuffs() const
{
    if (myEditMode)
        return myPreviewBuffs;

    return myBuffs;
}

std::vector<BuffFrame::BuffEntry>& BuffFrame::GetDisplayBuffsMutable()
{
    if (myEditMode)
        return myPreviewBuffs;

    return myBuffs;
}

void BuffFrame::ClearPreviewBuffs()
{
    myPreviewBuffs.clear();
}

void BuffFrame::EnsurePreviewBuffs()
{
    if (!myEditMode)
        return;

    if (!myPreviewBuffs.empty())
        return;

    auto& tm = Tga::Engine::GetInstance()->GetTextureManager();

    struct PreviewDef
    {
        int id;
        const char* name;
        const char* icon;
        float timeLeft;
    };

    const PreviewDef defs[] =
    {
        { 10001, "Arcane Intellect", "assets/ui/textures/Spells/Arcane_Intellect.jpg", 1800.f },
        { 10002, "Dampen Magic",     "assets/ui/textures/Spells/Dampen_Magic.jpg",     600.f  },
        { 10003, "Amplify Magic",    "assets/ui/textures/Spells/Amplify_Magic.jpg",    120.f  },
        { 10004, "Blink",            "assets/ui/textures/Spells/Blink.jpg",             48.f   },
        { 10005, "Fire Blast",       "assets/ui/textures/Spells/Fire_Blast.jpg",        22.f   },
        { 10006, "Frost Nova",       "assets/ui/textures/Spells/Frost_Nova.jpg",        9.f    },
        { 10007, "Cone of Cold",     "assets/ui/textures/Spells/Cone_of_Cold.jpg",      75.f   },
        { 10008, "Blizzard",         "assets/ui/textures/Spells/Blizzard.jpg",          300.f  }
    };

    for (const auto& d : defs)
    {
        BuffEntry entry;
        entry.id = d.id;
        entry.name = d.name;
        entry.iconPath = d.icon;
        entry.duration = d.timeLeft;
        entry.timeLeft = d.timeLeft;
        entry.active = true;

        entry.iconShared.myTexture = tm.GetTexture(d.icon);
        entry.iconShared.blendState = Tga::BlendState::AlphaBlend;
        entry.iconShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

        entry.iconInst.myPivot = { 0.5f, 0.5f };
        entry.iconInst.myColor = { 1.f,1.f,1.f,1.f };
        entry.iconInst.myIsHidden = (entry.iconShared.myTexture == nullptr);

        entry.timeText.SetColor({ 1.f,1.f,1.f,1.f });
        entry.nameText.SetColor({ 1.f,1.f,1.f,1.f });
        entry.nameText.SetText(d.name);

        myPreviewBuffs.push_back(std::move(entry));
    }
}

void BuffFrame::DrawDebugRect(const Tga::Vector2f& center, const Tga::Vector2f& size, const Tga::Color& color)
{
    const float halfW = size.x * 0.5f;
    const float halfH = size.y * 0.5f;

    const Tga::Vector3f tl{ center.x - halfW, center.y - halfH, 0.f };
    const Tga::Vector3f tr{ center.x + halfW, center.y - halfH, 0.f };
    const Tga::Vector3f br{ center.x + halfW, center.y + halfH, 0.f };
    const Tga::Vector3f bl{ center.x - halfW, center.y + halfH, 0.f };

    auto& dbg = Tga::Engine::GetInstance()->GetDebugDrawer();
    dbg.DrawLine(tl, tr, color);
    dbg.DrawLine(tr, br, color);
    dbg.DrawLine(br, bl, color);
    dbg.DrawLine(bl, tl, color);
}

void BuffFrame::DrawDebugLayout()
{
    DrawDebugRect(myBgInst.myPosition, myBgInst.mySize, { 0.f, 1.f, 0.f, 1.f });
}