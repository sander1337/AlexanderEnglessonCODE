﻿#include "PlayerFrame.h"
#include <tge/engine.h>
#include <tge/texture/TextureManager.h>
#include <tge/drawers/SpriteDrawer.h>
#include <tge/graphics/GraphicsEngine.h>
#include <tge/graphics/GraphicsStateStack.h>
#include <tge/drawers/DebugDrawer.h>
#include "States/Hud/HUD.h" // for edit mode integration if you want


static float PxFromH(float h, float t) { return h * t; } // t in 0..1
static float PxFromW(float w, float t) { return w * t; }


void PlayerFrame::InitRuntimeFrame(HUD* hud,
    const std::shared_ptr<Tga::Camera>& uiCam,
    const Tga::Vector2f& pos,
    const Tga::Vector2f& size)
{
    myHUD = hud;

    InitRuntime(pos, size);
    SetCamera(uiCam);
    SetVisible(true);

    auto& tm = Tga::Engine::GetInstance()->GetTextureManager();

    // Pick your textures
    myFrameShared.myTexture = tm.GetTexture("assets/ui/textures/frames/player_frame.png");
    myFrameShared.blendState = Tga::BlendState::AlphaBlend;
    myFrameShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    myFrameInst.myPivot = { 0.5f, 0.5f };
    myFrameInst.myIsHidden = (myFrameShared.myTexture == nullptr);
    myFrameInst.myColor = { 1,1,1,1 };

    // ✅ Portrait circular png (use your real path)
    myPortraitShared.myTexture = tm.GetTexture("assets/ui/textures/frames/player_portrait_circle.png");
    if (!myPortraitShared.myTexture)
        std::cout << "[PlayerFrame] portrait texture NOT found!\n";
    else
        std::cout << "[PlayerFrame] portrait texture loaded OK\n";
    myPortraitShared.blendState = Tga::BlendState::AlphaBlend;
    myPortraitShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;
    myPortraitInst.myPivot = { 0.5f, 0.5f };
    myPortraitInst.myIsHidden = (myPortraitShared.myTexture == nullptr);
    myPortraitInst.myColor = { 1,1,1,1 };

    // We’ll use white_1x1 and tint it for row backgrounds + fills
    auto white = tm.GetTexture("assets/ui/textures/white_1x1.png");

    // ✅ Name row background (empty bar)
    myNameBgShared.myTexture = white;
    myNameBgShared.blendState = Tga::BlendState::AlphaBlend;
    myNameBgShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;
    myNameBgInst.myPivot = { 0.5f, 0.5f };
    myNameBgInst.myIsHidden = (myNameBgShared.myTexture == nullptr);
    myNameBgInst.myColor = { 0.05f, 0.05f, 0.05f, 0.85f };

    // ✅ HP bg
    myHpBgShared.myTexture = white;
    myHpBgShared.blendState = Tga::BlendState::AlphaBlend;
    myHpBgShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;
    myHpBgInst.myPivot = { 0.5f, 0.5f };
    myHpBgInst.myIsHidden = (myHpBgShared.myTexture == nullptr);
    myHpBgInst.myColor = { 0.05f, 0.05f, 0.05f, 0.85f };

    // ✅ HP fill
    myHpFillShared.myTexture = white;
    myHpFillShared.blendState = Tga::BlendState::AlphaBlend;
    myHpFillShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;
    myHpFillInst.myPivot = { 0.5f, 0.5f };
    myHpFillInst.myIsHidden = (myHpFillShared.myTexture == nullptr);
    myHpFillInst.myColor = { 0.1f, 0.9f, 0.1f, 1.0f };

    // ✅ Mana bg
    myManaBgShared.myTexture = white;
    myManaBgShared.blendState = Tga::BlendState::AlphaBlend;
    myManaBgShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;
    myManaBgInst.myPivot = { 0.5f, 0.5f };
    myManaBgInst.myIsHidden = (myManaBgShared.myTexture == nullptr);
    myManaBgInst.myColor = { 0.05f, 0.05f, 0.05f, 0.85f };

    // ✅ Mana fill
    myManaFillShared.myTexture = white;
    myManaFillShared.blendState = Tga::BlendState::AlphaBlend;
    myManaFillShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;
    myManaFillInst.myPivot = { 0.5f, 0.5f };
    myManaFillInst.myIsHidden = (myManaFillShared.myTexture == nullptr);
    myManaFillInst.myColor = { 0.25f, 0.45f, 1.0f, 1.0f }; // blue

    myNameText = Tga::Text("Text/arial.ttf", Tga::FontSize_14, 1);
    myNameText.SetColor({ 1,1,1,1 });
    myNameText.SetText("Player");

    myManaText = Tga::Text("Text/arial.ttf", Tga::FontSize_14, 1);
    myManaText.SetColor({ 1,1,1,0.9f });
    myManaText.SetText("0 / 0");

    myHpText = Tga::Text("Text/arial.ttf", Tga::FontSize_14, 1);
    myHpText.SetColor({ 1,1,1,0.9f });

    SyncVisuals();
}

void PlayerFrame::SetEditMode(bool on)
{
    myEditMode = on;
    SetDraggable(on);
    if (!on) CancelDrag();
}

void PlayerFrame::ReceiveInput(InputEvent e, const std::any& data)
{
    if (!IsVisible())
        return;

    Button::ReceiveInput(e, data);
}

void PlayerFrame::SetName(const char* name)
{
    myNameText.SetText(name ? name : "Player");
}

void PlayerFrame::SetHealth(int hp, int maxHp)
{
    myHp = std::max(0, hp);
    myMaxHp = std::max(1, maxHp);

    const std::string s = std::to_string(myHp) + " / " + std::to_string(myMaxHp);
    myHpText.SetText(s.c_str());
}
void PlayerFrame::SetMana(int mana, int maxMana)
{
    myMana = std::max(0, mana);
    myMaxMana = std::max(1, maxMana);

    const std::string s = std::to_string(myMana) + " / " + std::to_string(myMaxMana);
    myManaText.SetText(s.c_str());
}

void PlayerFrame::Update(float dt)
{
    if (!IsVisible()) return;   // use Button visibility
    Button::Update(dt);

    SyncVisuals();
}

void PlayerFrame::Render()
{
    if (!IsVisible())
    {
        return;
    }

    auto& engine = *Tga::Engine::GetInstance();
    auto& gss = engine.GetGraphicsEngine().GetGraphicsStateStack();
    auto& drawer = engine.GetGraphicsEngine().GetSpriteDrawer();

    SyncVisuals();

    gss.Push();
    gss.SetBlendState(Tga::BlendState::AlphaBlend);

    // ✅ Portrait
    if (myPortraitShared.myTexture && !myPortraitInst.myIsHidden)
        drawer.Draw(myPortraitShared, myPortraitInst);

    // ✅ Frame
    if (myFrameShared.myTexture && !myFrameInst.myIsHidden)
        drawer.Draw(myFrameShared, myFrameInst);

    // ✅ HP
    if (myHpBgShared.myTexture && !myHpBgInst.myIsHidden)
        drawer.Draw(myHpBgShared, myHpBgInst);
    if (myHpFillShared.myTexture && !myHpFillInst.myIsHidden)
        drawer.Draw(myHpFillShared, myHpFillInst);

    // ✅ Mana
    if (myManaBgShared.myTexture && !myManaBgInst.myIsHidden)
        drawer.Draw(myManaBgShared, myManaBgInst);
    if (myManaFillShared.myTexture && !myManaFillInst.myIsHidden)
        drawer.Draw(myManaFillShared, myManaFillInst);

    // Text
    myNameText.Render();
    myHpText.Render();
    myManaText.Render();



    gss.Pop();
    if (myEditMode)
    {
        DrawDebugLayout();
    }

}

void PlayerFrame::SyncVisuals()
{
    const Tga::Vector2f p = GetPosition();
    const Tga::Vector2f size = (GetHalfSize() * 2.f) * myFrameScale;
	const float w = size.x;
    const float h = size.y;

    // Frame sprite matches widget
    myFrameInst.myPosition = p;
    myFrameInst.mySize = size;

    // =========================================================
    // 1) TUNE THESE RATIOS to match your frame art
    // =========================================================

    // Inner rectangle (the long carved bar area) relative to widget
    const float innerL = 0.385f; // % of width from left
    const float innerR = 0.05f; // % of width from right
    const float innerT = 0.44f; // % of height from top
    const float innerB = 0.15f; // % of height from bottom

    // Portrait circle placement relative to widget
    const float portraitCX = 0.20f; // center x as % of width from left edge
    const float portraitCY = 0.50f; // center y as % of height (0=bottom, 1=top)
    const float portraitD = 0.78f; // diameter as % of height

    // Bars vertical layout inside inner rect
    const float rowGapN = 0.06f;    // gap as % of innerH
    const float hpHN = 0.38f;    // hp height % of innerH
    const float manaHN = 0.26f;    // mana height % of innerH

    // Small padding inside inner rect
    const float padXn = 0.03f;      // % of innerW
    const float padYn = 0.06f;      // % of innerH

    // =========================================================
    // 2) Compute inner rect in world space
    // =========================================================
    const float x0 = p.x - w * 0.5f;
    const float y0 = p.y - h * 0.5f;

    const float innerX0 = x0 + w * innerL;
    const float innerX1 = x0 + w * (1.f - innerR);
    const float innerY1 = y0 + h * (1.f - innerT);
    const float innerY0 = y0 + h * innerB;

    const float innerW = std::max(10.f, innerX1 - innerX0);
    const float innerH = std::max(10.f, innerY1 - innerY0);

    const float padX = innerW * padXn;
    const float padY = innerH * padYn;

    // =========================================================
    // 3) Portrait rect (goes in the hole)
    // =========================================================
    const float pd = h * portraitD;
    myPortraitInst.mySize = { pd, pd };
    myPortraitInst.myPosition =
    {
        x0 + w * portraitCX,
        y0 + h * portraitCY
    };

    // =========================================================
    // 4) Bars inside inner rect
    // =========================================================
    const float usableW = innerW - padX * 2.f;

    const float gap = innerH * rowGapN;
    const float hpH = innerH * hpHN;
    const float manaH = innerH * manaHN;

    // Start from top inside inner rect
    float y = innerY1 - padY;

    const float hpY = y - hpH * 0.5f; y -= hpH + gap;
    const float manaY = y - manaH * 0.5f;

    const float cx = innerX0 + padX + usableW * 0.5f;
    const float left = innerX0 + padX;

    // --- Name in top tab ---
    const float tabCenterX = x0 + w * 0.44f;   // tweak horizontally
    const float tabCenterY = y0 + h * 0.62f;   // tweak vertically

    // HP bg + fill
    myHpBgInst.myPosition = { cx, hpY };
    myHpBgInst.mySize = { usableW, hpH };

    const float hp01 = (float)myHp / (float)std::max(1, myMaxHp);
    const float hpFillW = usableW * std::clamp(hp01, 0.f, 1.f);
    myHpFillInst.mySize = { hpFillW, hpH };
    myHpFillInst.myPosition = { left + hpFillW * 0.5f, hpY };

    // Mana bg + fill
    myManaBgInst.myPosition = { cx, manaY };
    myManaBgInst.mySize = { usableW, manaH };

    const float mana01 = (float)myMana / (float)std::max(1, myMaxMana);
    const float manaFillW = usableW * std::clamp(mana01, 0.f, 1.f);
    myManaFillInst.mySize = { manaFillW, manaH };
    myManaFillInst.myPosition = { left + manaFillW * 0.5f, manaY };

    // Text (tweak baseline factor if needed)
	myNameText.SetPosition({tabCenterX - myNameText.GetWidth() * 0.5f,tabCenterY});
    myHpText.SetPosition({ left + usableW * 0.03f, hpY - hpH * 0.4f });
    myManaText.SetPosition({ left + usableW * 0.03f, manaY - manaH * 0.4f });
}

void PlayerFrame::DrawDebugRect(const Tga::Vector2f& center, const Tga::Vector2f& size, const Tga::Color& color)
{
    const float halfW = size.x * 0.5f;
    const float halfH = size.y * 0.5f;

    const Tga::Vector3f tl{ center.x - halfW, center.y - halfH, 0.f };
    const Tga::Vector3f tr{ center.x + halfW, center.y - halfH, 0.f };
    const Tga::Vector3f br{ center.x + halfW, center.y + halfH, 0.f };
    const Tga::Vector3f bl{ center.x - halfW, center.y + halfH, 0.f };

    auto& dbg = Tga::Engine::GetInstance()->GetDebugDrawer();
    dbg.DrawLine(tl, tr, color);
    dbg.DrawLine(tr, br, color);
    dbg.DrawLine(br, bl, color);
    dbg.DrawLine(bl, tl, color);
}

void PlayerFrame::DrawDebugLayout()
{
    DrawDebugRect(myFrameInst.myPosition, myFrameInst.mySize, { 1.f, 1.f, 1.f, 1.f }); // full frame
}

