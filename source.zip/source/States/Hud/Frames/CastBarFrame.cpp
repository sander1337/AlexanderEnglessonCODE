#include "CastBarFrame.h"
#include "States/Hud/HUD.h"

#include <tge/engine.h>
#include <tge/texture/TextureManager.h>
#include <tge/drawers/SpriteDrawer.h>
#include <tge/graphics/GraphicsEngine.h>
#include <tge/graphics/GraphicsStateStack.h>
#include <tge/drawers/DebugDrawer.h>

#include <algorithm>
#include <string>

void CastBarFrame::InitRuntimeFrame(HUD* hud,
    const std::shared_ptr<Tga::Camera>& uiCam,
    const Tga::Vector2f& pos,
    const Tga::Vector2f& size)
{
    myHUD = hud;

    InitRuntime(pos, size);
    SetCamera(uiCam);
    SetVisible(false);

    auto& tm = Tga::Engine::GetInstance()->GetTextureManager();
    auto white = tm.GetTexture("assets/ui/textures/white_1x1.png");

    myBgShared.myTexture = white;
    myBgShared.blendState = Tga::BlendState::AlphaBlend;
    myBgShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    myFillShared.myTexture = white;
    myFillShared.blendState = Tga::BlendState::AlphaBlend;
    myFillShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    myBorderShared.myTexture = white;
    myBorderShared.blendState = Tga::BlendState::AlphaBlend;
    myBorderShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    myBgInst.myPivot = { 0.5f, 0.5f };
    myBgInst.myColor = { 0.05f, 0.05f, 0.05f, 0.90f };

    myFillInst.myPivot = { 0.5f, 0.5f };
    myFillInst.myColor = { 0.95f, 0.70f, 0.20f, 1.f };

    myBorderInst.myPivot = { 0.5f, 0.5f };
    myBorderInst.myColor = { 0.20f, 0.20f, 0.20f, 1.f };

    mySpellNameText = Tga::Text("Text/arial.ttf", Tga::FontSize_14, 1);
    mySpellNameText.SetColor({ 1.f, 1.f, 1.f, 1.f });

    myTimeText = Tga::Text("Text/arial.ttf", Tga::FontSize_14, 1);
    myTimeText.SetColor({ 1.f, 1.f, 1.f, 1.f });

    SyncVisuals();
}

void CastBarFrame::SetEditMode(bool on)
{
    myEditMode = on;
    SetDraggable(on);

    if (!on)
        CancelDrag();
}

void CastBarFrame::StartCast(const ActionBarSpell& spell)
{
    myCurrentSpell = spell;
    myCastDuration = std::max(0.01f, spell.castTime);
    myCastElapsed = 0.f;
    myIsCasting = true;

    mySpellNameText.SetText(spell.name.c_str());
    SetVisible(true);

    SyncVisuals();
}

void CastBarFrame::StopCast()
{
    myIsCasting = false;
    myCastDuration = 0.f;
    myCastElapsed = 0.f;
    myCurrentSpell = {};
    SetVisible(false);
}

void CastBarFrame::Update(float dt)
{
    if (!IsVisible() && !myEditMode)
        return;

    Button::Update(dt);

    if (myIsCasting)
    {
        myCastElapsed += dt;

        if (myCastElapsed >= myCastDuration)
        {
            StopCast();

            // if editing, keep visible as preview
            if (myEditMode)
                SetVisible(true);

            SyncVisuals();
            return;
        }
    }

    SyncVisuals();
}

void CastBarFrame::Render()
{
    if (!IsVisible())
        return;

    SyncVisuals();


    auto& engine = *Tga::Engine::GetInstance();
    auto& gss = engine.GetGraphicsEngine().GetGraphicsStateStack();
    auto& drawer = engine.GetGraphicsEngine().GetSpriteDrawer();

    gss.Push();
    gss.SetBlendState(Tga::BlendState::AlphaBlend);

    drawer.Draw(myBgShared, myBgInst);
    drawer.Draw(myFillShared, myFillInst);

    mySpellNameText.Render();
    myTimeText.Render();

    gss.Pop();

    if (myEditMode)
    {
        DrawDebugLayout();
    }
}

void CastBarFrame::SetFrameScale(float s)
{
    myFrameScale = s;
    SyncVisuals();
}

void CastBarFrame::SyncVisuals()
{
    const Tga::Vector2f p = GetPosition();
    const Tga::Vector2f size = (GetHalfSize() * 2.f) * myFrameScale;

    myBgInst.myPosition = p;
    myBgInst.mySize = size;

    float progress = 0.f;

    if (myIsCasting)
    {
        progress = std::clamp(myCastElapsed / std::max(0.01f, myCastDuration), 0.f, 1.f);
    }
    else if (myEditMode)
    {
        progress = 0.65f; // preview fill while editing
    }

    const float fillW = size.x * progress;
    const float left = p.x - size.x * 0.5f;

    myFillInst.mySize = { fillW, size.y };
    myFillInst.myPosition = { left + fillW * 0.5f, p.y };

    mySpellNameText.SetPosition({
        p.x - mySpellNameText.GetWidth() * 0.5f,
        p.y + 18.f
        });

    if (myIsCasting)
    {
        const float remain = std::max(0.f, myCastDuration - myCastElapsed);
        myTimeText.SetText(std::to_string(remain).substr(0, 4).c_str());
    }
    else if (myEditMode)
    {
        mySpellNameText.SetText("Fireball");
        myTimeText.SetText("2.3");
    }
    else
    {
        myTimeText.SetText("");
    }
    myTimeText.SetPosition({
        p.x + size.x * 0.5f - 45.f,
        p.y - 10.f
        });
}

void CastBarFrame::DrawDebugRect(const Tga::Vector2f& center, const Tga::Vector2f& size, const Tga::Color& color)
{
    const float halfW = size.x * 0.5f;
    const float halfH = size.y * 0.5f;

    const Tga::Vector3f tl{ center.x - halfW, center.y - halfH, 0.f };
    const Tga::Vector3f tr{ center.x + halfW, center.y - halfH, 0.f };
    const Tga::Vector3f br{ center.x + halfW, center.y + halfH, 0.f };
    const Tga::Vector3f bl{ center.x - halfW, center.y + halfH, 0.f };

    auto& dbg = Tga::Engine::GetInstance()->GetDebugDrawer();
    dbg.DrawLine(tl, tr, color);
    dbg.DrawLine(tr, br, color);
    dbg.DrawLine(br, bl, color);
    dbg.DrawLine(bl, tl, color);
}

void CastBarFrame::DrawDebugLayout()
{
    DrawDebugRect(myBgInst.myPosition, myBgInst.mySize, { 1.f, 1.f, 1.f, 1.f });
}
