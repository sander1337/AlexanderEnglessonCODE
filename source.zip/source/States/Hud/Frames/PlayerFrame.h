﻿#pragma once
#include "../../../UI/Button.h"
#include <tge/sprite/Sprite.h>
#include <tge/text/text.h>
#include <tge/math/Vector2.h>

namespace Tga { class Camera; }
class HUD;

class PlayerFrame : public Button
{
public:
    void InitRuntimeFrame(HUD* hud,
        const std::shared_ptr<Tga::Camera>& uiCam,
        const Tga::Vector2f& pos,
        const Tga::Vector2f& size);

    void SetEditMode(bool on);
    void ReceiveInput(InputEvent e, const std::any& data) override;
    void SetName(const char* name);
    void SetHealth(int hp, int maxHp);
    void SetMana(int mana, int maxMana);                

    void Render() override;
    void Update(float dt) override;
    bool ShouldRenderDebugBounds() const override { return false; }
    void SetFrameScale(float s) { myFrameScale = s; }
    float GetFrameScale() const { return myFrameScale; }
private:
    void SyncVisuals();
    void DrawDebugRect(const Tga::Vector2f& center, const Tga::Vector2f& size, const Tga::Color& color);
    void DrawDebugLayout();
private:
    bool myEditMode = false;
    HUD* myHUD = nullptr;
    float myFrameScale = 1.f;
    // (Optional) one big background frame (your existing)
    Tga::SpriteSharedData myFrameShared{};
    Tga::Sprite2DInstanceData myFrameInst{};

    // ✅ Portrait (circular png)
    Tga::SpriteSharedData myPortraitShared{};
    Tga::Sprite2DInstanceData myPortraitInst{};

    // ✅ Name row background (empty bar)
    Tga::SpriteSharedData myNameBgShared{};
    Tga::Sprite2DInstanceData myNameBgInst{};

    // ✅ HP background + fill
    Tga::SpriteSharedData myHpBgShared{};
    Tga::Sprite2DInstanceData myHpBgInst{};
    Tga::SpriteSharedData myHpFillShared{};
    Tga::Sprite2DInstanceData myHpFillInst{};

    // ✅ Mana background + fill
    Tga::SpriteSharedData myManaBgShared{};
    Tga::Sprite2DInstanceData myManaBgInst{};
    Tga::SpriteSharedData myManaFillShared{};
    Tga::Sprite2DInstanceData myManaFillInst{};

    // Text
    Tga::Text myNameText;
    Tga::Text myHpText;
    Tga::Text myManaText;                                // ✅ NEW

    int myHp = 1;
    int myMaxHp = 1;

    int myMana = 0;                                      // ✅ NEW
    int myMaxMana = 1;                                   // ✅ NEW
};