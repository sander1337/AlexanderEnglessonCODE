#pragma once
#include "../../../UI/Button.h"
#include <tge/sprite/Sprite.h>
#include <tge/text/text.h>
#include <tge/math/Vector2.h>

#include <vector>
#include <string>
#include <memory>

namespace Tga { class Camera; }
class HUD;
struct ActionBarSpell;

class BuffFrame : public Button
{
public:
    struct BuffEntry
    {
        int id = 0;
        std::string name;
        std::string iconPath;
        float duration = 0.f;     // 0 = permanent / no timer
        float timeLeft = 0.f;
        bool active = false;

        Tga::SpriteSharedData iconShared{};
        Tga::Sprite2DInstanceData iconInst{};
        Tga::Text timeText;
        Tga::Text nameText;

        BuffEntry()
            : timeText("Text/arial.ttf", Tga::FontSize_12, 1)
            , nameText("Text/arial.ttf", Tga::FontSize_12, 1)
        {
        }
    };

public:
    void InitRuntimeFrame(HUD* hud,
        const std::shared_ptr<Tga::Camera>& uiCam,
        const Tga::Vector2f& pos,
        const Tga::Vector2f& size);

    void SetEditMode(bool on);
    void Update(float dt) override;
    void Render() override;
    void ReceiveInput(InputEvent e, const std::any& data) override;
    bool ShouldRenderDebugBounds() const override { return false; }

    void AddOrRefreshBuff(int id, const std::string& name, const std::string& iconPath, float duration);
    void RemoveBuff(int id);
    void ClearBuffs();
    bool HasBuff(int id) const;

    void SetFrameScale(float s) { myFrameScale = s; }
    float GetFrameScale() const { return myFrameScale; }

    int HitTestBuffIndex(const Tga::Vector2f& mouseWorld) const;
    bool RemoveBuffAtMouse(const Tga::Vector2f& mouseWorld);

    void SetGrid(int columns, int rows)
    {
        myColumns = columns;
        myRows = rows;
        SyncVisuals();
    }

    void SetLayout(float iconSize, float paddingX, float paddingY, float colGap, float rowGap)
    {
        myIconSize = iconSize;
        myPaddingX = paddingX;
        myPaddingY = paddingY;
        myColumnGap = colGap;
        myRowGap = rowGap;
        SyncVisuals();
    }

    Tga::Vector2f GetRecommendedSize() const;

private:
    void SyncVisuals();
    void DrawDebugRect(const Tga::Vector2f& center, const Tga::Vector2f& size, const Tga::Color& color);
    void DrawDebugLayout();
    std::string FormatTime(float seconds) const;
    const std::vector<BuffEntry>& GetDisplayBuffs() const;
    std::vector<BuffEntry>& GetDisplayBuffsMutable();
    void EnsurePreviewBuffs();
    void ClearPreviewBuffs();
private:
    bool myEditMode = false;
    HUD* myHUD = nullptr;
    float myFrameScale = 1.f;

    Tga::SpriteSharedData myBgShared{};
    Tga::Sprite2DInstanceData myBgInst{};

    std::vector<BuffEntry> myBuffs;
    std::vector<BuffEntry> myPreviewBuffs;
    float myPaddingX = 10.f;
    float myPaddingY = 10.f;
    float myIconSize = 60.f;
    float myColumnGap = 10.f;
    float myRowGap = 18.f;
    int myColumns = 10;
    int myRows = 2;
    int myMaxVisibleBuffs = 20;
};