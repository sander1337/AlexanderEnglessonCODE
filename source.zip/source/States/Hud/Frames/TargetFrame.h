#pragma once
#include "../../../UI/Button.h"
#include <tge/sprite/Sprite.h>
#include <tge/text/text.h>
#include <tge/math/Vector2.h>

namespace Tga { class Camera; }
class HUD;

class TargetFrame : public Button
{
public:
    struct UnitSnapshot
    {
        std::string name;
        int hp = 1;
        int maxHp = 1;
        int mana = 0;
        int maxMana = 1;
    };


    void InitRuntimeFrame(HUD* hud,const std::shared_ptr<Tga::Camera>& uiCam,const Tga::Vector2f& pos,const Tga::Vector2f& size);

    void SetEditMode(bool on);

    void SetTarget(const UnitSnapshot& u);
    void ClearTarget();
    void SetName(const char* name);
    void SetHealth(int hp, int maxHp);
    void SetMana(int mana, int maxMana);
    bool ShouldRenderDebugBounds() const override { return false; }
    void Render() override;
    void Update(float dt) override;

    void SetFrameScale(float s) { myFrameScale = s; }
    float GetFrameScale() const { return myFrameScale; }
private:
    void SyncVisuals();
    void DrawDebugRect(const Tga::Vector2f& center, const Tga::Vector2f& size, const Tga::Color& color);
    void DrawDebugLayout();
private:
    bool myEditMode = false;
    HUD* myHUD = nullptr;
    float myFrameScale = 1.f;
    Tga::SpriteSharedData myFrameShared{};
    Tga::Sprite2DInstanceData myFrameInst{};

    Tga::SpriteSharedData myPortraitShared{};
    Tga::Sprite2DInstanceData myPortraitInst{};

    Tga::SpriteSharedData myHpBgShared{};
    Tga::Sprite2DInstanceData myHpBgInst{};
    Tga::SpriteSharedData myHpFillShared{};
    Tga::Sprite2DInstanceData myHpFillInst{};

    Tga::SpriteSharedData myManaBgShared{};
    Tga::Sprite2DInstanceData myManaBgInst{};
    Tga::SpriteSharedData myManaFillShared{};
    Tga::Sprite2DInstanceData myManaFillInst{};

    Tga::Text myNameText;
    Tga::Text myHpText;
    Tga::Text myManaText;

    int myHp = 1;
    int myMaxHp = 1;

    int myMana = 0;
    int myMaxMana = 1;
    bool myHasTarget = false;
};