#pragma once
#include "../../../UI/Button.h"
#include "../../ActionBars/ActionBarSpell.h"

#include <tge/sprite/Sprite.h>
#include <tge/text/text.h>
#include <tge/math/Vector2.h>

namespace Tga { class Camera; }
class HUD;

class CastBarFrame : public Button
{
public:
    void InitRuntimeFrame(HUD* hud,
        const std::shared_ptr<Tga::Camera>& uiCam,
        const Tga::Vector2f& pos,
        const Tga::Vector2f& size);

    void SetEditMode(bool on);

    void StartCast(const ActionBarSpell& spell);
    void StopCast();
    bool IsCasting() const { return myIsCasting; }

    void Update(float dt) override;
    void Render() override;

    void SetFrameScale(float s);
    float GetFrameScale() const { return myFrameScale; }
    bool ShouldRenderDebugBounds() const override { return false; }
private:
    void SyncVisuals();
    void DrawDebugRect(const Tga::Vector2f& center, const Tga::Vector2f& size, const Tga::Color& color);
    void DrawDebugLayout();
private:
    float myFrameScale = 1.f;
    HUD* myHUD = nullptr;
    bool myEditMode = false;

    bool myIsCasting = false;
    float myCastDuration = 0.f;
    float myCastElapsed = 0.f;
    ActionBarSpell myCurrentSpell{};

    Tga::SpriteSharedData myBgShared{};
    Tga::Sprite2DInstanceData myBgInst{};

    Tga::SpriteSharedData myFillShared{};
    Tga::Sprite2DInstanceData myFillInst{};

    Tga::SpriteSharedData myBorderShared{};
    Tga::Sprite2DInstanceData myBorderInst{};

    Tga::Text mySpellNameText;
    Tga::Text myTimeText;
};