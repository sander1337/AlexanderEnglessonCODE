#include "stdafx.h"
#include "FrameScalePopup.h"

#include <algorithm>
#include <cmath>
#include <vector>

#include <tge/engine.h>
#include <tge/texture/TextureManager.h>
#include <tge/drawers/SpriteDrawer.h>
#include <tge/input/InputManager.h>
#include "../../../Utilities/UIRectUtils.h"

#include "PlayerFrame.h"
#include "TargetFrame.h"
#include "CastBarFrame.h"

bool FrameScalePopup::PointInRectCenterSize(const Tga::Vector2f& p, const Tga::Vector2f& c, const Tga::Vector2f& s) const
{
    const Tga::Vector2f h = { s.x * 0.5f, s.y * 0.5f };
    return (p.x >= c.x - h.x && p.x <= c.x + h.x &&
        p.y >= c.y - h.y && p.y <= c.y + h.y);
}

float FrameScalePopup::SliderValue01(const Tga::Vector2f& mouse, const Tga::Vector2f& center, const Tga::Vector2f& size) const
{
    const float left = center.x - size.x * 0.5f;
    const float t = (mouse.x - left) / size.x;
    return std::max(0.f, std::min(1.f, t));
}

void FrameScalePopup::Init(const std::shared_ptr<Tga::Camera>& uiCam)
{
    myUiCam = uiCam;

    auto& tm = Tga::Engine::GetInstance()->GetTextureManager();

    myBgShared.myTexture = tm.GetTexture("assets/ui/textures/spellbook_panel.png");
    myBgShared.blendState = Tga::BlendState::AlphaBlend;
    myBgShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    myBgInst.myPivot = { 0.5f, 0.5f };
    myBgInst.myColor = { 1.f, 1.f, 1.f, 0.96f };
    myBgInst.myIsHidden = true;

    myBtnShared.myTexture = tm.GetTexture("assets/ui/textures/spellbook_panel.png");
    myBtnShared.blendState = Tga::BlendState::AlphaBlend;
    myBtnShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    myBtnCloseInst.myPivot = { 0.5f, 0.5f };
    myBtnCloseInst.myColor = { 1,1,1,1 };
    myBtnCloseInst.myIsHidden = false;

    mySliderTrackShared.myTexture = tm.GetTexture("assets/ui/textures/Slider_background.png");
    mySliderTrackShared.blendState = Tga::BlendState::AlphaBlend;
    mySliderTrackShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    mySliderKnobShared.myTexture = tm.GetTexture("assets/ui/textures/Slider_button.png");
    mySliderKnobShared.blendState = Tga::BlendState::AlphaBlend;
    mySliderKnobShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    mySliderTrackInst.myPivot = { 0.5f, 0.5f };
    mySliderKnobInst.myPivot = { 0.5f, 0.5f };

    myTitle = Tga::Text("Text/arial.ttf", Tga::FontSize_24, 1);
    myTitle.SetColor({ 1,1,1,1 });

    myLblScale = Tga::Text("Text/arial.ttf", Tga::FontSize_24, 1);
    myLblScale.SetText("Scale");
    myLblScale.SetColor({ 1,1,1,0.95f });

    myValScale = Tga::Text("Text/arial.ttf", Tga::FontSize_24, 1);
    myValScale.SetColor({ 1.f, 0.9f, 0.25f, 1.f });

    myCloseText = Tga::Text("Text/arial.ttf", Tga::FontSize_24, 1);
    myCloseText.SetText("X");
    myCloseText.SetColor({ 1,1,1,1 });
}

void FrameScalePopup::OpenNearPlayerFrame(PlayerFrame& frame)
{
    myOpen = true;
    myTargetType = TargetType::Player;
    myPlayerFrame = &frame;
    myTargetFrame = nullptr;

    myOriginalScale = frame.GetFrameScale();
    myEditScale = myOriginalScale;

    myPanelCenter = FindPopupCenter(frame.GetPosition(), myPanelSize.x, myPanelSize.y);

    myBgInst.myPosition = myPanelCenter;
    myBgInst.mySize = myPanelSize;
    myBgInst.myIsHidden = false;

    LayoutUI();
    ApplyToTarget();
}

void FrameScalePopup::OpenNearTargetFrame(TargetFrame& frame)
{
    myOpen = true;
    myTargetType = TargetType::Target;
    myPlayerFrame = nullptr;
    myTargetFrame = &frame;

    myOriginalScale = frame.GetFrameScale();
    myEditScale = myOriginalScale;

    myPanelCenter = FindPopupCenter(frame.GetPosition(), myPanelSize.x, myPanelSize.y);

    myBgInst.myPosition = myPanelCenter;
    myBgInst.mySize = myPanelSize;
    myBgInst.myIsHidden = false;

    LayoutUI();
    ApplyToTarget();
}

void FrameScalePopup::OpenNearCastBarFrame(CastBarFrame& frame)
{
    myOpen = true;
    myTargetType = TargetType::CastBar;
    myPlayerFrame = nullptr;
    myTargetFrame = nullptr;
    myCastBarFrame = &frame;

    myOriginalScale = frame.GetFrameScale();
    myEditScale = myOriginalScale;

    myPanelCenter = FindPopupCenter(frame.GetPosition(), myPanelSize.x, myPanelSize.y);

    myBgInst.myPosition = myPanelCenter;
    myBgInst.mySize = myPanelSize;
    myBgInst.myIsHidden = false;

    LayoutUI();
    ApplyToTarget();
}

void FrameScalePopup::Close()
{
    myOpen = false;
    myDraggingScale = false;
    myDraggingPanel = false;

    myTargetType = TargetType::None;
    myPlayerFrame = nullptr;
    myTargetFrame = nullptr;
    myCastBarFrame = nullptr;

    myBgInst.myIsHidden = true;
}

void FrameScalePopup::LayoutUI()
{
    const float W = myPanelSize.x;
    const float H = myPanelSize.y;

    const float left = myPanelCenter.x - W * 0.5f;
    const float right = myPanelCenter.x + W * 0.5f;
    const float top = myPanelCenter.y + H * 0.5f;

    const float padL = 40.f;
    const float padR = 40.f;
    const float padT = 35.f;

    const float innerL = left + padL;
    const float innerR = right - padR;
    const float innerT = top - padT;

    myTitle.SetText(
        myTargetType == TargetType::Player ? "Player Frame Scale" :
        myTargetType == TargetType::Target ? "Target Frame Scale" :
        myTargetType == TargetType::CastBar ? "Cast Bar Scale" :
        "Frame Scale");

    myTitle.SetPosition({ innerL, innerT });

    const float labelW = 120.f;
    const float valueW = 90.f;
    const float gap = 16.f;

    const float labelX = innerL;
    const float valueX = innerR - valueW;
    const float sliderL = labelX + labelW + gap;
    const float sliderR = valueX - gap;
    const float sliderW = std::max(120.f, sliderR - sliderL);

    const float y = innerT - 70.f;

    myLblScale.SetPosition({ labelX, y });
    myScaleSlider.c = { sliderL + sliderW * 0.5f, y + 12.f };
    myScaleSlider.s = { sliderW, 24.f };

    myValScale.SetPosition({ valueX, y });

    myCloseC = { right - 32.f, top - 30.f };
    myBtnCloseInst.myPosition = myCloseC;
    myBtnCloseInst.mySize = myCloseS;

    myCloseText.SetPosition({ myCloseC.x - 8.f, myCloseC.y - 12.f });

    myTitleBarC = { myPanelCenter.x, top - 35.f };
    myTitleBarS = { myPanelSize.x - 80.f, 70.f };
}

void FrameScalePopup::ApplyToTarget()
{
    myEditScale = std::max(myMinScale, std::min(myEditScale, myMaxScale));

    if (myPlayerFrame)
        myPlayerFrame->SetFrameScale(myEditScale);

    if (myTargetFrame)
        myTargetFrame->SetFrameScale(myEditScale);

    if (myCastBarFrame)
        myCastBarFrame->SetFrameScale(myEditScale);

    const int pct = (int)std::round(myEditScale * 100.f);
    myValScale.SetText((std::to_string(pct) + "%").c_str());
}

bool FrameScalePopup::Update(Tga::InputManager* im, const Tga::Vector2f& mouseWorld)
{
    if (!myOpen || !im)
        return false;

    const bool lmbDown = im->IsKeyHeld(VK_LBUTTON);
    const bool lmbPressed = im->IsKeyPressed(VK_LBUTTON);
    const bool lmbReleased = im->IsKeyReleased(VK_LBUTTON);

    if (lmbPressed)
    {
        if (!IsPointInsidePopup(mouseWorld))
        {
            Close();
            return true;
        }
    }

    if (lmbReleased)
    {
        myDraggingScale = false;
        myDraggingPanel = false;
    }

    if (lmbPressed)
    {
        if (PointInRectCenterSize(mouseWorld, myCloseC, myCloseS))
        {
            Close();
            return true;
        }

        if (PointInRectCenterSize(mouseWorld, myScaleSlider.c, myScaleSlider.s))
        {
            myDraggingScale = true;

            const float t = SliderValue01(mouseWorld, myScaleSlider.c, myScaleSlider.s);
            myEditScale = myMinScale + t * (myMaxScale - myMinScale);
            ApplyToTarget();
            return true;
        }

        if (PointInRectCenterSize(mouseWorld, myTitleBarC, myTitleBarS))
        {
            myDraggingPanel = true;
            myDragGrabOffset = mouseWorld - myPanelCenter;
            return true;
        }
    }

    if (lmbDown && myDraggingPanel && !myDraggingScale)
    {
        myPanelCenter = mouseWorld - myDragGrabOffset;
        myPanelCenter = ClampPopupToScreen(myPanelCenter, myPanelSize.x, myPanelSize.y);
        myBgInst.myPosition = myPanelCenter;

        LayoutUI();
        ApplyToTarget();
        return true;
    }

    if (lmbDown && myDraggingScale)
    {
        const float t = SliderValue01(mouseWorld, myScaleSlider.c, myScaleSlider.s);
        myEditScale = myMinScale + t * (myMaxScale - myMinScale);
        ApplyToTarget();
        return true;
    }

    return true;
}

void FrameScalePopup::Render(Tga::SpriteDrawer& drawer)
{
    if (!myOpen)
        return;

    drawer.Draw(myBgShared, myBgInst);
    drawer.Draw(myBtnShared, myBtnCloseInst);

    myTitle.Render();
    myLblScale.Render();
    myValScale.Render();
    myCloseText.Render();

    const float tScale = (myEditScale - myMinScale) / (myMaxScale - myMinScale);
    DrawSlider(drawer, myScaleSlider, tScale, 22.f, 22.f);
}

bool FrameScalePopup::IsPointInsidePopup(const Tga::Vector2f& p) const
{
    return PointInRectCenterSize(p, myPanelCenter, myPanelSize);
}

Tga::Vector2f FrameScalePopup::ClampPopupToScreen(Tga::Vector2f c, float panelW, float panelH) const
{
    if (!myUiCam)
        return c;

    const auto resI = Tga::Engine::GetInstance()->GetRenderSize();
    const Tga::Vector2f res{ (float)resI.x, (float)resI.y };

    const Tga::Vector2f worldBL = myUiCam->GetScreenToWorldCoordinatesVec2({ 0.f, 0.f });
    const Tga::Vector2f worldTR = myUiCam->GetScreenToWorldCoordinatesVec2({ res.x, res.y });

    const float halfW = panelW * 0.5f;
    const float halfH = panelH * 0.5f;

    c.x = std::max(worldBL.x + halfW, std::min(c.x, worldTR.x - halfW));
    c.y = std::max(worldBL.y + halfH, std::min(c.y, worldTR.y - halfH));
    return c;
}

Tga::Vector2f FrameScalePopup::FindPopupCenter(const Tga::Vector2f& anchor, float panelW, float panelH) const
{
    const float halfW = panelW * 0.5f;
    const float halfH = panelH * 0.5f;
    const float gap = 80.f;

    std::vector<Tga::Vector2f> candidates;
    candidates.push_back({ anchor.x + halfW + gap, anchor.y });
    candidates.push_back({ anchor.x - halfW - gap, anchor.y });
    candidates.push_back({ anchor.x, anchor.y + halfH + gap });
    candidates.push_back({ anchor.x, anchor.y - halfH - gap });

    Tga::Vector2f best = ClampPopupToScreen(candidates[0], panelW, panelH);
    float bestScore = 1e30f;

    for (const auto& c : candidates)
    {
        const Tga::Vector2f clamped = ClampPopupToScreen(c, panelW, panelH);
        const Tga::Vector2f d = clamped - c;
        const float score = d.x * d.x + d.y * d.y;

        if (score < bestScore)
        {
            bestScore = score;
            best = clamped;
        }
    }

    return best;
}



void FrameScalePopup::DrawSlider(Tga::SpriteDrawer& drawer, const SliderUI& ui, float t01, float knobW, float knobH)
{
    t01 = Clamp01(t01);

    mySliderTrackInst.myPosition = ui.c;
    mySliderTrackInst.mySize = ui.s;
    mySliderTrackInst.myColor = { 1,1,1,1 };
    mySliderTrackInst.myIsHidden = false;
    drawer.Draw(mySliderTrackShared, mySliderTrackInst);

    const float left = ui.c.x - ui.s.x * 0.5f;
    const float x = left + ui.s.x * t01;

    mySliderKnobInst.myPosition = { x, ui.c.y };
    mySliderKnobInst.mySize = { knobW, knobH };
    mySliderKnobInst.myColor = { 1,1,1,1 };
    mySliderKnobInst.myIsHidden = false;
    drawer.Draw(mySliderKnobShared, mySliderKnobInst);
}