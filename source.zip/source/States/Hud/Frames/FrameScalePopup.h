#pragma once

#include <memory>
#include <vector>
#include <tge/math/vector2.h>
#include <tge/sprite/Sprite.h>
#include <tge/text/text.h>

namespace Tga
{
    class Camera;
    class InputManager;
    class SpriteDrawer;
}

class PlayerFrame;
class TargetFrame;
class CastBarFrame;

class FrameScalePopup
{
public:
    void Init(const std::shared_ptr<Tga::Camera>& uiCam);

    void OpenNearPlayerFrame(PlayerFrame& frame);
    void OpenNearTargetFrame(TargetFrame& frame);
    void OpenNearCastBarFrame(CastBarFrame& frame);
    void Close();

    bool IsOpen() const { return myOpen; }

    bool Update(Tga::InputManager* im, const Tga::Vector2f& mouseWorld);
    void Render(Tga::SpriteDrawer& drawer);

private:
    enum class TargetType
    {
        None,
        Player,
        CastBar,
        Target
    };

    struct SliderUI
    {
        Tga::Vector2f c{};
        Tga::Vector2f s{};
    };

private:
    void LayoutUI();
    void ApplyToTarget();

    bool PointInRectCenterSize(const Tga::Vector2f& p, const Tga::Vector2f& c, const Tga::Vector2f& s) const;
    float SliderValue01(const Tga::Vector2f& mouse, const Tga::Vector2f& center, const Tga::Vector2f& size) const;
    bool IsPointInsidePopup(const Tga::Vector2f& p) const;
    Tga::Vector2f ClampPopupToScreen(Tga::Vector2f c, float panelW, float panelH) const;
    Tga::Vector2f FindPopupCenter(const Tga::Vector2f& anchor, float panelW, float panelH) const;
    void DrawSlider(Tga::SpriteDrawer& drawer, const SliderUI& ui, float t01, float knobW, float knobH);

private:
    bool myOpen = false;
    bool myDraggingScale = false;
    bool myDraggingPanel = false;

    TargetType myTargetType = TargetType::None;
    PlayerFrame* myPlayerFrame = nullptr;
    TargetFrame* myTargetFrame = nullptr;
    CastBarFrame* myCastBarFrame = nullptr;

    std::shared_ptr<Tga::Camera> myUiCam;

    float myOriginalScale = 1.f;
    float myEditScale = 1.f;

    float myMinScale = 0.75f;
    float myMaxScale = 1.50f;

    Tga::Vector2f myPanelCenter{};
    Tga::Vector2f myPanelSize{ 520.f, 240.f };
    Tga::Vector2f myDragGrabOffset{};

    Tga::Vector2f myTitleBarC{};
    Tga::Vector2f myTitleBarS{};

    SliderUI myScaleSlider{};
    Tga::Vector2f myCloseC{};
    Tga::Vector2f myCloseS{ 44.f, 44.f };

    Tga::SpriteSharedData myBgShared{};
    Tga::Sprite2DInstanceData myBgInst{};

    Tga::SpriteSharedData myBtnShared{};
    Tga::Sprite2DInstanceData myBtnCloseInst{};

    Tga::SpriteSharedData mySliderTrackShared{};
    Tga::SpriteSharedData mySliderKnobShared{};
    Tga::Sprite2DInstanceData mySliderTrackInst{};
    Tga::Sprite2DInstanceData mySliderKnobInst{};

    Tga::Text myTitle;
    Tga::Text myLblScale;
    Tga::Text myValScale;
    Tga::Text myCloseText;
};