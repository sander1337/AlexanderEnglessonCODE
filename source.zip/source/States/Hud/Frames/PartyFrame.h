#pragma once
#include "../../../UI/Button.h"
#include <tge/sprite/Sprite.h>
#include <tge/text/text.h>
#include <tge/math/Vector2.h>

namespace Tga { class Camera; }
class HUD;

class PartyFrame : public Button
{
public:
    void InitRuntimeFrame(HUD* hud,
        const std::shared_ptr<Tga::Camera>& uiCam,
        const Tga::Vector2f& anchorPos,     // top-most (or first) frame position
        const Tga::Vector2f& size,
        int partyIndex);                    // 0..4

    void SetEditMode(bool on);

    void SetPartyIndex(int idx);
    int  GetPartyIndex() const { return myPartyIndex; }

    void SetAnchorPosition(const Tga::Vector2f& anchorPos); // move whole stack start
    const Tga::Vector2f& GetAnchorPosition() const { return myAnchorPos; }

    void SetName(const char* name);
    void SetHealth(int hp, int maxHp);
    void SetMana(int mana, int maxMana);

    void Render() override;
    void Update(float dt) override;

    
    float GetFrameScale() const { return myFrameScale; }
    void SetFrameScale(float s);
    void SetUseRaidStyle(bool on);
    void SetUseHorizontalLayout(bool on);
    void SetRaidFrameWidth(float w);
    void SetRaidFrameHeight(float h);
    void RefreshLayout();
    bool ShouldRenderDebugBounds() const override { return false; }

private:
    void SyncVisuals();
    void SyncAutoPosition(); // computes GetPosition() based on anchor + index
    void SyncNormalVisuals();
    void SyncRaidVisuals();
    void DrawDebugRect(const Tga::Vector2f& center, const Tga::Vector2f& size);

    void UpdateTextSizes();
    Tga::FontSize CalcNameFontSize() const;
    Tga::FontSize CalcValueFontSize() const;
    static Tga::FontSize PickClosestFontSize(int px);
private:
    bool myEditMode = false;
    HUD* myHUD = nullptr;
    float myFrameScale = 1.f;
    Tga::Vector2f myNormalFrameSize{ 0.f, 0.f };
    int myPartyIndex = 0;
    Tga::Vector2f myAnchorPos{ 0.f, 0.f };
    float myVerticalSpacing = 18.f; // gap between frames (tweak)

    // === same visuals as PlayerFrame ===
    Tga::SpriteSharedData myFrameShared{};
    Tga::Sprite2DInstanceData myFrameInst{};

    Tga::SpriteSharedData myPortraitShared{};
    Tga::Sprite2DInstanceData myPortraitInst{};

    Tga::SpriteSharedData myRaidBgShared{};
    Tga::Sprite2DInstanceData myRaidBgInst{};

    Tga::SpriteSharedData myNameBgShared{};
    Tga::Sprite2DInstanceData myNameBgInst{};

    Tga::SpriteSharedData myHpBgShared{};
    Tga::Sprite2DInstanceData myHpBgInst{};
    Tga::SpriteSharedData myHpFillShared{};
    Tga::Sprite2DInstanceData myHpFillInst{};

    Tga::SpriteSharedData myManaBgShared{};
    Tga::Sprite2DInstanceData myManaBgInst{};
    Tga::SpriteSharedData myManaFillShared{};
    Tga::Sprite2DInstanceData myManaFillInst{};

    Tga::Text myNameText;
    Tga::Text myHpText;
    Tga::Text myManaText;

    int myHp = 1;
    int myMaxHp = 1;
    int myMana = 0;
    int myMaxMana = 1;

    bool myUseRaidStyle = false;
    bool myUseHorizontalLayout = false;
    float myRaidFrameWidth = 260.f;
    float myRaidFrameHeight = 70.f;

    std::string myNameString = "Party";
    std::string myHpString = "1 / 1";
    std::string myManaString = "0 / 0";

    int myCurrentNameFontSize = -1;
    int myCurrentValueFontSize = -1;
};