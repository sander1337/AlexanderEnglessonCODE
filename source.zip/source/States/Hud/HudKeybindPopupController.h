#pragma once
#include <memory>
#include <tge/math/Vector2.h>

class MenuScene;
class ActionBarSlotButton;

namespace Tga { class InputManager; class SpriteDrawer; }

#include "../../States/ActionBars/ActionBarKeybinds.h"

class HudKeybindPopupController
{
public:
    void Init(std::shared_ptr<MenuScene> scene);
    bool Update(Tga::InputManager* im, const Tga::Vector2f& mouseWorld); // returns true if modal ate input
    void Render(Tga::SpriteDrawer& drawer);

    void TryOpenPopupOnCtrlClick(Tga::InputManager* im, ActionBarSlotButton* slot);
    bool IsOpen() const { return myKeybinds.IsPopupOpen(); }

private:
    std::shared_ptr<MenuScene> myScene;
    ActionBarKeybinds myKeybinds;
};
