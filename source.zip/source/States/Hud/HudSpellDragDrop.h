#pragma once
#include <memory>
#include <functional>

#include <tge/math/Vector2.h>
#include <tge/sprite/Sprite.h>

#include "../ActionBars/ActionBarSpell.h"

class MenuScene;
class ActionBarSlotButton;
class HudActionBarsController;

namespace Tga { class SpriteDrawer; class InputManager; }

class HudSpellDragDrop
{
public:
    void Init(MenuScene& scene); // just stores scene ptr (for camera if needed)

    bool IsDragging() const { return myActive; }

    void BeginFromSlot(ActionBarSlotButton* from);
    void BeginFromSpell(const ActionBarSpell& spell);

    // Call every frame from HUD::Update AFTER you computed mouseWorld
    void Update(const Tga::Vector2f& mouseWorld, Tga::InputManager* im, HudActionBarsController& bars);

    void Render(Tga::SpriteDrawer& drawer);

    void Cancel(bool clearSourceIfMove = false);

    // Optional hooks (so dragdrop doesn't need to include HUD.h)
    void SetOnDropFromSpell(std::function<void(const ActionBarSpell&, ActionBarSlotButton* toSlot)> fn) { myOnDropFromSpell = std::move(fn); }
    void SetOnDropFromSlot(std::function<void(ActionBarSlotButton* from, ActionBarSlotButton* to, const ActionBarSpell& spell, bool copy)> fn) { myOnDropFromSlot = std::move(fn); }
    void SetOnCancelSpell(std::function<void()> fn) { myOnCancelSpell = std::move(fn); }

    // If you want CTRL-copy behavior:
    void SetCopyModifier(std::function<bool(Tga::InputManager*)> fn) { myIsCopyModifierHeld = std::move(fn); }

private:
    void StartIcon(const std::string& texturePath, const Tga::Vector2f& size, const Tga::Vector2f& mouseWorld);

private:
    MenuScene* myScene = nullptr;

    bool myActive = false;
    bool myFromSpellBook = false;

    ActionBarSlotButton* myFromSlot = nullptr;
    ActionBarSpell mySpell{};
    bool myCopy = false;

    // Drag icon
    Tga::SpriteSharedData myDragIconShared{};
    Tga::Sprite2DInstanceData myDragIconInst{};
    bool myDragIconVisible = false;

    Tga::Vector2f myDragOffset{ 0.f, 0.f };

    // Hooks
    std::function<void(const ActionBarSpell&, ActionBarSlotButton* toSlot)> myOnDropFromSpell;
    std::function<void(ActionBarSlotButton* from, ActionBarSlotButton* to, const ActionBarSpell& spell, bool copy)> myOnDropFromSlot;
    std::function<void()> myOnCancelSpell;

    std::function<bool(Tga::InputManager*)> myIsCopyModifierHeld; // ex: ctrl held
};
