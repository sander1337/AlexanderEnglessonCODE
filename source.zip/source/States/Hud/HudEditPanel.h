﻿#pragma once
#include "../../UI/Button.h"
#include <tge/sprite/Sprite.h>
#include <tge/text/text.h>

namespace Tga { class Camera; }
class HUD;

struct HudEditSettings
{
    float gridSize = 50.f;

    bool showGrid = true;          // ✔ checked
    bool snapToGrid = true;        // ✔ checked
    bool snapToElements = true;    // ✔ checked
    bool advancedOptions = false;  // ❌ unchecked

    bool playerFrame = true;       // ✔ checked
    bool targetAndFocus = true;    // ✔ checked
    bool partyFrames = true;       // ✔ checked
    bool petFrame = true;          // ✔ checked
    bool raidFrames = false;       // ❌ unchecked

    bool buffsDebuffs = true;      // ✔ checked
    bool castBar = true;           // ✔ checked
    bool petBar = true;            // ✔ checked
    bool stanceBar = true;         // ✔ checked
};

class HudEditPanel : public Button
{
public:
	void ApplySizeForMode();
    void InitRuntimePanel(HUD* hud,
	                      const std::shared_ptr<Tga::Camera>& uiCam,
	                      const Tga::Vector2f& pos,
	                      const Tga::Vector2f& size);

    void SetEditMode(bool on);

    void Render() override;
    void Update(float dt) override;
    void ReceiveInput(InputEvent e, const std::any& data) override;
	void PlaceGridSlider();

private:
    enum class RowId : uint8_t
    {
        ShowGrid,
        SnapToElements,

        PlayerFrame,    
        PartyFrames,
        RaidFrames,

        TargetAndFocus,
        BuffsDebuffs,
        CastBar,
        AdvancedOptions,

        // advanced-only
        PetFrame,
        PetBar,
        StanceBar,

        Count
    };

    struct CheckRow
    {
        RowId id{};
        std::string label;
        bool HudEditSettings::* member = nullptr;

        bool advancedOnly = false;

        // layout
        Tga::Vector2f rowC{};
        Tga::Vector2f rowS{};
        Tga::Vector2f boxC{};
        Tga::Vector2f boxS{};

        Tga::Text text;
        bool hovered = false;
    };

    void LayoutUI();
    int HitTestRow(const Tga::Vector2f& mouseWorld) const;
    bool IsRowVisible(const ::HudEditPanel::CheckRow& r) const;

private:
    CheckRow* FindRow(RowId id);
    const CheckRow* FindRow(RowId id) const;
    HUD* myHUD = nullptr;

    // Panel background
    Tga::SpriteSharedData myBgShared{};
    Tga::Sprite2DInstanceData myBgInst{};

    // Checkbox textures
    Tga::SpriteSharedData myCheckboxCheckedShared{};
    Tga::SpriteSharedData myCheckboxOpenShared{};
    Tga::Sprite2DInstanceData myCheckboxInst{};

    // Drag handle (titlebar)
    Tga::Vector2f myTitleBarC{};
    Tga::Vector2f myTitleBarS{ 0.f, 0.f };

    // (valfritt) visa en liten "drag icon" sprite
    Tga::SpriteSharedData myDragIconShared{};
    Tga::Sprite2DInstanceData myDragIconInst{};

    // Slider visuals
    Tga::SpriteSharedData mySliderTrackShared{};
    Tga::SpriteSharedData mySliderKnobShared{};
    Tga::Sprite2DInstanceData mySliderTrackInst{};
    Tga::Sprite2DInstanceData mySliderKnobInst{};

    Tga::SpriteSharedData myBackBtnShared{};
    Tga::Sprite2DInstanceData myBackBtnInst{};
    Tga::Text myBackText;

    Tga::Vector2f myBackBtnC{};
    Tga::Vector2f myBackBtnS{ 140.f, 44.f };

    // Grid size slider rect
    Tga::Vector2f myGridSliderC{};
    Tga::Vector2f myGridSliderS{ 260.f, 24.f };
    bool myDraggingGrid = false;

    // Text för label + value
    Tga::Text myGridVal;

    // helpers
    float SliderValue01(const Tga::Vector2f& mouse, const Tga::Vector2f& center, const Tga::Vector2f& size) const;
    void DrawSlider(Tga::SpriteDrawer& drawer, const Tga::Vector2f& c, const Tga::Vector2f& s, float t01);
    bool IsOverGridSlider(const Tga::Vector2f& mouseWorld) const;

    // Text
    Tga::Text myTitle;
    Tga::Text myHdrFrames;
    Tga::Text myHdrCombat;

    std::vector<CheckRow> myRows;

    int myHoverRow = -1;

    // HudEditPanel.h (private:)
    Tga::Vector2f mySizeCompact{ 900.f, 450.f };
    Tga::Vector2f mySizeAdvanced{ 900.f, 650.f };
};