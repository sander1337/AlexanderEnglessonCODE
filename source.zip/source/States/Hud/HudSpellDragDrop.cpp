#include "HudSpellDragDrop.h"

#include "../../SceneManagement/MenuScene.h"
#include "../Hud/HudActionBarsController.h"
#include "States/ActionBars/ActionBarSlotButton.h"

#include <tge/engine.h>
#include <tge/texture/TextureManager.h>
#include <tge/drawers/SpriteDrawer.h>
#include <tge/input/InputManager.h>

void HudSpellDragDrop::Init(MenuScene& scene)
{
    myScene = &scene;

    myDragIconInst.myPivot = { 0.5f, 0.5f };
    myDragIconInst.myIsHidden = true;
    myDragIconVisible = false;
}

void HudSpellDragDrop::StartIcon(const std::string& texturePath, const Tga::Vector2f& size, const Tga::Vector2f& mouseWorld)
{
    auto& tm = Tga::Engine::GetInstance()->GetTextureManager();

    myDragIconShared.myTexture = tm.GetTexture(texturePath.c_str());
    myDragIconShared.blendState = Tga::BlendState::AlphaBlend;

    myDragIconInst.myIsHidden = (myDragIconShared.myTexture == nullptr);
    myDragIconInst.mySize = size;
    myDragIconInst.myPosition = mouseWorld - myDragOffset;

    myDragIconVisible = !myDragIconInst.myIsHidden;
}

void HudSpellDragDrop::BeginFromSlot(ActionBarSlotButton* from)
{
    if (!from || from->IsEmpty() || !myScene)
        return;

    myActive = true;
    myFromSpellBook = false;
    myFromSlot = from;
    mySpell = from->GetSpell();
    myCopy = false;

    from->SetGhosted(true);

    myDragOffset = { 0.f, 0.f };
    StartIcon(mySpell.iconTexturePath, from->GetHalfSize() * 2.f, from->GetPosition());
    // NOTE: we will immediately update position in Update() anyway
}

void HudSpellDragDrop::BeginFromSpell(const ActionBarSpell& spell)
{
    if (!myScene) return;

    myActive = true;
    myFromSpellBook = true;
    myFromSlot = nullptr;
    mySpell = spell;
    myCopy = true; // dragging from spellbook is always copy by default

    myDragOffset = { 0.f, 0.f };

    // size: use a reasonable default if spellbook doesn't tell us
    const float s = 100.f;
    StartIcon(mySpell.iconTexturePath, { s, s }, { 0.f, 0.f }); // position fixed in Update
}

void HudSpellDragDrop::Update(const Tga::Vector2f& mouseWorld, Tga::InputManager* im, HudActionBarsController& bars)
{
    if (!myActive || !im)
        return;

    // follow mouse
    if (myDragIconVisible)
        myDragIconInst.myPosition = mouseWorld - myDragOffset;

    // optional copy modifier (ctrl)
    if (myIsCopyModifierHeld)
        myCopy = myIsCopyModifierHeld(im);

    // release -> drop
    if (im->IsKeyReleased(VK_LBUTTON))
    {
        ActionBarSlotButton* toSlot = bars.HitTestSlot(*myScene, mouseWorld);

        // unghost source
        if (myFromSlot)
            myFromSlot->SetGhosted(false);

        if (toSlot)
        {
            if (myFromSpellBook)
            {
                if (myOnDropFromSpell)
                    myOnDropFromSpell(mySpell, toSlot);
                else
                    toSlot->SetSpell(mySpell);
            }
            else
            {
                // from slot -> slot
                if (myOnDropFromSlot)
                {
                    myOnDropFromSlot(myFromSlot, toSlot, mySpell, myCopy);
                }
                else
                {
                    // default: copy or swap/move
                    if (myCopy)
                    {
                        toSlot->SetSpell(mySpell);
                    }
                    else
                    {
                        const ActionBarSpell a = myFromSlot->GetSpell();
                        const ActionBarSpell b = toSlot->GetSpell();
                        toSlot->SetSpell(a);
                        myFromSlot->SetSpell(b);
                    }
                }
            }
        }
        else
        {
            // dropped outside
            if (myFromSlot && !myCopy)
                myFromSlot->SetSpell(ActionBarSpell{});
        }

        // reset state
        myDragIconVisible = false;
        myDragIconShared.myTexture = nullptr;
        myDragIconInst.myIsHidden = true;

        myActive = false;
        myFromSpellBook = false;
        myFromSlot = nullptr;
        mySpell = {};
        myCopy = false;
    }
}

void HudSpellDragDrop::Render(Tga::SpriteDrawer& drawer)
{
    if (!myActive || !myDragIconVisible)
        return;

    drawer.Draw(myDragIconShared, myDragIconInst);
}

void HudSpellDragDrop::Cancel(bool clearSourceIfMove)
{
    if (!myActive) return;

    if (myFromSlot)
    {
        myFromSlot->SetGhosted(false);
        if (clearSourceIfMove && !myCopy)
            myFromSlot->SetSpell(ActionBarSpell{});
    }

    if (myOnCancelSpell)
        myOnCancelSpell();

    myDragIconVisible = false;
    myDragIconShared.myTexture = nullptr;
    myDragIconInst.myIsHidden = true;

    myActive = false;
    myFromSpellBook = false;
    myFromSlot = nullptr;
    mySpell = {};
    myCopy = false;
}
