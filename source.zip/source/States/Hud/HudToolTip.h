#pragma once
#include <string>
#include <tge/sprite/Sprite.h>
#include <tge/text/text.h>
#include <tge/math/Vector2.h>

#include "../../States/ActionBars/ActionBarSpell.h" // <-- include the definition

namespace Tga
{
    class TextureManager;
    class SpriteDrawer;
}

// Optional: where to anchor the tooltip
enum class HudTooltipAnchor
{
    BottomRight,
    TopRight,
    Mouse,       // if you want later
};

class HudTooltip
{
public:
    void Init(Tga::TextureManager& tm);

    void Show(const ActionBarSpell& spell, HudTooltipAnchor anchor = HudTooltipAnchor::BottomRight);
    void Hide();

    bool IsVisible() const { return myVisible; }

    void Render(Tga::SpriteDrawer& drawer);

    // Optional tuning if you want:
    void SetOffsetFromCorner(const Tga::Vector2f& v) { myOffsetFromCorner = v; }
    void SetMaxWidth(float w) { myMaxW = w; }

private:
    void BuildLayoutForSpell(const ActionBarSpell& spell, HudTooltipAnchor anchor);
    void BuildCancelLayout(HudTooltipAnchor anchor);

private:
    bool myVisible = false;
    ActionBarSpell mySpell{};

    // visuals
    Tga::SpriteSharedData myBgShared{};
    Tga::Sprite2DInstanceData myBgInst{};
    Tga::Text myName;
    Tga::Text myCost;
    Tga::Text myCast;
    Tga::Text myDesc;
    Tga::Text myMeasure;

    // tuning
    Tga::Vector2f myPadding = { 18.f, 14.f };
    Tga::Vector2f myOffsetFromCorner = { 30.f, 30.f };
    Tga::Vector2f myOffsetFromPos = { 0.f, -400.f };  
    float myMinW = 420.f;
    float myMaxW = 520.f;
    float myLineHeight = 24.f;

};
