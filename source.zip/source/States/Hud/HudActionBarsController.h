#pragma once
#include <vector>
#include <tge/math/Vector2.h>   

#include "../../Utilities/UIRectUtils.h"

class HUD;
class MenuScene;
class ActionBar;
class ActionBarSlotButton;

class HudActionBarsController
{
public:
    void EnsureDefaultBars(HUD& hud, MenuScene& scene);
    void SetEditMode(MenuScene& scene, bool enabled);

    void Update(MenuScene& scene, float dt);
    void RenderDebug(MenuScene& scene); // optional, can be empty for now

    ActionBarSlotButton* HitTestSlot(MenuScene& scene, const Tga::Vector2f& mouseWorld);
    ActionBarSlotButton* GetSlotForActionKey(MenuScene& scene, int actionKey);

    std::vector<Rect> GetBarRects(MenuScene& scene, float pad) const;

};
