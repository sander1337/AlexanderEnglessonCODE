﻿#include "HudTooltip.h"
#include <tge/engine.h>
#include <tge/texture/TextureManager.h>
#include <tge/drawers/SpriteDrawer.h>

#include "Utilities/UITextUtils.h"          
#include "States/ActionBars/ActionBarSpell.h"
#include "States/Hud/HudSpellBook.h"       

void HudTooltip::Init(Tga::TextureManager& tm)
{
    myBgShared.myTexture = tm.GetTexture("assets/ui/textures/white_1x1.png");
    myBgShared.blendState = Tga::BlendState::AlphaBlend;
    myBgShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    myBgInst.myPivot = { 0.5f, 0.5f };
    myBgInst.myColor = { 0.f, 0.f, 0.f, 0.80f };
    myBgInst.myIsHidden = false;

    myName = Tga::Text("Text/arial.ttf", Tga::FontSize_48, 1);
    myCost = Tga::Text("Text/arial.ttf", Tga::FontSize_24, 1);
    myCast = Tga::Text("Text/arial.ttf", Tga::FontSize_24, 1);
    myDesc = Tga::Text("Text/arial.ttf", Tga::FontSize_24, 1);

    myMeasure = Tga::Text("Text/arial.ttf", Tga::FontSize_24, 1);

    Hide();
}

void HudTooltip::Show(const ActionBarSpell& spell, HudTooltipAnchor anchor)
{
    if (spell.id == 0)
    {
        Hide();
        return;
    }

    myVisible = true;
    mySpell = spell;

    if (spell.id == HudSpellBook::kDontSetSpellId)
        BuildCancelLayout(anchor);
    else
        BuildLayoutForSpell(spell, anchor);
}

void HudTooltip::Hide()
{
    myVisible = false;
}

void HudTooltip::Render(Tga::SpriteDrawer& drawer)
{
    if (!myVisible) return;

    drawer.Draw(myBgShared, myBgInst);
    myName.Render();
    myCost.Render();
    myCast.Render();
    myDesc.Render();
}

static int CountLines(const std::string& s)
{
    int lines = 1;
    for (char c : s) if (c == '\n') ++lines;
    return lines;
}

void HudTooltip::BuildCancelLayout(HudTooltipAnchor anchor)
{
    myName.SetText("Clear Slot");
    myCost.SetText("");
    myCast.SetText("");

    myDesc.SetColor({ 0.8f, 0.8f, 0.8f, 1.f });

    const std::string rawDesc =
        "Press here to not set spell or just click outside of spellbook to not set.";

    const float lineGap = 8.f;

    // --- First wrap using max allowed width ---
    float innerW = myMaxW - myPadding.x * 2.f;
    std::string wrapped = UI::WrapTextToWidth(myMeasure, rawDesc, innerW);
    myDesc.SetText(wrapped.c_str());

    // --- Compute description height properly ---
    const int descLines = CountLines(wrapped);
    const float descH = descLines * myLineHeight;

    float contentW = std::max(myName.GetWidth(), myDesc.GetWidth());
    float contentH = myName.GetHeight() + lineGap + descH;

    float boxW = contentW + myPadding.x * 2.f;
    float boxH = contentH + myPadding.y * 2.f;

    boxW = std::max(boxW, myMinW);
    boxW = std::min(boxW, myMaxW);

    // --- Re-wrap if clamped ---
    innerW = boxW - myPadding.x * 2.f;
    wrapped = UI::WrapTextToWidth(myMeasure, rawDesc, innerW);
    myDesc.SetText(wrapped.c_str());

    const int finalDescLines = CountLines(wrapped);
    const float finalDescH = finalDescLines * myLineHeight;

    contentW = std::max(myName.GetWidth(), myDesc.GetWidth());
    contentH = myName.GetHeight() + lineGap + finalDescH;

    boxH = contentH + myPadding.y * 2.f;

    // small safety padding
    boxH += 6.f;

    // --- Position box ---
    const auto res = Tga::Engine::GetInstance()->GetRenderSize();
    const float w = (float)res.x;
    const float h = (float)res.y;

    Tga::Vector2f center{};

    switch (anchor)
    {
    case HudTooltipAnchor::TopRight:
        center = {
            w - myOffsetFromCorner.x - boxW * 0.5f,
            h - myOffsetFromCorner.y - boxH * 0.5f + myOffsetFromPos.y
        };
        break;

    case HudTooltipAnchor::BottomRight:
    default:
        center = {
            w - myOffsetFromCorner.x - boxW * 0.5f,
            myOffsetFromCorner.y + boxH * 0.5f + myOffsetFromPos.y
        };
        break;
    }

    myBgInst.myPosition = center;
    myBgInst.mySize = { boxW, boxH };

    // --- Layout text ---
    const float left = center.x - boxW * 0.5f + myPadding.x;
    float yTop = center.y + boxH * 0.5f - myPadding.y;

    myName.SetPosition({ left, yTop - myName.GetHeight() });
    yTop -= (myName.GetHeight() + lineGap);

    myDesc.SetPosition({ left, yTop - finalDescH });
}


void HudTooltip::BuildLayoutForSpell(const ActionBarSpell& spell, HudTooltipAnchor anchor)
{
    myName.SetText(spell.name.c_str());
    myCost.SetText(UI::FormatManaLine(spell).c_str());
    myCast.SetText(UI::FormatCastLine(spell).c_str());

    myCost.SetColor({ 0.3f, 0.6f, 1.f, 1.f });
    myCast.SetColor({ 0.8f, 0.8f, 0.8f, 1.f });
    myDesc.SetColor({ 1.0f, 0.82f, 0.0f, 1.0f });

    const float lineGap = 8.f;

    // --- First wrap using max width ---
    float innerW = myMaxW - myPadding.x * 2.f;
    std::string wrapped = UI::WrapTextToWidth(myMeasure, spell.description, innerW);
    myDesc.SetText(wrapped.c_str());

    const int descLines = CountLines(wrapped);
    const float descH = descLines * myLineHeight;

    float contentW = std::max(
        std::max(myName.GetWidth(), myCost.GetWidth()),
        std::max(myCast.GetWidth(), myDesc.GetWidth())
    );

    float contentH =
        myName.GetHeight() + lineGap +
        myCost.GetHeight() + lineGap +
        myCast.GetHeight() + lineGap +
        descH;

    float boxW = contentW + myPadding.x * 2.f;
    float boxH = contentH + myPadding.y * 2.f;

    boxW = std::max(boxW, myMinW);
    boxW = std::min(boxW, myMaxW);

    // --- Re-wrap to final width ---
    innerW = boxW - myPadding.x * 2.f;
    wrapped = UI::WrapTextToWidth(myMeasure, spell.description, innerW);
    myDesc.SetText(wrapped.c_str());

    const int finalDescLines = CountLines(wrapped);
    const float finalDescH = finalDescLines * myLineHeight;

    contentW = std::max(
        std::max(myName.GetWidth(), myCost.GetWidth()),
        std::max(myCast.GetWidth(), myDesc.GetWidth())
    );

    contentH =
        myName.GetHeight() + lineGap +
        myCost.GetHeight() + lineGap +
        myCast.GetHeight() + lineGap +
        finalDescH;

    boxH = contentH + myPadding.y * 2.f;

    // small safety padding
    boxH += 6.f;

    // --- Position ---
    const auto res = Tga::Engine::GetInstance()->GetRenderSize();
    const float w = (float)res.x;
    const float h = (float)res.y;

    Tga::Vector2f center{};

    switch (anchor)
    {
    case HudTooltipAnchor::TopRight:
        center = {
            w - myOffsetFromCorner.x - boxW * 0.5f,
            h - myOffsetFromCorner.y - boxH * 0.5f + myOffsetFromPos.y
        };
        break;

    case HudTooltipAnchor::BottomRight:
    default:
        center = {
            w - myOffsetFromCorner.x - boxW * 0.5f,
            myOffsetFromCorner.y + boxH * 0.5f + myOffsetFromPos.y
        };
        break;
    }

    myBgInst.myPosition = center;
    myBgInst.mySize = { boxW, boxH };

    // --- Layout ---
    const float left = center.x - boxW * 0.5f + myPadding.x;
    float yTop = center.y + boxH * 0.5f - myPadding.y;

    myName.SetPosition({ left, yTop - myName.GetHeight() });
    yTop -= (myName.GetHeight() + lineGap);

    myCost.SetPosition({ left, yTop - myCost.GetHeight() });
    yTop -= (myCost.GetHeight() + lineGap);

    myCast.SetPosition({ left, yTop - myCast.GetHeight() });
    yTop -= (myCast.GetHeight() + lineGap);

    myDesc.SetPosition({ left, yTop - finalDescH });
}

