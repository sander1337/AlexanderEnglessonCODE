﻿#include "HudEditPanel.h"
#include <tge/engine.h>
#include <tge/texture/TextureManager.h>
#include <tge/drawers/SpriteDrawer.h>
#include <tge/graphics/GraphicsEngine.h>
#include <tge/graphics/GraphicsStateStack.h>

#include "States/Hud/HUD.h"

void HudEditPanel::ApplySizeForMode()
{
    const bool adv = myHUD->GetHudEditSettings().advancedOptions;

    const Tga::Vector2f keepPos = GetPosition();            // keep center
    const Tga::Vector2f newSize = adv ? mySizeAdvanced : mySizeCompact;

    SetHalfSize(newSize * 0.5f);
    SetPosition(keepPos); // only needed if SetHalfSize messes with anything

    // sync bg + layout
    myBgInst.myPosition = GetPosition();
    myBgInst.mySize = GetHalfSize() * 2.f;
    LayoutUI();
}

void HudEditPanel::InitRuntimePanel(HUD* hud,const std::shared_ptr<Tga::Camera>& uiCam,const Tga::Vector2f& pos,const Tga::Vector2f& size)
{
    myHUD = hud;
    if (!myHUD) return;

    InitRuntime(pos, size);
    SetCamera(uiCam);
    SetVisible(true);

    auto& tm = Tga::Engine::GetInstance()->GetTextureManager();

    // Background panel
    myBgShared.myTexture = tm.GetTexture("assets/ui/textures/spellbook_panel.png");
    myBgShared.blendState = Tga::BlendState::AlphaBlend;
    myBgShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    myBgInst.myPivot = { 0.5f, 0.5f };
    myBgInst.myColor = { 1,1,1,0.96f };
    myBgInst.myIsHidden = false;

    // Checkbox textures
    myCheckboxCheckedShared.myTexture = tm.GetTexture("assets/ui/textures/T_UI_Checkbox_checked.dds");
    myCheckboxCheckedShared.blendState = Tga::BlendState::AlphaBlend;
    myCheckboxCheckedShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    myCheckboxOpenShared.myTexture = tm.GetTexture("assets/ui/textures/T_UI_Checkbox_open.dds");
    myCheckboxOpenShared.blendState = Tga::BlendState::AlphaBlend;
    myCheckboxOpenShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    myCheckboxInst.myPivot = { 0.5f, 0.5f };
    myCheckboxInst.myColor = { 1,1,1,1 };

    mySliderTrackShared.myTexture = tm.GetTexture("assets/ui/textures/Slider_background.png");
    mySliderTrackShared.blendState = Tga::BlendState::AlphaBlend;
    mySliderTrackShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    mySliderKnobShared.myTexture = tm.GetTexture("assets/ui/textures/Slider_button.png");
    mySliderKnobShared.blendState = Tga::BlendState::AlphaBlend;
    mySliderKnobShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    mySliderTrackInst.myPivot = { 0.5f, 0.5f };
    mySliderKnobInst.myPivot = { 0.5f, 0.5f };

    myBackBtnShared.myTexture = tm.GetTexture("assets/ui/textures/spellbook_panel.png");
    myBackBtnShared.blendState = Tga::BlendState::AlphaBlend;
    myBackBtnShared.depthStencilState = Tga::DepthStencilState::ReadOnlyLess;

    myBackBtnInst.myPivot = { 0.5f, 0.5f };
    myBackBtnInst.myColor = { 1,1,1,1 };
    myBackBtnInst.myIsHidden = false;

    myBackText = Tga::Text("Text/arial.ttf", Tga::FontSize_24, 1);
    myBackText.SetText("Back");
    myBackText.SetColor({ 1,1,1,1 });

    myGridVal = Tga::Text("Text/arial.ttf", Tga::FontSize_24, 1);
    myGridVal.SetColor({ 1.0f, 0.85f, 0.2f, 1.0f });

    myDragIconInst.myPivot = { 0.5f, 0.5f };
    myDragIconInst.myColor = { 1,1,1,0.9f };
    myDragIconInst.myIsHidden = false;

    // Title + headers
    myTitle = Tga::Text("Text/arial.ttf", Tga::FontSize_36, 1);
    myTitle.SetText("HUD Edit Mode");
    myTitle.SetColor({ 1,1,1,1 });

    auto mkHdr = [](const char* s)
        {
            Tga::Text t("Text/arial.ttf", Tga::FontSize_24, 1);
            t.SetText(s);
            t.SetColor({ 1.0f, 0.85f, 0.2f, 1.0f }); // WoW-ish gul
            return t;
        };
    myHdrFrames = mkHdr("Frames");
    myHdrCombat = mkHdr("Combat");


    auto mkRow = [](HudEditPanel::RowId id, const char* label, bool HudEditSettings::* mem, bool advOnly = false)
        {
            CheckRow r;
            r.id = id;
            r.label = label;
            r.member = mem;
            r.advancedOnly = advOnly;

            r.text = Tga::Text("Text/arial.ttf", Tga::FontSize_24, 1);
            r.text.SetText(label);
            r.text.SetColor({ 1,1,1,0.95f });
            return r;
        };

    myRows.clear();
    myRows.reserve(16);

    myRows.push_back(mkRow(RowId::ShowGrid, "Show Grid", &HudEditSettings::showGrid));
    myRows.push_back(mkRow(RowId::SnapToElements, "Snap to Elements", &HudEditSettings::snapToElements));

    myRows.push_back(mkRow(RowId::PlayerFrame, "Player Frame", &HudEditSettings::playerFrame));
    myRows.push_back(mkRow(RowId::TargetAndFocus, "Target and Focus", &HudEditSettings::targetAndFocus));
    myRows.push_back(mkRow(RowId::PartyFrames, "Party Frames", &HudEditSettings::partyFrames));

    myRows.push_back(mkRow(RowId::RaidFrames, "Raid Frames", &HudEditSettings::raidFrames));
    myRows.push_back(mkRow(RowId::BuffsDebuffs, "Buffs and Debuffs", &HudEditSettings::buffsDebuffs));
    myRows.push_back(mkRow(RowId::CastBar, "Cast Bar", &HudEditSettings::castBar, true));
    // Master toggle – alltid synlig
    myRows.push_back(mkRow(RowId::AdvancedOptions, "Advanced Options", &HudEditSettings::advancedOptions));

    // Advanced-only
    myRows.push_back(mkRow(RowId::PetFrame, "Pet Frame", &HudEditSettings::petFrame, true));
    myRows.push_back(mkRow(RowId::PetBar, "Pet Bar", &HudEditSettings::petBar, true));
    myRows.push_back(mkRow(RowId::StanceBar, "Stance Bar", &HudEditSettings::stanceBar, true));

    // Sync panel position/size
    myBgInst.myPosition = GetPosition();
    myBgInst.mySize = GetHalfSize() * 2.f;

    LayoutUI();
    ApplySizeForMode();
}

void HudEditPanel::SetEditMode(bool on)
{
    SetDraggable(on);     // om du vill kunna flytta panelen
    if (!on) CancelDrag();
}

void HudEditPanel::Update(float dt)
{
    Button::Update(dt);

    // Sync panel to current position/size (om du drar den)
    myBgInst.myPosition = GetPosition();
    myBgInst.mySize = GetHalfSize() * 2.f;

    LayoutUI();
}

void HudEditPanel::Render()
{
    if (!myHUD) return;
    if (myRows.empty()) return;

    auto& engine = *Tga::Engine::GetInstance();
    auto& gss = engine.GetGraphicsEngine().GetGraphicsStateStack();
    auto& drawer = engine.GetGraphicsEngine().GetSpriteDrawer();

    gss.Push();
    gss.SetBlendState(Tga::BlendState::AlphaBlend);

    drawer.Draw(myBgShared, myBgInst);

    myTitle.Render();
    myHdrFrames.Render();
    myHdrCombat.Render();

    auto& s = myHUD->GetHudEditSettings();

    // 1) Draw rows FIRST (so slider can be drawn on top)
    for (auto& r : myRows)
    {
        if (!IsRowVisible(r))
            continue;

        if (r.hovered)
        {
            Tga::Sprite2DInstanceData hl{};
            hl.myPivot = { 0.5f, 0.5f };
            hl.myPosition = r.rowC;
            hl.mySize = r.rowS;
            hl.myColor = { 1.f, 1.f, 1.f, 0.06f };
            drawer.Draw(myBgShared, hl);
        }

        myCheckboxInst.myPosition = r.boxC;
        myCheckboxInst.mySize = r.boxS;

        if (r.member && (s.*r.member))
            drawer.Draw(myCheckboxCheckedShared, myCheckboxInst);
        else
            drawer.Draw(myCheckboxOpenShared, myCheckboxInst);

        drawer.Draw(myBackBtnShared, myBackBtnInst);
        myBackText.Render();

        r.text.Render();
    }

    // 2) Draw slider LAST so it’s always above Advanced Options row
    if (s.showGrid)
    {
        const float minG = 25.f;
        const float maxG = 200.f;
        float t = (s.gridSize - minG) / (maxG - minG);
        t = std::max(0.f, std::min(1.f, t));

        DrawSlider(drawer, myGridSliderC, myGridSliderS, t);

        myGridVal.SetText((std::to_string((int)std::round(s.gridSize)) + "px").c_str());
        myGridVal.Render();
    }

    drawer.Draw(myBackBtnShared, myBackBtnInst);
    myBackText.Render();



    gss.Pop();
}


void HudEditPanel::LayoutUI()
{
    if (!myHUD) return;

    const auto p = GetPosition();
    const auto size = GetHalfSize() * 2.f;
    const float left = p.x - size.x * 0.5f;
    const float top = p.y + size.y * 0.5f;
    const float right = p.x + size.x * 0.5f;

    const float padL = 50.f;
    const float colGap = 80.f;
    const float colW = (size.x - padL * 2.f - colGap) * 0.5f;

    const float col1X = left + padL;
    const float col2X = col1X + colW + colGap;

    const float rowH = 54.f;
    const Tga::Vector2f boxSize{ 34.f, 34.f };
    const float textOffsetX = 26.f;

    auto placeRowAtY = [&](CheckRow& r, float x, float y)
        {
            const float rowW = colW;
            r.rowC = { x + rowW * 0.5f, y };
            r.rowS = { rowW, rowH };

            r.boxC = { x + 18.f, y };
            r.boxS = boxSize;

            r.text.SetPosition({ r.boxC.x + r.boxS.x * 0.5f + textOffsetX, y - 12.f });
        };

    auto placeRow = [&](CheckRow& r, float x, float& y)
        {
            placeRowAtY(r, x, y);
            y -= rowH;
        };

    // Title
    myTitle.SetPosition({ p.x - myTitle.GetWidth() * 0.5f, top - 100.f });

    // (Optional) title bar drag rect
    myTitleBarC = { p.x, top - 55.f };
    myTitleBarS = { size.x - 90.f, 70.f };

    const bool adv = myHUD->GetHudEditSettings().advancedOptions;

    myBackBtnC = { right - 90.f, top - 55.f };
    myBackBtnS = { 140.f, 44.f };

    myBackBtnInst.myPosition = myBackBtnC;
    myBackBtnInst.mySize = myBackBtnS;

    myBackText.SetPosition({
        myBackBtnC.x - myBackText.GetWidth() * 0.5f,
        myBackBtnC.y - 12.f
        });
    // -------------------------
    // COMPACT (advanced OFF)
    // -------------------------
    if (!adv)
    {
        myHdrFrames.SetPosition({ -99999.f, -99999.f });
        myHdrCombat.SetPosition({ -99999.f, -99999.f });

        float yL = top - 160.f;

        // 1) Place left column normally (this defines the Y of Target/Party)
        RowId leftList[] =
        {
            RowId::ShowGrid,
            RowId::SnapToElements,
        	RowId::PlayerFrame,     
            RowId::TargetAndFocus,
            RowId::PartyFrames,
            RowId::CastBar
        };

        for (RowId id : leftList)
        {
            if (auto* r = FindRow(id); r && IsRowVisible(*r))
                placeRow(*r, col1X, yL);
        }

        // 2) Fix AdvancedOptions at a constant Y (never moves)
        const float advY = top - 205.f; // pick your "fixed" spot
        if (auto* advRow = FindRow(RowId::AdvancedOptions))
            placeRowAtY(*advRow, col2X, advY);

        // 3) Align right rows to left rows (no flowing yR!)
        auto* tf = FindRow(RowId::TargetAndFocus);
        auto* party = FindRow(RowId::PartyFrames);

        if (auto* raid = FindRow(RowId::RaidFrames); raid && tf && IsRowVisible(*raid))
            placeRowAtY(*raid, col2X, tf->rowC.y);

        if (auto* buffs = FindRow(RowId::BuffsDebuffs); buffs && party && IsRowVisible(*buffs))
            placeRowAtY(*buffs, col2X, party->rowC.y);

        // 4) Slider on the ShowGrid row (right of the ShowGrid text)
        if (auto* show = FindRow(RowId::ShowGrid))
        {
            const float rowRight = show->rowC.x + show->rowS.x * 0.5f;
            const float y = show->rowC.y;

            const float textX = show->text.GetPosition().x;
            float labelW = show->text.GetWidth();
            if (labelW < 10.f) labelW = 140.f;

            const float pad = 100.f;

            // slider starts after label
            float sliderL = textX + labelW + pad;

            // keep px text after slider: we want slider to end before px
            const float pxGap = 14.f;
            const float pxW = 70.f;   // approx space for "200px"
            float sliderR = rowRight - (pxW + pxGap);

            // make it wider: increase min width
            float sliderW = std::max(420.f, sliderR - sliderL);

            myGridSliderS = { sliderW, 24.f };
            myGridSliderC = { sliderL + sliderW * 0.5f, y };

            const float sliderRight = myGridSliderC.x + myGridSliderS.x * 0.5f;
            myGridVal.SetPosition({ sliderRight + pxGap, show->text.GetPosition().y });
        }
        PlaceGridSlider();
        return;
    }

    // -------------------------
// FULL (advanced ON)
// -------------------------
    myHdrFrames.SetPosition({ col1X, top - 260.f });

    // Keep AdvancedOptions fixed here too
    const float advY = top - 205.f;
    if (auto* advRow = FindRow(RowId::AdvancedOptions))
        placeRowAtY(*advRow, col2X, advY);

    float yL = top - 160.f;
    float yR = top - 160.f;

    // top-left
    for (RowId id : { RowId::ShowGrid, RowId::SnapToElements })
        if (auto* r = FindRow(id); r && IsRowVisible(*r))
            placeRow(*r, col1X, yL);

    // Frames group
    yL = top - 300.f;
    yR = top - 300.f;

    for (RowId id : { RowId::PlayerFrame, RowId::TargetAndFocus, RowId::PartyFrames })
        if (auto* r = FindRow(id); r && IsRowVisible(*r))
            placeRow(*r, col1X, yL);

    for (RowId id : { RowId::PetFrame, RowId::RaidFrames })
        if (auto* r = FindRow(id); r && IsRowVisible(*r))
            placeRow(*r, col2X, yR);

    // place combat header dynamically below frame group
    const float combatHeaderY = std::min(yL, yR) - 20.f;
    myHdrCombat.SetPosition({ col1X, combatHeaderY });

    // Combat group
    yL = combatHeaderY - 40.f;
    yR = combatHeaderY - 40.f;

    for (RowId id : { RowId::BuffsDebuffs, RowId::StanceBar })
        if (auto* r = FindRow(id); r && IsRowVisible(*r))
            placeRow(*r, col1X, yL);

    for (RowId id : { RowId::CastBar, RowId::PetBar })
        if (auto* r = FindRow(id); r && IsRowVisible(*r))
            placeRow(*r, col2X, yR);

    PlaceGridSlider();
}

int HudEditPanel::HitTestRow(const Tga::Vector2f& mouseWorld) const
{
    for (int i = 0; i < (int)myRows.size(); ++i)
    {
        const auto& r = myRows[i];
        if (!IsRowVisible(r))
            continue;

        if (PointInRectCenterSize(mouseWorld, r.rowC, r.rowS))
            return i;
    }
    return -1;
}

void HudEditPanel::ReceiveInput(InputEvent e, const std::any& data)
{
    if (!myCamera || !myHUD) return;

    const auto mouseScreen = std::any_cast<Tga::Vector2f>(data);
    const auto mouseWorld = myCamera->GetScreenToWorldCoordinatesVec2(mouseScreen);

    auto& s = myHUD->GetHudEditSettings();

    if (e == InputEvent::MenuLRelease)
    {
        myDraggingGrid = false;
        myIsBeingClicked = false;
        Button::ReceiveInput(e, data);
        return;
    }

    if (myDraggingGrid)
    {
        if (e == InputEvent::Hover && s.showGrid)
        {
            const float t = SliderValue01(mouseWorld, myGridSliderC, myGridSliderS);
            const float minG = 25.f, maxG = 200.f;
            s.gridSize = minG + t * (maxG - minG);
            s.gridSize = std::round(s.gridSize / 5.f) * 5.f;
        }

        if (e == InputEvent::Hover)
        {
            myHoverRow = HitTestRow(mouseWorld);
            for (int i = 0; i < (int)myRows.size(); ++i)
                myRows[i].hovered = (i == myHoverRow);
        }
        return;
    }

    if (e == InputEvent::MenuLClick)
    {
        if (myIsBeingClicked)
            return;

        myIsBeingClicked = true;

        // Back button
        if (PointInRectCenterSize(mouseWorld, myBackBtnC, myBackBtnS))
        {
            Message msg;
            msg.eventType = Event::CloseHudEditMenu;
            msg.data = 0;
            EventManager::GetInstance()->SendEventMessage(msg);
            return;
        }

        if (s.showGrid && IsOverGridSlider(mouseWorld))
        {
            myDraggingGrid = true;

            const float t = SliderValue01(mouseWorld, myGridSliderC, myGridSliderS);
            const float minG = 25.f, maxG = 200.f;
            s.gridSize = minG + t * (maxG - minG);
            s.gridSize = std::round(s.gridSize / 5.f) * 5.f;
            return;
        }

        Button::ReceiveInput(e, data);

        const int hit = HitTestRow(mouseWorld);
        if (hit >= 0)
        {
            auto& r = myRows[hit];

            if (r.member)
            {
                s.*r.member = !(s.*r.member);
            }

            if (r.id == RowId::AdvancedOptions)
                ApplySizeForMode();

            myHUD->ApplyHudEditSettings();
        }
        return;
    }

    Button::ReceiveInput(e, data);

    if (e == InputEvent::Hover)
    {
        myHoverRow = HitTestRow(mouseWorld);
        for (int i = 0; i < (int)myRows.size(); ++i)
            myRows[i].hovered = (i == myHoverRow);
    }
}

void HudEditPanel::PlaceGridSlider()
{
    if (!myHUD) return;
    const auto& s = myHUD->GetHudEditSettings();
    if (!s.showGrid) return;

    auto* show = FindRow(RowId::ShowGrid);
    if (!show) return;

    const float rowRight = show->rowC.x + show->rowS.x * 0.5f;
    const float y = show->rowC.y;

    const float textX = show->text.GetPosition().x;
    float labelW = show->text.GetWidth();
    if (labelW < 10.f) labelW = 140.f;

    const float pad = 100.f;

    float sliderL = textX + labelW + pad;

    const float pxGap = 14.f;
    const float pxW = 70.f;
    float sliderR = rowRight - (pxW + pxGap);

    float sliderW = std::max(420.f, sliderR - sliderL);

    myGridSliderS = { sliderW, 24.f };
    myGridSliderC = { sliderL + sliderW * 0.5f, y };

    const float sliderRight = myGridSliderC.x + myGridSliderS.x * 0.5f;
    myGridVal.SetPosition({ sliderRight + pxGap, show->text.GetPosition().y });
}


bool HudEditPanel::IsRowVisible(const CheckRow& r) const
{
    if (!myHUD) return false;
    const auto& s = myHUD->GetHudEditSettings();

    // Master toggle syns alltid
    if (r.id == RowId::AdvancedOptions)
        return true;

    // Advanced-only syns bara när togglen är på
    if (r.advancedOnly && !s.advancedOptions)
        return false;

    // Compact mode (Advanced OFF): visa ENDAST detta set (bild 1)
    if (!s.advancedOptions)
    {
        switch (r.id)
        {
        case RowId::ShowGrid:
        case RowId::SnapToElements:
        case RowId::TargetAndFocus:
        case RowId::PartyFrames:
        case RowId::PlayerFrame:  
        case RowId::CastBar:
        case RowId::RaidFrames:
        case RowId::BuffsDebuffs:
            return true;
        default:
            return false;
        }
    }

    // Advanced ON: visa allt (utom advancedOnly som redan hanteras)
    return true;
}

HudEditPanel::CheckRow* HudEditPanel::FindRow(RowId id)
{
    for (auto& r : myRows)
        if (r.id == id)
            return &r;
    return nullptr;
}

const HudEditPanel::CheckRow* HudEditPanel::FindRow(RowId id) const
{
    for (const auto& r : myRows)
        if (r.id == id)
            return &r;
    return nullptr;
}

void HudEditPanel::DrawSlider(Tga::SpriteDrawer& drawer, const Tga::Vector2f& c, const Tga::Vector2f& s, float t01)
{
    t01 = std::max(0.f, std::min(1.f, t01));

    // Track
    mySliderTrackInst.myPosition = c;
    mySliderTrackInst.mySize = s;
    mySliderTrackInst.myColor = { 1,1,1,1 };
    mySliderTrackInst.myIsHidden = false;
    drawer.Draw(mySliderTrackShared, mySliderTrackInst);

    // Knob
    const float left = c.x - s.x * 0.5f;
    const float x = left + s.x * t01;

    mySliderKnobInst.myPosition = { x, c.y };
    mySliderKnobInst.mySize = { 22.f, 22.f };
    mySliderKnobInst.myColor = { 1,1,1,1 };
    mySliderKnobInst.myIsHidden = false;
    drawer.Draw(mySliderKnobShared, mySliderKnobInst);
}

float HudEditPanel::SliderValue01(const Tga::Vector2f& mouse, const Tga::Vector2f& center, const Tga::Vector2f& size) const
{
    const float left = center.x - size.x * 0.5f;
    const float t = (mouse.x - left) / size.x;
    return std::max(0.f, std::min(1.f, t));
}

bool HudEditPanel::IsOverGridSlider(const Tga::Vector2f& m) const
{
    return PointInRectCenterSize(m, myGridSliderC, myGridSliderS);
}