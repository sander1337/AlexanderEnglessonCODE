﻿#pragma once
#include <memory>
#include <vector>

#include <tge/sprite/Sprite.h>         
#include <tge/math/Vector2.h>
#include "../ActionBars/ActionBarSpell.h"
#include "../../Utilities/UIRectUtils.h"

class HUD;
class MenuScene;
class Button;
class SpellBookSpellButton;
class ActionBarSlotButton;

namespace Tga { class Camera; class SpriteDrawer; }

class HudActionBarsController; // forward, we only reference it as param

class HudSpellBook
{
public:
    void Init(HUD& hud, MenuScene& scene, std::shared_ptr<Tga::Camera> uiCam);

    void Toggle();
    void Open(const HudActionBarsController* bars = nullptr); // bars optional for placement
    void Close();

    bool IsOpen() const { return myOpen; }

    // For HUD Update:
    bool IsMouseInside(const Tga::Vector2f& mouseWorld) const;
    SpellBookSpellButton* HitTest(const Tga::Vector2f& mouseWorld);

    // For HUD Render:
    void RenderBackdrop(Tga::SpriteDrawer& spriteDrawer);

    // Optional helper: "what spell is hovered right now?"
    const ActionBarSpell* GetHoverSpell(const Tga::Vector2f& mouseWorld);

    // Slot-anchored open (your OpenSpellBookForSlot logic)
    void OpenForSlot(ActionBarSlotButton* slot, const HudActionBarsController* bars);

    // Cancel button id
    static constexpr int kDontSetSpellId = 1000;


private:
    void EnsureLoadedSpells();
    void EnsureButtons(int count);
    void LayoutAndApply(const HudActionBarsController* bars);

    SpellBookSpellButton* HitTestButtonsInternal(const Tga::Vector2f& mouseWorld) const;
    std::vector<Rect> GetActionBarRects(const HudActionBarsController* bars, float pad) const;
    Tga::Vector2f NudgeRectOutOfBars(const HudActionBarsController* bars,
        Tga::Vector2f center, float w, float h) const;

    Tga::Vector2f FindSpellBookCenterAvoidingBars(const HudActionBarsController* bars,
        const Tga::Vector2f& anchor, float panelW, float panelH) const;

private:
    HUD* myHUD = nullptr;
    MenuScene* myScene = nullptr;
    std::shared_ptr<Tga::Camera> myUiCam;

    bool myOpen = false;

    // spells + buttons
    std::vector<ActionBarSpell> myAllSpells;
    std::vector<std::shared_ptr<Button>> myButtons;
    std::shared_ptr<Button> myDontSetButton;

    // background sprites
    bool myBgInit = false;
    Tga::SpriteSharedData myDimShared{};
    Tga::Sprite2DInstanceData myDimInst{};
    Tga::SpriteSharedData myBgShared{};
    Tga::Sprite2DInstanceData myBgInst{};

    // layout tuning
    Tga::Vector2f myPanelPos = { -300.f, 0.f };
    Tga::Vector2f myPanelScale = { 1.f, 1.f };
    float myPanelMinW = 400.f;
    float myPanelMinH = 250.f;

    // anchor
    bool myHasAnchor = false;
    Tga::Vector2f myAnchorWorld = { 0.f, 0.f };
    Tga::Vector2f myAnchorHalf = { 0.f, 0.f };

    // internal cache for hover helper
    SpellBookSpellButton* myCachedHover = nullptr;
};
