﻿#pragma once
//#pragma message(__FILE__" was compiled")
#include "../../Events/EventManager.h"
#include "../../Input/InputMapper.h"

#include <tge/graphics/Camera.h>
#include <tge/text/text.h>

#include "HudEditPanel.h"
#include "../../UI/Button.h"
#include "../../Graphics/GameSprite.h"
#include "../../States/ActionBars/ActionBarSpell.h"
#include "../../States/ActionBars/ActionBarKeybinds.h"
#include "../../Utilities/UIRectUtils.h"
#include "../../States/Hud/HudActionBarsController.h"
#include "../../States/Hud/HudSpellBook.h"
#include "../../States/Hud/HudSpellDragDrop.h"
#include "../../States/Hud/HudTooltip.h"
#include "../../States/Hud/HudKeybindPopupController.h" 
#include "../../States/Hud/Frames/PlayerFrame.h"
#include "../../States/Hud/Frames/TargetFrame.h"
#include "../../States/Hud/Frames/PartyFrame.h"
#include "../../States/Hud/Frames/BuffFrame.h"
#include "../../States/Hud/Frames/CastBarFrame.h"
#include "../../States/ActionBars/StanceBar.h"

class MenuScene;
class ActionBarSlotButton;
class SpellBookSpellButton;

class HudActionBarsController;
class HudSpellBook;
class HudSpellDragDrop;
class HudTooltip;
class HudKeybindPopupController;

namespace Tga
{
    struct Sprite3DInstanceData;
}

class StateStack;
enum class LevelName;
class SceneManager;
class ActionBar;

struct PendingBind
{
    bool active = false;
    ActionBarSlotButton* targetSlot = nullptr;
};

struct PartyFrameSettings
{
    bool useRaidStyle = false;
    bool useHorizontal = false;
    float frameScale = 1.f;
    float raidWidth = 260.f;
    float raidHeight = 70.f;
};

class HUD : public Observer, public InputObserver
{
public:
    HUD() = default;
    void Init(SceneManager* aSceneManager, StateStack* aStateStack, Tga::Camera& aSceneCamera);
    void Render();
    void Update(float aDeltaTime);   // <-- ADD

    void SetSceneCamera(Tga::Camera* aCamera);
    void SetSceneToNull();

    void SubscribeToEvents();
    void UnsubscribeFromEvents();

    void SetEditMode(bool aEnabled);
    bool IsEditMode() const { return myEditMode; }

    void ReceiveEvent(const Message& aMessage) override;
    void ReceiveInput(InputEvent e, const std::any& data) override;
    void RegisterInput();
    void UnregisterInput();

    void SetPendingBind(ActionBarSlotButton* slot);

    void ShowSpellTooltip(const ActionBarSpell& spell) { myTooltip.Show(spell, HudTooltipAnchor::BottomRight); }
    void HideSpellTooltip() { myTooltip.Hide(); }

    void OpenSpellBookForSlot(ActionBarSlotButton* slot);
    void CloseSpellBook();
    bool IsSpellBookOpen() const;

    void BeginDragFromSlot(ActionBarSlotButton* from);
    void BeginDragFromSpell(const ActionBarSpell& spell);
    bool IsDraggingSpell() const { return myDragDrop.IsDragging(); }
    Tga::Camera* GetUICamera() { return &myCamera; }
    const Tga::Camera* GetUICamera() const { return &myCamera; }
    HudEditSettings& GetHudEditSettings() { return myHudEditSettings; }

    HudActionBarsController& GetActionBarsController() { return myActionBars; }
	const HudActionBarsController& GetActionBarsController() const { return myActionBars; }
    void ApplyHudEditSettings(); // ✅

    PartyFrameSettings& GetPartyFrameSettings() { return myPartyFrameSettings; }
    const PartyFrameSettings& GetPartyFrameSettings() const { return myPartyFrameSettings; }
    void ApplyPartyFrameSettings();
    Tga::Vector2f GetPartyFrameSettingsPopupPos() const;
    void SetPartyAnchor(const Tga::Vector2f& anchor);
    const Tga::Vector2f& GetPartyAnchor() const { return myPartyAnchor; }

    //CASTBAR
    void StartCastBar(const ActionBarSpell& spell);
    void StopCastBar();
    CastBarFrame* GetCastBarFrame() { return myCastBarFrame.get(); }
    bool myPendingCastActive = false;
    ActionBarSpell myPendingCastSpell{};
    bool IsCastingSpell() const;

    //BUFF
    void AddBuff(int id, const std::string& name, const std::string& iconPath, float duration);
    void RemoveBuff(int id);
    BuffFrame* GetBuffFrame() { return myBuffFrame.get(); }
    bool RemoveBuffAtMouse(const Tga::Vector2f& mouseWorld);
    void ApplyStanceBuff(MageStance stance);

    //DEBUFF
    void AddDebuff(int id, const std::string& name, const std::string& iconPath, float duration);
    void RemoveDebuff(int id);
    BuffFrame* GetDebuffFrame() { return myDebuffFrame.get(); }
    bool HasDebuff(int id) const;

    //STANCE BAR
    StanceBar* GetStanceBar() { return myStanceBar.get(); }

	//BUFF/DEBUFF OVERLAP SAFETY
    void ResolveBuffDebuffOverlap(float gap = 8.f);
    void RenderEditGrid(bool aShowGrid);
private:
   
    void SetTransformFor3DSprite(Tga::Sprite3DInstanceData& aSprite, Tga::Matrix4x4f aTransform, Tga::Vector2f aSpriteSize, Tga::Vector2f aPivot);
    Tga::Matrix4x4f CreateBillboardMatrix(const Tga::Vector3f& aPosition, const Tga::Vector3f& aTargetPosition, const Tga::Vector3f aScale);

    void UpdateDockedHealthBar(int aCurrentHealth, int aMaxHealth);
private:
    HudEditSettings myHudEditSettings{};
    HudActionBarsController myActionBars;
    HudSpellBook mySpellBooks;
    HudSpellDragDrop myDragDrop;
    HudTooltip myTooltip;
    HudKeybindPopupController myKeybindPopup;
    PartyFrameSettings myPartyFrameSettings{};

    std::shared_ptr<CastBarFrame> myCastBarFrame;
    std::shared_ptr<BuffFrame> myDebuffFrame;
    std::shared_ptr<BuffFrame> myBuffFrame;
    std::shared_ptr<PlayerFrame> myPlayerFrame;
    std::shared_ptr<TargetFrame> myTargetFrame;
    std::shared_ptr<StanceBar> myStanceBar;
    std::array<std::shared_ptr<PartyFrame>, 5> myPartyFrames;
    Tga::Vector2f myPartyAnchor{};
    TargetFrame::UnitSnapshot myPlayerSnap;
    std::array<TargetFrame::UnitSnapshot, 5> myPartySnaps;

    bool myInputRegistered = false;
    bool myEditMode = false;
    bool myIsSubscribedToEvents = false;

    Tga::SpriteSharedData mySharedData;
    Tga::Sprite2DInstanceData mySpriteInstance;
    std::vector<GameSprite> myStaticSprites;
    Tga::Camera myCamera;
    Tga::Camera* mySceneCamera = nullptr;
    Tga::Text myRemainingHeals;
    Tga::SpriteSharedData myEnemyEmptyBar;
    Tga::SpriteSharedData myEnemyFullBar;

    Tga::Sprite2DInstanceData myBossSpriteInstance;
    Tga::Text myBossName;

    std::shared_ptr<MenuScene> myScene;

    ActionBarSlotButton* myPrevHoverSlot = nullptr;
    SpellBookSpellButton* myPrevHoverSpell = nullptr;

    PendingBind myPendingBind{};

    bool myIgnoreOutsideClick = false;
};
