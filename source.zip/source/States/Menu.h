#pragma once
//#pragma message(__FILE__" was compiled")
#include "../UI/Button.h"
#include "State.h"

class MenuScene;
class RenderManager;
class SceneManager;
class StateStack;


class Menu : public State
{
public:
    Menu(StateStack& aStateStack, const std::shared_ptr<SceneManager>& aSceneManager, const std::shared_ptr<RenderManager>& aRenderManager, const bool aLetThroughRender = false);
    ~Menu() override = default;

    void OnEnter() override;
    void OnExit() override;
    void Update(float aDeltaTime) override;
    void Render() override;

    void ReceiveEvent(const Message& aMessage) override;

    StateID GetID() override;

protected:
    void TickSelectCooldown();

    Tga::Vector2i mySelectedButtonIndex = { 0, 0 };
    Tga::Vector2i  myDefaultSelectedButtonIndex = { 0, 0 };
    bool myIsUsingMouse = false;
    bool myHasSelected = false;
    float mySelectCooldown = 0.f;
};
