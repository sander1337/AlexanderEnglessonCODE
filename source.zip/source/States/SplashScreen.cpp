#include "SplashScreen.h"
#include "StateStack.h"
#include "../SceneManagement/SceneManager.h"

#include <tge/texture/TextureManager.h>
#include <tge/engine.h>
#include <tge/graphics/GraphicsEngine.h>
#include <tge/graphics/GraphicsStateStack.h>
#include <tge/drawers/SpriteDrawer.h>

SplashScreen::SplashScreen(StateStack& aStateStack, const std::shared_ptr<SceneManager>& aSceneManager, const std::shared_ptr<RenderManager>& aRenderManager, const bool aLetThroughRender)
	:State(aStateStack, aSceneManager, aRenderManager, aLetThroughRender)
{
	Init();
}

void SplashScreen::Init()
{
	auto& engine = *Tga::Engine::GetInstance();
	Tga::Vector2ui intResolution = engine.GetRenderSize();
	Tga::Vector2f resolution = { static_cast<float>(intResolution.x), static_cast<float>(intResolution.y) };
	Tga::TextureManager& textureManager = engine.GetTextureManager();
	Tga::Texture* texture = textureManager.GetTexture("assets/UI/splashscreen/tga_unity_splash_logo_1.dds");
	if (texture)
	{
		mySprites.emplace_back(Tga::SpriteSharedData{ texture });
		mySplashScreenMax++;
	}
	texture = nullptr;
	texture = textureManager.GetTexture("assets/UI/splashscreen/APA_splashscreen.dds");
	if (texture)
	{
		mySprites.emplace_back(Tga::SpriteSharedData{ texture });
		mySplashScreenMax++;
	}
	texture = nullptr;
	texture = textureManager.GetTexture("assets/UI/splashscreen/ashleep_splashscreen.dds");
	if (texture)
	{
		mySprites.emplace_back(Tga::SpriteSharedData{ texture });
		mySplashScreenMax++;
	}
	texture = nullptr;
	texture = textureManager.GetTexture("assets/UI/splashscreen/fmod_splashscreen.dds");
	if (texture)
	{
		mySprites.emplace_back(Tga::SpriteSharedData{ texture });
		mySplashScreenMax++;
	}

	mySpriteInstance.myPosition = resolution * 0.5f;
	mySpriteInstance.myPosition = { 0.5f, 0.5f };
	mySpriteInstance.myPivot = { 0.5f,0.5f };
	mySpriteInstance.myColor.a = 0.f;
	if (mySplashScreenMax > 0)
	{
		mySpriteInstance.mySize = mySprites[0].myTexture->CalculateTextureSize();
	}
	mySpriteInstance.mySize = resolution;
	mySplashScreenCurrent = 0;

	myCamera = std::make_shared<Tga::Camera>();

	myCamera->SetOrtographicProjection(
	    -static_cast<float>(resolution.x)*0.5f, static_cast<float>(resolution.x) * 0.5f,
	    -static_cast<float>(resolution.y) * 0.5f, static_cast<float>(resolution.y) * 0.5f,
	    0.f, 10000.f
	);

	myIsReadyToSwitch = false;

}

void SplashScreen::OnEnter()
{
	myCountdownMax = 1.2f;

	myFadeCount = 0.f;
	myFadeTime = 0.5f;
	myFadePerSecond = 2.f;

	myPauseCount = 0.f;
	myPauseTime = 0.5f;

	if (myCountdownMax <= 0.f)
	{
		myCountdownMax = 3.f;
	}
	myCountdownCurrent = myCountdownMax;

	if (myFadeTime > 0.f)
	{
		myFadePerSecond = 1.f / myFadeTime;
	}

	myIsReadyToSwitch = false;

	Tga::Engine::GetInstance()->ShowCustomCursor(false);
}

void SplashScreen::OnExit()
{
	Tga::Engine::GetInstance()->ShowCustomCursor(true);
}

void SplashScreen::Update(float aDeltaTime)
{
	if (myIsReadyToSwitch)
	{
		mySplashScreenCurrent++;

		myFadeCount = 0.f;
		myCountdownCurrent = myCountdownMax;
		myPauseCount = 0.f;
		myIsReadyToSwitch = false;
	}

	if (myPauseCount < myPauseTime)
	{
		myPauseCount += aDeltaTime;
		return;
	}

	if (mySplashScreenCurrent >= mySplashScreenMax)
	{
		myStateStack.Pop();
		myStateStack.Push(StateID::MainMenu);
		return;
	}

	if (myFadeCount < myFadeTime)
	{
		myFadeCount += aDeltaTime;
		if (myCountdownCurrent > 0.f)
		{
			FadeIn(aDeltaTime);
		}
		else
		{
			FadeOut(aDeltaTime);
		}
	}
	else
	{
		if (myCountdownCurrent > 0.f)
		{
			myCountdownCurrent -= aDeltaTime;
		}
		if (myCountdownCurrent <= 0.f)
		{
			myFadeCount = 0.f;
		}
	}

	if (myCountdownCurrent <= 0.f && myFadeCount >= myFadeTime)
	{
		myIsReadyToSwitch = true;
	}
}

void SplashScreen::Render()
{
	if (mySplashScreenCurrent >= mySplashScreenMax) return;

	Tga::GraphicsStateStack& graphicsStateStack = Tga::Engine::GetInstance()->GetGraphicsEngine().GetGraphicsStateStack();
	graphicsStateStack.Push();
	graphicsStateStack.SetSamplerState(Tga::SamplerFilter::Trilinear, Tga::SamplerAddressMode::Clamp);
	graphicsStateStack.SetCamera(*myCamera);
	graphicsStateStack.SetBlendState(Tga::BlendState::AlphaBlend);

	Tga::Engine::GetInstance()->GetGraphicsEngine().GetSpriteDrawer().Draw(mySprites[mySplashScreenCurrent], mySpriteInstance);

	graphicsStateStack.Pop();
}

StateID SplashScreen::GetID()
{
	return StateID::SplashScreen;
}

void SplashScreen::FadeIn(float aDeltaTime)
{
	float alpha = mySpriteInstance.myColor.a;
	alpha += myFadePerSecond * aDeltaTime;
	mySpriteInstance.myColor.a = std::clamp(alpha, 0.f, 1.f);
}

void SplashScreen::FadeOut(float aDeltaTime)
{
	float alpha = mySpriteInstance.myColor.a;
	alpha -= myFadePerSecond * aDeltaTime;
	mySpriteInstance.myColor.a = std::clamp(alpha, 0.f, 1.f);
}