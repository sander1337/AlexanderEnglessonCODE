#pragma once
#include "Menu.h"
#include "../Events/EventManager.h" // Observer + Message + EventManager
#include "ActionBars/ActionBarEditPopup.h"
#include "../States/Hud/HudEditPanel.h"
#include "Hud/Frames/FrameScalePopup.h"
#include "Hud/Frames/PartyFrame.h"
#include "Hud/Frames/PartyFrameSettingsPopup.h"
#include "Hud/Frames/CastBarFrame.h"
#include "ActionBars/StanceBarEditPopup.h"

struct HudLayoutSnapshot
{
    std::unordered_map<Tga::ButtonType, Tga::Vector2f> positions;
};

class HUD;

class HudMenu : public Menu
{
public:
    HudMenu(StateStack& aStateStack,
        const std::shared_ptr<SceneManager>& aSceneManager,
        const std::shared_ptr<RenderManager>& aRenderManager,
        const bool aLetThroughRender = false)
        : Menu(aStateStack, aSceneManager, aRenderManager, aLetThroughRender)
    {
        myLetThroughRender = true; // see game behind while editing (like pause)
    }

    void OnEnter() override;
    void OnExit() override;
    void Render() override;
    void Update(float aDeltaTime) override; 


    StateID GetID() override { return StateID::HUD; }

    void ReceiveEvent(const Message& aMessage) override;

    void SetHUD(HUD* hud) { myHUD = hud; }

private:
    Tga::Vector2f SnapToGrid(const Tga::Vector2f& pos) const;


    void SetHudEditMode(bool on);
    void CaptureSnapshot(HudLayoutSnapshot& snapshot);
    void ApplySnapshot(const HudLayoutSnapshot& snapshot);

private:
    CastBarFrame* FindCastBarFrameAt(const Tga::Vector2f& mouseWorld) const;
    CastBarFrame* myPendingCastBarClick = nullptr;
    void RefreshCastBarEditVisibility(bool editModeOn);

    ActionBar* FindActionBarAt(const Tga::Vector2f& mouseWorld) const;
    ActionBar* myPendingBarLeftClick = nullptr;
    ActionBar* myDraggingBar = nullptr;
    Tga::Vector2f myBarPressMouseWorld{ 0.f, 0.f };
    Tga::Vector2f myBarDragGrabOffset{ 0.f, 0.f };
    bool myBarDragStarted = false;

    PartyFrame* FindPartyFrameAt(const Tga::Vector2f& mouseWorld) const;
    PartyFrame* myPendingPartyClick = nullptr;
    Tga::Vector2f myPartyPressMouseWorld{ 0.f, 0.f };
    bool myPartyDragStarted = false;

    PlayerFrame* FindPlayerFrameAt(const Tga::Vector2f& mouseWorld) const;
    TargetFrame* FindTargetFrameAt(const Tga::Vector2f& mouseWorld) const;
    PlayerFrame* myPendingPlayerClick = nullptr;
    TargetFrame* myPendingTargetClick = nullptr;
    Tga::Vector2f myFramePressMouseWorld{ 0.f, 0.f };
    bool myFrameDragStarted = false;

    StanceBar* FindStanceBarAt(const Tga::Vector2f& mouseWorld) const;
    StanceBarEditPopup myStanceBarPopup;
    StanceBar* myPendingStanceBarClick = nullptr;
    bool myStanceBarDragStarted = false;
    Tga::Vector2f myStanceBarPressMouseWorld{ 0.f, 0.f };
    Tga::Vector2f myStanceBarDragGrabOffset{ 0.f, 0.f };
    StanceBar* myDraggingStanceBar = nullptr;
private:
    HUD* myHUD = nullptr;   
    ActionBarEditPopup myBarPopup;
    std::shared_ptr<HudEditPanel> myEditPanel;


    FrameScalePopup myFrameScalePopup;
    PartyFrameSettingsPopup myPartyFrameSettingsPopup;

    HudLayoutSnapshot myEditStartSnapshot;
    HudLayoutSnapshot mySavedSnapshot;
    bool myHasSavedSnapshot = false;
    bool myDidPressSave = false;

    // outline color
    Tga::Color myEditOutlineColor = { 1.0f, 0.0f, 0.0f, 1.0f };
};


