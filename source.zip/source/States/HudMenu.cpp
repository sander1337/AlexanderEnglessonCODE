﻿#include "stdafx.h"
#include "OtherMenus.h"
#include "HudMenu.h"// where HudMenu lives
#include "../SceneManagement/MenuScene.h"
#include "../Input/InputMapper.h"

#include <imgui/imgui_impl_dx11.h>
#include <tge/graphics/GraphicsEngine.h>
#include <tge/graphics/GraphicsStateStack.h>
#include <tge/input/InputManager.h>
#include <tge/drawers/DebugDrawer.h>

#include "StateStack.h"
#include "ActionBars/ActionBar.h"
#include "SceneManagement/GameScene.h"
#include "SceneManagement/SceneManager.h"
#include "Utilities/UIRectUtils.h"


static Tga::Vector2f GetMouseWorldUI(Tga::InputManager* im, Tga::Camera* uiCam)
{
    const auto res = Tga::Engine::GetInstance()->GetRenderSize();
    const float H = (float)res.y;

    const Tga::Vector2f mouseScreen{ im->GetMousePosition().x, H - im->GetMousePosition().y };
    return uiCam->GetScreenToWorldCoordinatesVec2(mouseScreen);
}

void HudMenu::OnEnter()
{
    myPartyFrameSettingsPopup.Init(myHUD, GetActiveCamera());
	myFrameScalePopup.Init(GetActiveCamera());

    Menu::OnEnter();
    EventManager::GetInstance()->Subscribe(Event::HudLayoutSavePressed, this);

    if (!myHUD)
    {
        std::cout << "[HudMenu] ERROR: myHUD is null. Did you call HudMenu::SetHUD()?\n";
    }

    if (auto* im = InputMapper::GetInstance().GetInputManager())
        im->ReleaseMouse();

    myDidPressSave = false;

    if (myHasSavedSnapshot)
        ApplySnapshot(mySavedSnapshot);

    CaptureSnapshot(myEditStartSnapshot);


    SetHudEditMode(true);

    auto menuScene = std::dynamic_pointer_cast<MenuScene>(myScene);
    if (!menuScene) return;

    auto uiCam = GetActiveCamera();

    // Skapa panel
    myEditPanel = std::make_shared<HudEditPanel>();
    myEditPanel->InitRuntimePanel(myHUD, uiCam, { 0, 550.f }, { 900.f, 450.f });

    // Lägg den som MODAL så den alltid ritas över frames (som spellbook panel)
    menuScene->AddModalRuntimeButton(myEditPanel);

    // Input för drag/hover/click
    myEditPanel->RegisterInput();
    myEditPanel->SetEditMode(true);

    myBarPopup.Init(*menuScene, GetActiveCamera());
 
    myStanceBarPopup.Init(*menuScene, GetActiveCamera());
	if (menuScene)
    {
        for (auto& bar : menuScene->GetActionBars())
            if (bar)
            {
                bar->SetEditMode(true);
            }

        for (auto& b : menuScene->GetRuntimeButtons())
            if (b) b->RegisterInput();   
    }
    
    EventManager::GetInstance()->Subscribe(Event::CloseHudEditMenu, this);
    Message m;
    m.eventType = Event::ToggleHudEditMode;
    m.data = 1;
    EventManager::GetInstance()->SendEventMessage(m);
    RefreshCastBarEditVisibility(true);
}

void HudMenu::OnExit()
{
    EventManager::GetInstance()->UnSubscribe(Event::HudLayoutSavePressed, this);
    EventManager::GetInstance()->UnSubscribe(Event::CloseHudEditMenu, this);

    if (!myDidPressSave)
        ApplySnapshot(myEditStartSnapshot);


    Message m;
    m.eventType = Event::ToggleHudEditMode;
    m.data = 0;
    EventManager::GetInstance()->SendEventMessage(m);
    RefreshCastBarEditVisibility(false);
    SetHudEditMode(false);

    auto menuScene = std::dynamic_pointer_cast<MenuScene>(myScene);
    if (menuScene && myEditPanel)
    {
        myEditPanel->UnregisterInput();
        menuScene->RemoveModalRuntimeButton(myEditPanel);   // ✅ important
        myEditPanel.reset();
    }

    if (menuScene)
    {
        for (auto& bar : menuScene->GetActionBars())
            if (bar) bar->SetEditMode(false);

        for (auto& b : menuScene->GetRuntimeButtons())
            if (b) b->UnregisterInput();
    }
    myFrameScalePopup.Close();
    myPartyFrameSettingsPopup.Close();
    myBarPopup.Close();
    myEditPanel.reset();
    Menu::OnExit();

}

void HudMenu::Render()
{
    Menu::Render();

    auto& engine = *Tga::Engine::GetInstance();
    auto& gss = engine.GetGraphicsEngine().GetGraphicsStateStack();

    gss.Push();
    // Option 1: use the menu scene camera (UI camera)
    gss.SetCamera(*GetActiveCamera()); // if Menu/State has GetActiveCamera()

    auto menuScene = std::dynamic_pointer_cast<MenuScene>(myScene);
    if (menuScene)
    {
        for (auto& [id, btn] : menuScene->GetButtons())
        {
            if (!btn) continue;
            btn->DebugDrawBounds(myEditOutlineColor);
        }

        for (auto& bar : menuScene->GetActionBars())
        {
            if (!bar || !bar->IsVisible())
                continue;

            bar->DebugDrawBounds(myEditOutlineColor);
        }

        for (auto& b : menuScene->GetRuntimeButtons())
            if (b) b->DebugDrawBounds(myEditOutlineColor);
    }

    if (myBarPopup.IsOpen())
    {
        auto& drawer = Tga::Engine::GetInstance()->GetGraphicsEngine().GetSpriteDrawer();
        myBarPopup.Render(drawer);
    }

    if (myFrameScalePopup.IsOpen())
    {
        auto& drawer = Tga::Engine::GetInstance()->GetGraphicsEngine().GetSpriteDrawer();
        myFrameScalePopup.Render(drawer);
    }

    if (myPartyFrameSettingsPopup.IsOpen())
    {
        auto& drawer = Tga::Engine::GetInstance()->GetGraphicsEngine().GetSpriteDrawer();
        myPartyFrameSettingsPopup.Render(drawer);
    }

    if (myStanceBarPopup.IsOpen())
    {
        auto& drawer = Tga::Engine::GetInstance()->GetGraphicsEngine().GetSpriteDrawer();
        myStanceBarPopup.Render(drawer);
    }

    gss.Pop();
}

void HudMenu::Update(float aDeltaTime)
{
    // Viktigt: låt Menu/State göra sin grej först (navigation, cooldown etc)
    Menu::Update(aDeltaTime);

    if (myHUD && myHUD->IsSpellBookOpen())
    {
        myHUD->CloseSpellBook();
    }

    auto* im = InputMapper::GetInstance().GetInputManager();
    if (!im) return;

    const Tga::Vector2f mouseWorld = GetMouseWorldUI(im, GetActiveCamera().get());

    if (myBarPopup.IsOpen())
    {
        myBarPopup.Update(im, mouseWorld);
        return; // consume input so bars don't drag behind popup
    }

    if (myFrameScalePopup.IsOpen())
    {
        myFrameScalePopup.Update(im, mouseWorld);
        return;
    }

    if (myPartyFrameSettingsPopup.IsOpen())
    {
        myPartyFrameSettingsPopup.Update(im, mouseWorld);
        return;
    }

    if (myStanceBarPopup.IsOpen())
    {
        myStanceBarPopup.Update(im, mouseWorld);
        return;
    }

    auto menuScene = std::dynamic_pointer_cast<MenuScene>(myScene);
    if (!menuScene)
        return;

    RefreshCastBarEditVisibility(true);

    // 1) Update runtime buttons
    for (auto& b : menuScene->GetRuntimeButtons())
    {
        if (b)
            b->Update(aDeltaTime);
    }

    for (auto& b : menuScene->GetModalRuntimeButtons())
        if (b) b->Update(aDeltaTime);

    // 2) Update actionbars
    for (auto& bar : menuScene->GetActionBars())
    {
        if (bar)
            bar->Update(aDeltaTime);
    }

    // GRID & snap
    if (myHUD)
    {
        const auto& s = myHUD->GetHudEditSettings();

        if (s.snapToElements)
        {
            for (auto& b : menuScene->GetRuntimeButtons())
            {
                if (!b || !b->IsVisible())
                    continue;

                const bool isSnapTarget =
                    dynamic_cast<CastBarFrame*>(b.get()) ||
                    dynamic_cast<PlayerFrame*>(b.get()) ||
                    dynamic_cast<TargetFrame*>(b.get()) ||
                    dynamic_cast<PartyFrame*>(b.get()) ||
                    dynamic_cast<BuffFrame*>(b.get());

                if (!isSnapTarget)
                    continue;

                if (!b->IsDragging())
                    continue;

                b->SetPosition(SnapToGrid(b->GetPosition()));
                break;
            }
        }
    }

    // -------------------------------------------------
    // LMB action bar interaction
    // click = popup
    // hold + move = drag
    // -------------------------------------------------
    {
        const bool lmbPressed = im->IsKeyPressed(VK_LBUTTON);
        const bool lmbHeld = im->IsKeyHeld(VK_LBUTTON);
        const bool lmbReleased = im->IsKeyReleased(VK_LBUTTON);

        if (lmbPressed)
        {
            myPendingBarLeftClick = FindActionBarAt(mouseWorld);
            myDraggingBar = nullptr;
            myBarDragStarted = false;
            myBarPressMouseWorld = mouseWorld;

            if (myPendingBarLeftClick)
            {
                myBarDragGrabOffset = mouseWorld - myPendingBarLeftClick->GetPosition();
            }
        }

        // turn click into drag if mouse moved enough
        if (lmbHeld && myPendingBarLeftClick && !myBarDragStarted)
        {
            const Tga::Vector2f d = mouseWorld - myBarPressMouseWorld;
            const float dragThresholdSq = 8.f * 8.f;
            const float distSq = d.x * d.x + d.y * d.y;

            if (distSq >= dragThresholdSq)
            {
                myDraggingBar = myPendingBarLeftClick;
                myBarDragStarted = true;
            }
        }

        // drag active action bar
        if (lmbHeld && myDraggingBar)
        {
            Tga::Vector2f newPos = mouseWorld - myBarDragGrabOffset;

            if (myHUD && myHUD->GetHudEditSettings().snapToElements)
                newPos = SnapToGrid(newPos);

            myDraggingBar->SetPosition(newPos);
            return; // consume input while dragging
        }

        // release = popup only if it was a click, not a drag
        if (lmbReleased && myPendingBarLeftClick)
        {
            if (!myBarDragStarted)
            {
                myBarPopup.OpenNearBar(*myPendingBarLeftClick);
                myPendingBarLeftClick = nullptr;
                myDraggingBar = nullptr;
                return;
            }

            myPendingBarLeftClick = nullptr;
            myDraggingBar = nullptr;
            myBarDragStarted = false;
            return;
        }
    }

    // -------------------------------------------------
    // LMB party frame interaction
    // click = popup
    // hold + move = drag
    // -------------------------------------------------
    {
        const bool lmbPressed = im->IsKeyPressed(VK_LBUTTON);
        const bool lmbHeld = im->IsKeyHeld(VK_LBUTTON);
        const bool lmbReleased = im->IsKeyReleased(VK_LBUTTON);

        if (lmbPressed)
        {
            myPendingPartyClick = FindPartyFrameAt(mouseWorld);
            myPartyDragStarted = false;
            myPartyPressMouseWorld = mouseWorld;
        }

        if (lmbHeld && myPendingPartyClick && !myPartyDragStarted)
        {
            const Tga::Vector2f d = mouseWorld - myPartyPressMouseWorld;
            const float dragThresholdSq = 8.f * 8.f;
            const float distSq = d.x * d.x + d.y * d.y;

            // ONLY actual movement decides drag
            if (distSq >= dragThresholdSq)
            {
                myPartyDragStarted = true;
            }
        }

        if (lmbReleased && myPendingPartyClick)
        {
            if (!myPartyDragStarted)
            {
                myPartyFrameSettingsPopup.Open(myHUD->GetPartyFrameSettingsPopupPos());
                myPendingPartyClick = nullptr;
                return;
            }

            myPendingPartyClick = nullptr;
            myPartyDragStarted = false;
            return;
        }
    }

    // -------------------------------------------------
// LMB player/target frame interaction
// click = popup
// hold + move = drag
// -------------------------------------------------
    {
        const bool lmbPressed = im->IsKeyPressed(VK_LBUTTON);
        const bool lmbHeld = im->IsKeyHeld(VK_LBUTTON);
        const bool lmbReleased = im->IsKeyReleased(VK_LBUTTON);

        if (lmbPressed)
        {
            myPendingPlayerClick = FindPlayerFrameAt(mouseWorld);
            myPendingTargetClick = nullptr;
            myPendingCastBarClick = nullptr;

            if (!myPendingPlayerClick)
                myPendingTargetClick = FindTargetFrameAt(mouseWorld);

            if (!myPendingPlayerClick && !myPendingTargetClick)
                myPendingCastBarClick = FindCastBarFrameAt(mouseWorld);

            myFrameDragStarted = false;
            myFramePressMouseWorld = mouseWorld;
        }

        if (lmbHeld && (myPendingPlayerClick || myPendingTargetClick || myPendingCastBarClick) && !myFrameDragStarted)
        {
            const Tga::Vector2f d = mouseWorld - myFramePressMouseWorld;
            const float dragThresholdSq = 8.f * 8.f;
            const float distSq = d.x * d.x + d.y * d.y;

            if (distSq >= dragThresholdSq)
            {
                myFrameDragStarted = true;
            }
        }

        if (lmbReleased && (myPendingPlayerClick || myPendingTargetClick || myPendingCastBarClick))
        {
            if (!myFrameDragStarted)
            {
                if (myPendingPlayerClick)
                {
                    myFrameScalePopup.OpenNearPlayerFrame(*myPendingPlayerClick);
                }
                else if (myPendingTargetClick)
                {
                    myFrameScalePopup.OpenNearTargetFrame(*myPendingTargetClick);
                }
                else if (myPendingCastBarClick)
                {
                    myFrameScalePopup.OpenNearCastBarFrame(*myPendingCastBarClick);
                }

                myPendingPlayerClick = nullptr;
                myPendingTargetClick = nullptr;
                myPendingCastBarClick = nullptr;
                return;
            }

            myPendingPlayerClick = nullptr;
            myPendingTargetClick = nullptr;
            myPendingCastBarClick = nullptr;
            myFrameDragStarted = false;
        }
    }

    // -------------------------------------------------
// LMB stance bar interaction
// click = popup
// hold + move = drag
// -------------------------------------------------
    {
        const bool lmbPressed = im->IsKeyPressed(VK_LBUTTON);
        const bool lmbHeld = im->IsKeyHeld(VK_LBUTTON);
        const bool lmbReleased = im->IsKeyReleased(VK_LBUTTON);

        if (lmbPressed)
        {
            myPendingStanceBarClick = FindStanceBarAt(mouseWorld);
            myDraggingStanceBar = nullptr;
            myStanceBarDragStarted = false;
            myStanceBarPressMouseWorld = mouseWorld;

            if (myPendingStanceBarClick)
                myStanceBarDragGrabOffset = mouseWorld - myPendingStanceBarClick->GetPosition();
        }

        if (lmbHeld && myPendingStanceBarClick && !myStanceBarDragStarted)
        {
            const Tga::Vector2f d = mouseWorld - myStanceBarPressMouseWorld;
            const float dragThresholdSq = 8.f * 8.f;
            const float distSq = d.x * d.x + d.y * d.y;

            if (distSq >= dragThresholdSq)
            {
                myDraggingStanceBar = myPendingStanceBarClick;
                myStanceBarDragStarted = true;
            }
        }

        if (lmbHeld && myDraggingStanceBar)
        {
            Tga::Vector2f newPos = mouseWorld - myStanceBarDragGrabOffset;

            if (myHUD && myHUD->GetHudEditSettings().snapToElements)
                newPos = SnapToGrid(newPos);

            myDraggingStanceBar->SetPosition(newPos);
            return;
        }

        if (lmbReleased && myPendingStanceBarClick)
        {
            if (!myStanceBarDragStarted)
            {
                myStanceBarPopup.OpenNearBar(*myPendingStanceBarClick);
                myPendingStanceBarClick = nullptr;
                myDraggingStanceBar = nullptr;
                return;
            }

            myPendingStanceBarClick = nullptr;
            myDraggingStanceBar = nullptr;
            myStanceBarDragStarted = false;
            return;
        }
    }
}

void HudMenu::ReceiveEvent(const Message& aMessage)
{
    if (aMessage.eventType == Event::CloseHudEditMenu)
    {
        myStateStack.Pop();

    	return;
    }

    if (aMessage.eventType != Event::HudLayoutSavePressed)
        return;

    CaptureSnapshot(mySavedSnapshot);
    myHasSavedSnapshot = true;
    myDidPressSave = true;
}

Tga::Vector2f HudMenu::SnapToGrid(const Tga::Vector2f& pos) const
{
    if (!myHUD)
        return pos;

    const float g = std::max(1.f, myHUD->GetHudEditSettings().gridSize);

    return {
        std::round(pos.x / g) * g,
        std::round(pos.y / g) * g
    };
}

void HudMenu::SetHudEditMode(bool on)
{
    auto menuScene = std::dynamic_pointer_cast<MenuScene>(myScene);
    if (!menuScene) return;

    for (auto& [id, btn] : menuScene->GetButtons())
    {
        if (!btn) continue;

        const bool isHudWidget =
            id == Tga::ButtonType::Info;

        if (!isHudWidget)
            continue;

        btn->SetDraggable(on);
        if (!on) btn->CancelDrag();
    }
    // ---- ✅ runtime widgets (ActionBar slots + frames) ----
    for (auto& b : menuScene->GetRuntimeButtons())
    {
        if (!b) continue;

        if (auto* pf = dynamic_cast<PlayerFrame*>(b.get()))
            pf->SetEditMode(on);

        if (auto* tf = dynamic_cast<TargetFrame*>(b.get()))
            tf->SetEditMode(on);

        if (auto* party = dynamic_cast<PartyFrame*>(b.get()))
            party->SetEditMode(on);

        if (auto* buff = dynamic_cast<BuffFrame*>(b.get()))
            buff->SetEditMode(on);

        if (auto* cast = dynamic_cast<CastBarFrame*>(b.get()))
            cast->SetEditMode(on);

        if (auto* cast = dynamic_cast<StanceBar*>(b.get()))
            cast->SetEditMode(on);
    }
}

void HudMenu::CaptureSnapshot(HudLayoutSnapshot& snapshot)
{
    snapshot.positions.clear();

    auto menuScene = std::dynamic_pointer_cast<MenuScene>(myScene);
    if (!menuScene) return;

    for (auto& [id, btn] : menuScene->GetButtons())
    {
        if (!btn) continue;

        // filtrera bara hud widgets om du vill
        snapshot.positions[id] = btn->GetPosition(); // du har const GetPosition()
    }
}

void HudMenu::ApplySnapshot(const HudLayoutSnapshot& snapshot)
{
    auto menuScene = std::dynamic_pointer_cast<MenuScene>(myScene);
    if (!menuScene) return;

    for (auto& [id, btn] : menuScene->GetButtons())
    {
        if (!btn) continue;

        auto it = snapshot.positions.find(id);
        if (it == snapshot.positions.end()) continue;

        btn->SetPosition(it->second);
    }
}

CastBarFrame* HudMenu::FindCastBarFrameAt(const Tga::Vector2f& mouseWorld) const
{
    auto menuScene = std::dynamic_pointer_cast<MenuScene>(myScene);
    if (!menuScene)
        return nullptr;

    for (auto& b : menuScene->GetRuntimeButtons())
    {
        if (!b || !b->IsVisible())
            continue;

        auto* cast = dynamic_cast<CastBarFrame*>(b.get());
        if (!cast)
            continue;

        if (PointInRectCenterSize(mouseWorld, b->GetPosition(), b->GetHalfSize() * 2.f * cast->GetFrameScale()))
            return cast;
    }

    return nullptr;
}
void HudMenu::RefreshCastBarEditVisibility(bool editModeOn)
{
    auto menuScene = std::dynamic_pointer_cast<MenuScene>(myScene);
    if (!menuScene || !myHUD)
        return;

    const auto& s = myHUD->GetHudEditSettings();

    for (auto& b : menuScene->GetRuntimeButtons())
    {
        if (!b)
            continue;

        auto* cast = dynamic_cast<CastBarFrame*>(b.get());
        if (!cast)
            continue;

        // while HUD edit menu is open -> preview only if checkbox is enabled
        if (editModeOn)
        {
            cast->SetVisible(s.castBar);
            cast->SetEditMode(true);
        }
        else
        {
            cast->SetEditMode(false);
            cast->SetVisible(s.castBar && cast->IsCasting());
        }

        if (!s.castBar)
            cast->CancelDrag();

        break;
    }
}
ActionBar* HudMenu::FindActionBarAt(const Tga::Vector2f& mouseWorld) const
{
    auto menuScene = std::dynamic_pointer_cast<MenuScene>(myScene);
    if (!menuScene)
        return nullptr;

    for (auto& bar : menuScene->GetActionBars())
    {
        if (!bar || !bar->IsVisible())
            continue;

        if (PointInAabb(mouseWorld, bar->GetBoundsMin(), bar->GetBoundsMax()))
            return bar.get();
    }

    return nullptr;
}

PartyFrame* HudMenu::FindPartyFrameAt(const Tga::Vector2f& mouseWorld) const
{
    auto menuScene = std::dynamic_pointer_cast<MenuScene>(myScene);
    if (!menuScene)
        return nullptr;

    for (auto& b : menuScene->GetRuntimeButtons())
    {
        if (!b || !b->IsVisible())
            continue;

        auto* party = dynamic_cast<PartyFrame*>(b.get());
        if (!party)
            continue;

        if (PointInRectCenterSize(mouseWorld, b->GetPosition(), b->GetHalfSize() * 2.f))
            return party;
    }

    return nullptr;
}

PlayerFrame* HudMenu::FindPlayerFrameAt(const Tga::Vector2f& mouseWorld) const
{
    auto menuScene = std::dynamic_pointer_cast<MenuScene>(myScene);
    if (!menuScene)
        return nullptr;

    for (auto& b : menuScene->GetRuntimeButtons())
    {
        if (!b || !b->IsVisible())
            continue;

        auto* pf = dynamic_cast<PlayerFrame*>(b.get());
        if (!pf)
            continue;

        if (PointInRectCenterSize(mouseWorld, b->GetPosition(), b->GetHalfSize() * 2.f))
            return pf;
    }

    return nullptr;
}

TargetFrame* HudMenu::FindTargetFrameAt(const Tga::Vector2f& mouseWorld) const
{
    auto menuScene = std::dynamic_pointer_cast<MenuScene>(myScene);
    if (!menuScene)
        return nullptr;

    for (auto& b : menuScene->GetRuntimeButtons())
    {
        if (!b || !b->IsVisible())
            continue;

        auto* tf = dynamic_cast<TargetFrame*>(b.get());
        if (!tf)
            continue;

        if (PointInRectCenterSize(mouseWorld, b->GetPosition(), b->GetHalfSize() * 2.f))
            return tf;
    }

    return nullptr;
}

StanceBar* HudMenu::FindStanceBarAt(const Tga::Vector2f& mouseWorld) const
{
    if (!myHUD) return nullptr;

    auto* bar = myHUD->GetStanceBar();
    if (!bar || !bar->IsVisible())
        return nullptr;

    if (PointInAabb(mouseWorld, bar->GetBoundsMin(), bar->GetBoundsMax()))
        return bar;

    return nullptr;
}
