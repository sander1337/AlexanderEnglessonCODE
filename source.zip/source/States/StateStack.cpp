#include "stdafx.h"
#include "StateStack.h"
#include "StateID.h"

#include "InGame.h"
#include "OtherMenus.h"
#include "Cutscene.h"
#include "HudMainMenu.h"
#include "HudMenu.h"
#include "SplashScreen.h"
#include "../SceneManagement/SceneManager.h"

void StateStack::Init(SceneID aSceneID, const std::shared_ptr<SceneManager>& aSceneManager, const std::shared_ptr<RenderManager>& aRenderManager)
{
    myCachedStates[StateID::InGame] = std::make_shared<InGame>(*this, aSceneManager, aRenderManager);
    myCachedStates[StateID::MainMenu] = std::make_shared<Menu>(*this, aSceneManager, aRenderManager);
    myCachedStates[StateID::Credits] = std::make_shared<CreditsMenu>(*this, aSceneManager, aRenderManager);
    myCachedStates[StateID::Options] = std::make_shared<OptionsMenu>(*this, aSceneManager, aRenderManager);
    myCachedStates[StateID::LevelSelect] = std::make_shared<LevelSelectMenu>(*this, aSceneManager, aRenderManager);
    myCachedStates[StateID::Pause] = std::make_shared<PauseMenu>(*this, aSceneManager, aRenderManager, true);
    myCachedStates[StateID::Cutscene] = std::make_shared<Cutscene>(*this, aSceneManager, aRenderManager);
    myCachedStates[StateID::SplashScreen] = std::make_shared<SplashScreen>(*this, aSceneManager, aRenderManager);
    myCachedStates[StateID::EndScreen] = std::make_shared<Menu>(*this, aSceneManager, aRenderManager);
    myCachedStates[StateID::HUD] = std::make_shared<HudMenu>(*this, aSceneManager, aRenderManager, true /* letThroughRender */);
    myCachedStates[StateID::HudMainMenu] = std::make_shared<HudMainMenu>(*this, aSceneManager, aRenderManager, true /* letThroughRender */);

    auto mainMenu = static_cast<MainMenu*>(myCachedStates[StateID::MainMenu].get());
    mainMenu->SetPendingScene(SceneID::MainMenu);

    auto inGame = static_cast<InGame*>(myCachedStates[StateID::InGame].get());
    EventManager::GetInstance()->Subscribe(Event::SwitchLevel, inGame);

#ifdef _RETAIL
    aSceneID;
    Push(StateID::SplashScreen);
#else
    if (aSceneID == SceneID::MainMenu)
    {
        Push(StateID::MainMenu, aSceneID);
    }
    else
    {
        inGame->SetPendingScene(aSceneID);
        Push(StateID::InGame, aSceneID);
    }
#endif
}

void StateStack::Update(float aDeltaTime)
{
    for (int i = static_cast<int>(myStack.size() - 1); i >= 0; --i)
    {
        myStack[i]->Update(aDeltaTime);

        if (i <= myStack.size() - 1)
        {
            if (!myStack[i]->LetsThroughUpdate())
            {
	            break;
            }
        }
    }
}

void StateStack::Render(int anIndex)
{
    if (anIndex == -10) anIndex = static_cast<int>(myStack.size()) - 1;
    if (myStack.empty() || anIndex < 0) return;


    // Render states below 
    if (myStack[anIndex]->LetsThroughRender())
    {
        Render(anIndex - 1);
    }

    // Render the state 
    myStack[anIndex]->Render();
}

void StateStack::Push(StateID aStateID, SceneID aSceneID)
{
    auto it = myCachedStates.find(aStateID);

    if (it != myCachedStates.end())
    {
        if (!myStack.empty())
        { 
            // Optional
            if (!it->second->LetsThroughUpdate())
            {
                ExitState();
            }
        }
        myStack.push_back(it->second.get());
        if (aSceneID != SceneID::Count)
        {
            myStack.back()->SetPendingScene(aSceneID);
        }
        EnterState();
    }
}

void StateStack::Pop()
{
    if (!myStack.empty())
    {
        bool alreadyInScene = myStack.back()->LetsThroughUpdate();
        myStack.back()->OnExit();
        myStack.back()->SetHasExited(true);
        //ExitState();
        myStack.pop_back();

        if (!myQueue.empty())
        {
            Push(myQueue.back().first, myQueue.back().second);
            myQueue.pop_back();
        }
        // Optional
        else if (!myStack.empty())
        {
            if (!alreadyInScene)
            {
                EnterState();
            }
        }
    }
}

void StateStack::EnterState(int anIndex)
{
    if (anIndex == -10) anIndex = static_cast<int>(myStack.size()) - 1;
    if (myStack.empty() || anIndex < 0) return;

    if (myStack[anIndex]->LetsThroughUpdate())
    {
        EnterState(anIndex - 1);
    }
    if (myStack[anIndex]->GetHasExited())
    {
        myStack[anIndex]->OnEnter();
        myStack[anIndex]->SetHasExited(false);
    }
}

void StateStack::ExitState(int anIndex)
{
    if (anIndex == -10) anIndex = static_cast<int>(myStack.size()) - 1;
    if (myStack.empty() || anIndex < 0) return;

    if (myStack[anIndex]->LetsThroughUpdate())
    {
        ExitState(anIndex - 1);
    }
    myStack[anIndex]->OnExit();
    myStack[anIndex]->SetHasExited(true);
}

void StateStack::QueueState(StateID aStateID, SceneID aSceneID)
{
    auto it = myCachedStates.find(aStateID);

    if (it != myCachedStates.end())
    {
        myQueue.emplace_back(std::pair<StateID, SceneID>(aStateID, aSceneID));
    }
}

void StateStack::Clear()
{
    while (!myStack.empty())
    {
        myStack.pop_back();
    }
}

State* StateStack::GetCurrentState() const
{
    if (!myStack.empty())
    {
        return myStack.back();
    }

    return nullptr;
}

State* StateStack::GetState(StateID aStateID) const
{
    if (myCachedStates.contains(aStateID))
    {
        return &*myCachedStates.at(aStateID);
    }
    return nullptr;
}

State* StateStack::GetBelowCurrentState() const
{
    if (myStack.size() < 2) return nullptr;
    return myStack[myStack.size() - 2];
}