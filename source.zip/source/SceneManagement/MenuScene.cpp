#include "stdafx.h"
#include "MenuScene.h"
#include "../UI/Button.h"
#include "../UI/ToolTip.h"
#include <tge/graphics/Camera.h>

#include "States/ActionBars/ActionBar.h"

void MenuScene::Update(float aDeltaTime)
{
	for (auto& b : myRuntimeButtons)
		if (b) b->Update(aDeltaTime);

	for (auto& bar : myActionBars)
		if (bar) bar->Update(aDeltaTime);
}

void MenuScene::OnEnter(SceneManager& aSceneManager, StateStack& aStateStack)
{
	aSceneManager;
	aStateStack;

	if (!myIsInitialized)
	{
		myCamera = std::make_shared<Tga::Camera>();
		myCamera->Init(Tga::Camera::ProjectionType::Ortoraphic);
		myIsInitialized = true;
	}

	for (auto& button : myButtons)
	{
		button.second->RegisterInput();
		button.second->SetCamera(myCamera);
		// Register button input
	}

	for (auto& b : myRuntimeButtons)
	{
		if (!b) continue;
		b->SetStateStack(&aStateStack);
		b->SetCamera(myCamera);       
		b->RegisterInput();
	}

	for (auto& tooltip : myToolTips)
	{
		tooltip->RegisterEvent();
	}
}

void MenuScene::OnExit()
{

	for (auto& button : myButtons)
	{
		button.second->UnregisterInput();
		// Unregister button input
	}

	for (auto& b : myRuntimeButtons)
	{
		if (!b) continue;
		b->UnregisterInput();
	}


	for (auto& tooltip : myToolTips)
	{
		tooltip->UnregisterEvent();
	}
}

void MenuScene::AddButton(const Tga::ButtonType aButtonType, const std::shared_ptr<Button>& aButton)
{
	myButtons[aButtonType] = aButton;

	auto it = std::find(myButtonDrawOrder.begin(), myButtonDrawOrder.end(), aButtonType);
	if (it == myButtonDrawOrder.end())
		myButtonDrawOrder.push_back(aButtonType);
}

void MenuScene::AddSprite(const std::shared_ptr<GameSprite>& aSprite)
{
	mySprites.push_back(aSprite);
}

void MenuScene::AddToolTip(const std::shared_ptr<ToolTip>& aToolTip)
{
	myToolTips.push_back(aToolTip);
}

void MenuScene::BringToFront(Tga::ButtonType type)
{
	auto it = std::find(myButtonDrawOrder.begin(), myButtonDrawOrder.end(), type);
	if (it == myButtonDrawOrder.end())
		return;

	myButtonDrawOrder.erase(it);
	myButtonDrawOrder.push_back(type); 
}

void MenuScene::RemoveModalRuntimeButton(const std::shared_ptr<Button>& button)
{
	auto it = std::remove(myModalRuntimeButtons.begin(), myModalRuntimeButtons.end(), button);
	myModalRuntimeButtons.erase(it, myModalRuntimeButtons.end());
}


