#pragma once
#include "RunTimeScene.h"
#include "Events/EventManager.h"

#include <map>
#include <tge/scene/ScenePropertyTypes.h>

class ActionBar;
class GameSprite;
class Button;
class ToolTip;

class MenuScene : public RunTimeScene
{
public:
    MenuScene() = default;
    ~MenuScene() = default;

    void Update(float aDeltaTime) override;
    void OnEnter(SceneManager& aSceneManager, StateStack& aStateStack) override;
    void OnExit() override;

    void AddButton(const Tga::ButtonType aButtonType, const std::shared_ptr<Button>& aButton);
    void AddSprite(const std::shared_ptr<GameSprite>& aSprite);
    void AddToolTip(const std::shared_ptr<ToolTip>& aToolTip);

    const std::vector<Tga::ButtonType>& GetButtonDrawOrder() const { return myButtonDrawOrder; }
    void BringToFront(Tga::ButtonType type);
    void RemoveModalRuntimeButton(const std::shared_ptr<Button>& button);

    std::map<Tga::ButtonType, std::shared_ptr<Button>>& GetButtons() { return myButtons; }
    std::vector<std::shared_ptr<GameSprite>>& GetSprites() { return mySprites; }
    std::vector<std::shared_ptr<ToolTip>>& GetToolTips() { return myToolTips; }

    // Runtime buttons (slots etc)
    void AddRuntimeButton(const std::shared_ptr<Button>& b) { myRuntimeButtons.push_back(b); }
    std::vector<std::shared_ptr<Button>>& GetRuntimeButtons() { return myRuntimeButtons; }
    const std::vector<std::shared_ptr<Button>>& GetRuntimeButtons() const { return myRuntimeButtons; }

    // ActionBars container
    void AddActionBar(const std::shared_ptr<ActionBar>& bar) { myActionBars.push_back(bar); }
    std::vector<std::shared_ptr<ActionBar>>& GetActionBars() { return myActionBars; }
    const std::vector<std::shared_ptr<ActionBar>>& GetActionBars() const { return myActionBars; }

    // Modal runtime buttons (spellbook etc)
    void AddModalRuntimeButton(const std::shared_ptr<Button>& b) { myModalRuntimeButtons.push_back(b); }
    std::vector<std::shared_ptr<Button>>& GetModalRuntimeButtons() { return myModalRuntimeButtons; }
    const std::vector<std::shared_ptr<Button>>& GetModalRuntimeButtons() const { return myModalRuntimeButtons; }

    std::shared_ptr<Tga::Camera> GetCamera() const { return myCamera; }

private:
    std::map<Tga::ButtonType, std::shared_ptr<Button>> myButtons;
    std::vector<std::shared_ptr<GameSprite>> mySprites;
    std::vector<std::shared_ptr<ToolTip>> myToolTips;
    std::vector<Tga::ButtonType> myButtonDrawOrder;
    std::vector<std::shared_ptr<Button>> myRuntimeButtons;
    std::vector<std::shared_ptr<ActionBar>> myActionBars;
    std::vector<std::shared_ptr<Button>> myModalRuntimeButtons;
};
