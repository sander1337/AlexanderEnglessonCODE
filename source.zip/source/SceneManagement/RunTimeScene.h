#pragma once

#include <tge/scene/Scene.h>

namespace Tga
{
	class Camera;
}

class StateStack;
class SceneManager;
enum class SceneID : std::uint8_t;

class RunTimeScene
{
public:
	friend class RenderManager;
	RunTimeScene() = default;
	~RunTimeScene() = default;

	virtual void Update(float aDeltaTime) = 0;
	virtual void OnEnter(SceneManager& aSceneManager, StateStack& aStateStack) = 0;
	virtual void OnExit() = 0;

	const std::shared_ptr<Tga::Camera>& GetActiveCamera() const {return myCamera;};
	SceneID GetSceneID() const;
	void SetSceneID(SceneID aSceneID);

protected:
	std::shared_ptr<Tga::Camera> myCamera;
	SceneID mySceneID;
	bool myIsInitialized = false;
};

inline SceneID RunTimeScene::GetSceneID() const
{
	return mySceneID;
}

inline void RunTimeScene::SetSceneID(SceneID aSceneID)
{
	mySceneID = aSceneID;
}