#pragma once
#include <memory>
#include <functional>
#include <tge/scene/ScenePropertyTypes.h>

class GameObject;

namespace Tga
{
	struct ScenePropertyDefinition;
}


class GameObjectFactory
{
public:
	explicit GameObjectFactory(const std::vector<Tga::ScenePropertyDefinition>& aObjectProperties);

	// Creates a new GameObject based on a tag.
    // Sets isPlayer to true if it is the player, for now. so we need to send in a bool :/, but yeah
    std::shared_ptr<GameObject> CreateGameObject(const Tga::TagData& aTagData, bool& aIsPlayer);

private:
	const std::vector<Tga::ScenePropertyDefinition>& myObjectProperties;
	
	using CreatorFunc = std::function<std::shared_ptr<GameObject>()>;
	std::map<Tga::Tag, CreatorFunc> myGameObjectRegistry;
};
