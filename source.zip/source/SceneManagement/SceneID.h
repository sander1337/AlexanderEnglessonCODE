#pragma once
//#pragma message(__FILE__" was compiled")
enum class SceneID : std::uint8_t
{
    Level1,
    Level2,
    AssetGym,
    VFXGym,
    PlayerGym,
    AnimationGym,
    AIGym,
    MainMenu,
    Options,
    LevelSelect,
    Credits,
	Pause,

    HUD,
	HudMainMenu,

    EndScreen,
    Custom,
    Count,
};