#pragma once
//#pragma message(__FILE__" was compiled")
#include "RunTimeScene.h"
#include <tge/scene/SceneObjectDefinitionManager.h>

#include <PhysX/include/PxPhysicsAPI.h>

static physx::PxDefaultErrorCallback globalDefaultErrorCallback;
static physx::PxDefaultAllocator globalDefaultAllocatorCallback;

namespace physx
{
    class PxFoundation;
}

class PropertyApplier;

namespace Tga
{
	class SceneObject;
	class Scene;
    class TextureManager;
}

class RunTimeScene;
class GameObject;
class MenuScene;
class GameScene;
enum class SceneID : std::uint8_t;

class SceneManager
{
public:

    SceneManager() = default;
    ~SceneManager() = default;

    void Init();

    // Ladda in scener fran editorn
    void LoadScene(SceneID aSceneID, Tga::SceneType aSceneType = Tga::SceneType::GameScene);

    SceneID ReturnSceneID(const char* aFilePath);
    std::shared_ptr<RunTimeScene> GetScene(SceneID aSceneID);
    bool IsLoaded(SceneID aSceneID);
    std::weak_ptr<GameObject> LoadAssetToScene(const std::shared_ptr<GameScene>& aGameScene, const Tga::StringId& anObjectID, Tga::Matrix4x4f aMatrix = {}, bool aMarkForAdd = false);

private:
    //Spara och cacha scener/scenobjekt

    //Creates a GameScene from a given scene from the editor or other source of engine scene
    std::shared_ptr<RunTimeScene> BuildRunTimeScene(Tga::Scene& aScene, Tga::SceneType aSceneType);
    std::shared_ptr<GameScene> BuildGameScene(Tga::Scene& aScene);
    std::shared_ptr<MenuScene> BuildMenuScene(Tga::Scene& aScene);
    static std::weak_ptr<GameObject> BuildGameObject(const PropertyApplier& aPropertyApplier, const std::shared_ptr<GameScene>& aGameScene, std::vector<Tga::ScenePropertyDefinition>& someObjectProperties, const Tga::Matrix4x4f& anObjectTransform, const Tga::StringId& aStringID, bool aMarkForAdd = false);
    static std::weak_ptr<GameObject> BuildGameObject(const PropertyApplier& aPropertyApplier, const std::shared_ptr<GameScene>& aGameScene, Tga::SceneObjectDefinitionManager& aSceneObjectDefinitionManager, const std::shared_ptr<Tga::SceneObject>& aSceneObject, bool aMarkForAdd = false);
    void BuildMenuObject(const std::shared_ptr<MenuScene>& aMenuScene, const std::vector<Tga::ScenePropertyDefinition>& someObjectProperties, const Tga::SceneObject& anObject);
    static void BuildTerrainObject(const PropertyApplier& aPropertyApplier, std::shared_ptr<GameScene> gameScene, const std::vector<Tga::ScenePropertyDefinition>& someObjectProperties, const Tga::Matrix4x4f& anObjectTransform);
    const char* ReturnSceneFilePath(SceneID aSceneID);
    void SetLightFromSceneSettings(Tga::Scene& aScene);

    struct LoadedScene
    {
        std::shared_ptr<Tga::Scene> engineScene;
        std::shared_ptr<RunTimeScene> runTimeScene;
        std::string path;
    };

    Tga::SceneObjectDefinitionManager mySceneObjectDefinitionManager;
    std::map<SceneID, LoadedScene> myLoadedScenes;
    std::string myCustomScenePath;
    
    physx::PxFoundation* myFoundation;
};