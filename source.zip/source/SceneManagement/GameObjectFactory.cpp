#include "stdafx.h"
#include "GameObjectFactory.h"

#include "PropertyApplier.h"
#include <Objects/Actors/Attacks/FollowingAttack.h>
#include <Objects/Actors/Attacks/ProjectileAttack.h>
#include <Objects/Actors/Player/Player.h>
#include <Objects/Actors/Attacks/Attack.h>
#include <Objects/StaticObjects/DestructibleObject.h>
#include <Objects/StaticObjects/PickupObject.h>
#include <Objects/StaticObjects/LevelEndTrigger.h>
#include <Objects/StaticObjects/TutorialTrigger.h>
#include <Objects/StaticObjects/ScriptedEventTrigger.h>
#include <Objects/Actors/Enemy/Enemies/Human.h>

GameObjectFactory::GameObjectFactory(const std::vector<Tga::ScenePropertyDefinition>& aObjectProperties) : myObjectProperties(aObjectProperties)
{
	myGameObjectRegistry =
	{
		// Register known game object types
		{
			Tga::Tag::Other, []
			{
				auto object = std::make_shared<GameObject>();
				return object;
			}
		},
		{
			Tga::Tag::Player, []
			{
				auto object = std::make_shared<Player>();
				return object;
			}
		},
		{
			Tga::Tag::Popcorn, []
			{
				auto object = std::make_shared<Human>();
				return object;
			}
		},
		{
			Tga::Tag::Attack, [&]() -> std::shared_ptr<GameObject>
			{
				if (auto property = PropertyApplier::FindProperty<Tga::AttackProp>(myObjectProperties))
				{
					switch (property->Get().type)
					{
						case Tga::AttackProp::AttackType::StaticAttack:
						{
							return std::make_shared<Attack>(property->Get());
						}
						case Tga::AttackProp::AttackType::FollowingAttack:
						{
							return std::make_shared<FollowingAttack>(property->Get());
						}
						case Tga::AttackProp::AttackType::ProjectileAttack:
						{
							return std::make_shared<ProjectileAttack>(property->Get());
						}
						default:
						{
							return std::make_shared<Attack>(property->Get());
						}
					}
				}
				//If object has no property:
				return std::make_shared<GameObject>();
			}
		},
		{
			Tga::Tag::Destructible, []
			{
				auto object = std::make_shared<DestructibleObject>();
				return object;
			}
		},
		{
			//Tga::Tag::Pickup, []
			//{
			//	auto object = std::make_shared<PickupObject>();
			//	return object;
			//}
			Tga::Tag::Pickup, [&]() -> std::shared_ptr<GameObject>
			{
				if (auto property = PropertyApplier::FindProperty<Tga::PickUpData>(myObjectProperties))
				{
					return std::make_shared<PickupObject>(property->Get());
				}
				//If object has no property:
				return std::make_shared<GameObject>();
			}
		},
		{
			Tga::Tag::Trigger, [&]() -> std::shared_ptr<GameObject>
			{
				if (auto property = PropertyApplier::FindProperty<Tga::TriggerData>(myObjectProperties))
				{
					switch (property->Get().type)
					{
						case Tga::TriggerType::LevelEndTrigger:
						{
							return std::make_shared<LevelEndTrigger>(property->Get());
						}
						case Tga::TriggerType::TutorialTrigger:
						{
							return std::make_shared<TutorialTrigger>(property->Get());
						}
						case Tga::TriggerType::ScriptedEventTrigger:
						{
							return std::make_shared<ScriptedEventTrigger>(property->Get());
						}
						default: {}
					}
				}
				//If object has no property:
				return std::make_shared<GameObject>();
			}
		},
	};
}

std::shared_ptr<GameObject> GameObjectFactory::CreateGameObject(const Tga::TagData& aTagData, bool& aIsPlayer)
{
    if (aTagData.tag == Tga::Tag::Player)
    {
        aIsPlayer = true;
    }

    if (myGameObjectRegistry.contains(aTagData.tag))
    {
        std::shared_ptr<GameObject> gameObject = myGameObjectRegistry[aTagData.tag]();
        gameObject->SetTag(aTagData.tag);
        return gameObject;
    }

    return std::make_shared<GameObject>();
}