﻿#include "stdafx.h"
#include "GameScene.h"

#include "SceneManager.h"
#include <tge/graphics/Camera.h>
#include <Objects/Actors/Player/Player.h>
#include <Utilities/Picking.h>
#include <Collisions/Narrow/Collider.h>
#include <Collisions/Broad/Bound.h>
#include <SceneManagement/SceneID.h>
#include <Graphics/SpawnedObject.h>
#include <Graphics/VFXManager.h>
#include <Objects/StaticObjects/DestructibleObject.h>
#include <Objects/StaticObjects/PickupObject.h>
#include <Input/InputMapper.h>
#include <tge/input/InputManager.h>

#include "States/HudMainMenu.h"
#include "States/HudMenu.h"
#include "States/StateID.h"
#include "States/StateStack.h"


void GameScene::Update(float aDeltaTime)
{

	if (Tga::ModelFactory::GetInstance().GetIsLoading())
	{
		return;
	}

	if (!myEventIsPlaying)
	{
		if (auto player = myPlayer.lock())
		{
			for (auto& gameObject : myGameObjects)
			{
				if (gameObject->GetMarkedForDelete())
				{
					continue;
				}
				gameObject->Update(aDeltaTime);

				if (gameObject->GetTag() == Tga::Tag::Trigger)
				{
					if (gameObject->GetCollider()->Collision(*player->GetCollider()))
					{
						gameObject->OnCollision(player->GetCollider());
					}
				}

				if (gameObject->GetMarkedForDelete())
				{
					myDeletedGameObjects.push_back(gameObject);
				}
			}
			for (auto& spawnedObject : mySpawnedObjects)
			{
				spawnedObject->Update(aDeltaTime);
			}
		
			if (auto p = myPlayer.lock())
			{
				auto& camTr = myCamera->GetTransform();

				const Tga::Vector3f camPos = p->GetThirdPersonCameraPos();
				camTr.SetPosition(camPos);

				const Tga::Vector3f pivot = p->GetPosition() + Tga::Vector3f(0.f, 120.f, 0.f);
				const Tga::Vector3f toTarget = (pivot - camPos).GetNormalized();

				const float yaw = std::atan2(toTarget.x, toTarget.z);
				const float pitch = -std::asin(toTarget.y);

				constexpr float RadToDeg = 57.2957795f;
				camTr.SetRotation({ pitch * RadToDeg, yaw * RadToDeg, 0.f });
			}
		}

		if (InputMapper::GetInstance().GetInputManager()->IsKeyPressed('B'))
		{
			myScriptedEventType = Tga::ScriptedEventType::Ending;
			myEventIsPlaying = true;
		}
	}

	{
		constexpr auto removalPredicate = [](const std::shared_ptr<GameObject>& aGameObject) { return aGameObject->GetMarkedForDelete(); };
		auto expiredObjects = std::ranges::remove_if(myGameObjects, removalPredicate);
		myGameObjects.erase(expiredObjects.begin(), expiredObjects.end());
	}
	{
		constexpr auto removalPredicate = [](const std::shared_ptr<SpawnedObject>& aSpawnedObject) { return aSpawnedObject->IsExpired() || aSpawnedObject->GetIsExpired(); };
		auto expiredSpawnedObjs = std::ranges::remove_if(mySpawnedObjects, removalPredicate);
		mySpawnedObjects.erase(expiredSpawnedObjs.begin(), expiredSpawnedObjs.end());
	}
	
	myHUD->Update(aDeltaTime);
	for (auto& object : myGameObjectsToAdd)
	{
		myGameObjects.push_back(object);
	}

	myGameObjectsToAdd.clear();
}

void GameScene::OnEnter(SceneManager& aSceneManager, StateStack& aStateStack)
{
	aSceneManager;
	aStateStack;

	if (auto* im = InputMapper::GetInstance().GetInputManager())
	{
		im->ShowMouse();
		im->ReleaseMouse();   // viktigt: släpp clip om den låg kvar
	}



	Picking& picking = *Picking::GetInstance();

	if (!myIsInitialized)
	{
#ifndef _RETAIL
		if (mySceneID == SceneID::AssetGym)
		{
			VFXManager::GetInstance()->DebugSpawnAllVfx();
		}
#endif
		myCamera = std::make_shared<Tga::Camera>();
		myCamera->Init(Tga::Camera::ProjectionType::Perspective);
		if (!myHUD)
			myHUD = std::make_shared<HUD>();

		myHUD->Init(&aSceneManager, &aStateStack, *myCamera);

		// ✅ Koppla HUD till dina HUD-states (cache:ade i StateStack)
		if (auto* hm = dynamic_cast<HudMenu*>(aStateStack.GetState(StateID::HUD)))
		{
			hm->SetHUD(myHUD.get());
		}

		myIsInitialized = true;
	}
	myCamera->RegisterInput();
	if (const auto player = myPlayer.lock())
	{
		player->RegisterInput();
	}
	picking.SwitchScene(this);
	picking.Init(myCamera);

	myHUD->RegisterInput();      
	myHUD->SubscribeToEvents();
	myHUD->SetSceneCamera(&*myCamera);
	// Updates HUD to player's ability if needed at start of scene

	if (shouldReset)
	{
		if (myPlayer.lock())
		{
			myPlayer.lock()->ResetPlayer(mySceneID);
		}
		ResetDeletedObjects();
		shouldReset = false;
	}
}

void GameScene::OnExit()
{
	if (!myPlayer.expired())
	{
		myPlayer.lock()->UnregisterInput();
	}

	if (auto* im = InputMapper::GetInstance().GetInputManager())
	{
		im->ShowMouse();
		im->ReleaseMouse();
	}

	myHUD->UnregisterInput();   
	myHUD->UnsubscribeFromEvents();

	if (myCamera)
	{
	myCamera->UnregisterInput();
	}
}

void GameScene::ResetDeletedObjects()
{
	for (auto& object : myDeletedGameObjects)
	{
		object->ResetMe();
		myGameObjects.push_back(object);
	}

	myDeletedGameObjects.clear();
}

void GameScene::ReceiveEvent(const Message& aMessage)
{
	aMessage;
}

void GameScene::AddGameObject(const std::shared_ptr<GameObject>& aGameObject, bool aMarkForAdd)
{
	if (aMarkForAdd)
	{
		std::scoped_lock guard(myGameObjectsToAddMutex);
		myGameObjectsToAdd.push_back(aGameObject);
	}
	else
	{
		std::scoped_lock guard(myGameObjectsMutex);
		myGameObjects.push_back(aGameObject);
	}
}

void GameScene::AddStaticObject(const std::shared_ptr<GameObject>& aStaticGameObject)
{
	std::scoped_lock guard(myStaticObjectsMutex);
	myStaticObjects.push_back(aStaticGameObject);
}

void GameScene::RemoveStaticObjectByTag(const Tga::Tag aTag)
{
	std::vector<std::vector<std::weak_ptr<GameObject>>::iterator> iterators;

	for (auto it = myStaticObjects.begin(); it != myStaticObjects.end(); ++it)
	{
		auto obj = it->lock();
		if (obj && obj->GetTag() == aTag)
		{
			iterators.push_back(it);
		}
	}

	if (!iterators.empty())
	{
		for (auto it = iterators.rbegin(); it != iterators.rend(); ++it)
		{
			myStaticObjects.erase(*it);
		}

		iterators.clear();
	}
}

void GameScene::SetAllObjectsWithTagToMarkForDelete(const Tga::Tag aTag)
{
	for (auto& object : myGameObjects)
	{
		if (object->GetTag() == aTag)
		{
			object->MarkForDelete();
		}
	}
}

void GameScene::AddSpawnedObject(const std::shared_ptr<SpawnedObject>& aSpawnedObject)
{
	std::scoped_lock guard(mySpawnedObjsMutex);
	mySpawnedObjects.push_back(aSpawnedObject);
}

void GameScene::AddDecal(const std::shared_ptr<NCE::Decal>& aDecal)
{
	std::scoped_lock guard(myDecalsMutex);
	myDecals.push_back(aDecal);
}

void GameScene::AddPointLight(const std::shared_ptr<Tga::PointLight>& aPointLight)
{
	std::scoped_lock guard(myLightsMutex);
	myPointLights.push_back(aPointLight);
}

void GameScene::AddDirectionalLight(const std::shared_ptr<Tga::DirectionalLight>& aDirectionalLight)
{
	std::scoped_lock guard(myLightsMutex);
	myDirectionalLights.push_back(aDirectionalLight);
}

void GameScene::SetAmbientLight(const std::shared_ptr<Tga::AmbientLight>& anAmbientLight)
{
	std::scoped_lock guard(myLightsMutex);
	myAmbientLight = anAmbientLight;
}

const std::vector<std::shared_ptr<GameObject>>& GameScene::GetGameObjects() const
{
	return myGameObjects;
}

const std::vector<std::shared_ptr<Tga::PointLight>>& GameScene::GetPointLights() const
{
	return myPointLights;
}

std::vector<std::shared_ptr<Tga::PointLight>>& GameScene::GetPointLights()
{
	return myPointLights;
}

const std::vector<std::shared_ptr<Tga::DirectionalLight>>& GameScene::GetDirectionalLights() const
{
	return myDirectionalLights;
}

std::vector<std::shared_ptr<SpawnedObject>>& GameScene::GetSpawnedObjects()
{
	return mySpawnedObjects;
}

std::vector<std::shared_ptr<NCE::Decal>>& GameScene::GetDecals()
{
	return myDecals;
}

void GameScene::AddPlayer(const std::shared_ptr<Player>& aPlayer)
{
	myPlayer = aPlayer;
}

const std::weak_ptr<Player>& GameScene::GetPlayer() const
{
	return myPlayer;
}

void GameScene::AddNavmesh(const std::shared_ptr<Navmesh>& aNavmesh)
{
	myNavmesh = aNavmesh;
}

const std::shared_ptr<Navmesh>& GameScene::GetNavmesh() const
{
	return myNavmesh;
}

std::shared_ptr<Navmesh>& GameScene::GetNavmesh()
{
	return myNavmesh;
}

std::vector<std::weak_ptr<Actor>> GameScene::GetActorsInBounds(const std::shared_ptr<Bound>& aBound) const
{
	std::vector<std::weak_ptr<Actor>> culledGameObjects;
	for (auto& gameObject : myGameObjects)
	{
		//Check has collider and is actor, then if bounds are overlapping 
		if (auto& collider = gameObject->GetCollider())
		{
			if (std::shared_ptr<Actor> actor = std::dynamic_pointer_cast<Actor, GameObject>(gameObject))
			{
				if (aBound->CheckOverlap(*collider->GetBounds()))
				{
					culledGameObjects.push_back(actor);
				}
			}
		}
	}

	return culledGameObjects;
}

std::vector<std::weak_ptr<Actor>> GameScene::GetActors() const
{
	std::vector<std::weak_ptr<Actor>> actors;
	for (auto& gameObject : myGameObjects)
	{
		if (std::shared_ptr<Actor> actor = std::dynamic_pointer_cast<Actor, GameObject>(gameObject))
		{
			actors.push_back(actor);
		}
	}

	return actors;
}

std::vector<std::weak_ptr<GameObject>> GameScene::GetStaticObjectsInBounds(const std::shared_ptr<Bound>& aBound) const
{
	std::vector<std::weak_ptr<GameObject>> culledGameObjects;
	for (auto& lockedGameObject : myStaticObjects)
	{
		//Check has collider and is GameObject, then if bounds are overlapping 
		if (std::shared_ptr<GameObject> gameObject = lockedGameObject.lock())
		{
			if (auto& collider = gameObject->GetCollider())
			{
				if (aBound->CheckOverlap(*collider->GetBounds()))
				{
					culledGameObjects.push_back(lockedGameObject);
				}
			}
		}
	}

	return culledGameObjects;
}

Tga::Vector3f GameScene::CheckStaticCollisions(const std::shared_ptr<Collider>& aCollider) const
{
	std::vector<std::weak_ptr<GameObject>> staticObjects = GetStaticObjectsInBounds(aCollider->GetBounds());

	Tga::Vector3f totalSeparation{ 0.f };
	for (std::weak_ptr lockedObject : staticObjects)
	{
		if (std::shared_ptr staticObject = lockedObject.lock())
		{
			if (aCollider->Collision(*staticObject->GetCollider()))
			{
				totalSeparation += aCollider->SeparateCollision(*staticObject->GetCollider());
			}
		}
	}

	return totalSeparation;
}

void GameScene::RenderHUD()
{
	myHUD->Render();

}

void GameScene::RenderHUDGrid(bool aShowGrid)
{
	if (myHUD)
	{
		myHUD->RenderEditGrid(aShowGrid);
	}
}



void GameScene::RemoveGameObject(std::shared_ptr<GameObject>& anObjToRemove)
{
	auto& objs = myGameObjects;

	for (auto it = objs.begin(); it != objs.end(); )
	{
		if (it->get() == anObjToRemove.get())
		{
			it = objs.erase(it);

			return;
		}
		else
		{
			++it;
		}
	}
}

std::vector<std::weak_ptr<DestructibleObject>> GameScene::GetDestructibleObjectsInBounds(const std::shared_ptr<Bound>& aBound) const
{
	std::vector<std::weak_ptr<DestructibleObject>> destructibleObjects;
	for (auto& gameObject : myGameObjects)
	{
		//Check has collider and is actor, then if bounds are overlapping 
		if (auto& collider = gameObject->GetCollider())
		{
			if (std::shared_ptr<DestructibleObject> destructible = std::dynamic_pointer_cast<DestructibleObject, GameObject>(gameObject))
			{
				if (aBound->CheckOverlap(*collider->GetBounds()))
				{
					destructibleObjects.push_back(destructible);
				}
			}
		}
	}

	return destructibleObjects;
}
std::vector<std::weak_ptr<PickupObject>> GameScene::GetPickupObjectsInBounds(const std::shared_ptr<Bound>& aBound) const
{
	std::vector<std::weak_ptr<PickupObject>> pickupObjects;
	for (auto& gameObject : myGameObjects)
	{
		//Check has collider and is actor, then if bounds are overlapping 
		if (auto& collider = gameObject->GetCollider())
		{
			if (std::shared_ptr<PickupObject> pickup = std::dynamic_pointer_cast<PickupObject, GameObject>(gameObject))
			{
				if (aBound->CheckOverlap(*collider->GetBounds()))
				{
					pickupObjects.push_back(pickup);
				}
			}
		}
	}

	return pickupObjects;
}