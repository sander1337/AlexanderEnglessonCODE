#include "stdafx.h"
#include "SceneManager.h"

#include "GameObjectFactory.h"
#include "GameScene.h"
#include "MenuScene.h"
#include "PropertyApplier.h"
#include "../Graphics/VFXManager.h"
#include "../Utilities/ConstantIdentifiers.h"
#include <tge/scene/Scene.h>
#include <tge/scene/ScenePropertyTypes.h>
#include <tge/scene/SceneSerialize.h>
#include <tge/script/CopyOnWriteWrapper.h>
#include <tge/settings/settings.h>
#include <tge/texture/TextureManager.h>
#include "../Objects/GameObject.h"
#include "../Objects/Actors/Actor.h"
#include <tge/navmesh/navmesh.h>

#include <fstream>
#include <filesystem>
#include <ranges>

#include "../source/SceneManagement/SceneID.h"
#include "../UI/Button.h"
#include "../UI/ToolTip.h"

#include <thread>
#include <tge/graphics/DirectionalLight.h>
#include <tge/graphics/PointLight.h>
#include <tge/script/ScriptManager.h>
#include <tge/scene/SceneObjectDefinitionManager.h>
#include <mutex>
#include "Render/RenderResources.h"
#include "GameWorld.h"
#include "Render/RenderManager.h"
#include "States/ActionBars/ActionBar.h"

using namespace Tga;
using namespace physx;

void SceneManager::Init()
{
	mySceneObjectDefinitionManager.Init(Settings::GameAssetRoot().string());

	myFoundation = PxCreateFoundation(PX_PHYSICS_VERSION, globalDefaultAllocatorCallback, globalDefaultErrorCallback);
	if (!myFoundation)
	{
		throw std::runtime_error("PxCreateFoundation failed!");
	}
}

void SceneManager::LoadScene(SceneID aSceneID, SceneType aSceneType)
{
	const char* filePath = nullptr;

	if (aSceneID == SceneID::Custom)
	{
		filePath = myCustomScenePath.c_str();
	}
	else
	{
		filePath = ReturnSceneFilePath(aSceneID);
	}
	if (!filePath)
	{
		// TODO: ADD ERROR HANDLING
		std::cout << "Could not Load Scene with Scene ID: " << static_cast<int>(aSceneID) << "\n";
		return;
	}

	// Create engine scene representation and load that scene

	std::shared_ptr<Scene> scene = std::make_shared<Scene>();

	Tga::LoadScene(filePath, *scene);

	// Create game scene representation and build that scene

	{
		std::shared_ptr<RunTimeScene> runTimeScene = BuildRunTimeScene(*scene, aSceneType);
		runTimeScene->SetSceneID(aSceneID);
		//Add loaded scene containing both representations, in myScenes.

		LoadedScene& slot = myLoadedScenes[aSceneID];
		slot.path = filePath;
		slot.engineScene = std::move(scene);
		slot.runTimeScene = std::move(runTimeScene);
	}

	if (!IsLoaded(SceneID::HUD))
	{
		LoadScene(SceneID::HUD, SceneType::MenuScene);

	}
}

std::shared_ptr<RunTimeScene> SceneManager::GetScene(SceneID aSceneID)
{
	auto it = myLoadedScenes.find(aSceneID);

	if (it != myLoadedScenes.end())
	{
		return myLoadedScenes.at(aSceneID).runTimeScene;
	}

	return nullptr;
}

bool SceneManager::IsLoaded(SceneID aSceneID)
{
	auto it = myLoadedScenes.find(aSceneID);

	if (it != myLoadedScenes.end())
	{
		return true;
	}

	return false;
}

std::weak_ptr<GameObject> SceneManager::LoadAssetToScene(const std::shared_ptr<GameScene>& aGameScene, const Tga::StringId& anObjectID, Tga::Matrix4x4f aMatrix, bool aMarkForAdd)
{
	if (mySceneObjectDefinitionManager.Get(anObjectID) == nullptr)
	{
		std::cerr << "Could not find object definition for ID '" << anObjectID.GetString() << "'\n";
		return {};
	}

	auto object = std::make_shared<SceneObject>();
	object->SetSceneObjectDefintionName(anObjectID);

	std::vector<ScenePropertyDefinition> objectProperties;
	object->CalculateCombinedPropertySet(mySceneObjectDefinitionManager, objectProperties);
	return BuildGameObject({}, aGameScene, objectProperties, aMatrix, anObjectID, aMarkForAdd);
}

std::shared_ptr<RunTimeScene> SceneManager::BuildRunTimeScene(Scene& aScene, SceneType aSceneType)
{
	switch (aSceneType)
	{
	case SceneType::MenuScene:
	{
		return BuildMenuScene(aScene);
	}
	case SceneType::GameScene:
	{
		return BuildGameScene(aScene);
	}
	default:
	{
		return BuildGameScene(aScene);
	}
	}
}

namespace
{
	std::mutex locCalculateCombinedPropertySetMutex;
}

std::shared_ptr<GameScene> SceneManager::BuildGameScene(Tga::Scene& aScene)
{
	bool useRefinedTerrain = aScene.GetUseRefinedTerrain();
	PropertyApplier propertyApplier;

#ifdef _RETAIL
	useRefinedTerrain = true;
#endif
	// Create new GameScene to act as a wrapper for Scene and to not mix with engine functionality
	std::shared_ptr<GameScene> gameScene = std::make_shared<GameScene>();
	{
		// PIXScopedEvent(PIX_COLOR(27, 227, 57), L"BuildSceneObjects");
		constexpr std::uint8_t threadAmount = 8;

		const size_t threadLoadSize = aScene.GetSceneObjects().size() / threadAmount;

		std::array<std::vector<std::shared_ptr<SceneObject>>, threadAmount> objectLists;
		for (auto& objectList : objectLists)
		{
			objectList.reserve(threadLoadSize);
		}

		// Split directory into multiple vectors
		unsigned nextThreadIndex = 0;
		for (const auto& sceneObject : aScene.GetSceneObjects() | std::views::values)
		{
			objectLists[nextThreadIndex].emplace_back(sceneObject);
			nextThreadIndex = nextThreadIndex + 1 < threadAmount ? nextThreadIndex + 1 : 0;
		}
		auto threadLogic = [&](const std::shared_ptr<GameScene>& aGameScene, const std::vector<std::shared_ptr<SceneObject>>& someObjects, Tga::SceneObjectDefinitionManager& aSceneObjectDefinitionManager, PropertyApplier& aPropertyApplier)
			{
				std::vector<ScenePropertyDefinition> objectPropertyBuffer;
				for (const auto& sceneObject : someObjects)
				{
					bool isPartOfTerrain = false;
					{
						std::scoped_lock guard(locCalculateCombinedPropertySetMutex);
						objectPropertyBuffer.clear();
						sceneObject->CalculateCombinedPropertySet(aSceneObjectDefinitionManager, objectPropertyBuffer, &isPartOfTerrain);
					}
					if (!useRefinedTerrain || !isPartOfTerrain)
					{
						// PIXScopedEvent(PIX_COLOR(244, 3, 252), L"Object building");
						//BuildGameObject(aPropertyApplier, aGameScene, objectPropertyBuffer, sceneObject->GetTransform(), sceneObject->GetSceneObjectDefinitionName());
						BuildGameObject(aPropertyApplier, aGameScene, aSceneObjectDefinitionManager, sceneObject);
					}
				}
			};

		std::vector<std::thread> threads;
		for (const auto& objectList : objectLists)
		{
			threads.emplace_back(threadLogic, std::ref(gameScene), objectList, std::ref(mySceneObjectDefinitionManager), std::ref(propertyApplier));
		}

		// Wait for all threads to finish
		for (auto& thread : threads)
		{
			thread.join();
		}
	}

	// Load refined terrain meshes
	if (useRefinedTerrain)
	{
		std::vector<ScenePropertyDefinition> objectPropertyBuffer;
		for (const auto& terrainObject : aScene.GetTerrainObjects() | std::views::values)
		{
			objectPropertyBuffer.clear();
			terrainObject->CalculateCombinedPropertySet(mySceneObjectDefinitionManager, objectPropertyBuffer);

			BuildTerrainObject(propertyApplier, gameScene, objectPropertyBuffer, terrainObject->GetTransform());
		}
	}

	// Adding Navmesh to GameScene
	Tga::StringId pathId = Tga::StringRegistry::RegisterOrGetString(aScene.GetPath());
	std::string finalPath = Navmesh::GetNavmeshFilePath(pathId).GetString();
	std::fstream meshLoader;
	meshLoader.open(finalPath, std::ios_base::in);
	if (meshLoader.is_open())
	{
		std::shared_ptr<Navmesh> navmesh = std::make_shared<Navmesh>();
		navmesh->Init(finalPath.c_str());
		gameScene->AddNavmesh(navmesh);
	}
	else
	{
		std::cout << "Failed to open and load navmesh from path " << finalPath << std::endl;
	}

	// TODO : Light from Scene Settings
	SetLightFromSceneSettings(aScene);
	// end light

	return gameScene;
}

std::shared_ptr<MenuScene> SceneManager::BuildMenuScene(Tga::Scene& aScene)
{
	// Create new MenuScene to act as a wrapper for Scene and to not mix with engine functionality

	std::shared_ptr<MenuScene> menuScene = std::make_shared<MenuScene>();

	std::vector<ScenePropertyDefinition> objectPropertyBuffer;
	for (const auto& sceneObject : aScene.GetSceneObjects() | std::views::values)
	{
		objectPropertyBuffer.clear();
		sceneObject->CalculateCombinedPropertySet(mySceneObjectDefinitionManager, objectPropertyBuffer);

		BuildMenuObject(menuScene, objectPropertyBuffer, *sceneObject);
	}

	return menuScene;
}

std::weak_ptr<GameObject> SceneManager::BuildGameObject(const PropertyApplier& aPropertyApplier, const std::shared_ptr<GameScene>& aGameScene, std::vector<Tga::ScenePropertyDefinition>& someObjectProperties, const Matrix4x4f& anObjectTransform, const StringId& aStringID, bool aMarkForAdd)
{
	bool isPlayer = false;
	std::shared_ptr<SpawnedObject> spawnedObject = nullptr;

	TagData objectTagData = { Tag::Other }; // If no tag was found, create an "other" GameObject (regular GameObject)

	// Find tag in ObjectProperties
	for (auto& property : someObjectProperties)
	{
		if (property.type == GetPropertyType<CopyOnWriteWrapper<TagData>>())
		{
			objectTagData = property.value.Get<CopyOnWriteWrapper<TagData>>()->Get();
			break;
		}
	}

	if (objectTagData.tag == Tag::Light)
	{
		//PIXScopedEvent(PIX_COLOR(75, 25, 133), L"Create light");
		aPropertyApplier.BuildAndAddLightObject(someObjectProperties, anObjectTransform, aGameScene);
	}

	// Create GameObject from tag
	std::shared_ptr<GameObject> gameObject;
	{
		//PIXScopedEvent(PIX_COLOR(66, 245, 185), L"Create GameObject");
		GameObjectFactory gameObjectFactory(someObjectProperties);
		gameObject = gameObjectFactory.CreateGameObject(objectTagData, isPlayer);
	}

	if (objectTagData.tag == Tag::VFX)
	{
		//todo: This can be moved outside of "BuildGameObject" function later 
		//PIXScopedEvent(PIX_COLOR(245, 170, 66), L"Cache VFX");
		VFXManager::GetInstance()->CacheVfx(someObjectProperties, aStringID, aPropertyApplier.GetTextureManager());
		return {};
	}

	if (objectTagData.tag == Tag::StaticObject || objectTagData.tag == Tag::StaticCollider)
	{
		gameObject->SetTag(objectTagData.tag);
		aGameScene->AddStaticObject(gameObject);
	}

	if (objectTagData.tag == Tag::Water)
	{
		gameObject->SetTag(objectTagData.tag);
	}

	{
		//PIXScopedEvent(PIX_COLOR(200, 200, 200), L"Apply properties"); // Apply all properties
		aPropertyApplier.ApplyGeneralProperties(gameObject, someObjectProperties, anObjectTransform);
	}

	//Todo remove this workaround if possible
	Vector3f position;
	Quaternionf rotation;
	Vector3f scale;
	anObjectTransform.DecomposeMatrix(position, rotation, scale);
	gameObject->SetScale(scale);

	gameObject->Init();

	if (auto actor = std::dynamic_pointer_cast<Actor, GameObject>(gameObject))
	{
		actor->ApplyProps(someObjectProperties);
	}
	if (isPlayer)
	{
		aGameScene->AddPlayer(std::reinterpret_pointer_cast<Player>(gameObject));
	}

	aGameScene->AddGameObject(gameObject, aMarkForAdd);
	return gameObject;
}

std::weak_ptr<GameObject> SceneManager::BuildGameObject(const PropertyApplier& aPropertyApplier, const std::shared_ptr<GameScene>& aGameScene, Tga::SceneObjectDefinitionManager& aSceneObjectDefinitionManager, const std::shared_ptr<Tga::SceneObject>& aSceneObject, bool aMarkForAdd)
{
	bool isPlayer = false;
	std::shared_ptr<SpawnedObject> spawnedObject = nullptr;

	TagData objectTagData = { Tag::Other }; // If no tag was found, create an "other" GameObject (regular GameObject)

	std::vector<ScenePropertyDefinition> objectPropertyBuffer;
	aSceneObject->CalculateCombinedPropertySet(aSceneObjectDefinitionManager, objectPropertyBuffer);

	Tga::Matrix4x4f objTransform = aSceneObject->GetTransform();

	// Find tag in ObjectProperties
	for (auto& property : objectPropertyBuffer)
	{
		if (property.type == GetPropertyType<CopyOnWriteWrapper<TagData>>())
		{
			objectTagData = property.value.Get<CopyOnWriteWrapper<TagData>>()->Get();
			break;
		}
	}

	if (objectTagData.tag == Tag::Light)
	{
		//PIXScopedEvent(PIX_COLOR(75, 25, 133), L"Create light");
		aPropertyApplier.BuildAndAddLightObject(objectPropertyBuffer, objTransform, aGameScene);
	}

	if (objectTagData.tag == Tag::Decal)
	{
		aPropertyApplier.BuildAndAddDecal(objectPropertyBuffer, objTransform, aGameScene);
		return {};
	}

	// Create GameObject from tag
	std::shared_ptr<GameObject> gameObject;
	{
		//PIXScopedEvent(PIX_COLOR(66, 245, 185), L"Create GameObject");
		GameObjectFactory gameObjectFactory(objectPropertyBuffer);
		gameObject = gameObjectFactory.CreateGameObject(objectTagData, isPlayer);
	}

	if (objectTagData.tag == Tag::VFX)
	{
		//todo: This can be moved outside of "BuildGameObject" function later 
		//PIXScopedEvent(PIX_COLOR(245, 170, 66), L"Cache VFX");
		VFXManager::GetInstance()->CacheVfx(objectPropertyBuffer, aSceneObject->GetSceneObjectDefinitionName(), aPropertyApplier.GetTextureManager());
		return {};
	}

	if (objectTagData.tag == Tag::StaticObject || objectTagData.tag == Tag::StaticCollider)
	{
		gameObject->SetTag(objectTagData.tag);
		aGameScene->AddStaticObject(gameObject);
	}

	if (objectTagData.tag == Tag::Water)
	{
		gameObject->SetTag(objectTagData.tag);
	}

	if (objectTagData.tag == Tag::ActionBar)
	{
		gameObject->SetTag(objectTagData.tag);
	}

	{
		//PIXScopedEvent(PIX_COLOR(200, 200, 200), L"Apply properties"); // Apply all properties
		aPropertyApplier.ApplyGeneralProperties(gameObject, objectPropertyBuffer, objTransform);
	}

	std::vector<StringId> scripts;
	SceneObjectDefinition* objDef = aSceneObjectDefinitionManager.Get(aSceneObject->GetSceneObjectDefinitionName());

	if (!objDef)
	{
		std::cerr
			<< "[SceneManager] Missing SceneObjectDefinition for object '"
			<< aSceneObject->GetName() << "' def='"
			<< aSceneObject->GetSceneObjectDefinitionName().GetString()
			<< "'\n";

		// Inget script -> forts�tt utan att krascha
	}
	else
	{
		scripts = objDef->GetScripts();
		if (!scripts.empty())
			gameObject->SetScript(scripts.back());
	}

	//Todo remove this workaround if possible
	Vector3f position;
	Quaternionf rotation;
	Vector3f scale;
	objTransform.DecomposeMatrix(position, rotation, scale);
	gameObject->SetScale(scale);

	gameObject->Init();

	if (auto actor = std::dynamic_pointer_cast<Actor, GameObject>(gameObject))
	{
		actor->ApplyProps(objectPropertyBuffer);
	}
	if (isPlayer)
	{
		aGameScene->AddPlayer(std::reinterpret_pointer_cast<Player>(gameObject));
	}

	aGameScene->AddGameObject(gameObject, aMarkForAdd);
	return gameObject;
}

void SceneManager::BuildMenuObject(const std::shared_ptr<MenuScene>& aMenuScene, const std::vector<Tga::ScenePropertyDefinition>& someObjectProperties, const Tga::SceneObject& anObject)
{
	Tag tag = Tag::Count;
	SceneSprite sprite;
	GameSpriteData flipbookData;
	ButtonType buttonType = ButtonType::Count;
	HUDType hudType = HUDType::Count;
	ActionBarData ab{};
	bool hasActionBarData = false;

	for (auto& property : someObjectProperties)
	{
		if (property.type == GetPropertyType<CopyOnWriteWrapper<TagData>>())
		{
			tag = property.value.Get<CopyOnWriteWrapper<TagData>>()->Get().tag;
		}
		else if (property.type == GetPropertyType<CopyOnWriteWrapper<ButtonData>>())
		{
			buttonType = property.value.Get<CopyOnWriteWrapper<ButtonData>>()->Get().buttonType;
		}
		else if (property.type == GetPropertyType<CopyOnWriteWrapper<HUDData>>())
		{
			hudType = property.value.Get<CopyOnWriteWrapper<HUDData>>()->Get().hudType;
		}
		else if (property.type == GetPropertyType<CopyOnWriteWrapper<SceneSprite>>())
		{
			sprite = property.value.Get<CopyOnWriteWrapper<SceneSprite>>()->Get();
		}
		else if (property.type == GetPropertyType<CopyOnWriteWrapper<GameSpriteData>>())
		{
			flipbookData = property.value.Get<CopyOnWriteWrapper<GameSpriteData>>()->Get();
		}
		else if (property.type == GetPropertyType<CopyOnWriteWrapper<ActionBarData>>())
		{
			ab = property.value.Get<CopyOnWriteWrapper<ActionBarData>>()->Get();
			hasActionBarData = true;
		}
	}

	// Do tag-specific things
	if (tag == Tag::Button)
	{
		// Change to Button factory
		if (buttonType == ButtonType::NewGame)
		{
			std::shared_ptr<NewGameButton> newGameButton = std::make_shared<NewGameButton>();
			newGameButton->Init(anObject, someObjectProperties);
			aMenuScene->AddButton(buttonType, newGameButton);
		}
		else if (buttonType == ButtonType::LevelSelect)
		{
			std::shared_ptr<LevelSelectButton> levelSelectButton = std::make_shared<LevelSelectButton>();
			levelSelectButton->Init(anObject, someObjectProperties);
			aMenuScene->AddButton(buttonType, levelSelectButton);
		}
		else if (buttonType == ButtonType::Options)
		{
			std::shared_ptr<OptionsButton> optionsButton = std::make_shared<OptionsButton>();
			optionsButton->Init(anObject, someObjectProperties);
			aMenuScene->AddButton(buttonType, optionsButton);
		}
		else if (buttonType == ButtonType::VolumeMaster || buttonType == ButtonType::VolumeSFX || buttonType == ButtonType::VolumeMusic || buttonType == ButtonType::VolumeAmbience)
		{
			std::shared_ptr<VolumeButton> volumeButton = std::make_shared<VolumeButton>();
			volumeButton->Init(anObject, someObjectProperties);
			aMenuScene->AddButton(buttonType, volumeButton);
		}
		else if (buttonType == ButtonType::FullScreen)
		{
			std::shared_ptr<FullScreenButton> fullScreenButton = std::make_shared<FullScreenButton>();
			fullScreenButton->Init(anObject, someObjectProperties);
			aMenuScene->AddButton(buttonType, fullScreenButton);
		}
		else if (buttonType == ButtonType::Credits)
		{
			std::shared_ptr<CreditsButton> creditsButton = std::make_shared<CreditsButton>();
			creditsButton->Init(anObject, someObjectProperties);
			aMenuScene->AddButton(buttonType, creditsButton);
		}
		else if (buttonType == ButtonType::Back)
		{
			std::shared_ptr<BackButton> backButton = std::make_shared<BackButton>();
			backButton->Init(anObject, someObjectProperties);
			aMenuScene->AddButton(buttonType, backButton);
		}
		else if (buttonType == ButtonType::Back2x)
		{
			std::shared_ptr<BackButton2x> backButton2x = std::make_shared<BackButton2x>();
			backButton2x->Init(anObject, someObjectProperties);
			aMenuScene->AddButton(buttonType, backButton2x);
		}
		else if (buttonType == ButtonType::MainMenu)
		{
			std::shared_ptr<MainMenuButton> mainMenuButton = std::make_shared<MainMenuButton>();
			mainMenuButton->Init(anObject, someObjectProperties);
			aMenuScene->AddButton(buttonType, mainMenuButton);
		}
		else if (buttonType == ButtonType::Quit)
		{
			std::shared_ptr<QuitButton> quitButton = std::make_shared<QuitButton>();
			quitButton->Init(anObject, someObjectProperties);
			aMenuScene->AddButton(buttonType, quitButton);
		}
		else if (buttonType == ButtonType::EditHUD)
		{
			std::shared_ptr<EditHUDButton> editHudButton = std::make_shared<EditHUDButton>();
			editHudButton->Init(anObject, someObjectProperties);
			aMenuScene->AddButton(buttonType, editHudButton);
		}
		else if (buttonType == ButtonType::Save)
		{
			std::shared_ptr<Save> SaveButton = std::make_shared<Save>();
			SaveButton->Init(anObject, someObjectProperties);
			aMenuScene->AddButton(buttonType, SaveButton);
		}
		else if (buttonType == ButtonType::MoveAllButtonsInMySize)
		{
			std::shared_ptr<MoveAllButtonsInMySize> MoveAllButton = std::make_shared<MoveAllButtonsInMySize>();
			MoveAllButton->Init(anObject, someObjectProperties);
			aMenuScene->AddButton(buttonType, MoveAllButton);
		}
		else if (buttonType == ButtonType::NextLine)
		{
			std::shared_ptr<NextLineButton> nextLineButton = std::make_shared<NextLineButton>();
			nextLineButton->Init(anObject, someObjectProperties);
			aMenuScene->AddButton(buttonType, nextLineButton);
		}
		else if (buttonType == ButtonType::Level2)
		{
			std::shared_ptr<Level2Button> level2Button = std::make_shared<Level2Button>();
			level2Button->Init(anObject, someObjectProperties);
			aMenuScene->AddButton(buttonType, level2Button);
		}
	}
	else if (tag == Tag::HUD && hudType != HUDType::Count)
	{
		// Change to HUD factory
		switch (hudType)
		{
		case HUDType::AbilitySlash:
		{
			buttonType = ButtonType::AbilitySlash;
			break;
		}
		case HUDType::AbilityArrow:
		{
			buttonType = ButtonType::AbilityArrow;
			break;
		}
		case HUDType::AbilityHeal:
		{
			buttonType = ButtonType::AbilityHeal;
			break;
		}
		case HUDType::AbilityDash:
		{
			buttonType = ButtonType::AbilityDash;
			break;
		}
		case HUDType::AbilityRangedAOE:
		{
			buttonType = ButtonType::AbilityRangedAOE;
			break;
		}
		case HUDType::AbilityAura:
		{
			buttonType = ButtonType::AbilityAura;
			break;
		}
		/*case HUDType::Health:
		{
			buttonType = ButtonType::Health;
			break;
		}
		case HUDType::Ammo:
		{
			buttonType = ButtonType::Ammo;
			break;
		}
		case HUDType::Reload:
		{
			buttonType = ButtonType::Reload;
			break;
		}
		case HUDType::Points:
		{
			buttonType = ButtonType::Points;
			break;
		}
		case HUDType::Combo:
		{
			buttonType = ButtonType::Combo;
			break;
		}*/
		case HUDType::Info:
		{
			buttonType = ButtonType::Info;
			break;
		}
		}

		if (hudType == HUDType::Info)
		{
			std::shared_ptr<ValueHUDButton> orbHUDButton = std::make_shared<ValueHUDButton>();
			orbHUDButton->Init(anObject, someObjectProperties);
			aMenuScene->AddButton(buttonType, orbHUDButton);
		}
		else
		{
			std::shared_ptr<AbilityHUDButton> abilityHUDButton = std::make_shared<AbilityHUDButton>();
			abilityHUDButton->Init(anObject, someObjectProperties);
			aMenuScene->AddButton(buttonType, abilityHUDButton);
		}
	}
	else if (tag == Tag::ToolTip)
	{
		std::shared_ptr<ToolTip> toolTip = std::make_shared<ToolTip>();
		toolTip->Init(anObject, someObjectProperties);
		aMenuScene->AddToolTip(toolTip);
	}
	else if (tag == Tag::ActionBar && hasActionBarData)
	{
		/*auto bar = std::make_shared<ActionBar>();

		const Tga::Vector2f anchorPos{ anObject.GetPosition().x, anObject.GetPosition().y };

		bar->Init(*aMenuScene, ab.barId, ab.slotCount, anchorPos);

		ActionBarLayout layout{};
		layout.columns = ab.columns;
		layout.rows = ab.rows;
		layout.iconSize = ab.iconSize;
		layout.padding = ab.padding;
		layout.snapToGrid = ab.snapToGrid;
		layout.gridSize = ab.gridSize;

		bar->SetLayout(layout);
		bar->SetVisible(ab.visible);

		aMenuScene->AddActionBar(bar);*/

		return; // viktigt: s� vi inte skapar sprite/button av samma objekt
	}
	else
	{
		GameSprite gameSprite;
		gameSprite.Init(flipbookData, anObject);
		aMenuScene->AddSprite(std::make_shared<GameSprite>(gameSprite));
	}

	if (tag == Tag::Button)
	{
		std::cout << "BUTTON OBJ: " << anObject.GetName()
			<< " buttonType=" << (int)buttonType << "\n";
	}
}

void SceneManager::BuildTerrainObject(const PropertyApplier& aPropertyApplier, const std::shared_ptr<GameScene> gameScene, const std::vector<Tga::ScenePropertyDefinition>& someObjectProperties, const Tga::Matrix4x4f& anObjectTransform)
{
	std::shared_ptr<GameObject> gameObject = std::make_shared<GameObject>();
	gameObject->Init();

	aPropertyApplier.ApplyGeneralProperties(gameObject, someObjectProperties, anObjectTransform);

	//Todo remove this workaround if possible
	Vector3f position;
	Quaternionf rotation;
	Vector3f scale;
	anObjectTransform.DecomposeMatrix(position, rotation, scale);
	gameObject->SetTerrain(true);
	gameObject->SetScale(scale);
	gameScene->AddGameObject(gameObject);
}

SceneID SceneManager::ReturnSceneID(const char* aFilePath)
{
	static const std::unordered_map<std::string_view, SceneID> sceneLookUp =
	{
		{TGS_LEVEL_1_NAME, SceneID::Level1},
		{TGS_LEVEL_2_NAME, SceneID::Level2},
		{TGS_ASSET_GYM_NAME, SceneID::AssetGym},
		{TGS_AI_GYM_NAME, SceneID::AIGym},
		{TGS_PLAYER_GYM_NAME, SceneID::PlayerGym},
		{TGS_VFX_GYM_NAME, SceneID::VFXGym},
		{TGS_ANIMATION_GYM_NAME, SceneID::AnimationGym},
		{TGS_MAIN_MENU_NAME, SceneID::MainMenu},
		{TGS_CREDITS_MENU_NAME, SceneID::Credits},
		{TGS_LEVELSELECT_MENU_NAME, SceneID::LevelSelect},
		{TGS_OPTIONS_MENU_NAME, SceneID::Options},
		{TGS_PAUSE_MENU_NAME, SceneID::Pause}
	};

	auto pair = sceneLookUp.find(aFilePath);

	if (pair != sceneLookUp.end())
	{
		return pair->second;
	}

	myCustomScenePath = aFilePath;

	return SceneID::Custom;
}

const char* SceneManager::ReturnSceneFilePath(SceneID aSceneID)
{
	static const std::unordered_map<SceneID, std::string_view> filePathLookUp =
	{
		{SceneID::Level1, TGS_LEVEL_1_NAME},
		{SceneID::Level2, TGS_LEVEL_2_NAME},
		{SceneID::AssetGym, TGS_ASSET_GYM_NAME},
		{SceneID::AIGym, TGS_AI_GYM_NAME},
		{SceneID::PlayerGym, TGS_PLAYER_GYM_NAME},
		{SceneID::VFXGym, TGS_VFX_GYM_NAME},
		{SceneID::AnimationGym, TGS_ANIMATION_GYM_NAME},
		{SceneID::MainMenu, TGS_MAIN_MENU_NAME},
		{SceneID::Credits, TGS_CREDITS_MENU_NAME},
		{SceneID::LevelSelect, TGS_LEVELSELECT_MENU_NAME},
		{SceneID::Options, TGS_OPTIONS_MENU_NAME},
		{SceneID::HUD, TGS_HUD_NAME},
		{SceneID::HudMainMenu, TGS_HUDMAINMENU_NAME},
		{SceneID::Pause, TGS_PAUSE_MENU_NAME}
	};

	auto pair = filePathLookUp.find(aSceneID);

	if (pair != filePathLookUp.end())
	{
		return pair->second.data();
	}

	return nullptr;
}

void SceneManager::SetLightFromSceneSettings(Tga::Scene& aScene)
{
	RenderManager& renderManager = *GameWorld::GetInstance().GetRenderManager().lock();
	NCE::RenderResources& renderResources = renderManager.GetRenderResources();

	DirectionalLight* dirLight = renderResources.directionalLight.get();
	AmbientLight* amLight = renderResources.ambientLight.get();

	LightPreviewSettings lightSettings = aScene.GetSettings().myLightSettings;

	Vector3f const rotation = { lightSettings.directionalLightPitch, lightSettings.directionalLightYaw, 0.f };

	if (dirLight)
	{
		*dirLight = DirectionalLight{ Matrix4x4f::CreateFromRollPitchYaw(rotation), lightSettings.directionalLightColor, lightSettings.directionalLightColorMultiplier };
	}
	else
	{
		renderResources.directionalLight = std::make_shared<DirectionalLight>(DirectionalLight{ Matrix4x4f::CreateFromRollPitchYaw(rotation), lightSettings.directionalLightColor, lightSettings.directionalLightColorMultiplier });
	}
	renderResources.directionalLight->SetRotation(rotation);

	if (!amLight)
	{
		std::wstring cubeMap = string_cast<std::wstring>(Settings::ResolveGameAssetPath("assets/lights/cubemap/T_Cubemap.dds"));
		renderResources.ambientLight = std::make_shared<AmbientLight>();
		amLight = renderResources.ambientLight.get();
	}
	renderResources.ambientLight->SetColor(lightSettings.ambientColor);
	renderResources.ambientLight->SetIntensity(lightSettings.ambientColorMultiplier);
}
