#pragma once

#include <memory>
#include <mutex>
#include <vector>
#include "RunTimeScene.h"
#include "../States/Hud/HUD.h"
#include "../Events/EventManager.h"
#include <tge/Scene/ScenePropertyTypes.h>
#include "../Events/ScriptedEventManager.h"
#include <tge/render/Decal.h>

namespace Tga
{
	class DirectionalLight;
	class AmbientLight;
}

class Collider;
class SpawnedObject;
class Bound;
class Player;
class Actor;
class Navmesh;
class GameObject;
class DestructibleObject;
class PickupObject;
class NCE::Decal;

namespace Tga
{
	class PointLight;
}


class GameScene : public RunTimeScene, public Observer
{
public:
	friend class RenderManager;
	GameScene() = default;
	~GameScene() override = default;

	void Update(float aDeltaTime) override;
	void OnEnter(SceneManager& aSceneManager, StateStack& aStateStack) override;
	void OnExit() override;
	void ResetDeletedObjects();

	void ReceiveEvent(const Message& aMessage) override;
	void AddGameObject(const std::shared_ptr<GameObject>& aGameObject, bool aMarkForAdd = false); //todo: Should prob remove aMarkForAdd next project
	void AddStaticObject(const std::shared_ptr<GameObject>& aStaticGameObject);
	void RemoveStaticObjectByTag(const Tga::Tag aTag);
	void AddSpawnedObject(const std::shared_ptr<SpawnedObject>& aSpawnedObject);
	void AddDecal(const std::shared_ptr<NCE::Decal>& aDecal);
	void AddPointLight(const std::shared_ptr<Tga::PointLight>& aPointLight);
	void AddDirectionalLight(const std::shared_ptr<Tga::DirectionalLight>& aDirectionalLight);
	void SetAmbientLight(const std::shared_ptr<Tga::AmbientLight>& anAmbientLight);
	void AddPlayer(const std::shared_ptr<Player>& aPlayer);

	const std::weak_ptr<Player>& GetPlayer() const;
	const std::vector<std::shared_ptr<GameObject>>& GetGameObjects() const;
	const std::vector<std::shared_ptr<Tga::PointLight>>& GetPointLights() const;
	std::vector<std::shared_ptr<Tga::PointLight>>& GetPointLights();
	const std::vector<std::shared_ptr<Tga::DirectionalLight>>& GetDirectionalLights() const;
	std::vector<std::shared_ptr<SpawnedObject>>& GetSpawnedObjects();
	std::vector<std::shared_ptr<NCE::Decal>>& GetDecals();
	void AddNavmesh(const std::shared_ptr<Navmesh>& aNavmesh);
	const std::shared_ptr<Navmesh>& GetNavmesh() const;
	std::shared_ptr<Navmesh>& GetNavmesh();
	std::vector<std::weak_ptr<Actor>> GetActorsInBounds(const std::shared_ptr<Bound>& aBound) const;
	std::vector<std::weak_ptr<DestructibleObject>> GetDestructibleObjectsInBounds(const std::shared_ptr<Bound>& aBound) const;
	std::vector<std::weak_ptr<PickupObject>> GetPickupObjectsInBounds(const std::shared_ptr<Bound>& aBound) const;
	std::vector<std::weak_ptr<Actor>> GetActors() const;
	std::vector<std::weak_ptr<GameObject>> GetStaticObjectsInBounds(const std::shared_ptr<Bound>& aBound) const;
	Tga::Vector3f CheckStaticCollisions(const std::shared_ptr<Collider>& aCollider) const;
	// If we need gameobjects by editable reference. But preferably not.
	//std::vector<std::shared_ptr<GameObject>>& EditObjects() { return myGameObjects; }

	HUD* GetHUD() { return myHUD.get(); }     
	void RenderHUD();
	void RenderHUDGrid(bool aShowGrid);
	void RemoveGameObject(std::shared_ptr<GameObject>& anObjToRemove);
	void SetAllObjectsWithTagToMarkForDelete(const Tga::Tag aTag);

private:
	std::weak_ptr<Player> myPlayer;
	std::shared_ptr<Navmesh> myNavmesh;
	std::vector<std::shared_ptr<GameObject>> myGameObjects;
	std::vector<std::shared_ptr<GameObject>> myGameObjectsToAdd;
	std::vector<std::shared_ptr<GameObject>> myDeletedGameObjects;
	std::vector<std::weak_ptr<GameObject>> myStaticObjects;
	std::vector<std::shared_ptr<SpawnedObject>> mySpawnedObjects;
	std::vector <std::shared_ptr<NCE::Decal>> myDecals;
	std::vector<std::shared_ptr<Tga::PointLight>> myPointLights;
	std::vector<std::shared_ptr<Tga::DirectionalLight>> myDirectionalLights;
	std::shared_ptr<Tga::AmbientLight> myAmbientLight;
	std::mutex myGameObjectsMutex;
	std::mutex myGameObjectsToAddMutex;
	std::mutex myStaticObjectsMutex;
	std::mutex mySpawnedObjsMutex;
	std::mutex myLightsMutex;
	std::mutex myDecalsMutex;

	std::shared_ptr<HUD> myHUD;
	std::vector<std::vector<std::shared_ptr<GameObject>>::iterator> myIterators;

	bool shouldReset = false;
	bool myEventIsPlaying = false;
	Tga::ScriptedEventType myScriptedEventType;
	ScriptedEventManager myScriptedEvent;
};