#include "stdafx.h"
#include "PropertyApplier.h"

#include "../Objects/GameObject.h"
#include "../GameWorld.h"
#include <tge/model/ModelFactory.h>
#include <tge/shaders/ModelShader.h>
#include "../Collisions/Narrow/BoxCollider.h"
#include "../Collisions/Narrow/SphereCollider.h"
#include <tge/texture/TextureManager.h>

#include "../Collisions/Narrow/CapsuleCollider.h"
#include "../Objects/AnimatedObject.h"
#include <tge/render/EffectMaterial.h>
#include "../Render/RenderManager.h"

#include <tge/model/ModelInstance.h>
#include <tge/scene/ScenePropertyTypes.h>
#include <tge/shaders/SpriteShader.h>

#include <mutex>

#include "GameScene.h"
#include "tge/graphics/DirectionalLight.h"
#include "tge/graphics/PointLight.h"

#include <tge/model/AnimatedModelInstance.h>

using namespace Tga;

PropertyApplier::PropertyApplier(): myTextureManager(Tga::Engine::GetInstance()->GetTextureManager()), myModelFactory(ModelFactory::GetInstance())
{}

void PropertyApplier::ApplyGeneralProperties(std::shared_ptr<GameObject>& aGameObject, const std::vector<ScenePropertyDefinition>& someObjectProperties, const Matrix4x4f& aTransform) const
{
    std::shared_ptr<Tga::ModelShader> shader = nullptr;
    for (auto& property : someObjectProperties)
    {
        // --- Model ---
        if (property.type == GetPropertyType<CopyOnWriteWrapper<SceneModel>>())
        {
            const SceneModel& model = property.value.Get<CopyOnWriteWrapper<SceneModel>>()->Get();
            ApplySceneModel(aGameObject, model, aTransform);
        }

        // --- Collider ---
        else if (property.type == GetPropertyType<CopyOnWriteWrapper<ColliderData>>())
        {
            const ColliderData collider = property.value.Get<CopyOnWriteWrapper<ColliderData>>()->Get();
            if (collider.enabled)
            {
                ApplyCollider(aGameObject, collider);
            }
        }

        // --- Animated Model ---
        else if (property.type == GetPropertyType<CopyOnWriteWrapper<SceneAnimatedModel>>())
        {
            const SceneAnimatedModel& anim = property.value.Get<CopyOnWriteWrapper<SceneAnimatedModel>>()->Get();
            ApplyAnimatedModel(aGameObject, anim, aTransform);
        }

        // --- Sprite ---
        else if (property.type == GetPropertyType<CopyOnWriteWrapper<SceneSprite>>())
        {
            const SceneSprite& sceneSprite = property.value.Get<CopyOnWriteWrapper<SceneSprite>>()->Get();
            Apply3DSprite( aGameObject, sceneSprite, aTransform);
        }

        // --- ShouldRender ---
        else if (property.type == GetPropertyType<CopyOnWriteWrapper<ShouldRender>>())
        {
            const ShouldRender& renderFlag = property.value.Get<CopyOnWriteWrapper<ShouldRender>>()->Get();
            aGameObject->SetShouldRender(renderFlag.shouldRender);
        }

        // --- ShouldFade ---
        else if (property.type == GetPropertyType<CopyOnWriteWrapper<ShouldFade>>())
        {
            const ShouldFade& fadeFlag = property.value.Get<CopyOnWriteWrapper<ShouldFade>>()->Get();
            aGameObject->SetShouldFade(fadeFlag.shouldFade);
        }
        // --- Effect Material ---
        else if (property.type == GetPropertyType<CopyOnWriteWrapper<EffectMaterialData>>())
        {
            const EffectMaterialData& effectMaterial = property.value.Get<CopyOnWriteWrapper<EffectMaterialData>>()->Get();
            ApplyEffectMaterial(aGameObject, effectMaterial);
        }
    }

    if (shader)
    {
        aGameObject->GetModelInstance()->SetShader(shader);
    }

    //Create a base instance if there is no model
    if (!aGameObject->GetModelInstance())
    {
        aGameObject->SetModelInstance(std::make_shared<BaseModelInstance>());
        aGameObject->SetTransform(aTransform);
    }
}

void PropertyApplier::ApplySceneModel(std::shared_ptr<GameObject>& aGameObject, const SceneModel& aModel, const Matrix4x4f& aTransform) const
{
	std::shared_ptr<ModelInstance> instance = myModelFactory.GetModelInstance(aModel);
	
    instance->SetTransform(aTransform);

    instance->SetRasterizerState(aModel.rasterizerState);
    instance->SetBlendState(aModel.blendState);
    instance->SetCastsShadow(aModel.castsShadow);
    if (aModel.canBePainted && !aModel.paintWeights.empty())
    {
        instance->SetPaintWeights(aModel.paintWeights);
    }
    aGameObject->SetRenderType(RenderType::Model);
    aGameObject->SetModelInstance(instance);
}

void PropertyApplier::ApplyCollider(std::shared_ptr<GameObject>& aGameObject, const ColliderData& aColliderData)
{
    switch (aColliderData.type)
    {
	    case ColliderType::Box:
	    {
	        aGameObject->CreateCollider(std::make_shared<BoxCollider>(aGameObject, aColliderData.offset, aColliderData.boxSize));
	        break;
	    }
	    case ColliderType::Sphere:
	    {
	        aGameObject->CreateCollider(std::make_shared<SphereCollider>(aGameObject, aColliderData.offset, aColliderData.radius));
	        break;
	    }
        case ColliderType::Capsule:
	    {
	        aGameObject->CreateCollider(std::make_shared<CapsuleCollider>(aGameObject, aColliderData.offset, aColliderData.radius, aColliderData.height, aColliderData.direction));
	        break;
	    }
    }
}

void PropertyApplier::ApplyAnimatedModel(std::shared_ptr<GameObject>& aGameObject, const SceneAnimatedModel& aAnimatedModel, const Matrix4x4f& aTransform) const
{
	const std::shared_ptr<AnimatedModelInstance> modelInstance = myModelFactory.GetAnimatedModelInstance(aAnimatedModel, aGameObject);
	
    modelInstance->SetTransform(aTransform);
	modelInstance->SetRasterizerState(aAnimatedModel.rasterizerState);
	modelInstance->SetCastsShadow(aAnimatedModel.castsShadow);
    aGameObject->SetRenderType(RenderType::AnimatedModel);
	aGameObject->SetModelInstance(modelInstance);
}

void PropertyApplier::Apply3DSprite(std::shared_ptr<GameObject>& aGameObject, const SceneSprite& aSprite, const Matrix4x4f& aTransform) const
{
    RenderManager& renderManager = *GameWorld::GetInstance().GetRenderManager().lock();
    NCE::RenderResources& renderResources = renderManager.GetRenderResources();

    // ***** BUILD CACHE KEY *****
    SpriteSharedDataKey cacheKey;
    cacheKey.texture0 = aSprite.textures[0];
    cacheKey.texture1 = aSprite.textures[1];
    cacheKey.texture2 = aSprite.textures[2];
    cacheKey.texture3 = aSprite.textures[3];
    cacheKey.pixelShader = aSprite.shader.pixel;
    cacheKey.isBillboard = aSprite.hasBillBoardEffect;
    cacheKey.rasterizerState = aSprite.rasterizerState;
    cacheKey.blendState = aSprite.blendState;
    cacheKey.depthStencilState = aSprite.depthStencilState;
    cacheKey.samplerFilter = aSprite.samplerfilter;

    // Try to reuse shared data
    std::scoped_lock lock(renderResources.mySpriteCacheMutex);

    auto sharedIt = renderResources.mySpriteSharedDataTest.find(cacheKey);
    if (sharedIt == renderResources.mySpriteSharedDataTest.end())
    {
        // Create new shared data
        Tga::SpriteSharedData sharedData = {};

        auto LoadIfNotEmpty = [&](const Tga::StringId& aStringId, TextureSrgbMode aMode) -> Texture*
            {
                const char* p = aStringId.GetString();
                if (!p || p[0] == '\0')
                {
                    return nullptr;
                }
                return myTextureManager.GetTexture(p, aMode);
            };

        sharedData.myTexture = LoadIfNotEmpty(aSprite.textures[0], TextureSrgbMode::ForceSrgbFormat);
        sharedData.myMaps[0] = LoadIfNotEmpty(aSprite.textures[1], TextureSrgbMode::ForceNoSrgbFormat);
        sharedData.myMaps[1] = LoadIfNotEmpty(aSprite.textures[2], TextureSrgbMode::ForceNoSrgbFormat);
        sharedData.myMaps[2] = LoadIfNotEmpty(aSprite.textures[3], TextureSrgbMode::ForceNoSrgbFormat);
        sharedData.isBillboard = aSprite.hasBillBoardEffect;
        sharedData.rasterizerState = aSprite.rasterizerState;
        sharedData.depthStencilState = aSprite.depthStencilState;
        sharedData.samplerFilter = aSprite.samplerfilter;
        sharedData.blendState = aSprite.blendState;

        // Optional custom pixel shader 
        if (!aSprite.shader.pixel.IsEmpty())
        {
            const char* pixelPath = aSprite.shader.pixel.GetString();
            Tga::StringId shaderID = Tga::StringRegistry::RegisterOrGetString(pixelPath);

            auto shaderIt = renderResources.mySpriteShaders.find(shaderID);
            if (shaderIt == renderResources.mySpriteShaders.end())
            {
                auto shader = std::make_unique<Tga::SpriteShader>();
                shader->Init("Shaders/instanced_sprite_shader_VS", pixelPath);
                sharedData.myCustomShader = shader.get();
                renderResources.mySpriteShaders.emplace(shaderID, std::move(shader));
            }
            else
            {
                sharedData.myCustomShader = shaderIt->second.get();
            }
        }

        sharedIt = renderResources.mySpriteSharedDataTest.emplace(cacheKey, std::make_shared<SpriteSharedData>(sharedData)).first;
    }

    std::shared_ptr<Sprite3DInstanceData> instance = std::make_shared<Sprite3DInstanceData>();
    instance->mySize = aSprite.size;
    instance->myTransform = aTransform;

    aGameObject->SetRenderType(RenderType::Sprite);
    aGameObject->Set3DSpriteInstance(std::move(instance));
    aGameObject->SetSpriteSharedData(sharedIt->second);
}

void PropertyApplier::ApplyEffectMaterial(std::shared_ptr<GameObject>& aGameObject, const EffectMaterialData& aEffectMaterialData) const
{
    std::shared_ptr<EffectMaterial> effectMaterial = std::make_shared<EffectMaterial>();

    EffectParameters effectParameters;

    effectParameters.customParametersVector4 = aEffectMaterialData.customParameterVector4;
    effectParameters.customParametersVector2 = aEffectMaterialData.customParameterVector2;
    effectParameters.customParametersVector2second = aEffectMaterialData.customParameterVector2second;
    effectParameters.customParameter1 = aEffectMaterialData.customParameter1;
    effectParameters.customParameter2 = aEffectMaterialData.customParameter2;
    effectParameters.customParameter3 = aEffectMaterialData.customParameter3;
    effectParameters.customParameter4 = aEffectMaterialData.customParameter4;
    effectParameters.customParameter5 = aEffectMaterialData.customParameter5;
    effectParameters.customParameter6 = aEffectMaterialData.customParameter6;

    effectMaterial->SetEffectParameters(effectParameters);

    for (int i = 0; i < MAX_CUSTOM_TEXTURES; i++)
    {
        if (!aEffectMaterialData.textures[i].IsEmpty())
        {
            TextureSrgbMode srgbMode = aEffectMaterialData.isSRGB[i] ? TextureSrgbMode::ForceSrgbFormat : TextureSrgbMode::ForceNoSrgbFormat;
            Texture* texture = myTextureManager.GetTexture(aEffectMaterialData.textures[i].GetString(), srgbMode);

            if (texture)
            {
                effectMaterial->SetTexture(i, texture);
            }
        }
    }

    aGameObject->SetEffectMaterial(std::move(effectMaterial));
}

void PropertyApplier::BuildAndAddLightObject(std::vector<Tga::ScenePropertyDefinition>& someObjectProperties, const Tga::Matrix4x4f& anObjectTransform, const std::shared_ptr<GameScene>& aGameScene) const
{
    RenderManager& renderManager = *GameWorld::GetInstance().GetRenderManager().lock();
    NCE::RenderResources& renderResources = renderManager.GetRenderResources();

	std::shared_ptr<ModelInstance> instance;

	for (auto& property : someObjectProperties)
	{
        // --- Model ---
        if (property.type == GetPropertyType<CopyOnWriteWrapper<SceneModel>>())
        {
            const SceneModel& model = property.value.Get<CopyOnWriteWrapper<SceneModel>>()->Get();

            instance = myModelFactory.GetModelInstance(model);

            instance->SetTransform(anObjectTransform);

            if (model.shader.pixel.IsEmpty() || model.shader.vertex.IsEmpty())
            {
                instance->SetShader(nullptr);
            }

            instance->SetRasterizerState(model.rasterizerState);
            instance->SetBlendState(model.blendState);
            break;
        }
	}


    for (auto& property : someObjectProperties)
    {
	    // --- Light Type ---
    	if (property.type == GetPropertyType<CopyOnWriteWrapper<SceneLight>>())
    	{
    		const SceneLight& light = property.value.Get<CopyOnWriteWrapper<SceneLight>>()->Get();
            LightType lightType = light.lightType;
    		float intensity = light.intensity;
            float lightRange = light.range;
            Tga::Vector3f rotation = light.rotation;
            Tga::Color color = light.color;

    		if (lightType == LightType::PointLight)
    		{
    			instance->GetTransform().Scale(lightRange * 1.05f);
    			const std::shared_ptr<PointLight> pointLight = std::make_shared<PointLight>(instance->GetTransform(), color, intensity, lightRange);
    			pointLight->SetModelInstance(instance);
    			aGameScene->AddPointLight(pointLight);
    		}
    		else if (lightType == LightType::DirectionalLightVolume)
    		{
                rotation = light.rotation;
    			Matrix4x4f lightTransform = Matrix4x4f::CreateFromRollPitchYaw(rotation);
    			Vector3f const forward = lightTransform.GetForward().GetNormalized();
    			lightTransform.SetPosition(forward * 800.f);
    			instance->GetTransform().Scale(lightRange * 1.05f);
    			const std::shared_ptr<DirectionalLight> directionalLightBoundingVolume = std::make_shared<DirectionalLight>(lightTransform, color, intensity);
    			directionalLightBoundingVolume->SetRotation(rotation);
    			directionalLightBoundingVolume->SetModelInstance(instance);
    			directionalLightBoundingVolume->SetRange(lightRange * 1.05f);
    			aGameScene->AddDirectionalLight(directionalLightBoundingVolume);
    		}
    		else if (lightType == LightType::MainDirectionalLight)
    		{
    			Matrix4x4f lightTransform = Matrix4x4f::CreateFromRollPitchYaw(rotation);
    			Vector3f const forward = lightTransform.GetForward().GetNormalized();
    			lightTransform.SetPosition(forward * 800.f);

    			auto dLight = DirectionalLight(lightTransform, color, intensity);
    			renderResources.directionalLight = std::make_shared<DirectionalLight>(dLight);
    			renderResources.directionalLight->SetRotation(rotation);
    		}
    		else if (lightType == LightType::AmbientLight)
    		{
                std::wstring cubeMap;
    			if (!light.cubemap.IsEmpty())
    			{
    				//cubeMap = string_cast<std::wstring>(light.cubemap.GetString());
                    cubeMap = string_cast<std::wstring>(Settings::ResolveGameAssetPath(light.cubemap.GetString()));
				}
    			else
    			{
    				cubeMap = string_cast<std::wstring>(Settings::ResolveGameAssetPath("assets/lights/cubemap/T_Cubemap.dds"));
    			}

    			auto aLight = AmbientLight(cubeMap, color, intensity);

    			renderResources.ambientLight = std::make_shared<AmbientLight>(aLight);
    		}
    	}
    }
}

void PropertyApplier::BuildAndAddDecal(std::vector<Tga::ScenePropertyDefinition>& someObjectProperties, const Tga::Matrix4x4f& anObjectTransform, const std::shared_ptr<GameScene>& aGameScene) const
{
    std::shared_ptr<ModelInstance> instance;

    uint32_t texturesEnabled[4] = { false, false, false, false };

    for (auto& property : someObjectProperties)
    {
        if (property.type == GetPropertyType<CopyOnWriteWrapper<SceneDecal>>())
        {
            const SceneDecal& decalData = property.value.Get<CopyOnWriteWrapper<SceneDecal>>()->Get();

            instance = myModelFactory.GetModelInstance("Models/cube.fbx");
            Tga::Model* model = instance->GetModel().get();
            for (int i = 0; i < 4; i++)
            {
                TextureSrgbMode srgbMode = i == 0 ? TextureSrgbMode::ForceSrgbFormat : TextureSrgbMode::ForceNoSrgbFormat;
                TextureResource* texture = nullptr;
                if (!decalData.textures[i].IsEmpty())
                {
                    texture = myTextureManager.GetTexture(decalData.textures[i].GetString(), srgbMode);
                    if (texture)
                    {
                        texturesEnabled[i] = true;
                    }
                }
                else
                {
                        model->GetDefaultTextures(0)[i];
                }
                if (texture)
                {
                    instance->SetTexture(0, i, texture);
                }
            }
            instance->SetTransform(anObjectTransform);

            Tga::ModelShader shader;
            shader.Init("shaders/Vertex/PbrModelShaderVs", "shaders/Decal_PS");
            instance->SetShader(std::make_shared<Tga::ModelShader>(shader));

            instance->SetRasterizerState(Tga::RasterizerState::FrontfaceCulling);
            instance->SetBlendState(Tga::BlendState::AlphaBlend);
            break;
        }
    }

    std::shared_ptr<NCE::Decal> decal = std::make_shared<NCE::Decal>();
    decal->SetTexturesEnabled(texturesEnabled[0], texturesEnabled[1], texturesEnabled[2], texturesEnabled[3]);
    decal->SetTransform(anObjectTransform);
    decal->SetModelInstance(instance);
    aGameScene->AddDecal(decal);
}
