#pragma once
//#pragma message(__FILE__" was compiled")
#include <memory>
#include <vector>
#include <tge/script/CopyOnWriteWrapper.h>
#include <tge/script/Property.h>
#include <tge/scene/SceneObjectDefinition.h>

class GameScene;
class GameObject;

namespace Tga
{
    class ModelFactory;
	class TextureManager;
    struct ColliderData;
	struct SceneModel;
	struct EffectMaterialData;
	struct SceneSprite;
	struct SceneAnimatedModel;
}

class PropertyApplier
{
public:
    PropertyApplier();

    PropertyApplier(Tga::TextureManager& aTextureManager, Tga::ModelFactory& aModelFactory)
        : myTextureManager(aTextureManager), myModelFactory(aModelFactory) {}
    
    Tga::TextureManager& GetTextureManager() const
    {
        return myTextureManager;
    }

    Tga::ModelFactory& GetModelFactory() const
    {
        return myModelFactory;
    }

    void ApplyGeneralProperties(std::shared_ptr<GameObject>& aGameObject, const std::vector<Tga::ScenePropertyDefinition>& someObjectProperties, const Tga::Matrix4x4f& aTransform) const;
    void BuildAndAddLightObject(std::vector<Tga::ScenePropertyDefinition>& someObjectProperties, const Tga::Matrix4x4f& anObjectTransform, const std::shared_ptr<GameScene>& aGameScene) const;
    void BuildAndAddDecal(std::vector<Tga::ScenePropertyDefinition>& someObjectProperties, const Tga::Matrix4x4f& anObjectTransform, const std::shared_ptr<GameScene>& aGameScene) const;

    template <class Prop>
    static const Tga::CopyOnWriteWrapper<Prop>* FindProperty(const std::vector<Tga::ScenePropertyDefinition>& someObjectProperties);
private:
    void ApplySceneModel(std::shared_ptr<GameObject>& aGameObject, const Tga::SceneModel& aModel, const Tga::Matrix4x4f& aTransform) const;
    static void ApplyCollider(std::shared_ptr<GameObject>& aGameObject, const Tga::ColliderData& aColliderData);
    void ApplyAnimatedModel(std::shared_ptr<GameObject>& aGameObject, const Tga::SceneAnimatedModel& aAnimatedModel, const Tga::Matrix4x4f& aTransform) const;
    void Apply3DSprite(std::shared_ptr<GameObject>& aGameObject, const Tga::SceneSprite& aSprite, const Tga::Matrix4x4f& aTransform) const;
    void ApplyEffectMaterial(std::shared_ptr<GameObject>& aGameObject, const Tga::EffectMaterialData& aEffectMaterialData) const;

    Tga::TextureManager& myTextureManager;
    Tga::ModelFactory& myModelFactory;
};



template <class Prop>
const Tga::CopyOnWriteWrapper<Prop>* PropertyApplier::FindProperty(const std::vector<Tga::ScenePropertyDefinition>& someObjectProperties)
{
    for (auto& scemeProp : someObjectProperties)
    {
        if (scemeProp.type == Tga::GetPropertyType<Tga::CopyOnWriteWrapper<Prop>>())
        {
            return scemeProp.value.Get<Tga::CopyOnWriteWrapper<Prop>>();
        }
    }
    
    return nullptr;
}
