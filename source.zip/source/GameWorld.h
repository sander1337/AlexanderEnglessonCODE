#pragma once

#include "States/StateStack.h"
#include "Utilities/ImGuiDebugWindow.h"

class GameObject;
class RunTimeScene;
class GameScene;
class SceneManager;
class RenderManager;

namespace Tga 
{
	class Scene;
}

class GameWorld
{	
public:
	GameWorld(); 
	~GameWorld();

	void Init(const char* aPath);
	void Update(float aDeltaTime);
	void Render();

	std::weak_ptr<GameScene> GetCurrentGameScene() const;
	std::weak_ptr<RunTimeScene> GetCurrentScene() const;
	std::weak_ptr<SceneManager> GetSceneManager() const;
	std::weak_ptr<RenderManager> GetRenderManager() const;
	const StateStack* GetStateStack() const;
	void UpdateImGui();
	
	static GameWorld& GetInstance() { return *myInstance; }
	[[maybe_unused]] std::weak_ptr<GameObject> LoadAssetToScene(const Tga::StringId& anObjectID, const Tga::Matrix4x4f& aMatrix, bool aMarkForAdd = false);

private:
	std::shared_ptr<SceneManager> mySceneManager;
	std::shared_ptr<RenderManager> myRenderManager;
	StateStack myStateStack;

	//ImGui
	ImGuiDebugWindow myImGuiDebug;
	bool ShowEnemyCircles = true;

	static GameWorld* myInstance;
};